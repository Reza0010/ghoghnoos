#!/usr/bin/env bash
# XAU AI Trader — Control Panel (Linux/macOS launcher)
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
    exec python3 run_panel.py "$@"
else
    echo "python3 not found — install Python 3.10+ first."
    exit 2
fi
