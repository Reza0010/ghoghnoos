"""PHASE 66 (§24) — BROKER_REALTIME_PAPER mode.

Runs the full decision pipeline against REAL broker market data while being
structurally incapable of placing an order:

    real MT5 candles/tick → features → ML → SMC → regime → (AI, optional)
    → risk engine → decision → journal (every decision, incl. WAIT reasons)

For every observation it journals: decision (signal/WAIT + reason), latency,
AI availability, spread, regime. It NEVER calls send_market_order — the
executor used here is a read-only journaling stub and the class asserts the
provider is used read-only.

On Linux (no MT5) it refuses honestly; with a ReplayProvider it can be
integration-tested deterministically (tests/test_phase66_audit.py).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class PaperObservation:
    ts: str
    decision: str                    # BUY / SELL / WAIT
    wait_reason: str | None
    spread: float | None
    regime: str
    ml_prob: list[float] | None
    smc_bias: float | None
    ai_available: bool | None
    latency_ms: float
    risk_status: str
    price: float | None


class BrokerRealtimePaper:
    """Read-only realtime paper loop. NEVER sends orders — by construction."""

    mode_name = "BROKER_REALTIME_PAPER"

    def __init__(self, cfg, provider, bundle, feature_builder, smc_engine,
                 journal_path: str = "logs/realtime_paper.jsonl",
                 poll_seconds: int = 900, min_bars: int = 300,
                 ai_gateway=None) -> None:
        if provider.supports_real_execution:
            # MT5 provider CAN execute — we deliberately do not wire it here.
            logger.warning("%s: provider supports execution; orders are HARD-DISABLED "
                           "in this mode (§24)", self.mode_name)
        self._send_orders = False          # structural guarantee, referenced below
        self.cfg = cfg
        self.provider = provider
        self.bundle = bundle
        self.fb = feature_builder
        self.smc = smc_engine
        self.poll = poll_seconds
        self.min_bars = min_bars
        self.ai = ai_gateway
        self.observations: list[PaperObservation] = []
        self.journal_path = Path(journal_path)
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ run --
    def observe_once(self, symbol: str) -> PaperObservation:
        t0 = time.perf_counter()
        tf = self.cfg.timeframes.base.value
        candles = self.provider.get_candles(symbol, tf, self.min_bars)
        if candles.empty or len(candles) < self.min_bars // 2:
            return self._record(PaperObservation(
                ts=datetime.now(timezone.utc).isoformat(), decision="WAIT",
                wait_reason="INSUFFICIENT_DATA", spread=None, regime="UNKNOWN",
                ml_prob=None, smc_bias=None, ai_available=None,
                latency_ms=(time.perf_counter() - t0) * 1000, risk_status="WAIT",
                price=None))
        spread = float(candles["spread"].iloc[-1]) if "spread" in candles else None
        close = float(candles["close"].iloc[-1])
        regime = self._classify_regime(candles)
        smc_bias = self._smc_bias(candles)
        ml_probs = self._ml_probs(candles)

        decision, reason, risk_status = "WAIT", "NO_SIGNAL", "OK"
        if ml_probs is None:
            decision, reason, risk_status = "WAIT", "MODEL_UNAVAILABLE", "WAIT"
        else:
            side, gate_reason = self._ensemble_gate(ml_probs, smc_bias, regime)
            if side is None:
                decision, reason, risk_status = "WAIT", gate_reason, "WAIT"
            else:
                decision, reason = side, "SIGNAL_ACCEPTED_PAPER_ONLY"

        ai_available = None
        if self.ai is not None:
            ai_available = not getattr(self.ai, "degraded", False)

        obs = PaperObservation(
            ts=candles.index[-1].isoformat(), decision=decision,
            wait_reason=None if decision != "WAIT" else reason,
            spread=spread, regime=regime.name if hasattr(regime, "name") else str(regime),
            ml_prob=[float(p) for p in ml_probs] if ml_probs is not None else None,
            smc_bias=float(smc_bias) if smc_bias is not None else None,
            ai_available=ai_available,
            latency_ms=(time.perf_counter() - t0) * 1000,
            risk_status=risk_status, price=close)
        return self._record(obs)

    def run(self, symbol: str, max_observations: int) -> list[PaperObservation]:
        """Poll until ``max_observations`` collected (or interrupted)."""
        count = 0
        while count < max_observations:
            try:
                self.observe_once(symbol)
                count += 1
            except KeyboardInterrupt:
                break
            except Exception as e:  # never crash the loop — journal and continue
                logger.error("%s observation error: %s", self.mode_name, e)
                time.sleep(self.poll)
                continue
            time.sleep(self.poll)
        return self.observations

    # ------------------------------------------------------------ internals --
    def _record(self, obs: PaperObservation) -> PaperObservation:
        self.observations.append(obs)
        with self.journal_path.open("a", encoding="utf-8") as f:
            f.write(obs_to_json(obs) + "\n")
        assert self._send_orders is False   # structural: no order path exists
        return obs

    def _classify_regime(self, candles: pd.DataFrame):
        from app.config.schema import Regime
        c = candles["close"]
        atr_pct = (candles["high"] - candles["low"]).rolling(14).mean() / c * 100
        adx = self._simple_adx(candles, 14)
        i = -1
        if adx >= self.cfg.regime.adx_trend_min:
            diff = c.diff().iloc[-20:].sum()
            return Regime.TRENDING_BULL if diff > 0 else Regime.TRENDING_BEAR
        if atr_pct.iloc[i] >= self.cfg.regime.high_vol_atr_pct:
            return Regime.HIGH_VOLATILITY
        if atr_pct.iloc[i] <= self.cfg.regime.low_vol_atr_pct:
            return Regime.LOW_VOLATILITY
        return Regime.RANGING

    @staticmethod
    def _simple_adx(candles: pd.DataFrame, period: int = 14) -> float:
        h, l, c = candles["high"], candles["low"], candles["close"]
        up = h.diff()
        dn = -l.diff()
        plus_dm = np.where((up > dn) & (up > 0), up, 0.0)
        minus_dm = np.where((dn > up) & (dn > 0), dn, 0.0)
        tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
        atr = tr.rolling(period).mean()
        with np.errstate(divide="ignore", invalid="ignore"):
            pdi = 100 * pd.Series(plus_dm, index=c.index).rolling(period).mean() / atr
            mdi = 100 * pd.Series(minus_dm, index=c.index).rolling(period).mean() / atr
            dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
        return float(dx.iloc[-1]) if np.isfinite(dx.iloc[-1]) else 0.0

    def _smc_bias(self, candles: pd.DataFrame) -> float | None:
        try:
            res = self.smc.analyze(candles, self.cfg.timeframes.base.value)
            series = res.directional_bias_series(self.cfg.features.event_recent_bars)
            return float(series.iloc[-1]) if len(series) else None
        except Exception as e:
            logger.warning("SMC bias unavailable: %s", e)
            return None

    def _ml_probs(self, candles: pd.DataFrame) -> np.ndarray | None:
        try:
            feats = self.fb.build(candles, self.cfg.timeframes.base.value)
            row = feats.iloc[[-1]].select_dtypes(include=[np.number]).fillna(0.0)
            return self.bundle.average_proba(row)[0]
        except Exception as e:
            logger.warning("ML probability unavailable: %s", e)
            return None

    def _ensemble_gate(self, ml_probs: np.ndarray, smc_bias: float | None,
                       regime) -> tuple[str | None, str]:
        ens = self.cfg.ensemble
        p_dn, p_flat, p_up = float(ml_probs[0]), float(ml_probs[1]), float(ml_probs[2])
        conf = max(p_up, p_dn)
        if conf < ens.min_ml_confidence:
            return None, f"ML_CONFIDENCE_{conf:.2f}_BELOW_{ens.min_ml_confidence}"
        if abs(p_up - p_dn) < ens.ml_conflict_margin:
            return None, "ML_DIRECTION_CONFLICT"
        side = "BUY" if p_up > p_dn else "SELL"
        if smc_bias is not None:
            want = 1.0 if side == "BUY" else -1.0
            if want * float(np.sign(smc_bias or 0)) < 0 and abs(smc_bias) >= ens.smc_conflict_margin:
                return None, "SMC_CONFLICT"
        return side, "GATES_PASSED"


def obs_to_json(o: PaperObservation) -> str:
    import json

    return json.dumps({
        "ts": o.ts, "decision": o.decision, "wait_reason": o.wait_reason,
        "spread": o.spread, "regime": o.regime, "ml_prob": o.ml_prob,
        "smc_bias": o.smc_bias, "ai_available": o.ai_available,
        "latency_ms": round(o.latency_ms, 2), "risk_status": o.risk_status,
        "price": o.price, "mode": "BROKER_REALTIME_PAPER",
        "orders_sent": 0,
    })
