"""v1.4 §21 — Central MT5 retcode policy (single source of truth).

Raw MT5 retcodes / magic action numbers must never be scattered through
business logic. Every known retcode maps to exactly ONE policy class:

    SUCCESS          — deterministic broker acceptance (order lives)
    SUCCESS_PARTIAL  — accepted, partially filled (still deterministic)
    RETRYABLE        — deterministic reject that a refreshed-price retry
                       may legitimately resolve (requote / price moved)
    AMBIGUOUS        — the broker-side outcome is UNKNOWN (timeout,
                       connection lost mid-request, ``order_send`` returned
                       None). Callers MUST reconcile against orders/deals/
                       positions before doing ANYTHING else. Blind retry
                       here is how duplicate positions are born.
    FATAL            — deterministic reject; retrying cannot help
                       (invalid stops, no money, market closed, ...)

Official reference:
https://www.mql5.com/en/docs/python_metatrader5/mt5ordersend_py
"""

from __future__ import annotations

from enum import Enum


class RetcodePolicy(str, Enum):
    SUCCESS = "SUCCESS"
    SUCCESS_PARTIAL = "SUCCESS_PARTIAL"
    RETRYABLE = "RETRYABLE"
    AMBIGUOUS = "AMBIGUOUS"
    FATAL = "FATAL"
    UNKNOWN = "UNKNOWN"


# --- Official MT5 trade return codes (subset that the Python API exposes
#     for order_send / order_check results) -------------------------------
RETCODE_NAMES: dict[int, str] = {
    10004: "TRADE_RETCODE_REQUOTE",
    10006: "TRADE_RETCODE_REJECT",
    10007: "TRADE_RETCODE_CANCEL",
    10008: "TRADE_RETCODE_PLACED",
    10009: "TRADE_RETCODE_DONE",
    10010: "TRADE_RETCODE_DONE_PARTIAL",
    10011: "TRADE_RETCODE_ERROR",
    10012: "TRADE_RETCODE_TIMEOUT",
    10013: "TRADE_RETCODE_INVALID",
    10014: "TRADE_RETCODE_INVALID_VOLUME",
    10015: "TRADE_RETCODE_INVALID_PRICE",
    10016: "TRADE_RETCODE_INVALID_STOPS",
    10017: "TRADE_RETCODE_TRADE_DISABLED",
    10018: "TRADE_RETCODE_MARKET_CLOSED",
    10019: "TRADE_RETCODE_NO_MONEY",
    10020: "TRADE_RETCODE_PRICE_CHANGED",
    10021: "TRADE_RETCODE_PRICE_OFF",
    10022: "TRADE_RETCODE_INVALID_EXPIRATION",
    10023: "TRADE_RETCODE_ORDER_CHANGED",
    10024: "TRADE_RETCODE_TOO_MANY_REQUESTS",
    10025: "TRADE_RETCODE_NO_CHANGES",
    10026: "TRADE_RETCODE_SERVER_DISABLES_AT",
    10027: "TRADE_RETCODE_CLIENT_DISABLES_AT",
    10028: "TRADE_RETCODE_LOCKED",
    10029: "TRADE_RETCODE_FROZEN",
    10030: "TRADE_RETCODE_INVALID_FILL",
    10031: "TRADE_RETCODE_CONNECTION",
    10032: "TRADE_RETCODE_ONLY_REAL",
    10033: "TRADE_RETCODE_LIMIT_PERMISSIONS",
    10034: "TRADE_RETCODE_LIMIT_ORDERS",
    10035: "TRADE_RETCODE_LIMIT_VOLUME",
}

# Well-known retcode values (named so business logic never hardcodes raws)
RETCODE_PLACED = 10008
RETCODE_DONE = 10009
RETCODE_DONE_PARTIAL = 10010

RETCODE_POLICY: dict[int, RetcodePolicy] = {
    # deterministic acceptances
    10008: RetcodePolicy.SUCCESS,          # PLACED (order accepted, async)
    10009: RetcodePolicy.SUCCESS,          # DONE
    10010: RetcodePolicy.SUCCESS_PARTIAL,  # DONE_PARTIAL
    # deterministic rejects where a refreshed-price retry is legitimate
    10004: RetcodePolicy.RETRYABLE,        # REQUOTE
    10020: RetcodePolicy.RETRYABLE,        # PRICE_CHANGED
    10021: RetcodePolicy.RETRYABLE,        # PRICE_OFF
    10024: RetcodePolicy.RETRYABLE,        # TOO_MANY_REQUESTS (backoff!)
    # outcome UNKNOWN — never retry blindly, reconcile first
    10012: RetcodePolicy.AMBIGUOUS,        # TIMEOUT
    10031: RetcodePolicy.AMBIGUOUS,        # CONNECTION
    # deterministic rejects — retry cannot help
    10006: RetcodePolicy.FATAL,            # REJECT
    10007: RetcodePolicy.FATAL,            # CANCEL
    10011: RetcodePolicy.FATAL,            # ERROR
    10013: RetcodePolicy.FATAL,            # INVALID
    10014: RetcodePolicy.FATAL,            # INVALID_VOLUME
    10015: RetcodePolicy.FATAL,            # INVALID_PRICE
    10016: RetcodePolicy.FATAL,            # INVALID_STOPS
    10017: RetcodePolicy.FATAL,            # TRADE_DISABLED
    10018: RetcodePolicy.FATAL,            # MARKET_CLOSED
    10019: RetcodePolicy.FATAL,            # NO_MONEY
    10022: RetcodePolicy.FATAL,            # INVALID_EXPIRATION
    10023: RetcodePolicy.FATAL,            # ORDER_CHANGED
    10025: RetcodePolicy.FATAL,            # NO_CHANGES
    10026: RetcodePolicy.FATAL,            # SERVER_DISABLES_AT
    10027: RetcodePolicy.FATAL,            # CLIENT_DISABLES_AT
    10028: RetcodePolicy.FATAL,            # LOCKED
    10029: RetcodePolicy.FATAL,            # FROZEN
    10030: RetcodePolicy.FATAL,            # INVALID_FILL
    10032: RetcodePolicy.FATAL,            # ONLY_REAL
    10033: RetcodePolicy.FATAL,            # LIMIT_PERMISSIONS
    10034: RetcodePolicy.FATAL,            # LIMIT_ORDERS
    10035: RetcodePolicy.FATAL,            # LIMIT_VOLUME
}

# Symbol filling-mode bitmask (SYMBOL_FILLING_FOK=1 | SYMBOL_FILLING_IOC=2);
# ORDER_FILLING_RETURN(0) is the terminal default when neither is set.
FILLING_FOK = 1
FILLING_IOC = 2
FILLING_RETURN = 0

# Request actions
TRADE_ACTION_DEAL = 1
TRADE_ACTION_PENDING = 5
TRADE_ACTION_SLTP = 6

# Order types
ORDER_TYPE_BUY = 0
ORDER_TYPE_SELL = 1


def classify(retcode: int | None) -> RetcodePolicy:
    """Map a raw retcode (or None = transport-level failure) to its policy.

    ``None`` (order_send returned nothing at all) and any unrecognised code
    are treated conservatively: None -> AMBIGUOUS, unknown -> FATAL.
    """
    if retcode is None:
        return RetcodePolicy.AMBIGUOUS
    return RETCODE_POLICY.get(int(retcode), RetcodePolicy.FATAL)


def describe(retcode: int | None) -> str:
    if retcode is None:
        return "NO_RESPONSE(order_send returned None)"
    return RETCODE_NAMES.get(int(retcode), f"UNKNOWN_RETCODE_{int(retcode)}")


def choose_filling_mode(symbol_filling_mode: int | None) -> int:
    """Pick a filling mode from the broker's symbol filling-mode bitmask.

    Policy (documented, deterministic): IOC if the broker allows it, else
    FOK, else RETURN. Market execution on most ECN brokers accepts IOC.
    """
    mask = int(symbol_filling_mode or 0)
    if mask & FILLING_IOC:
        return FILLING_IOC
    if mask & FILLING_FOK:
        return FILLING_FOK
    return FILLING_RETURN
