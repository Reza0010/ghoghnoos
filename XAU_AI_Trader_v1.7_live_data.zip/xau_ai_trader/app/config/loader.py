"""Configuration loader: YAML file + .env secrets.

- Secrets come ONLY from environment variables (never from YAML).
- Loader is explicit: entry points call ``load_config`` and pass the
  resulting ``AppConfig`` down; no global mutable state.
"""

from __future__ import annotations

import os
from pathlib import Path

import yaml
from dotenv import load_dotenv

from app.config.schema import AppConfig
from app.core.exceptions import ConfigError


def load_dotenv_file(project_root: str | Path) -> None:
    load_dotenv(Path(project_root) / ".env")


def _normalize_enums(data: dict) -> dict:
    """Make enum-valued string fields case-insensitive (e.g. 'PAPER' → 'paper')."""
    if not isinstance(data, dict):
        return data
    data = dict(data)
    exec_cfg = data.get("execution")
    if isinstance(exec_cfg, dict) and isinstance(exec_cfg.get("mode"), str):
        exec_cfg["mode"] = exec_cfg["mode"].lower()
    return data


def _deep_merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(config_path: str | Path | None = None, project_root: str | Path | None = None) -> AppConfig:
    root = Path(project_root or os.environ.get("XAU_PROJECT_ROOT", Path.cwd()))
    load_dotenv_file(root)
    path = Path(config_path or root / "config.yaml")
    data: dict = {}
    if path.exists():
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as e:
            raise ConfigError(f"Invalid YAML in {path}: {e}") from e
    env_overlay = os.environ.get("XAU_CONFIG_JSON")
    if env_overlay:
        import json

        try:
            data = _deep_merge(data, json.loads(env_overlay))
        except json.JSONDecodeError as e:
            raise ConfigError(f"XAU_CONFIG_JSON is not valid JSON: {e}") from e
    try:
        data = _normalize_enums(data)
        cfg = AppConfig(**data)
    except Exception as e:
        raise ConfigError(f"Configuration validation failed: {e}") from e
    _resolve_paths(cfg, root)
    return cfg


def _resolve_paths(cfg: AppConfig, root: Path) -> None:
    p = cfg.paths
    for field in ("data_dir", "models_dir", "reports_dir", "logs_dir"):
        val = Path(getattr(p, field))
        if not val.is_absolute():
            val = root / val
        val.mkdir(parents=True, exist_ok=True)
        setattr(p, field, str(val))
    ks = Path(cfg.kill_switch.state_file)
    if not ks.is_absolute():
        ks = root / ks
    ks.parent.mkdir(parents=True, exist_ok=True)
    cfg.kill_switch.state_file = str(ks)
    news_csv = Path(cfg.news.csv_path)
    if not news_csv.is_absolute():
        news_csv = root / news_csv
    cfg.news.csv_path = str(news_csv)


def require_env(name: str) -> str:
    val = os.environ.get(name)
    if not val:
        raise ConfigError(f"Required environment variable '{name}' is not set")
    return val


def get_env(name: str) -> str | None:
    return os.environ.get(name)
