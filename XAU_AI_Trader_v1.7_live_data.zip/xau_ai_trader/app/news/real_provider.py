"""PHASE 66 (§16) — REAL news provider contract + validation status.

STATUS: NEWS_VALIDATION_PENDING.

The abstraction below defines exactly what a real economic-calendar provider
must deliver (timestamp, event, currency, impact, previous, forecast, actual,
source, URL, release time). NO genuinely accessible free provider has been
integrated in this phase; MockNewsProvider / sample CSV are explicitly
FORBIDDEN as substitutes for real validation (§16). Until a concrete provider
is plugged in and verified, every report must carry NEWS_VALIDATION_PENDING.
"""

from __future__ import annotations

from abc import abstractmethod
from datetime import datetime

from app.news.models import NewsEvent
from app.news.providers import NewsProvider

NEWS_VALIDATION_PENDING = "NEWS_VALIDATION_PENDING"


class RealNewsProvider(NewsProvider):
    """Contract for a REAL economic calendar provider.

    Implementations must populate every field below from a live, attributable
    source. Impact must be normalised to LOW/MEDIUM/HIGH. URL must point to
    the provider's own event page for auditability.
    """

    name = "real"

    @abstractmethod
    def get_events(self, start: datetime, end: datetime) -> list[NewsEvent]:
        """Return real events in [start, end]. Raise on provider failure —
        the engine degrades to UNKNOWN risk; it must NOT guess."""

    @staticmethod
    def required_fields() -> list[str]:
        return ["time", "event", "currency", "impact/importance", "previous",
                "forecast", "actual", "source", "url", "release_time"]

    @staticmethod
    def validation_status() -> str:
        return NEWS_VALIDATION_PENDING


def news_validation_status(provider: NewsProvider | None) -> dict:
    """Honest status helper used by reports (§16/§26)."""
    if provider is None:
        return {"status": NEWS_VALIDATION_PENDING,
                "reason": "no news provider configured — NEWS-NEUTRAL assumption used"}
    kind = type(provider).__name__
    real = isinstance(provider, RealNewsProvider)
    return {
        "status": "REAL_PROVIDER_IMPLEMENTED" if real else NEWS_VALIDATION_PENDING,
        "provider_class": kind,
        "note": ("mock/static providers are NOT substitutes for real news "
                 "validation (§16) — any report using them must say so"),
    }
