"""News risk engine: LOW / MEDIUM / HIGH + reason codes.

HIGH risk within the configured window is a hard WAIT (config enforced in
the risk engine). UNKNOWN (provider failure) defaults to WAIT as well.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from app.config.schema import NewsConfig, NewsRisk
from app.news.models import NewsEvent
from app.news.providers import NewsProvider


@dataclass
class NewsAssessment:
    risk: NewsRisk
    reasons: list[str] = field(default_factory=list)
    upcoming: list[NewsEvent] = field(default_factory=list)
    provider_healthy: bool = True

    def to_market_state(self) -> dict:
        return {
            "risk": self.risk.value,
            "reasons": self.reasons,
            "upcoming": [
                {"event": e.event, "currency": e.currency, "importance": e.importance,
                 "time": e.time.isoformat()}
                for e in self.upcoming[:5]
            ],
        }


class NewsEngine:
    def __init__(self, provider: NewsProvider, cfg: NewsConfig) -> None:
        self.provider = provider
        self.cfg = cfg

    def assess(self, now: datetime | None = None, symbol_currency: str = "USD") -> NewsAssessment:
        now = now or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        window_start = now - timedelta(minutes=max(self.cfg.high_after_minutes, self.cfg.medium_after_minutes))
        window_end = now + timedelta(minutes=max(self.cfg.high_before_minutes, self.cfg.medium_before_minutes))
        try:
            events = self.provider.get_events(window_start, window_end)
        except Exception:
            events = []
        healthy = self.provider.healthy()
        if not events and not healthy:
            return NewsAssessment(risk=NewsRisk.UNKNOWN,
                                  reasons=["NEWS_PROVIDER_UNAVAILABLE"],
                                  provider_healthy=False)
        # v1.5 (Mission 21 / finding 19): freshness gate — a provider whose
        # data cannot be proven current yields UNKNOWN (WAIT), never LOW.
        if healthy and not self.provider.is_fresh():
            return NewsAssessment(risk=NewsRisk.UNKNOWN,
                                  reasons=["NEWS_PROVIDER_STALE"],
                                  provider_healthy=healthy)

        # v1.5 fix (news-N2): the currency filter used a per-EVENT-independent
        # clause — with symbol_currency="XAU" every event of ANY currency
        # counted (a EUR HIGH event would hard-WAIT the system). Gold is
        # USD-priced: only the configured currencies filter, and XAU maps
        # to USD events by construction.
        wanted = {c.upper() for c in self.cfg.currencies}
        if symbol_currency and symbol_currency.upper() not in wanted:
            wanted.add(symbol_currency.upper())
        relevant = [e for e in events if e.currency.upper() in wanted]
        risk = NewsRisk.LOW
        reasons: list[str] = []
        upcoming: list[NewsEvent] = []
        for e in relevant:
            delta_min = (e.time - now).total_seconds() / 60.0
            if e.importance == "HIGH":
                before, after = self.cfg.high_before_minutes, self.cfg.high_after_minutes
            elif e.importance == "MEDIUM":
                before, after = self.cfg.medium_before_minutes, self.cfg.medium_after_minutes
            else:
                continue
            if -after <= delta_min <= before:
                upcoming.append(e)
                level = "HIGH" if e.importance == "HIGH" else "MEDIUM"
                if level == "HIGH":
                    risk = NewsRisk.HIGH
                elif level == "MEDIUM" and risk != NewsRisk.HIGH:
                    risk = NewsRisk.MEDIUM
                reasons.append(
                    f"{e.event} ({e.currency}, {e.importance}) at {e.time.strftime('%H:%M')} UTC "
                    f"({'in ' + str(int(delta_min)) + 'm' if delta_min >= 0 else str(int(-delta_min)) + 'm ago'})"
                )
        return NewsAssessment(risk=risk, reasons=reasons[:6], upcoming=upcoming[:5],
                              provider_healthy=healthy)
