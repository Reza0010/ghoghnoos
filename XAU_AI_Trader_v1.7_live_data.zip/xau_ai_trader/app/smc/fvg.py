"""Fair Value Gaps (3-candle imbalance)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.smc.types import Direction, SMCEvent, SMCEventType


def detect_fvgs(df: pd.DataFrame, atr: pd.Series, timeframe: str,
                min_atr: float = 0.25) -> list[SMCEvent]:
    """Bull FVG: low[i] > high[i-2]  (gap between candle i-2 high and i low).
    Bear FVG: high[i] < low[i-2]. Emitted at bar i where the gap completes."""
    events: list[SMCEvent] = []
    high = df["high"].values
    low = df["low"].values
    a = atr.values
    for i in range(2, len(df)):
        av = a[i] if not np.isnan(a[i]) else np.nan
        if np.isnan(av) or av <= 0:
            continue
        if low[i] > high[i - 2]:
            size = low[i] - high[i - 2]
            if size >= min_atr * av:
                events.append(SMCEvent(
                    type=SMCEventType.FVG_BULL, direction=Direction.BULLISH, timeframe=timeframe,
                    price=float((low[i] + high[i - 2]) / 2.0), strength=float(min(1.0, size / av * 0.4)),
                    timestamp=df.index[i], invalidation=float(low[i]),
                    meta={"gap_top": float(low[i]), "gap_bottom": float(high[i - 2]), "size_atr": float(size / av)},
                ))
        elif high[i] < low[i - 2]:
            size = low[i - 2] - high[i]
            if size >= min_atr * av:
                events.append(SMCEvent(
                    type=SMCEventType.FVG_BEAR, direction=Direction.BEARISH, timeframe=timeframe,
                    price=float((high[i] + low[i - 2]) / 2.0), strength=float(min(1.0, size / av * 0.4)),
                    timestamp=df.index[i], invalidation=float(high[i]),
                    meta={"gap_top": float(low[i - 2]), "gap_bottom": float(high[i]), "size_atr": float(size / av)},
                ))
    return events


def fvg_distance_features(df: pd.DataFrame, fvgs: list[SMCEvent]) -> pd.DataFrame:
    """Causal per-bar distance to nearest FVG midpoint of each side.

    Semantics note (do NOT change silently — trained models depend on it):
    the historical implementation intended to drop fully-mitigated zones, but
    its filter condition algebraically reduced to `close < close` / `close >
    close` (always False), so *every* FVG detected up to bar i remained in the
    candidate set. Models in models/registry/* were trained on exactly those
    values, so this implementation reproduces the same effective semantics —
    distance to the nearest FVG midpoint created at or before bar i — with an
    O(N log M) bisect search instead of the previous O(N x M) per-bar scan
    (the old scan rebuilt and re-scanned the whole candidate list every bar,
    which made multi-thousand-bar frames take minutes).

    `up` is kept in the signature for API compatibility; it no longer affects
    results because mitigation never removed zones in the reference behavior.
    """
    import bisect

    bull = sorted([e for e in fvgs if e.type == SMCEventType.FVG_BULL], key=lambda e: e.timestamp)
    bear = sorted([e for e in fvgs if e.type == SMCEventType.FVG_BEAR], key=lambda e: e.timestamp)
    out = pd.DataFrame(index=df.index)
    close = df["close"].values
    n = len(df)

    def nearest_dist(events, up: bool) -> np.ndarray:
        res = np.full(n, np.nan)
        mids: list[float] = []  # sorted FVG midpoints detected at or before bar i
        ei = 0
        for i in range(n):
            ts_i = df.index[i]
            while ei < len(events) and events[ei].timestamp <= ts_i:
                bisect.insort(mids, float(events[ei].price))
                ei += 1
            if mids:
                j = bisect.bisect_left(mids, close[i])
                best = np.inf
                if j < len(mids):
                    best = mids[j] - close[i]
                if j > 0:
                    best = min(best, close[i] - mids[j - 1])
                res[i] = float(best)
        return res

    out["dist_fvg_bull"] = nearest_dist(bull, up=False)
    out["dist_fvg_bear"] = nearest_dist(bear, up=True)
    return out
