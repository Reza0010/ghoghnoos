"""PHASE 5 — SMC orchestrator.

Combines structure, liquidity, FVG, order blocks and displacement into a
single deterministic result per (symbol, timeframe), plus causal per-bar
numeric features used by the ML layer.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from app.config.schema import SMCConfig
from app.indicators.ta import atr as atr_ind
from app.smc.fvg import detect_fvgs, fvg_distance_features
from app.smc.liquidity import (
    detect_sweeps,
    equal_high_lows,
    previous_day_week_levels,
    sweep_flags,
)
from app.smc.order_blocks import detect_displacement, detect_order_blocks, order_block_features
from app.smc.structure import detect_structure, find_swings, structure_state_series
from app.smc.types import Direction, SMCEvent, SMCEventType


@dataclass
class SMCResult:
    timeframe: str
    events: list[SMCEvent] = field(default_factory=list)
    features: pd.DataFrame | None = None
    swings: pd.DataFrame | None = None
    # v1.5: content fingerprint of the data window this result was computed
    # from — the cache-validity contract used by FeatureBuilder (a fixed-size
    # rolling window keeps len() constant while sliding, so length alone can
    # never prove freshness).
    fingerprint: str = ""

    def attach_fingerprint(self, fingerprint: str) -> "SMCResult":
        self.fingerprint = fingerprint
        return self

    def directional_bias(self, recent_bars: int = 20) -> tuple[float, list[str]]:
        """Recent-event bias score in [-1, 1] with reason codes."""
        weights = {"BOS": 1.0, "CHOCH": 1.2, "LIQ_SWEEP": 0.9, "FVG_BULL": 0.6, "FVG_BEAR": 0.6,
                   "ORDER_BLOCK_BULL": 0.5, "ORDER_BLOCK_BEAR": 0.5, "BREAKER_BULL": 0.7,
                   "BREAKER_BEAR": 0.7, "DISPLACEMENT_BULL": 0.8, "DISPLACEMENT_BEAR": 0.8,
                   "EQH": 0.3, "EQL": 0.3, "SWING_HIGH": 0.0, "SWING_LOW": 0.0}
        score = 0.0
        reasons: list[str] = []
        relevant = [e for e in self.events if e.type.value in weights]
        if self.features is not None and len(self.features):
            # v1.5 fix: short frames (provider returns fewer bars than the
            # window) used to crash with IndexError on index[-recent_bars].
            cutoff = self.features.index[max(0, len(self.features) - recent_bars)]
            relevant = [e for e in relevant if e.timestamp >= cutoff]
        if not relevant:
            return 0.0, ["SMC_NO_RECENT_EVENTS"]
        relevant = sorted(relevant, key=lambda e: e.timestamp)[-10:]
        for e in relevant:
            w = weights.get(e.type.value, 0.0) * e.strength
            if e.direction == Direction.BULLISH:
                score += w
            elif e.direction == Direction.BEARISH:
                score -= w
        for e in relevant[-3:]:
            reasons.append(f"SMC_{e.type.value}_{e.direction.value}")
        return float(np.clip(score / 3.0, -1.0, 1.0)), reasons

    def directional_bias_series(self, recent_bars: int = 20) -> pd.Series:
        """Causal per-bar bias series: at each bar only events ≤ that bar count.

        O(n * k) with k = events in window; efficient via rolling pointer.
        """
        weights = {"BOS": 1.0, "CHOCH": 1.2, "LIQ_SWEEP": 0.9, "FVG_BULL": 0.6, "FVG_BEAR": 0.6,
                   "ORDER_BLOCK_BULL": 0.5, "ORDER_BLOCK_BEAR": 0.5, "BREAKER_BULL": 0.7,
                   "BREAKER_BEAR": 0.7, "DISPLACEMENT_BULL": 0.8, "DISPLACEMENT_BEAR": 0.8,
                   "EQH": 0.3, "EQL": 0.3}
        if self.features is None:
            return pd.Series(dtype=float)
        idx = self.features.index
        from app.smc.types import Direction as _D

        scored = sorted(
            [(e.timestamp, (weights.get(e.type.value, 0.0) * e.strength)
              * (1 if e.direction == _D.BULLISH else (-1 if e.direction == _D.BEARISH else 0)))
             for e in self.events if e.type.value in weights],
            key=lambda x: x[0],
        )
        out = np.zeros(len(idx))
        j = 0
        window: deque = deque()
        for i, ts in enumerate(idx):
            while j < len(scored) and scored[j][0] <= ts:
                window.append(scored[j])
                j += 1
            cutoff = ts - (idx[min(i, len(idx) - 1)] - idx[max(0, i - recent_bars)])
            while window and window[0][0] < cutoff:
                window.popleft()
            if window:
                out[i] = np.clip(sum(s for _, s in window) / 3.0, -1.0, 1.0)
        return pd.Series(out, index=idx)


class SMCEngine:
    def __init__(self, cfg: SMCConfig) -> None:
        self.cfg = cfg

    def analyze(self, df: pd.DataFrame, timeframe: str) -> SMCResult:
        atr = atr_ind(df["high"], df["low"], df["close"], 14)
        swings = find_swings(df, self.cfg.swing_left, self.cfg.swing_right)
        events: list[SMCEvent] = []

        structure_events = detect_structure(df, swings, atr, timeframe, self.cfg.min_event_strength)
        events.extend(structure_events)

        sweeps = detect_sweeps(df, swings, atr, timeframe, self.cfg.sweep_recent_bars)
        events.extend(sweeps)

        eq_events = equal_high_lows(df, swings, atr, self.cfg.equal_levels_atr_tolerance, timeframe)
        events.extend(eq_events)

        fvgs = detect_fvgs(df, atr, timeframe, self.cfg.fvg_min_atr)
        events.extend(fvgs)

        disps = detect_displacement(df, atr, timeframe,
                                    self.cfg.displacement_body_atr, self.cfg.displacement_range_atr)
        events.extend(disps)

        obs = detect_order_blocks(df, atr, timeframe, disps, self.cfg.ob_max_lookback)
        events.extend(obs)

        # causal per-bar feature frame
        feats = structure_state_series(df, swings)
        pdwl = previous_day_week_levels(df)
        feats = feats.join(pdwl, how="left")
        feats = feats.join(sweep_flags(df, sweeps, self.cfg.sweep_recent_bars), how="left")
        feats = feats.join(fvg_distance_features(df, fvgs), how="left")
        feats = feats.join(order_block_features(df, obs), how="left")

        # premium / discount within the last major dealing range (causal)
        high = df["high"].values
        low = df["low"].values
        close = df["close"].values
        lb = self.cfg.premium_discount_lookback
        n = len(df)
        pd_pos = np.full(n, 0.5)
        for i in range(n):
            lo_w = low[max(0, i - lb):i + 1]
            hi_w = high[max(0, i - lb):i + 1]
            rng = hi_w.max() - lo_w.min()
            if rng > 0:
                pd_pos[i] = (close[i] - lo_w.min()) / rng
        feats["premium_discount"] = pd_pos

        return SMCResult(timeframe=timeframe, events=events, features=feats, swings=swings)
