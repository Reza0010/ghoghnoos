"""PHASE 57 (orchestrator) — TradingSystem main loop.

STARTUP HEALTH CHECK → LOOP:
  fetch → quality → features → SMC → ML → regime → news
  → hard gates (WAIT if any) → AI (only for valid setups) → consensus
  → ensemble → risk engine → execution → journal → state snapshot

The loop never blocks on AI/dashboard/notifications; failures degrade to
WAIT / SAFE MODE instead of crashing.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import asdict

import numpy as np
import pandas as pd

from app.ai.consensus import AIConsensus
from app.ai.gateway import AIGateway, GatewayResult
from app.config.schema import TradingMode
from app.core import exceptions as exc
from app.core.security import sanitize_reason_codes
from app.execution.paper import PaperExecutor
from app.journal.journal import Journal
from app.monitoring.drift import PerformanceDriftMonitor
from app.monitoring.health import HealthRegistry
from app.monitoring.state import StateStore
from app.news.engine import NewsEngine
from app.pipeline import AnalysisPipeline, AnalysisResult
from app.risk.engine import RiskEngine
from app.signals.ensemble import SignalEnsemble

logger = logging.getLogger(__name__)


class TradingSystem:
    def __init__(
        self,
        cfg,
        provider,
        pipeline: AnalysisPipeline,
        ensemble: SignalEnsemble,
        risk: RiskEngine,
        executor,
        gateway: AIGateway,
        journal: Journal,
        health: HealthRegistry,
        kill_switch,
        state_store: StateStore,
        notifiers=None,
    ) -> None:
        self.cfg = cfg
        self.provider = provider
        self.pipeline = pipeline
        self.ensemble = ensemble
        self.risk = risk
        self.executor = executor
        self.gateway = gateway
        self.journal = journal
        self.health = health
        self.kill_switch = kill_switch
        self.state_store = state_store
        self.notifiers = notifiers
        self.consensus = AIConsensus()
        self.perf_monitor = PerformanceDriftMonitor(
            cfg.drift.perf_window_trades, cfg.drift.perf_winrate_min
        )
        self._running = False
        self._data_error_streak = 0
        self._ai_fail_streak = 0
        self._exec_fail_streak = 0
        self._peak_equity = cfg.backtest.initial_balance
        self._last_quality = 100.0
        self._last_result: AnalysisResult | None = None
        self._loop_count = 0

    # ------------------------------------------------------------- startup --
    def startup_health_check(self) -> dict:
        results: dict[str, bool] = {}
        try:
            ok = self.provider.connect()
            results["MT5/Provider"] = bool(ok)
            self.health.mark("MT5", ok, error_detail="provider connect failed")
        except Exception as e:
            results["MT5/Provider"] = False
            self.health.update("MT5", "SAFE_MODE", str(e)[:120])
        try:
            info = self.provider.get_symbol_info(self.cfg.symbol.primary)
            results["Symbol"] = info is not None
            self.health.mark("DATA", info is not None, f"symbol={info.name}")
        except Exception as e:
            results["Symbol"] = False
            self.health.update("DATA", "WARNING", str(e)[:120])
        results["Models"] = self.pipeline.bundle is not None
        self.health.update("ML", "NORMAL" if results["Models"] else "WARNING",
                           "bundle loaded" if results["Models"] else "no models — ML gate will WAIT")
        ai_names = self.gateway.available_providers
        results["AI"] = len(ai_names) > 0
        self.health.update("AI", "NORMAL" if results["AI"] else "DISABLED",
                           ",".join(ai_names) or "no providers configured")
        news_ok = self.pipeline.news_engine.provider.healthy()
        results["News"] = news_ok
        self.health.mark("NEWS", news_ok, error_detail="news provider unhealthy")
        results["Risk"] = self.risk.cfg.risk_percent <= self.risk.cfg.max_risk_percent
        self.health.mark("RISK", results["Risk"], error_detail="risk config invalid")
        results["Execution"] = True
        self.health.update("EXECUTION", "NORMAL", self.executor.mode)
        logger.info("startup health: %s", results)
        return results

    # ----------------------------------------------------------------- loop --
    async def run(self, once: bool = False, max_loops: int | None = None) -> None:
        self._running = True
        self.startup_health_check()
        while self._running:
            loop_start = time.perf_counter()
            try:
                await self.iterate()
                self._data_error_streak = 0
            except exc.DataError as e:
                self._data_error_streak += 1
                logger.error("data error (%d): %s", self._data_error_streak, e)
                self.kill_switch.check(consecutive_data_errors=self._data_error_streak)
            except exc.ExecutionError as e:
                self._exec_fail_streak += 1
                logger.error("execution error: %s", e)
                self.kill_switch.check(consecutive_execution_failures=self._exec_fail_streak)
            except exc.KillSwitchActive:
                logger.critical("kill switch active — loop paused")
            except Exception:
                logger.exception("unexpected loop error")
            self._write_state()
            if once or (max_loops is not None and self._loop_count >= max_loops):
                break
            await asyncio.sleep(max(1.0, self.cfg.execution.poll_interval_seconds -
                                    (time.perf_counter() - loop_start)))

    def stop(self) -> None:
        self._running = False

    # ------------------------------------------------------------- iterate --
    async def iterate(self) -> None:
        self._loop_count += 1
        cfg = self.cfg

        # manage open positions first
        self._manage_positions()

        account = self._account()
        if account.equity > self._peak_equity:
            self._peak_equity = account.equity

        daily_loss_pct = self._daily_loss_percent(account)
        drawdown_pct = self._drawdown_percent(account)

        # kill switch pre-check
        ks = self.kill_switch.check(
            daily_loss_percent=daily_loss_pct,
            drawdown_percent=drawdown_pct,
            mt5_connected=self.provider.is_connected(),
        )
        if ks.active:
            self.journal.log_signal(cfg.symbol.primary, self.executor.mode, "WAIT",
                                    reasons=[f"KILL_SWITCH_{ks.trigger}"])
            self.health.update("SYSTEM", "SAFE_MODE", f"kill: {ks.trigger}")
            return

        # analysis pipeline
        result = self.pipeline.analyze()
        self._last_result = result
        self._last_quality = result.market_data.worst_score()
        self.health.update("DATA", "NORMAL", f"quality={self._last_quality:.0f}")

        price = result.price
        base = result.market_data.frames.get(cfg.timeframes.base.value)
        atr = float(result.features.iloc[-1].get("atr", 0.0) or 0.0)
        # v1.5 (SMC-N4): stamp the symbol point size onto the frame so
        # SLMethod.FIXED converts points→price with the REAL symbol geometry.
        try:
            base.attrs["point"] = float(self._point())
        except Exception:
            pass
        tick = self._tick()

        # hard WAIT gates (before any AI call — cost control)
        if result.wait_reasons:
            self._log_wait(result, price, result.wait_reasons)
            return
        if self.pipeline.bundle is None:
            self._log_wait(result, price, ["MODELS_NOT_LOADED"])
            return

        # AI layer (cached; only reached for valid setups)
        ai_decision, ai_conf, ai_conflict, gateway_result = None, None, False, None
        if self.gateway.available_providers:
            try:
                gateway_result = await self.gateway.analyze(
                    result.market_state, [e.event for e in result.news.upcoming]
                )
                if gateway_result.degraded:
                    # v1.7 — only a REAL fresh attempt that failed counts as an
                    # AI failure. When every provider was merely skipped (429
                    # cooldown / daily cost cap), this is a neutral WAIT: the
                    # streak is neither incremented nor reset, so the kill
                    # switch no longer trips from rate-limit storms.
                    if getattr(gateway_result, "attempts_made", 0) > 0:
                        self._ai_fail_streak += 1
                        self.kill_switch.check(consecutive_ai_failures=self._ai_fail_streak)
                        if cfg.ai.require_ai_for_trade and cfg.ai.on_all_fail == "WAIT":
                            self._log_wait(result, price, ["AI_UNAVAILABLE_SAFE_MODE"])
                            self.health.update("AI", "SAFE_MODE", ";".join(gateway_result.errors)[:120])
                            return
                    else:
                        if cfg.ai.require_ai_for_trade and cfg.ai.on_all_fail == "WAIT":
                            self._log_wait(result, price, ["AI_COOLDOWN_SAFE_MODE"])
                            self.health.update("AI", "SAFE_MODE",
                                               ("cooldown: " + ";".join(gateway_result.errors))[:120])
                            return
                else:
                    self._ai_fail_streak = 0
                    cons = self.consensus.combine([(gateway_result.provider, gateway_result.output)])
                    ai_decision, ai_conf, ai_conflict = cons.decision, cons.confidence, cons.conflict
                    self.health.update("AI", "NORMAL", f"provider={gateway_result.provider}")
            except Exception as e:
                logger.exception("gateway error")
                self._ai_fail_streak += 1
        elif cfg.ai.require_ai_for_trade:
            self._log_wait(result, price, ["AI_NOT_CONFIGURED"])
            return

        # ensemble decision (with EV gate — Mission 13)
        # v1.5: expected value after costs is estimated from the calibrated
        # direction probability and the planned barrier geometry; a non-
        # positive EV vetoes the trade inside the ensemble.
        expected_value_r = None
        try:
            from app.signals.expected_value import compute_expected_value

            p_dir = 0.0
            if result.ml_probs:
                arrs = [np.asarray(p, dtype=float) for p in result.ml_probs.values()]
                avg = np.mean(arrs, axis=0)  # [SELL, NO_EDGE, BUY]
                p_dir = float(max(avg[0], avg[2]))
            ev_res = compute_expected_value(
                p_win=p_dir,
                rr_gross=float(cfg.risk.min_rr),
                spread_price=float(tick.spread),
                slippage_price=float(cfg.execution.slippage_points) * float(self._point()),
                sl_distance=float(cfg.risk.atr_sl_mult) * atr,
            )
            expected_value_r = ev_res.expected_value_r * 100.0  # R×100 scale for gating
        except Exception:
            expected_value_r = None
        decision = self.ensemble.decide(
            ml_probs=result.ml_probs,
            smc_bias=result.smc.directional_bias()[0],
            regime=result.regime.regime,
            news_risk=result.news.risk,
            ai_decision=ai_decision,
            ai_confidence=ai_conf,
            ai_conflict=ai_conflict,
            model_quality=self._model_quality(),
            expected_value=expected_value_r,
        )
        signal_id = self.journal.log_signal(
            cfg.symbol.primary, self.executor.mode, decision.side,
            score=decision.score, confidence=decision.confidence, price=price,
            components=decision.components, reasons=decision.reasons,
            regime=result.regime.regime.value, news_risk=result.news.risk.value,
            quality_score=self._last_quality,
        )
        if decision.is_actionable:
            self.notifiers and self.notifiers.notify(
                decision.side, symbol=cfg.symbol.primary, price=price,
                sl=0.0, tp=0.0, lot=0.0, reasons=", ".join(decision.reasons[:4]),
            )
        else:
            logger.info("WAIT: %s (score=%.2f)", decision.reasons[:3], decision.score)
            return

        # risk engine (deterministic — overrides everything)
        entry = tick.ask if decision.side == "BUY" else tick.bid
        spread_points = tick.spread / self._point()
        from app.smc.liquidity import previous_day_week_levels

        pdwl = previous_day_week_levels(base)
        liquidity_levels = {}
        if len(pdwl):
            last_pdwl = pdwl.iloc[-1]
            liquidity_levels = {
                "pdh": float(last_pdwl.get("pdh", np.nan)) if pd.notna(last_pdwl.get("pdh", np.nan)) else None,
                "pdl": float(last_pdwl.get("pdl", np.nan)) if pd.notna(last_pdwl.get("pdl", np.nan)) else None,
            }
        # v1.4 §16: compute REAL open risk from provider/executor state.
        # None => OPEN_RISK_UNKNOWN => risk engine refuses (fail-closed).
        open_risk = self._open_risk_percent(account)
        risk = self.risk.evaluate(
            side=decision.side, entry=entry,
            account=account, symbol=self._symbol_info(),
            df=base, atr=atr,
            ml_confidence=decision.confidence,
            smc_bias=result.smc.directional_bias()[0],
            regime=result.regime.regime,
            news_risk=result.news.risk,
            data_quality=self._last_quality,
            spread_points=spread_points,
            open_positions=len(self.executor.positions()),
            open_risk_percent=open_risk,
            smc_events=result.smc.events,
            liquidity_levels=liquidity_levels,
            daily_loss_percent=daily_loss_pct,
            drawdown_percent=drawdown_pct,
            peak_equity=self._peak_equity,
            ai_confidence=ai_conf if cfg.ai.require_ai_for_trade else None,
            ai_required=cfg.ai.require_ai_for_trade,
            ai_available=bool(self.gateway.available_providers) or not cfg.ai.require_ai_for_trade,
            mt5_connected=bool(self.provider.is_connected()),
        )
        if not risk.approved:
            self.journal.log_signal(cfg.symbol.primary, self.executor.mode, "WAIT",
                                    price=price, reasons=risk.reason_codes,
                                    regime=result.regime.regime.value,
                                    news_risk=result.news.risk.value)
            logger.info("RISK REJECT: %s", risk.reason_codes)
            return

        # execute
        try:
            res = self.executor.open_market(
                cfg.symbol.primary, risk.side, risk.lot, risk.sl, risk.tp,
                # v1.5 (finding 11): embed the signal id in the broker comment
                # so orders/deals can be reconciled back to the exact intent.
                comment=f"{cfg.execution.comment}|sid{signal_id}",
                magic=cfg.execution.magic_number,
            )
            self._exec_fail_streak = 0
            self.journal.log_trade_open(
                res.ticket, cfg.symbol.primary, self.executor.mode, risk.side,
                risk.lot, res.price, pd.Timestamp.now(tz="UTC").isoformat(),
                risk.sl, risk.tp, magic=cfg.execution.magic_number,
                comment=cfg.execution.comment, signal_id=signal_id,
            )
            self.notifiers and self.notifiers.notify(
                "TRADE_OPEN", ticket=res.ticket, side=risk.side, lot=risk.lot, price=res.price,
            )
            logger.info("EXECUTED %s %s %.2f @ %.2f SL %.2f TP %.2f (RR %.1f)",
                        risk.side, cfg.symbol.primary, risk.lot, res.price,
                        risk.sl, risk.tp, risk.achieved_rr)
        except exc.ExecutionError as e:
            self._exec_fail_streak += 1
            self.kill_switch.check(consecutive_execution_failures=self._exec_fail_streak)
            logger.error("execution failed: %s", e)

    # ------------------------------------------------------------ helpers ---
    def _tick(self):
        """Live tick from the provider. Replay/simulated providers synthesise
        one from the last real candle (bid/ask around close with the recorded
        or assumed spread) so the paper loop can run offline (PHASE 65 §18).
        v1.5 (exec-N7): in LIVE mode a missing tick is a WAIT, never a
        synthetic price driving SL/TP sizing."""
        try:
            return self.provider.get_tick(self.cfg.symbol.primary)
        except exc.DataError:
            if self.executor.mode == "live":
                raise  # fail-closed: no synthetic ticks feeding live entries
            base = self._last_result.market_data.frames.get(self.cfg.timeframes.base.value) \
                if self._last_result else None
            if base is None or not len(base):
                raise
            last = base.iloc[-1]
            close = float(last["close"])
            spread = float(last.get("spread", 0.0) or 0.0)
            if spread <= 0:
                spread = float(getattr(self.cfg.backtest, "assumed_spread", 0.0) or 0.0)
            half = spread / 2.0
            ts = base.index[-1].to_pydatetime()
            from app.data.market.models import Tick

            return Tick(time=ts, bid=close - half, ask=close + half, last=close)

    def _symbol_info(self):
        return self.provider.get_symbol_info(self.cfg.symbol.primary)

    def _point(self) -> float:
        return self._symbol_info().point

    def _account(self):
        bal = getattr(self.executor, "_balance_override", None)
        if hasattr(self.executor, "account"):
            acc = self.executor.account(bal if bal is not None else self.cfg.backtest.initial_balance)
        else:
            acc = self.provider.get_account_info()
        return acc

    def _daily_loss_percent(self, account) -> float:
        pnl = self.journal.daily_pnl()
        floating = account.equity - account.balance
        total = pnl + floating
        if account.balance <= 0:
            return 0.0
        return max(0.0, -total / account.balance * 100.0)

    def _open_risk_percent(self, account) -> float | None:
        """v1.4 §16 / v1.5 (exec-N3) — real open risk, fail-closed.

        PaperExecutor keeps positions internally while the (simulated)
        provider returns none — the EXECUTOR view is authoritative in paper
        mode; the provider view is authoritative for MT5. Returns None when
        risk cannot be determined — the risk engine then refuses new risk.
        """
        try:
            from app.risk.open_risk import OpenRiskCalculator

            source = self.executor if isinstance(self.executor, PaperExecutor) \
                else self.provider
            report = OpenRiskCalculator(source).compute(equity=account.equity)
        except Exception as e:
            logger.warning("open risk calculation failed: %s", e)
            return None
        if report.risk_percent is None:
            logger.warning("open risk UNKNOWN: %s", report.as_dict())
        return report.risk_percent

    def _model_quality(self) -> dict[str, float] | None:
        """OOS log-loss per model from the registry, for ensemble weighting.
        Missing registry data → None (ensemble falls back to equal weights)."""
        try:
            from pathlib import Path

            from app.models.registry import ModelRegistry

            reg = ModelRegistry(Path(self.cfg.paths.models_dir) / "registry")
            out: dict[str, float] = {}
            for entry in reg.list():
                mid = entry.get("model_id", "")
                m = entry.get("metrics", {}) or {}
                ll = m.get("log_loss") if isinstance(m, dict) else None
                if ll is not None:
                    key = "lgbm" if mid.startswith("lgbm") else ("xgb" if mid.startswith("xgb") else mid)
                    out[key] = float(ll)
            return out or None
        except Exception:
            return None

    def _drawdown_percent(self, account) -> float:
        if self._peak_equity <= 0:
            return 0.0
        return max(0.0, (self._peak_equity - account.equity) / self._peak_equity * 100.0)

    def _manage_positions(self) -> None:
        if isinstance(self.executor, PaperExecutor):
            for pos, reason in self.executor.update():
                self.journal.log_trade_close(
                    pos.ticket, pos.open_price, pd.Timestamp.now(tz="UTC").isoformat(),
                    pos.profit, fees=pos.commission, swap=pos.swap, exit_reason=reason,
                )
                self.notifiers and self.notifiers.notify(
                    "TRADE_CLOSE", ticket=pos.ticket, pnl=pos.profit, reason=reason,
                )
                if reason == "SL":
                    self.notifiers and self.notifiers.notify("SL", ticket=pos.ticket)
                elif reason == "TP":
                    self.notifiers and self.notifiers.notify("TP", ticket=pos.ticket)

    def _log_wait(self, result: AnalysisResult, price: float, reasons: list[str]) -> None:
        reasons = sanitize_reason_codes(reasons)
        self.journal.log_signal(
            self.cfg.symbol.primary, self.executor.mode, "WAIT", price=price,
            reasons=reasons, regime=result.regime.regime.value if result.regime else "",
            news_risk=result.news.risk.value if result.news else "UNKNOWN",
            quality_score=self._last_quality,
        )
        logger.info("WAIT: %s", reasons)

    def _write_state(self) -> None:
        try:
            account = self._account()
            res = self._last_result
            # PHASE 65 §22 — realtime monitoring fields required on the dashboard
            spread_val, freshness_min, ml_prob, smc_bias_v, ai_status = None, None, None, None, None
            try:
                base_df = res.market_data.frames.get(self.cfg.timeframes.base.value) if res else None
                if base_df is not None and len(base_df):
                    spread_val = float(base_df["spread"].iloc[-1]) if "spread" in base_df else None
                    last_ts = base_df.index[-1]
                    if last_ts.tzinfo is None:
                        last_ts = last_ts.tz_localize("UTC")
                    freshness_min = round((pd.Timestamp.now(tz="UTC") - last_ts).total_seconds() / 60.0, 1)
            except Exception:
                pass
            if res and res.ml_probs:
                try:
                    arr = np.asarray(next(iter(res.ml_probs.values())), dtype=float)
                    ml_prob = {"SELL": round(float(arr[0]), 3), "NO_EDGE": round(float(arr[1]), 3),
                               "BUY": round(float(arr[2]), 3)}
                except Exception:
                    pass
            if res and res.smc is not None:
                try:
                    smc_bias_v = round(float(res.smc.directional_bias()[0]), 3)
                except Exception:
                    pass
            try:
                stats = self.journal.ai_stats(days=1)
                z = stats.get("zai") or next(iter(stats.values()), None)
                ai_status = ("ok" if z and z.get("ok") else "degraded") if z else \
                    ("configured" if self.gateway.available_providers else "not_configured")
            except Exception:
                ai_status = "unknown"

            state = {
                "symbol": self.cfg.symbol.primary,
                "mode": self.executor.mode,
                "price": res.price if res else None,
                "mt5_connected": bool(self.provider.is_connected()),
                "data_freshness_minutes": freshness_min,
                "spread": round(spread_val, 4) if spread_val is not None else None,
                "current_regime": res.regime.regime.value if res and res.regime else None,
                "ml_probability": ml_prob,
                "smc_bias": smc_bias_v,
                "ai_status": ai_status,
                "risk_status": {
                    "daily_loss_pct": round(self._daily_loss_percent(account), 2),
                    "drawdown_pct": round(self._drawdown_percent(account), 2),
                    "kill_switch_active": bool(self.kill_switch.state.active),
                },
                "last_signal": (res.wait_reasons[:3] if res and res.wait_reasons else None),
                "paper_positions": len(self.executor.positions()),
                "news_risk": res.news.risk.value if res and res.news else None,
                "data_quality": round(self._last_quality, 1),
                "account": {k: account.model_dump().get(k) for k in
                            ("balance", "equity", "margin", "free_margin")},
                "daily_pnl": round(self.journal.daily_pnl(), 2),
                "open_positions": len(self.executor.positions()),
                "kill_switch": asdict(self.kill_switch.state),
                "health": self.health.summary(),
                "loop": self._loop_count,
                "ai_stats": self.journal.ai_stats(),
                "trade_stats": self.journal.closed_trade_stats(),
            }
            self.state_store.write(state)
        except Exception:
            logger.debug("state write failed", exc_info=True)
