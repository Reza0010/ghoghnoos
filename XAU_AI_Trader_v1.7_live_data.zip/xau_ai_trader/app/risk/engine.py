"""PHASE 26-28 — Hard Risk Filters (deterministic, AI-proof).

Every trade must pass ALL filters. Even a perfect signal rejected here
results in NO TRADE. The Risk Engine always overrides the AI layer.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from app.config.schema import NewsRisk, Regime, RiskConfig
from app.data.market.models import AccountInfo, SymbolInfo
from app.risk.sizing import calc_lot, margin_required, round_price
from app.risk.stops import compute_stop_loss, compute_take_profit


@dataclass
class RiskDecision:
    approved: bool
    reason_codes: list[str] = field(default_factory=list)
    side: str = ""
    entry: float = 0.0
    sl: float = 0.0
    tp: float = 0.0
    lot: float = 0.0
    risk_percent: float = 0.0
    achieved_rr: float = 0.0


class RiskEngine:
    def __init__(self, cfg: RiskConfig, kill_switch=None) -> None:
        self.cfg = cfg
        self.kill_switch = kill_switch

    def evaluate(
        self,
        side: str,
        entry: float,
        account: AccountInfo,
        symbol: SymbolInfo,
        df: pd.DataFrame,
        atr: float,
        ml_confidence: float,
        smc_bias: float,
        regime: Regime,
        news_risk: NewsRisk,
        data_quality: float,
        spread_points: float,
        open_positions: int,
        open_risk_percent: float | None = None,
        smc_events: list | None = None,
        liquidity_levels: dict | None = None,
        daily_loss_percent: float | None = None,
        drawdown_percent: float | None = None,
        ai_confidence: float | None = None,
        ai_required: bool = False,
        ai_available: bool | None = None,
        peak_equity: float | None = None,
        mt5_connected: bool | None = None,
    ) -> RiskDecision:
        """Deterministic, AI-proof gate (v1.5: fail-closed on UNKNOWN).

        Mission 15/48: any value the caller could NOT determine (open risk,
        daily loss, drawdown, connection state, AI availability) is UNKNOWN
        and produces WAIT — never a silent permissive bypass. The old
        defaults (open_risk=0.0, daily_loss=0.0, ai_available=True,
        mt5_connected hard-coded True) were exactly such bypasses.
        """
        reasons: list[str] = []

        # ---- kill switch first -------------------------------------------
        if self.kill_switch is not None and self.kill_switch.is_active:
            reasons.append(f"KILL_SWITCH_{self.kill_switch.state.trigger}")
            return RiskDecision(False, reasons, side)
        ks = None
        if self.kill_switch is not None:
            ks = self.kill_switch.check(
                daily_loss_percent=daily_loss_percent if daily_loss_percent is not None else 0.0,
                drawdown_percent=drawdown_percent if drawdown_percent is not None else 0.0,
                spread_points=spread_points,
                mt5_connected=mt5_connected if mt5_connected is not None else False,
            )
            if ks.active:
                return RiskDecision(False, [f"KILL_SWITCH_{ks.trigger}"], side)

        # ---- unknown-state fail-closed gates (Mission 48) ------------------
        if open_risk_percent is None:
            reasons.append("OPEN_RISK_UNKNOWN")
        if daily_loss_percent is None:
            reasons.append("DAILY_LOSS_UNKNOWN")
        if mt5_connected is None:
            reasons.append("MT5_CONNECTION_UNKNOWN")
        if ai_available is None:
            reasons.append("AI_AVAILABILITY_UNKNOWN")

        # ---- market condition filters ------------------------------------
        if spread_points > self.cfg.max_spread_points:
            reasons.append(f"SPREAD_TOO_HIGH_{spread_points:.0f}pts")
        if self.cfg.block_on_high_news and news_risk == NewsRisk.HIGH:
            reasons.append("NEWS_RISK_HIGH")
        if regime not in self.cfg.allowed_regimes:
            reasons.append(f"REGIME_NOT_ALLOWED_{regime.value}")
        if self.cfg.block_on_low_data_quality and data_quality < self.cfg.min_data_quality:
            reasons.append(f"DATA_QUALITY_LOW_{data_quality:.0f}")

        # ---- account-level filters ----------------------------------------
        if daily_loss_percent is not None and daily_loss_percent >= self.cfg.max_daily_loss_percent:
            reasons.append(f"MAX_DAILY_LOSS_{daily_loss_percent:.2f}pct")
        peak = peak_equity if peak_equity is not None else account.equity
        dd_now = 0.0
        if peak > 0:
            dd_now = max(0.0, (peak - account.equity) / peak * 100.0)
        if dd_now >= self.cfg.max_drawdown_percent:
            reasons.append(f"MAX_DRAWDOWN_{dd_now:.1f}pct")
        if open_positions >= self.cfg.max_open_positions:
            reasons.append("MAX_OPEN_POSITIONS")
        if open_risk_percent is not None and \
                open_risk_percent + self.cfg.risk_percent > self.cfg.max_open_risk_percent:
            reasons.append("MAX_OPEN_RISK")

        # ---- confidence filters --------------------------------------------
        if ml_confidence < self.cfg.min_ml_confidence:
            reasons.append(f"ML_CONF_LOW_{ml_confidence:.2f}")
        if ai_required and (not ai_available or ai_confidence is None):
            reasons.append("AI_REQUIRED_UNAVAILABLE")
        elif ai_confidence is not None and ai_confidence < self.cfg.min_ai_confidence:
            reasons.append(f"AI_CONF_LOW_{ai_confidence:.2f}")

        if reasons:
            return RiskDecision(False, reasons, side)

        # ---- SL / TP ---------------------------------------------------------
        sl = compute_stop_loss(side, entry, df, atr, self.cfg.sl_method, self.cfg, smc_events)
        if sl is None:
            return RiskDecision(False, ["SL_NOT_COMPUTABLE"], side)
        sl_dist = abs(entry - sl)
        sl_dist_atr = sl_dist / atr if atr > 0 else 999
        if sl_dist_atr > self.cfg.max_sl_atr_distance:
            return RiskDecision(False, [f"SL_TOO_WIDE_{sl_dist_atr:.1f}atr"], side)
        tp, achieved_rr = compute_take_profit(side, entry, sl, df, atr, self.cfg.tp_method,
                                              self.cfg, liquidity_levels)
        if tp is None or achieved_rr < self.cfg.min_rr:
            return RiskDecision(False, ["MIN_RR_NOT_MET"], side)

        # ---- broker stop-distance validation (v1.5, exec-N6) -----------------
        stops_min = float(getattr(symbol, "stops_level_points", 0) or 0) * float(symbol.point)
        if stops_min > 0 and (abs(entry - sl) < stops_min or abs(entry - tp) < stops_min):
            return RiskDecision(False, [f"BROKER_STOPS_LEVEL_{stops_min:.2f}"], side)

        # ---- position sizing ---------------------------------------------------
        lot = calc_lot(account.equity, self.cfg.risk_percent, sl_dist, symbol)
        if lot <= 0:
            return RiskDecision(False, ["LOT_TOO_SMALL_FOR_RISK"], side)
        if lot > self.cfg.max_lot:
            lot = self.cfg.max_lot
        margin = margin_required(entry, lot, symbol)
        # v1.5 (N2): unconditional margin gate — a zero/negative free_margin
        # account used to SKIP the gate entirely and approve new trades.
        if margin > account.free_margin * (self.cfg.margin_usage_max_pct / 100.0):
            return RiskDecision(False, [f"INSUFFICIENT_MARGIN_{margin:.0f}"], side)

        return RiskDecision(
            approved=True,
            reason_codes=["RISK_APPROVED"],
            side=side,
            entry=round_price(entry, symbol),
            sl=round_price(sl, symbol),
            tp=round_price(tp, symbol),
            lot=lot,
            risk_percent=self.cfg.risk_percent,
            achieved_rr=round(achieved_rr, 2),
        )
