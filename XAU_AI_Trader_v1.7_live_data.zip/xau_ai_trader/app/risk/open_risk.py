"""v1.4 §16 — Open risk calculation from real broker/provider state.

The Risk Engine previously trusted a caller-supplied ``open_risk_percent``
that defaulted to 0.0 — the cumulative-risk cap could be bypassed by simply
not passing the value. This module makes open risk a computed quantity:

    for each open position:
        risk_to_sl = |entry - sl| / tick_size * tick_value * volume
        (side-aware: a BUY loses when price falls to its SL, a SELL when it
         rises; |entry - sl| is the same distance either way)
    open_risk_money  = sum(risk_to_sl)
    open_risk_percent = 100 * open_risk_money / equity

Fail-closed rules (WAIT — never silently bypass):
    * position without SL            -> that position counts as UNBOUNDED
                                        risk -> caller must refuse new risk
    * symbol info / tick value un-
    * available                      -> risk UNKNOWN -> caller must refuse
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class OpenRiskReport:
    risk_percent: float | None          # None => UNKNOWN (fail-closed)
    positions: list[dict] = field(default_factory=list)
    unbounded_positions: list[int] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "risk_percent": self.risk_percent,
            "n_positions": len(self.positions),
            "unbounded_positions": self.unbounded_positions,
            "errors": self.errors,
        }


class OpenRiskCalculator:
    """Computes aggregate open risk from the provider's real positions."""

    def __init__(self, provider) -> None:
        self._provider = provider

    def compute(self, equity: float, symbol: str | None = None,
                magic: int | None = None) -> OpenRiskReport:
        report = OpenRiskReport(risk_percent=None)
        if equity <= 0:
            report.errors.append("equity must be positive to compute open risk")
            return report
        try:
            positions = self._provider.get_open_positions(
                symbol=symbol) if symbol else self._provider.get_open_positions()
        except Exception as e:  # provider failure => UNKNOWN, never 0.0
            report.errors.append(f"positions unavailable: {e}")
            return report
        if magic is not None:
            positions = [p for p in positions if p.magic == magic]
        if not positions:
            report.risk_percent = 0.0
            return report

        total_risk = 0.0
        unknown = False
        for p in positions:
            entry = {"ticket": p.ticket, "symbol": p.symbol, "side": p.side,
                     "volume": p.volume, "sl": p.sl, "open_price": p.open_price}
            report.positions.append(entry)
            if not p.sl or p.sl <= 0:
                report.unbounded_positions.append(p.ticket)
                unknown = True
                continue
            try:
                info = self._provider.get_symbol_info(p.symbol)
            except Exception as e:
                report.errors.append(f"symbol_info({p.symbol}) failed: {e}")
                unknown = True
                continue
            if not info.tick_size or info.tick_size <= 0 or \
                    not info.tick_value or info.tick_value <= 0:
                report.errors.append(
                    f"symbol {p.symbol}: invalid tick_size/tick_value "
                    f"({info.tick_size}/{info.tick_value})")
                unknown = True
                continue
            sl_distance = abs(p.open_price - p.sl)
            risk_money = (sl_distance / info.tick_size) * info.tick_value * p.volume
            entry["risk_money"] = round(risk_money, 2)
            total_risk += risk_money

        if unknown or report.errors:
            return report  # risk_percent stays None -> fail-closed
        report.risk_percent = round(100.0 * total_risk / equity, 4)
        return report
