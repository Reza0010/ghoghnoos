"""PHASE 23 — Deterministic position sizing.

lot = risk_money / (sl_distance / tick_size * tick_value)
Respects volume_min / volume_max / volume_step — rounds DOWN to step
(never risks more than configured).
"""

from __future__ import annotations

import math

from app.data.market.models import SymbolInfo


def calc_stop_distance_ticks(sl_distance: float, tick_size: float) -> float:
    if tick_size <= 0:
        raise ValueError("tick_size must be positive")
    return sl_distance / tick_size


def loss_per_lot(sl_distance: float, tick_size: float, tick_value: float) -> float:
    ticks = calc_stop_distance_ticks(sl_distance, tick_size)
    return ticks * tick_value


def calc_lot(
    equity: float,
    risk_percent: float,
    sl_distance: float,
    symbol: SymbolInfo,
) -> float:
    """Return lot size rounded DOWN to the broker lot step, clamped to
    [volume_min, volume_max]. Returns 0.0 when the risk is untradeable."""
    if sl_distance <= 0:
        return 0.0
    risk_money = equity * (risk_percent / 100.0)
    if risk_money <= 0:
        return 0.0
    per_lot = loss_per_lot(sl_distance, symbol.tick_size, symbol.tick_value)
    if per_lot <= 0:
        return 0.0
    raw = risk_money / per_lot
    step = symbol.volume_step if symbol.volume_step > 0 else 0.01
    lots = math.floor(raw / step) * step
    lots = round(lots, 8)
    if lots < symbol.volume_min:
        # risking less than min-lot loss is fine only if min lot still fits
        # within the risk budget — otherwise refuse (0.0 → WAIT).
        if symbol.volume_min * per_lot <= risk_money * 1.0:
            return symbol.volume_min
        return 0.0
    return min(lots, symbol.volume_max, 10**9)


def margin_required(price: float, lots: float, symbol: SymbolInfo) -> float:
    """Simple contract-value margin (leverage applied)."""
    if symbol.leverage <= 0:
        raise ValueError("leverage must be positive")
    return price * symbol.contract_size * lots / symbol.leverage


def round_price(price: float, symbol: SymbolInfo) -> float:
    factor = 10 ** symbol.digits
    return round(price * factor) / factor
