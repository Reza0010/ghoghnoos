"""PHASE 66 (§22) — Fail-safe matrix.

Central, testable mapping from abnormal system/market conditions to the
required trading action: NO_NEW_TRADE (finish safely, stop entering) or HALT
(stop everything). Every condition in the directive's 18-scenario matrix has
an explicit entry here so it can be unit-tested automatically.

Used by the trader loop and the BROKER_REALTIME_PAPER mode. Expected behaviour
for every scenario is "NO NEW TRADE" or "HALT" — never "open anyway".
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class FailSafeAction(str, Enum):
    PROCEED = "PROCEED"                # normal operation
    NO_NEW_TRADE = "NO_NEW_TRADE"      # manage existing, open nothing
    HALT = "HALT"                      # stop trading loop entirely


# severity per condition family: HALT = environment is untrustworthy end-to-end
HALT_CONDITIONS = {
    "MT5_DISCONNECT", "DATABASE_FAILURE", "JOURNAL_FAILURE",
    "RECONCILIATION_MISMATCH", "RISK_LIMIT_VIOLATION",
    "DAILY_LOSS_LIMIT", "MAX_DRAWDOWN_BREACH", "BROKER_REJECTION",
    "DUPLICATE_ORDER",
}
NO_TRADE_CONDITIONS = {
    "STALE_MARKET_DATA", "ABNORMAL_SPREAD", "INVALID_OHLC",
    "MISSING_MODEL", "CORRUPT_MODEL", "INVALID_AI_JSON", "AI_TIMEOUT",
    "AI_RATE_LIMITED", "NEWS_PROVIDER_FAILURE", "AI_UNAVAILABLE",
    "AI_LOW_CONFIDENCE", "DRIFT_ACTION", "UNKNOWN",
}


@dataclass(frozen=True)
class FailSafeState:
    """Snapshot of conditions that matter to the trading loop. ``None`` means
    "unknown/not measured" — unknown is treated as unsafe (WAIT-first)."""
    mt5_connected: bool | None = None
    market_data_fresh: bool | None = None
    spread_ok: bool | None = None
    ohlc_valid: bool | None = None
    model_available: bool | None = None
    model_integrity_ok: bool | None = None
    ai_response_valid: bool | None = None
    ai_reachable: bool | None = None
    news_provider_ok: bool | None = None
    journal_ok: bool | None = None
    database_ok: bool | None = None
    risk_limits_ok: bool | None = None
    daily_loss_ok: bool | None = None
    drawdown_ok: bool | None = None
    duplicate_order_suspected: bool = False
    broker_rejection: bool = False
    reconciliation_ok: bool | None = None
    drift_action_level: str | None = None      # None / WARNING / ACTION


def evaluate_failsafe(state: FailSafeState) -> tuple[FailSafeAction, str]:
    """Return (action, reason). Order matters: integrity failures first."""
    checks: list[tuple[bool | None, FailSafeAction, str]] = [
        (state.mt5_connected is False, FailSafeAction.HALT, "MT5_DISCONNECT"),
        (state.database_ok is False, FailSafeAction.HALT, "DATABASE_FAILURE"),
        (state.journal_ok is False, FailSafeAction.HALT, "JOURNAL_FAILURE"),
        (state.reconciliation_ok is False, FailSafeAction.HALT, "RECONCILIATION_MISMATCH"),
        (state.risk_limits_ok is False, FailSafeAction.HALT, "RISK_LIMIT_VIOLATION"),
        (state.daily_loss_ok is False, FailSafeAction.HALT, "DAILY_LOSS_LIMIT"),
        (state.drawdown_ok is False, FailSafeAction.HALT, "MAX_DRAWDOWN_BREACH"),
        (state.duplicate_order_suspected, FailSafeAction.HALT, "DUPLICATE_ORDER"),
        (state.broker_rejection, FailSafeAction.HALT, "BROKER_REJECTION"),
        (state.market_data_fresh is False, FailSafeAction.NO_NEW_TRADE, "STALE_MARKET_DATA"),
        (state.spread_ok is False, FailSafeAction.NO_NEW_TRADE, "ABNORMAL_SPREAD"),
        (state.ohlc_valid is False, FailSafeAction.NO_NEW_TRADE, "INVALID_OHLC"),
        (state.model_available is False, FailSafeAction.NO_NEW_TRADE, "MISSING_MODEL"),
        (state.model_integrity_ok is False, FailSafeAction.NO_NEW_TRADE, "CORRUPT_MODEL"),
        (state.ai_response_valid is False, FailSafeAction.NO_NEW_TRADE, "INVALID_AI_JSON"),
        (state.ai_reachable is False, FailSafeAction.NO_NEW_TRADE, "AI_TIMEOUT"),
        (state.news_provider_ok is False, FailSafeAction.NO_NEW_TRADE, "NEWS_PROVIDER_FAILURE"),
        (state.drift_action_level == "ACTION", FailSafeAction.NO_NEW_TRADE, "DRIFT_ACTION"),
    ]
    for failed, action, name in checks:
        if failed:
            return action, name
    # unknown-critical guards: any unknown state on HALT-grade checks is unsafe
    if any(v is None for v in (state.mt5_connected, state.database_ok, state.journal_ok,
                               state.reconciliation_ok, state.risk_limits_ok,
                               state.daily_loss_ok, state.drawdown_ok)):
        return FailSafeAction.NO_NEW_TRADE, "UNKNOWN_CRITICAL_STATE"
    return FailSafeAction.PROCEED, "ALL_CLEAR"


def scenario_matrix() -> list[dict]:
    """§22 — the documented 18-scenario matrix with required behaviour."""
    rows = [
        ("MT5 disconnect",           FailSafeState(mt5_connected=False),                 "HALT"),
        ("stale market data",        FailSafeState(market_data_fresh=False),             "NO_NEW_TRADE"),
        ("abnormal spread",          FailSafeState(spread_ok=False),                     "NO_NEW_TRADE"),
        ("invalid OHLC",             FailSafeState(ohlc_valid=False),                    "NO_NEW_TRADE"),
        ("missing model",            FailSafeState(model_available=False),               "NO_NEW_TRADE"),
        ("corrupt model",            FailSafeState(model_integrity_ok=False),            "NO_NEW_TRADE"),
        ("invalid AI JSON",          FailSafeState(ai_response_valid=False),             "NO_NEW_TRADE"),
        ("AI timeout",               FailSafeState(ai_reachable=False),                  "NO_NEW_TRADE"),
        ("AI 429",                   FailSafeState(ai_response_valid=None, ai_reachable=False), "NO_NEW_TRADE"),
        ("news provider failure",    FailSafeState(news_provider_ok=False),              "NO_NEW_TRADE"),
        ("journal failure",          FailSafeState(journal_ok=False),                    "HALT"),
        ("database failure",         FailSafeState(database_ok=False),                   "HALT"),
        ("risk limit violation",     FailSafeState(risk_limits_ok=False),                "HALT"),
        ("daily loss limit",         FailSafeState(daily_loss_ok=False),                 "HALT"),
        ("max drawdown",             FailSafeState(drawdown_ok=False),                   "HALT"),
        ("duplicate order",          FailSafeState(duplicate_order_suspected=True),      "HALT"),
        ("broker rejection",         FailSafeState(broker_rejection=True),               "HALT"),
        ("reconciliation mismatch",  FailSafeState(reconciliation_ok=False),             "HALT"),
    ]
    return [{"scenario": s, "state": st.__dict__, "required": req} for s, st, req in rows]
