"""PHASE EV (v1.5, Mission 13) — Expected Value layer.

Computes the expected value of a candidate trade AFTER costs, in R-multiples
(1R = stop distance), BEFORE risk approval. A trade is only actionable when
EV > threshold. This layer never overrides risk caps — it is an additional
economic gate that makes "RR ظاهری" (gross RR) vs "RR net" explicit.

EV_R = p_win * RR_net − (1 − p_win)
RR_net = RR_gross − cost_in_R,  cost_in_R = (spread + 2*slippage) / SL_distance
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EVResult:
    expected_value_r: float      # EV in R-multiples after costs
    rr_gross: float
    rr_net: float
    cost_in_r: float
    p_win: float

    @property
    def is_actionable(self) -> bool:
        return self.expected_value_r > 0.0


def compute_expected_value(
    p_win: float,
    rr_gross: float,
    spread_price: float,
    slippage_price: float,
    sl_distance: float,
) -> EVResult:
    """EV in R after spread/slippage costs.

    p_win: calibrated P(direction) from the ensemble/ML path.
    rr_gross: reward:risk ratio of the planned barriers (gross).
    sl_distance: stop distance in PRICE units (must be > 0).
    """
    if sl_distance <= 0:
        return EVResult(-1.0, rr_gross, 0.0, float("inf"), p_win)
    cost_price = abs(spread_price) + 2.0 * abs(slippage_price)
    cost_in_r = cost_price / sl_distance
    rr_net = rr_gross - cost_in_r
    p = min(max(p_win, 0.0), 1.0)
    ev = p * rr_net - (1.0 - p)
    return EVResult(expected_value_r=ev, rr_gross=rr_gross, rr_net=rr_net,
                    cost_in_r=cost_in_r, p_win=p)
