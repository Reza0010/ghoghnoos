"""v1.6 — Real AI provider connectivity test (used by the panel's Test button).

Makes ONE minimal real API call to the provider:
  - OpenAI-compatible providers → POST /chat/completions with a 1-token ping
  - Gemini → POST /models/{model}:generateContent
Returns provider/latency/http_status/verdict — never fakes success.
The API key never leaves the server; only the verdict is returned.
"""

from __future__ import annotations

import time
from typing import Any

import httpx

from app.panel.settings_store import OPENAI_COMPATIBLE

GEMINI_STYLE = {"gemini"}


def test_provider(provider_name: str, base_url: str, model: str, api_key: str,
                  timeout_seconds: float = 20.0) -> dict:
    """Run a real ping. Returns {"ok", "latency_ms", "http_status", "detail"}."""
    started = time.perf_counter()
    name = provider_name.strip().lower()
    if not api_key:
        return {"ok": False, "latency_ms": 0, "http_status": None,
                "detail": "API key not set — enter it in the settings form first", "real_call": True}
    try:
        if name in GEMINI_STYLE:
            status, detail, usage = _test_gemini(base_url, model, api_key, timeout_seconds)
        else:
            status, detail, usage = _test_openai_compat(base_url, model, api_key, timeout_seconds)
        latency = int((time.perf_counter() - started) * 1000)
        ok = 200 <= status < 300
        return {"ok": ok, "latency_ms": latency, "http_status": status,
                "detail": detail, "usage": usage, "real_call": True,
                "model": model, "provider": name}
    except httpx.TimeoutException:
        return {"ok": False, "latency_ms": int((time.perf_counter() - started) * 1000),
                "http_status": None, "detail": f"timeout after {timeout_seconds}s", "real_call": True}
    except httpx.HTTPError as e:
        return {"ok": False, "latency_ms": int((time.perf_counter() - started) * 1000),
                "http_status": None, "detail": f"transport error: {e}", "real_call": True}
    except Exception as e:  # noqa: BLE001 — surface anything to the UI
        return {"ok": False, "latency_ms": int((time.perf_counter() - started) * 1000),
                "http_status": None, "detail": f"unexpected: {e}", "real_call": True}


def _test_openai_compat(base_url: str, model: str, api_key: str, timeout: float) -> tuple[int, str, dict | None]:
    url = f"{(base_url or '').rstrip('/')}/chat/completions"
    if not base_url:
        return 0, "base_url is empty — set it in the form", None
    payload = {
        "model": model or "gpt-4o-mini",
        "messages": [{"role": "user", "content": "ping — reply with the single word: pong"}],
        "max_tokens": 8,
        "temperature": 0.0,
    }
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    with httpx.Client(timeout=httpx.Timeout(timeout)) as client:
        resp = client.post(url, json=payload, headers=headers)
    if resp.status_code >= 400:
        detail = _extract_error(resp)
        return resp.status_code, detail, None
    data = resp.json()
    try:
        text = data["choices"][0]["message"]["content"]
    except Exception:
        return resp.status_code, "reachable but unexpected response shape", None
    usage = data.get("usage") or {}
    return resp.status_code, f"OK — model replied: {str(text)[:60]!r}", usage


def _test_gemini(base_url: str, model: str, api_key: str, timeout: float) -> tuple[int, str, dict | None]:
    base = (base_url or OPENAI_COMPATIBLE["gemini"]["default_url"]).rstrip("/")
    url = f"{base}/models/{model or 'gemini-2.0-flash'}:generateContent"
    payload = {
        "contents": [{"role": "user", "parts": [{"text": "ping — reply with the single word: pong"}]}],
        "generationConfig": {"temperature": 0.0, "maxOutputTokens": 8},
    }
    with httpx.Client(timeout=httpx.Timeout(timeout)) as client:
        resp = client.post(url, json=payload, headers={"x-goog-api-key": api_key})
    if resp.status_code >= 400:
        return resp.status_code, _extract_error(resp), None
    data = resp.json()
    try:
        text = data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception:
        return resp.status_code, "reachable but unexpected response shape", None
    usage = data.get("usageMetadata") or {}
    return resp.status_code, f"OK — model replied: {str(text)[:60]!r}", usage


def _extract_error(resp: httpx.Response) -> str:
    try:
        data = resp.json()
        err = data.get("error") or data
        msg = err.get("message") if isinstance(err, dict) else None
        return f"HTTP {resp.status_code}: {msg or str(data)[:200]}"
    except Exception:
        return f"HTTP {resp.status_code}: {resp.text[:200]}"
