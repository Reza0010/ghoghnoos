"""v1.7 — Panel LIVE MARKET FEED: real-time gold prices for the panel UI.

A small daemon around :class:`LivePublicProvider` that keeps REAL market data
flowing to the panel EVEN WHEN the trading loop is stopped (the panel must
always show live prices, per the user's requirement).

- own LivePublicProvider instance (independent of the loop's provider —
  the loop may be restarted/reconfigured without interrupting the feed)
- thread-safe snapshot + intraday candle series for the price chart
- never raises: on total failure ``ok=False`` with the error string
"""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path

logger = logging.getLogger(__name__)


class LiveMarketFeed:
    def __init__(self, project_root: Path, config_path: str | None = None) -> None:
        self.root = Path(project_root).resolve()
        self.config_path = config_path
        self._provider = None
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._started_at: float | None = None
        self._last_error = ""
        self._last_ok: float | None = None

    # ------------------------------------------------------------- build --
    def _build(self):
        from app.config.loader import load_config
        from app.data.market.live_public import LivePublicProvider

        cfg = load_config(self.config_path, project_root=self.root)
        return LivePublicProvider(
            symbol=cfg.provider.public_symbol,
            refresh_seconds=cfg.provider.public_refresh_seconds,
            spread_points=cfg.provider.public_spread_points,
            timeout_seconds=cfg.provider.public_timeout_seconds,
            defaults=cfg.symbol.fallback_symbol_info,
            initial_balance=cfg.backtest.initial_balance,
            display_symbol=cfg.symbol.primary,
        )

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()

        def _run() -> None:
            try:
                provider = self._build()
            except Exception as e:  # noqa: BLE001 — config broken → honest error
                self._last_error = f"feed init failed: {type(e).__name__}: {e}"
                logger.warning("[market-feed] %s", self._last_error)
                return
            with self._lock:
                self._provider = provider
            self._started_at = time.time()
            while not self._stop.is_set():
                try:
                    provider.connect()          # idempotent; seeds on first call
                    self._last_ok = time.time()
                    self._last_error = ""
                except Exception as e:  # noqa: BLE001
                    self._last_error = f"{type(e).__name__}: {e}"
                    logger.debug("[market-feed] connect failed: %s", self._last_error)
                    self._stop.wait(30.0)
                    continue
                self._stop.wait(max(15.0, provider._refresh_seconds))

        self._thread = threading.Thread(target=_run, name="panel-market-feed",
                                        daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        with self._lock:
            if self._provider is not None:
                try:
                    self._provider.disconnect()
                except Exception:
                    pass

    # ---------------------------------------------------------- snapshot --
    def snapshot(self) -> dict:
        with self._lock:
            provider = self._provider
        if provider is None:
            return {"ok": False, "error": self._last_error or "feed not initialized",
                    "available": False}
        try:
            snap = provider.snapshot()
            tick = provider.get_tick("XAUUSD") if snap.get("price") else None
            spot = provider.spot_reference()
            return {
                "ok": True,
                "available": True,
                "symbol": "XAUUSD",
                "remote_symbol": snap.get("remote_symbol"),
                "source": snap.get("source"),
                "price": snap.get("price"),
                "bid": tick.bid if tick else None,
                "ask": tick.ask if tick else None,
                "spread_points": snap.get("spread_points"),
                "price_time_utc": snap.get("price_time_utc"),
                "market_open": snap.get("market_open"),
                "tick_age_seconds": snap.get("tick_age_seconds"),
                "spot": spot.get("price") if spot else snap.get("spot"),
                "spot_updated": spot.get("updated") if spot else None,
                "spot_source": spot.get("source") if spot else snap.get("spot_source"),
                "degraded": snap.get("degraded"),
                "error": snap.get("error") or self._last_error,
                "frames": snap.get("frames", {}),
                "feed_uptime_seconds": int(time.time() - self._started_at) if self._started_at else 0,
            }
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "available": False, "error": f"{type(e).__name__}: {e}"}

    def candles(self, timeframe: str = "M5", count: int = 300) -> dict:
        """Candle series for the panel chart (list, oldest→newest)."""
        with self._lock:
            provider = self._provider
        if provider is None:
            return {"ok": False, "error": "feed not initialized", "candles": []}
        try:
            df = provider.get_candles("XAUUSD", timeframe, int(count))
            out = [{"t": str(ts), "o": float(r.open), "h": float(r.high),
                    "l": float(r.low), "c": float(r.close)}
                   for ts, r in df.tail(int(count)).iterrows()]
            return {"ok": True, "timeframe": timeframe, "candles": out,
                    "source": provider.source_label}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": f"{type(e).__name__}: {e}", "candles": []}
