"""XAU AI Trader — Professional AI-Assisted Quantitative Trading Platform.

Package root. All modules are organised by domain responsibility:
data, features, indicators, smc, models, regime, news, ai, signals,
risk, execution, backtest, paper, monitoring, journal, dashboard, utils.

Design principles (enforced project-wide):
- WAIT / NO-TRADE is a first-class, valid output.
- The Risk Engine is deterministic Python and always overrides AI.
- No hard-coded API keys, symbols, risk numbers or magic numbers.
- Data-leakage prevention is audited, not assumed.
"""

__version__ = "0.1.0"
