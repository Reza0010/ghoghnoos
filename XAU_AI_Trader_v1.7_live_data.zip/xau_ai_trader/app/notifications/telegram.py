"""PHASE 42 — Telegram notifications (optional, never fatal)."""

from __future__ import annotations

import logging

import httpx

from app.core.exceptions import NotificationError

logger = logging.getLogger(__name__)

_TEMPLATES = {
    "fa": {
        "BUY": "🟢 سیگنال خرید {symbol} | قیمت {price:.2f} | SL {sl:.2f} | TP {tp:.2f} | لات {lot:.2f}",
        "SELL": "🔴 سیگنال فروش {symbol} | قیمت {price:.2f} | SL {sl:.2f} | TP {tp:.2f} | لات {lot:.2f}",
        "WAIT": "⏳ WAIT — بدون معامله | {reasons}",
        "TRADE_OPEN": "📬 معامله باز شد #{ticket} {side} {lot:.2f} @ {price:.2f}",
        "TRADE_CLOSE": "✅ معامله بسته شد #{ticket} | P/L {pnl:.2f} | دلیل {reason}",
        "DAILY_LOSS": "🛑 حد ضرر روزانه فعال شد ({pct:.2f}%) — معاملات جدید متوقف",
        "KILL_SWITCH": "🚨 KILL SWITCH: {trigger} — {detail}",
        "MT5_DISCONNECT": "⚠️ اتصال MT5 قطع شد",
        "AI_FAILURE": "⚠️ خطای AI: {detail}",
    },
    "en": {
        "BUY": "🟢 BUY {symbol} | price {price:.2f} | SL {sl:.2f} | TP {tp:.2f} | lot {lot:.2f}",
        "SELL": "🔴 SELL {symbol} | price {price:.2f} | SL {sl:.2f} | TP {tp:.2f} | lot {lot:.2f}",
        "WAIT": "⏳ WAIT — no trade | {reasons}",
        "TRADE_OPEN": "📬 Trade opened #{ticket} {side} {lot:.2f} @ {price:.2f}",
        "TRADE_CLOSE": "✅ Trade closed #{ticket} | P/L {pnl:.2f} | reason {reason}",
        "DAILY_LOSS": "🛑 Daily loss limit hit ({pct:.2f}%) — new trades halted",
        "KILL_SWITCH": "🚨 KILL SWITCH: {trigger} — {detail}",
        "MT5_DISCONNECT": "⚠️ MT5 connection lost",
        "AI_FAILURE": "⚠️ AI failure: {detail}",
    },
}


class TelegramNotifier:
    def __init__(self, token: str, chat_id: str, language: str = "fa",
                 events: list[str] | None = None) -> None:
        self.token = token
        self.chat_id = chat_id
        self.language = language if language in _TEMPLATES else "en"
        self.events = set(events or _TEMPLATES[self.language].keys())
        self._client = httpx.Client(timeout=10.0)

    def notify(self, event: str, **kwargs) -> bool:
        if event not in self.events:
            return False
        template = _TEMPLATES[self.language].get(event)
        if template is None:
            return False
        try:
            text = template.format(**{**{k: "" for k in
                                         ("symbol", "price", "sl", "tp", "lot", "reasons", "ticket",
                                          "side", "pnl", "reason", "pct", "trigger", "detail")},
                                      **kwargs})
        except KeyError as e:
            logger.debug("telegram template key missing: %s", e)
            text = f"{event}: {kwargs}"
        try:
            # v1.5 (news-N3): the POST runs in a worker thread via the caller's
            # async bridge (notify_async) — the trading loop must never block
            # on network I/O (Mission 40). The sync path is kept for scripts.
            resp = self._client.post(
                f"https://api.telegram.org/bot{self.token}/sendMessage",
                json={"chat_id": self.chat_id, "text": text[:4000]},
            )
            return resp.status_code == 200
        except Exception as e:
            logger.warning("telegram send failed: %s", e)
            return False

    async def notify_async(self, event: str, **kwargs) -> bool:
        """Non-blocking variant for the async trading loop (Mission 40)."""
        import asyncio

        return await asyncio.to_thread(self.notify, event, **kwargs)


class CompositeNotifier:
    def __init__(self, notifiers: list | None = None) -> None:
        self.notifiers = notifiers or []

    def notify(self, event: str, **kwargs) -> None:
        for n in self.notifiers:
            try:
                n.notify(event, **kwargs)
            except Exception:
                logger.debug("notifier %s failed", type(n).__name__, exc_info=True)


def build_notifier(cfg) -> CompositeNotifier:
    """cfg = NotificationsConfig; token/chat from env only."""
    import os

    notifiers = []
    if cfg.telegram_enabled:
        token = os.environ.get(cfg.telegram_token_env)
        chat_id = os.environ.get(cfg.telegram_chat_id_env)
        if token and chat_id:
            notifiers.append(TelegramNotifier(token, chat_id, cfg.language, cfg.events))
        else:
            logger.info("telegram disabled — token/chat env not set")
    return CompositeNotifier(notifiers)
