"""Security helpers: secret masking, untrusted-text sanitisation.

External content (news feeds, AI responses, any HTTP payload) is treated as
UNTRUSTED DATA. It is sanitised before it can reach logs, the AI prompt or
the journal, and it is never executed or interpreted as instructions.
"""

from __future__ import annotations

import re
from typing import Iterable

_SECRET_KEY_RE = re.compile(
    r"(api[_-]?key|token|secret|password|authorization|bearer)",
    re.IGNORECASE,
)
_CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_MULTI_WS_RE = re.compile(r"\s+")


def mask_secrets(data: object) -> object:
    """Recursively mask values whose key looks like a secret.

    Works on dicts / lists / any nested structure. Values are replaced by
    ``'***'`` preserving type independence.
    """
    if isinstance(data, dict):
        out = {}
        for k, v in data.items():
            if isinstance(k, str) and _SECRET_KEY_RE.search(k):
                out[k] = "***"
            else:
                out[k] = mask_secrets(v)
        return out
    if isinstance(data, (list, tuple)):
        return [mask_secrets(x) for x in data]
    return data


_MASK_IN_TEXT_RE = re.compile(
    r"(?P<key>(?:api[_-]?key|token|secret|password)\s*[=:]\s*)(?P<val>\S+)",
    re.IGNORECASE,
)


def mask_secrets_in_text(text: str) -> str:
    """Mask ``key=value`` style secrets embedded in free text / log lines."""

    def _repl(m: re.Match) -> str:
        return f"{m.group('key')}***"

    return _MASK_IN_TEXT_RE.sub(_repl, text)


def sanitize_untrusted_text(text: str, max_length: int = 300) -> str:
    """Sanitise untrusted text before it enters prompts, logs or storage.

    Steps:
    1. Remove control characters (terminal/prompt injection vectors).
    2. Collapse whitespace.
    3. Neutralise XML/HTML-like delimiters used to fake prompt structure.
    4. Hard-limit length.
    """
    if not isinstance(text, str):
        return ""
    cleaned = _CONTROL_CHARS_RE.sub("", text)
    cleaned = cleaned.replace("<", "‹").replace(">", "›")
    cleaned = _MULTI_WS_RE.sub(" ", cleaned).strip()
    if len(cleaned) > max_length:
        cleaned = cleaned[: max_length - 1] + "…"
    return cleaned


def sanitize_reason_codes(codes: Iterable[str], max_items: int = 10, max_len: int = 48) -> list[str]:
    """Sanitise a list of machine-generated reason codes."""
    out: list[str] = []
    for c in codes or []:
        c = re.sub(r"[^A-Za-z0-9_\-. ]", "", str(c))[:max_len].strip()
        if c and c not in out:
            out.append(c)
        if len(out) >= max_items:
            break
    return out


def is_safe_file_path(path: str, base_dir: str) -> bool:
    """Ensure a user/file-supplied path stays inside ``base_dir`` (no traversal)."""
    import os

    base = os.path.realpath(base_dir)
    candidate = os.path.realpath(os.path.join(base, path))
    return candidate == base or candidate.startswith(base + os.sep)
