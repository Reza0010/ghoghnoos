"""PHASE 3 — Multi-timeframe data container.

Fetches every configured timeframe from a provider, runs quality checks and
exposes aligned access. A low quality score anywhere → the pipeline must
WAIT (enforced in app.pipeline).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import pandas as pd

from app.config.schema import MultiTimeframeConfig, Timeframe
from app.data.market.base import MarketDataProvider
from app.data.quality import QualityReport, check_candles

logger = logging.getLogger(__name__)


@dataclass
class MarketData:
    symbol: str
    frames: dict[str, pd.DataFrame] = field(default_factory=dict)
    quality: dict[str, QualityReport] = field(default_factory=dict)

    def worst_score(self) -> float:
        return min((q.score for q in self.quality.values()), default=100.0)

    def get(self, tf: Timeframe | str) -> pd.DataFrame:
        return self.frames[Timeframe(tf).value]


class MultiTimeframeEngine:
    def __init__(self, provider: MarketDataProvider, cfg: MultiTimeframeConfig, quality_cfg) -> None:
        self.provider = provider
        self.cfg = cfg
        self.quality_cfg = quality_cfg

    def fetch(self, symbol: str, end_time: pd.Timestamp | None = None) -> MarketData:
        md = MarketData(symbol=symbol)
        for tf in self.cfg.enabled:
            bars = self.cfg.bars.get(tf.value, 1500)
            df = self.provider.get_candles(symbol, tf.value, bars, end_time=end_time)
            report = check_candles(
                df, symbol, tf.value, tf.minutes,
                max_gap_factor=self.quality_cfg.max_gap_factor,
                spread_anomaly_z=self.quality_cfg.spread_anomaly_z,
            )
            md.frames[tf.value] = df
            md.quality[tf.value] = report
            if report.issues:
                logger.debug("quality %s %s: score=%.0f issues=%s", symbol, tf.value,
                             report.score, [(i.check, i.severity) for i in report.issues])
        return md
