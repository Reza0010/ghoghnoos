"""v1.7 — LIVE PUBLIC market-data provider: REAL gold prices, zero keys.

Sources (free, no API key, verified 2026-10):
  1. Yahoo Finance chart API  — COMEX gold futures ``GC=F``:
       M1  → interval=1m, range=5d    (~5,700 bars)
       M5  → interval=5m, range=60d   (~17,000 bars)
       H1  → interval=1h, range=730d  (~17,000 bars)
       D1  → interval=1d, range=5y    (~1,260 bars)
       M15/M30 resampled from M5, H4 resampled from H1.
  2. gold-api.com spot ``XAU`` — tick-only fallback when Yahoo is unreachable,
     and a spot-reference price shown in the panel.

Honesty contract (PHASE 65, unchanged):
  - Prices are REAL market prices, but ``GC=F`` is a COMEX *futures* proxy for
    XAUUSD spot (basis risk: futures typically trade a few dollars above spot).
  - The bid/ask spread is NOT available from public sources — it is a
    DOCUMENTED ASSUMPTION (provider.public_spread_points, default 30 pt=$0.30).
  - When the market is closed the tick holds the last REAL traded price and
    ``market_open=False`` — it never invents movement.
  - All failures degrade to cached data + ``degraded`` flag, never fabrication.

Implementation notes:
  - stdlib ``urllib`` in a daemon refresh thread (zero new dependencies, safe
    on Windows + Python 3.13, no event-loop coupling).
  - Tiered refresh: light M1 poll every cycle, M5 every 5th, H1/D1 every 60th.
  - Thread-safe: all reads take a lock; candles are immutable snapshots.
"""

from __future__ import annotations

import json
import logging
import threading
import time
import urllib.request
from datetime import datetime, timezone

import numpy as np
import pandas as pd

from app.config.schema import SymbolInfoDefaults, Timeframe
from app.core.exceptions import ProviderConnectionError
from app.data.market.base import MarketDataProvider
from app.data.market.models import AccountInfo, OrderResult, Position, SymbolInfo, Tick
from app.data.market.simulated import resample_ohlc

logger = logging.getLogger(__name__)

YAHOO_CHART = "https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
YAHOO_QUERY = "?interval={interval}&range={range}"
SPOT_URL = "https://api.gold-api.com/price/XAU"
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# (timeframe, interval, range) → the four Yahoo fetches that seed everything
SEED_FETCHES = [
    ("M1", "1m", "5d"),
    ("M5", "5m", "60d"),
    ("H1", "1h", "730d"),
    ("D1", "1d", "5y"),
]
TIER_OF = {"M1": 0, "M5": 1, "H1": 2, "D1": 2}   # refresh tier per fetch
TIER_EVERY = {0: 1, 1: 5, 2: 60}                  # run tier every N cycles


def _http_get_json(url: str, timeout: float) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT,
                                               "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        if r.status != 200:
            raise ProviderConnectionError(f"HTTP {r.status} from {url}")
        return json.loads(r.read().decode("utf-8", "replace"))


def parse_yahoo_chart(payload: dict) -> tuple[pd.DataFrame, dict]:
    """Yahoo chart JSON → (OHLCV df indexed by UTC, meta dict).

    Raises ProviderConnectionError on any structural surprise (honest failure,
    never partial fabrication)."""
    try:
        result = payload["chart"]["result"][0]
        meta = result["meta"]
        ts = result["timestamp"]
        quote = result["indicators"]["quote"][0]
    except (KeyError, IndexError, TypeError) as e:
        raise ProviderConnectionError(f"yahoo chart payload unexpected: {e}") from e

    idx = pd.to_datetime(ts, unit="s", utc=True)
    df = pd.DataFrame({
        "open": quote.get("open"), "high": quote.get("high"),
        "low": quote.get("low"), "close": quote.get("close"),
        "volume": quote.get("volume"),
    }, index=idx)
    df = df.dropna(subset=["open", "high", "low", "close"])
    df = df[~df.index.duplicated(keep="last")].sort_index()
    meta_out = {
        "symbol": meta.get("symbol"),
        "regular_market_price": meta.get("regularMarketPrice"),
        "regular_market_time": meta.get("regularMarketTime"),
        "currency": meta.get("currency"),
        "exchange": meta.get("fullExchangeName"),
        "fetched_at": time.time(),
    }
    return df, meta_out


def normalize_yahoo_frame(df: pd.DataFrame, spread_price: float) -> pd.DataFrame:
    """Yahoo quote frame → provider OHLCV schema (MT5/simulated contract):
    open/high/low/close/tick_volume/real_volume/spread."""
    out = df.copy()
    out["tick_volume"] = out.pop("volume") if "volume" in out else 0
    out["real_volume"] = 0
    out["spread"] = float(spread_price)
    return out[["open", "high", "low", "close", "tick_volume",
                "real_volume", "spread"]]


class LivePublicProvider(MarketDataProvider):
    """REAL market data from free public sources (Yahoo COMEX GC=F primary)."""

    name = "public-live"

    def __init__(
        self,
        symbol: str = "GC=F",
        refresh_seconds: float = 30.0,
        spread_points: float = 30.0,
        timeout_seconds: float = 15.0,
        defaults: SymbolInfoDefaults | None = None,
        initial_balance: float = 10_000.0,
        display_symbol: str = "XAUUSD",
        start_refresh_thread: bool = True,
    ) -> None:
        self._remote = symbol
        self._refresh_seconds = max(15.0, float(refresh_seconds))
        self._spread_points = float(spread_points)
        self._timeout = float(timeout_seconds)
        self._defaults = defaults or SymbolInfoDefaults()
        self._balance = float(initial_balance)
        self._display = display_symbol

        self._lock = threading.RLock()
        self._connected = False
        self._frames: dict[str, pd.DataFrame] = {}       # TF → OHLCV cache
        self._resampled: dict[str, tuple[str, pd.DataFrame]] = {}  # TF → (src_ts_key, df)
        self._meta: dict = {}
        self._spot: dict | None = None                   # gold-api spot reference
        self._cycle = 0
        self._degraded = False
        self._last_error = ""
        self._last_refresh = 0.0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._auto_thread = start_refresh_thread

    # --------------------------------------------------------- properties --
    @property
    def source_label(self) -> str:
        return f"Yahoo Finance {self._remote} (COMEX) + gold-api spot"

    @property
    def is_degraded(self) -> bool:
        with self._lock:
            return self._degraded

    @property
    def last_error(self) -> str:
        with self._lock:
            return self._last_error

    # ----------------------------------------------------------- fetching --
    def _fetch_candles(self, interval: str, rng: str) -> tuple[pd.DataFrame, dict]:
        url = YAHOO_CHART.format(symbol=self._remote) + YAHOO_QUERY.format(
            interval=interval, range=rng)
        payload = _http_get_json(url, self._timeout)
        return parse_yahoo_chart(payload)

    def _fetch_spot(self) -> dict | None:
        try:
            data = _http_get_json(SPOT_URL, min(10.0, self._timeout))
            price = float(data.get("price") or 0)
            if price <= 0:
                return None
            return {"price": price, "updated": data.get("updatedAt"),
                    "fetched_at": time.time(), "source": "gold-api.com"}
        except Exception as e:  # noqa: BLE001 — spot is best-effort only
            logger.debug("spot fetch failed: %s", e)
            return None

    def refresh(self, force: bool = False) -> None:
        """One refresh cycle (tiered). Never raises — degrades honestly."""
        self._cycle += 1
        ok_any, err = False, ""
        for tf, interval, rng in SEED_FETCHES:
            tier = TIER_OF[tf]
            if not force and self._cycle % TIER_EVERY[tier] != 0:
                continue
            try:
                df, meta = self._fetch_candles(interval, rng)
                with self._lock:
                    spread_price = self._spread_points * float(self._defaults.point)
                    df = normalize_yahoo_frame(df, spread_price)
                    prev = self._frames.get(tf)
                    if prev is not None and len(prev):
                        df = pd.concat([prev[df.index > prev.index[-1]], df])
                        df = df[~df.index.duplicated(keep="last")].sort_index()
                    self._frames[tf] = df
                    self._meta = meta
                    self._resampled.clear()          # derived TFs refresh too
                ok_any = True
            except Exception as e:  # noqa: BLE001
                err = f"{tf}: {type(e).__name__}: {e}"
                logger.debug("live refresh %s failed: %s", tf, err)
        spot = self._fetch_spot()
        with self._lock:
            if spot:
                self._spot = spot
            self._last_refresh = time.time()
            self._degraded = not ok_any
            self._last_error = "" if ok_any else (err or "no source responded")

    def _refresh_loop(self) -> None:
        # initial seed is done by connect(); this loop only keeps data fresh
        while not self._stop.wait(self._refresh_seconds):
            try:
                self.refresh()
            except Exception:  # pragma: no cover — refresh never raises
                logger.debug("refresh cycle error", exc_info=True)

    # ------------------------------------------------------ interface ----
    def connect(self) -> bool:
        if not self._connected:
            # blocking initial seed — the trader's startup health check expects
            # data to be available right after connect()
            self.refresh(force=True)
            with self._lock:
                if not self._frames:
                    raise ProviderConnectionError(
                        f"LivePublicProvider could not fetch any data "
                        f"({self._last_error or 'network unreachable'})")
            self._connected = True
            if self._auto_thread and (self._thread is None or not self._thread.is_alive()):
                self._thread = threading.Thread(
                    target=self._refresh_loop, name="live-public-feed", daemon=True)
                self._thread.start()
        return True

    def disconnect(self) -> None:
        self._stop.set()
        self._connected = False

    def is_connected(self) -> bool:
        return self._connected

    def discover_symbols(self, aliases: list[str]) -> list[SymbolInfo]:
        return [self._symbol_info(a) for a in aliases]

    def _symbol_info(self, name: str) -> SymbolInfo:
        d = self._defaults
        return SymbolInfo(
            name=name,
            digits=int(d.digits), point=float(d.point),
            tick_size=float(d.tick_size), tick_value=float(d.tick_value),
            contract_size=float(d.contract_size),
            volume_min=float(d.volume_min), volume_max=float(d.volume_max),
            volume_step=float(d.volume_step), leverage=int(d.leverage),
            description=(f"Live public data — Yahoo Finance {self._remote} (COMEX "
                         f"futures proxy for {self._display}); spread is a "
                         f"documented assumption ({self._spread_points:.0f} pt)"),
        )

    def get_symbol_info(self, symbol: str) -> SymbolInfo:
        return self._symbol_info(symbol)

    def get_account_info(self) -> AccountInfo:
        return AccountInfo(
            login="public-live",
            balance=self._balance, equity=self._balance,
            margin=0.0, free_margin=self._balance, margin_level=0.0,
            leverage=int(self._defaults.leverage),
        )

    # ---------------------------------------------------------- candles ---
    def _ensure_resampled(self, tf: Timeframe) -> pd.DataFrame:
        """Resample from the best available source TF (cached)."""
        src_map = {"M5": "M1", "M15": "M5", "M30": "M5", "H1": "M5",
                   "H4": "H1", "D1": "H1"}
        direct = {"M1", "M5", "H1", "D1"}
        if tf.value in direct:
            return self._frames.get(tf.value, pd.DataFrame())
        src_tf = src_map.get(tf.value)
        src = self._frames.get(src_tf, pd.DataFrame()) if src_tf else pd.DataFrame()
        if src.empty:
            return pd.DataFrame()
        key = str(src.index[-1])
        cached = self._resampled.get(tf.value)
        if cached and cached[0] == key:
            return cached[1]
        out = resample_ohlc(src, tf)
        self._resampled[tf.value] = (key, out)
        return out

    def get_candles(
        self, symbol: str, timeframe: str, count: int, end_time: pd.Timestamp | None = None
    ) -> pd.DataFrame:
        with self._lock:
            tf = Timeframe(timeframe)
            df = self._ensure_resampled(tf)
            if df is None or df.empty:
                raise ProviderConnectionError(
                    f"no live data for {timeframe} ({self._last_error or 'not connected'})")
            out = df
            if end_time is not None:
                end_time = pd.Timestamp(end_time)
                if end_time.tzinfo is None:
                    end_time = end_time.tz_localize("UTC")
                out = out[out.index <= end_time]
            out = out.tail(int(count)).copy()
            return out

    # ------------------------------------------------------------- tick ---
    def market_open(self) -> bool:
        """True when the exchange reported a fresh price recently.

        Yahoo has a 2–10 min publication lag on GC=F during open hours, so the
        freshness threshold is 15 min. When the market truly closes (daily
        break / weekend) the reported price stops advancing → age grows past
        the threshold → honestly reported closed."""
        with self._lock:
            rmt = (self._meta or {}).get("regular_market_time")
            if rmt:
                age = time.time() - float(rmt)
                return age < 900
            # no meta yet → fall back to newest candle age
            m1 = self._frames.get("M1")
            if m1 is not None and len(m1):
                return (time.time() - m1.index[-1].timestamp()) < 1200
            return False

    def tick_age_seconds(self) -> float | None:
        with self._lock:
            m1 = self._frames.get("M1")
            if m1 is not None and len(m1):
                return time.time() - m1.index[-1].timestamp()
            return None

    def get_tick(self, symbol: str) -> Tick:
        with self._lock:
            m1 = self._frames.get("M1")
            if m1 is None or m1.empty:
                raise ProviderConnectionError(
                    f"no live tick ({self._last_error or 'not connected'})")
            last_ts = m1.index[-1]
            last = float(m1["close"].iloc[-1])
            # meta price is fresher than the last closed M1 bar (intra-minute)
            meta = self._meta or {}
            mp = meta.get("regular_market_price")
            if mp and meta.get("regular_market_time"):
                try:
                    mt = float(meta["regular_market_time"])
                    if mt >= last_ts.timestamp():
                        last = float(mp)
                except (TypeError, ValueError):
                    pass
            spread_price = self._spread_points * float(self._defaults.point)
            half = spread_price / 2.0
            return Tick(time=last_ts.to_pydatetime(),
                        bid=round(last - half, 2), ask=round(last + half, 2),
                        last=round(last, 2))

    def spot_reference(self) -> dict | None:
        with self._lock:
            return dict(self._spot) if self._spot else None

    def snapshot(self) -> dict:
        """Thread-safe summary for the panel market feed."""
        with self._lock:
            m1 = self._frames.get("M1")
            price = None
            ts = None
            if m1 is not None and len(m1):
                price = float(m1["close"].iloc[-1])
                ts = m1.index[-1].isoformat()
            meta = self._meta or {}
            mp = meta.get("regular_market_price")
            if mp:
                try:
                    price = float(mp)     # exchange price is always freshest
                except (TypeError, ValueError):
                    pass
            return {
                "source": self.source_label,
                "remote_symbol": self._remote,
                "price": round(price, 2) if price else None,
                "price_time_utc": ts,
                "market_open": self.market_open() if (m1 is not None and len(m1)) else False,
                "tick_age_seconds": self.tick_age_seconds(),
                "spot": (self._spot or {}).get("price"),
                "spot_source": (self._spot or {}).get("source"),
                "degraded": self._degraded,
                "error": self._last_error,
                "last_refresh": self._last_refresh,
                "spread_points": self._spread_points,
                "frames": {k: len(v) for k, v in self._frames.items()},
            }

    # ---------------------------------------------------------- orders ---
    def get_open_positions(self, symbol: str | None = None,
                           magic: int | None = None) -> list[Position]:
        return []  # execution is handled by the paper executor

    def send_market_order(self, symbol: str, side: str, volume: float, sl: float,
                          tp: float, comment: str, magic: int) -> OrderResult:
        raise ProviderConnectionError("LivePublicProvider does not execute orders — paper executor only")

    def close_position(self, ticket: int) -> OrderResult:
        raise ProviderConnectionError("LivePublicProvider does not execute orders — paper executor only")

    def modify_position(self, ticket: int, sl: float, tp: float) -> OrderResult:
        raise ProviderConnectionError("LivePublicProvider does not execute orders — paper executor only")
