"""Simulated XAUUSD market-data provider (Linux development / testing).

Deterministic synthetic data:
- Regime-switching geometric random walk (trend + range + volatility bursts)
- Session-dependent intraday volatility (Asia/London/NY/overlap)
- Realistic spread widening during rollover and news-ish random spikes
- Weekend gaps honoured (Fri 21:00 UTC close → Sun 22:00 UTC open)

⚠ This provider is for engineering purposes ONLY. Its output says nothing
about real-market profitability (PHASE 61 — honesty about simulation).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.config.schema import SymbolInfoDefaults, Timeframe
from app.core.exceptions import ProviderConnectionError
from app.data.market.base import MarketDataProvider
from app.data.market.models import AccountInfo, OrderResult, Position, SymbolInfo, Tick

TF_MIN = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240, "D1": 1440}


def session_vol_multiplier(hour: int) -> float:
    """Intraday volatility multiplier by UTC hour (documented approximation)."""
    if 12 <= hour < 16:
        return 1.7      # London/NY overlap
    if 7 <= hour < 12:
        return 1.3      # London
    if 16 <= hour < 21:
        return 1.15     # NY afternoon
    if 0 <= hour < 7:
        return 0.7      # Asia
    return 0.5          # late NY / rollover


def resample_ohlc(df: pd.DataFrame, timeframe: Timeframe | str) -> pd.DataFrame:
    """Resample M1 OHLCV to a higher timeframe (bar label = open time)."""
    tf = Timeframe(timeframe)
    rule = f"{tf.minutes}min"
    agg = {"open": "first", "high": "max", "low": "min", "close": "last",
           "tick_volume": "sum", "real_volume": "sum", "spread": "mean"}
    out = df.resample(rule, label="left", closed="left").agg(agg)
    out = out.dropna(subset=["open", "high", "low", "close"])
    return out


class SimulatedProvider(MarketDataProvider):
    name = "simulated"

    def __init__(
        self,
        days: int = 150,
        seed: int = 42,
        start_price: float = 2350.0,
        annual_vol: float = 0.16,
        defaults: SymbolInfoDefaults | None = None,
        initial_balance: float = 10_000.0,
    ) -> None:
        self._days = days
        self._seed = seed
        self._start_price = start_price
        self._annual_vol = annual_vol
        self._defaults = defaults or SymbolInfoDefaults()
        self._connected = False
        self._m1: pd.DataFrame | None = None
        self._counter = 0
        self._balance = initial_balance

    # -------------------------------------------------- data generation ---
    def _market_index(self) -> pd.DatetimeIndex:
        end = pd.Timestamp.now(tz="UTC").floor("min")
        start = end - pd.Timedelta(days=self._days)
        full = pd.date_range(start, end, freq="1min")
        wd = full.weekday
        hour = full.hour
        keep = np.ones(len(full), dtype=bool)
        keep[wd == 5] = False                                   # Saturday closed
        keep[(wd == 6) & (hour < 22)] = False                   # Sunday before open
        keep[(wd == 4) & (hour >= 21)] = False                  # Friday after close
        return full[keep]

    def _generate_m1(self) -> pd.DataFrame:
        idx = self._market_index()
        n = len(idx)
        if n == 0:
            raise ProviderConnectionError("SimulatedProvider produced no market minutes")
        rng = np.random.default_rng(self._seed)
        minutes_per_year = 365 * 24 * 60
        sigma_min = self._annual_vol / np.sqrt(minutes_per_year)

        hours = idx.hour.values
        mult = np.array([session_vol_multiplier(int(h)) for h in hours])

        # Regime switching: segments of trend / range / vol-burst
        drift = np.zeros(n)
        vol_scale = np.ones(n)
        pos = 0
        seg = 0
        while pos < n:
            seg_len = int(rng.integers(240, 241 * 6))  # 4h..24h segments
            kind = seg % 3
            seg += 1
            stop = min(pos + seg_len, n)
            if kind == 0:      # trending
                drift[pos:stop] = rng.choice([-1.0, 1.0]) * sigma_min * 0.35
                vol_scale[pos:stop] = 1.1
            elif kind == 1:    # ranging
                drift[pos:stop] = 0.0
                vol_scale[pos:stop] = 0.7
            else:              # volatility burst
                drift[pos:stop] = rng.choice([-0.5, 0.5]) * sigma_min * 0.2
                vol_scale[pos:stop] = 2.2
            pos = stop

        noise = rng.standard_normal(n)
        rets = drift * mult * 0.5 + sigma_min * mult * vol_scale * noise
        close = self._start_price * np.exp(np.cumsum(rets))
        open_ = np.empty(n)
        open_[0] = self._start_price
        open_[1:] = close[:-1]

        wick = np.abs(rng.standard_normal(n)) * sigma_min * mult * vol_scale * 0.6
        high = np.maximum(open_, close) + wick
        low = np.minimum(open_, close) - wick

        base_tv = 40 * mult * vol_scale
        tick_volume = rng.lognormal(mean=np.log(base_tv), sigma=0.35).astype(np.int64)
        real_volume = (tick_volume * rng.uniform(0, 1, n)).astype(np.int64)

        # Spread in points: 12..45 typical for XAUUSD brokers, wider at rollover
        spread_pts = 12 + 30 * (rng.random(n)) + np.where((hours >= 21) & (hours < 23), 25, 0)
        spread_price = spread_pts * self._defaults.point

        df = pd.DataFrame(
            {
                "open": open_, "high": high, "low": low, "close": close,
                "tick_volume": tick_volume, "real_volume": real_volume,
                "spread": spread_price,
            },
            index=idx,
        )
        df.index.name = "time"
        return df

    def _ensure_data(self) -> pd.DataFrame:
        if self._m1 is None:
            self._m1 = self._generate_m1()
        return self._m1

    # ------------------------------------------------------ interface ----
    def connect(self) -> bool:
        self._ensure_data()
        self._connected = True
        return True

    def disconnect(self) -> None:
        self._connected = False

    def is_connected(self) -> bool:
        return self._connected

    def discover_symbols(self, aliases: list[str]) -> list[SymbolInfo]:
        return [self._symbol_info(a) for a in aliases]

    def _symbol_info(self, name: str) -> SymbolInfo:
        return SymbolInfo(
            name=name,
            digits=int(self._defaults.digits),
            point=float(self._defaults.point),
            tick_size=float(self._defaults.tick_size),
            tick_value=float(self._defaults.tick_value),
            contract_size=float(self._defaults.contract_size),
            volume_min=float(self._defaults.volume_min),
            volume_max=float(self._defaults.volume_max),
            volume_step=float(self._defaults.volume_step),
            leverage=int(self._defaults.leverage),
            description=f"Simulated {name} (synthetic data)",
        )

    def get_symbol_info(self, symbol: str) -> SymbolInfo:
        return self._symbol_info(symbol)

    def get_account_info(self) -> AccountInfo:
        return AccountInfo(
            login="simulated",
            balance=self._balance,
            equity=self._balance,
            margin=0.0,
            free_margin=self._balance,
            margin_level=0.0,
            leverage=int(self._defaults.leverage),
        )

    def get_candles(
        self, symbol: str, timeframe: str, count: int, end_time: pd.Timestamp | None = None
    ) -> pd.DataFrame:
        m1 = self._ensure_data()
        tf = Timeframe(timeframe)
        if end_time is not None:
            end_time = pd.Timestamp(end_time)
            if end_time.tzinfo is None:
                end_time = end_time.tz_localize("UTC")
            m1 = m1[m1.index <= end_time]
        if tf == Timeframe.M1:
            return m1.tail(count).copy()
        hi = resample_ohlc(m1, tf)
        return hi.tail(count).copy()

    def get_tick(self, symbol: str) -> Tick:
        m1 = self._ensure_data()
        last = m1.iloc[-1]
        mid = float(last["close"])
        half = float(last["spread"]) / 2.0
        return Tick(time=m1.index[-1].to_pydatetime(), bid=mid - half, ask=mid + half, last=mid)

    def get_open_positions(self, symbol: str | None = None, magic: int | None = None) -> list[Position]:
        return []  # execution is handled by the paper executor, not the data provider

    def send_market_order(self, symbol: str, side: str, volume: float, sl: float, tp: float,
                          comment: str, magic: int) -> OrderResult:
        raise ProviderConnectionError("SimulatedProvider does not execute orders — use PaperExecutor")

    def close_position(self, ticket: int) -> OrderResult:
        raise ProviderConnectionError("SimulatedProvider does not execute orders — use PaperExecutor")

    def modify_position(self, ticket: int, sl: float, tp: float) -> OrderResult:
        raise ProviderConnectionError("SimulatedProvider does not execute orders — use PaperExecutor")
