"""Market data models (pydantic, validated)."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class SymbolInfo(BaseModel):
    name: str
    digits: int = 2
    point: float = 0.01
    tick_size: float = 0.01
    tick_value: float = 1.0
    contract_size: float = 100.0
    volume_min: float = 0.01
    volume_max: float = 100.0
    volume_step: float = 0.01
    spread_points: float = 0.0
    leverage: int = 100
    description: str = ""
    # v1.5 provenance: True when tick_value was synthesized as
    # contract_size*point because the broker reported 0/None.
    # LIVE risk paths must fail-closed (WAIT) on fallback values.
    tick_value_is_fallback: bool = False
    # v1.5 broker stop-distance constraints (points; 0 = broker reports none)
    stops_level_points: int = 0
    freeze_level_points: int = 0

    @field_validator("tick_size", "point")
    @classmethod
    def _positive(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("tick_size/point must be positive")
        return v


class AccountInfo(BaseModel):
    login: str = "simulated"
    balance: float = 0.0
    equity: float = 0.0
    margin: float = 0.0
    free_margin: float = 0.0
    margin_level: float = 0.0
    currency: str = "USD"
    leverage: int = 100


class Tick(BaseModel):
    time: datetime
    bid: float
    ask: float
    last: float = 0.0
    volume: float = 0.0

    @property
    def spread(self) -> float:
        return self.ask - self.bid


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class Position(BaseModel):
    ticket: int
    symbol: str
    side: Literal["BUY", "SELL"]
    volume: float
    open_price: float
    sl: float = 0.0
    tp: float = 0.0
    open_time: datetime
    comment: str = ""
    magic: int = 0
    profit: float = 0.0
    swap: float = 0.0
    commission: float = 0.0


class OrderResult(BaseModel):
    success: bool
    retcode: int = 0
    ticket: int = 0
    price: float = 0.0
    volume: float = 0.0
    comment: str = ""
    deal: int = 0


class CandleFrame(BaseModel):
    """Wrapper carrying a candle DataFrame with provenance metadata."""

    symbol: str
    timeframe: str
    rows: int
    first_time: datetime | None = None
    last_time: datetime | None = None
    source: str = "unknown"
