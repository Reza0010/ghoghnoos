"""Abstract market-data provider interface.

Implementations:
- ``app.data.mt5.provider.MT5DataProvider``  — real MetaTrader 5 (Windows).
- ``app.data.market.simulated.SimulatedProvider`` — deterministic synthetic
  XAUUSD data for development/testing on Linux (clearly labelled simulated).
"""

from __future__ import annotations

import abc
import pandas as pd

from app.data.market.models import AccountInfo, OrderResult, Position, SymbolInfo, Tick


class MarketDataProvider(abc.ABC):
    """All timestamps produced by providers are tz-aware UTC."""

    name: str = "base"

    @abc.abstractmethod
    def connect(self) -> bool: ...

    @abc.abstractmethod
    def disconnect(self) -> None: ...

    @abc.abstractmethod
    def is_connected(self) -> bool: ...

    @abc.abstractmethod
    def discover_symbols(self, aliases: list[str]) -> list[SymbolInfo]: ...

    @abc.abstractmethod
    def get_symbol_info(self, symbol: str) -> SymbolInfo: ...

    @abc.abstractmethod
    def get_account_info(self) -> AccountInfo: ...

    @abc.abstractmethod
    def get_candles(
        self,
        symbol: str,
        timeframe: str,
        count: int,
        end_time: pd.Timestamp | None = None,
    ) -> pd.DataFrame:
        """Return OHLCV DataFrame indexed by UTC time with columns:
        open, high, low, close, tick_volume, real_volume, spread."""

    @abc.abstractmethod
    def get_tick(self, symbol: str) -> Tick: ...

    @abc.abstractmethod
    def get_open_positions(self, symbol: str | None = None, magic: int | None = None) -> list[Position]: ...

    @abc.abstractmethod
    def send_market_order(
        self,
        symbol: str,
        side: str,
        volume: float,
        sl: float,
        tp: float,
        comment: str,
        magic: int,
    ) -> OrderResult: ...

    @abc.abstractmethod
    def close_position(self, ticket: int) -> OrderResult: ...

    @abc.abstractmethod
    def modify_position(self, ticket: int, sl: float, tp: float) -> OrderResult: ...

    @property
    def supports_real_execution(self) -> bool:
        return False
