"""PHASE 2 — Data quality validation and scoring.

A low quality score is a hard veto: the pipeline must return WAIT/NO-TRADE.
Checks:
- missing candles (unexpected gaps, weekend-aware)
- duplicate timestamps
- out-of-order timestamps
- impossible OHLC (high<max(o,c), low>min(o,c), zero/negative prices)
- spread anomalies (z-score vs rolling median)
- staleness (last bar too old)
- timezone sanity (tz-aware, monotonic)
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from app.core.exceptions import DataError

_WEEKEND_ALLOWED = {"fri_to_sun", "sun_open", "fri_close", "daily"}


@dataclass
class QualityIssue:
    check: str
    severity: str  # "error" | "warning"
    detail: str


@dataclass
class QualityReport:
    symbol: str
    timeframe: str
    score: float
    issues: list[QualityIssue] = field(default_factory=list)
    stats: dict = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return self.score >= 70.0 and not any(i.severity == "error" for i in self.issues)

    def error_issues(self) -> list[QualityIssue]:
        return [i for i in self.issues if i.severity == "error"]


def _spans_weekend(start: pd.Timestamp, gap_minutes: float) -> bool:
    """True when the interval [start, start+gap_minutes] touches a Saturday
    or a Sunday (v1.5 fix: the staleness exemption must test the actual
    quiet interval, not a mis-derived anchor)."""
    end = start + pd.Timedelta(minutes=float(gap_minutes))
    days = int(gap_minutes // (24 * 60)) + 2
    for d in range(days):
        mid = start + pd.Timedelta(days=d)
        if mid > end:
            break
        if mid.weekday() >= 5:
            return True
    return False


def _is_weekend_gap(start: pd.Timestamp, gap_minutes: float) -> bool:
    """Friday-evening→Sunday-evening closures (and D1 windows) are normal."""
    if gap_minutes >= 3 * 24 * 60:
        return True
    wd, h = start.weekday(), start.hour
    if wd == 4 and h >= 20:            # Friday late
        return True
    if wd == 6 and h < 23:             # Sunday
        return True
    return False


def _is_daily_session_break(start: pd.Timestamp, gap_minutes: float) -> bool:
    """PHASE 65: CME-style daily maintenance pause (17:00–18:00 ET). The last
    pre-break bar can start 20:45–22:00 UTC depending on DST and bar stamping.
    Real exchange structure, not missing data. Applies to short gaps only."""
    if gap_minutes > 100:
        return False
    return start.hour in (20, 21, 22)


def _is_holiday_closure(start: pd.Timestamp, gap_minutes: float) -> bool:
    """PHASE 65: exchange holidays and early closes.

    Real CME closures include pre-holiday half days (13:00/17:30 ET closes
    before July-4th, Thanksgiving, Christmas) which break the naive
    Friday-20:00 weekend rule. A gap is a legitimate closure when:
    - its window touches a Saturday/Sunday (weekend + adjacent holiday), or
    - it is a 3h–48h weekday pause starting overnight (<06 UTC) or afternoon
      (>=16 UTC) — full-day holidays and pre-holiday early closes.
    Anything else (intraday drops during continuous trading) stays an error.
    """
    start = pd.Timestamp(start)
    end = start + pd.Timedelta(minutes=float(gap_minutes))
    days = int(gap_minutes // (24 * 60)) + 2
    for d in range(days):
        mid = start + pd.Timedelta(days=d)
        if mid > end:
            break
        if mid.weekday() >= 5:
            return True
    # full weekday pause of 3h–48h is a holiday/early close ONLY when it starts
    # overnight (<06:00 UTC, full-day holidays) or in the afternoon (>=16:00 UTC,
    # pre-holiday early closes). An intraday drop during continuous trading
    # (e.g. 3h gap starting 08:00) remains an error.
    if 3 * 60 <= gap_minutes <= 48 * 60 and (start.hour < 6 or start.hour >= 16):
        return True
    return False


def check_candles(
    df: pd.DataFrame,
    symbol: str,
    timeframe: str,
    tf_minutes: int,
    max_gap_factor: float = 3.0,
    spread_anomaly_z: float = 6.0,
    stale_after_bars: int | None = None,
) -> QualityReport:
    issues: list[QualityIssue] = []
    stats: dict = {}

    if df is None or len(df) == 0:
        return QualityReport(symbol, timeframe, 0.0,
                             [QualityIssue("empty", "error", "no candles returned")], {"rows": 0})

    score = 100.0

    # --- index sanity -----------------------------------------------------
    if not isinstance(df.index, pd.DatetimeIndex):
        raise DataError("Candle index must be a DatetimeIndex")
    if df.index.tz is None:
        issues.append(QualityIssue("timezone", "error", "index is tz-naive; UTC required"))
        score -= 30
    mono = df.index.is_monotonic_increasing
    dups = int(df.index.duplicated().sum())
    if dups:
        issues.append(QualityIssue("duplicates", "error", f"{dups} duplicate timestamps"))
        score -= min(40, dups * 2)
    if not mono:
        issues.append(QualityIssue("order", "error", "timestamps out of order"))
        score -= 25

    # --- price sanity ------------------------------------------------------
    px = df[["open", "high", "low", "close"]]
    if (px <= 0).any().any():
        n_bad = int((px <= 0).any(axis=1).sum())
        issues.append(QualityIssue("non_positive_price", "error", f"{n_bad} rows with zero/negative prices"))
        score -= 40
    bad_ohlc = int(((df.high < df[["open", "close"]].max(axis=1)) |
                    (df.low > df[["open", "close"]].min(axis=1))).sum())
    if bad_ohlc:
        issues.append(QualityIssue("impossible_ohlc", "error", f"{bad_ohlc} rows violate OHLC logic"))
        score -= min(40, bad_ohlc * 2)
    stats["impossible_ohlc"] = bad_ohlc

    # --- gaps ---------------------------------------------------------------
    ts_ns = df.index.values.astype("datetime64[ns]").astype("int64")
    diffs_min = np.diff(ts_ns) / 60e9
    expected = tf_minutes
    gap_mask = diffs_min > expected * max_gap_factor
    idx_gap = np.where(gap_mask)[0]
    weekend_ok = np.array([
        _is_weekend_gap(df.index[i], float(diffs_min[i])) for i in idx_gap
    ], dtype=bool) if gap_mask.any() else np.array([], dtype=bool)
    session_breaks = np.array([
        (not weekend_ok[j]) and _is_daily_session_break(df.index[i], float(diffs_min[i]))
        for j, i in enumerate(idx_gap)
    ], dtype=bool) if len(idx_gap) else np.array([], dtype=bool)
    holidays = np.array([
        (not weekend_ok[j]) and (not session_breaks[j])
        and _is_holiday_closure(df.index[i], float(diffs_min[i]))
        for j, i in enumerate(idx_gap)
    ], dtype=bool) if len(idx_gap) else np.array([], dtype=bool)
    real_gaps = int(len(idx_gap) - weekend_ok.sum() - session_breaks.sum() - holidays.sum())
    stats["unexpected_gaps"] = real_gaps
    stats["weekend_gaps"] = int(weekend_ok.sum())
    stats["daily_session_breaks"] = int(session_breaks.sum())
    stats["holiday_closures"] = int(holidays.sum())
    if real_gaps:
        issues.append(QualityIssue("missing_candles", "warning" if real_gaps <= 5 else "error",
                                   f"{real_gaps} unexpected gaps"))
        score -= min(35, real_gaps * 3)

    # --- spread anomalies ----------------------------------------------------
    if "spread" in df.columns and df["spread"].notna().sum() > 20:
        s = df["spread"].astype(float)
        med = s.rolling(200, min_periods=20).median()
        z = (s - med) / (med.abs() + 1e-12)
        n_spread_anom = int((z > spread_anomaly_z).sum())
        stats["spread_anomalies"] = n_spread_anom
        stats["spread_median"] = float(med.iloc[-1]) if med.notna().any() else 0.0
        if n_spread_anom > len(df) * 0.01:
            issues.append(QualityIssue("spread_anomaly", "warning", f"{n_spread_anom} anomalous spread bars"))
            score -= min(15, n_spread_anom)

    # --- staleness ------------------------------------------------------------
    last_ts = df.index[-1]
    if last_ts.tzinfo is None:
        last_ts = last_ts.tz_localize("UTC")
    age_min = (pd.Timestamp.now(tz="UTC") - last_ts).total_seconds() / 60.0
    stats["last_bar_age_minutes"] = float(age_min)
    # v1.5: honour the configured stale_after_bars knob (bars, not a magic 10x)
    stale_bars = int(stale_after_bars) if stale_after_bars else 10
    if age_min > expected * stale_bars and not (
            _spans_weekend(last_ts, age_min) or _is_holiday_closure(last_ts, age_min)):
        issues.append(QualityIssue("stale_data", "error", f"last bar is {age_min:.0f} minutes old"))
        score -= 20

    score = max(0.0, min(100.0, score))
    stats.update({"rows": int(len(df)), "duplicates": dups,
                  "first": str(df.index[0]), "last": str(last_ts)})
    return QualityReport(symbol=symbol, timeframe=timeframe, score=score, issues=issues, stats=stats)
