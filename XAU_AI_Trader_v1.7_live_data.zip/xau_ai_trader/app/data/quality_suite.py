"""PHASE 65 (§5) — Full data-quality suite for REAL datasets.

Extends the runtime quality scorer (app.data.quality) with the additional
checks required for real-data validation reporting:

- zero / flat volume detection
- abnormal spread share
- weekend-closure gap audit (futures/spot session aware)
- timezone & freshness
- per-check pass/fail suitable for data_quality_report.json
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.data.dataset_meta import DatasetMetadata
from app.data.quality import QualityReport, check_candles


def _zero_volume_share(df: pd.DataFrame) -> float:
    vol = df["real_volume"].astype(float) + df["tick_volume"].astype(float)
    return float((vol <= 0).mean()) if len(vol) else 1.0


def _flat_price_share(df: pd.DataFrame) -> float:
    return float((df["high"] == df["low"]).mean()) if len(df) else 1.0


def run_quality_suite(
    df: pd.DataFrame,
    meta: DatasetMetadata,
    tf_minutes: int,
    max_gap_factor: float = 3.0,
    spread_anomaly_z: float = 6.0,
) -> dict:
    """Run every §5 check on a real dataset and return a JSON-ready report."""
    report: QualityReport = check_candles(
        df, meta.symbol, meta.timeframe, tf_minutes,
        max_gap_factor=max_gap_factor, spread_anomaly_z=spread_anomaly_z,
    )
    checks: dict[str, dict] = {}

    def _ok(name: str, passed: bool, detail: str, severity: str = "error") -> None:
        checks[name] = {"passed": bool(passed), "detail": detail, "severity": severity}

    stats = report.stats
    _ok("missing_candles", stats.get("unexpected_gaps", 0) <= 5,
        f"unexpected_gaps={stats.get('unexpected_gaps', 0)}, "
        f"weekend_closures={stats.get('weekend_gaps', 0)}")
    _ok("duplicates", stats.get("duplicates", 0) == 0,
        f"duplicates={stats.get('duplicates', 0)}")
    _ok("timestamp_ordering", not any(i.check == "order" for i in report.issues),
        "monotonic increasing" if not any(i.check == "order" for i in report.issues)
        else "out-of-order timestamps found")
    _ok("ohlc_consistency", stats.get("impossible_ohlc", 0) == 0,
        f"violations={stats.get('impossible_ohlc', 0)}")
    _ok("timezone", df.index.tz is not None,
        f"tz={df.index.tz} (must be declared)" if df.index.tz is not None else "tz-naive")

    zs = _zero_volume_share(df)
    _ok("zero_volume", zs < 0.50, f"zero-volume share={zs:.2%}", severity="warning")
    fs = _flat_price_share(df)
    _ok("flat_bars", fs < 0.20, f"flat (high==low) share={fs:.2%}", severity="warning")

    if "spread" in df.columns and df["spread"].astype(float).abs().sum() > 0:
        s = df["spread"].astype(float)
        z = (s - s.rolling(200, min_periods=20).median()) / (
            s.rolling(200, min_periods=20).median().abs() + 1e-12)
        anom = float((z > spread_anomaly_z).mean())
        _ok("abnormal_spread", anom < 0.01, f"anomalous share={anom:.2%}", severity="warning")
    else:
        _ok("abnormal_spread", True,
            "no broker spread column in dataset — spread_available=false "
            "(costs modelled via documented assumed_spread)", severity="warning")

    weekend = stats.get("weekend_gaps", 0)
    _ok("weekend_gaps", True, f"{weekend} weekend/insertion-break closures detected (expected)",
        severity="warning")

    return {
        "file": f"{meta.symbol}_{meta.timeframe}",
        "source": meta.source,
        "instrument": meta.instrument,
        "data_kind": meta.data_kind,
        "bar_count": int(len(df)),
        "start": str(df.index[0]) if len(df) else None,
        "end": str(df.index[-1]) if len(df) else None,
        "score": report.score,
        "runtime_score_passed": bool(report.passed),
        "checks": checks,
        "stats": stats,
        "issues": [{"check": i.check, "severity": i.severity, "detail": i.detail}
                   for i in report.issues],
    }
