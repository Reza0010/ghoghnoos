"""PHASE 40/41 — Optional Streamlit web dashboard (FA/EN with RTL).

Install optionally:  pip install streamlit
Run:                 python dashboard.py --web
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).parents[2]))

from app.config.loader import load_config  # noqa: E402
from app.journal.journal import Journal  # noqa: E402

st.set_page_config(page_title="XAU AI Trader", layout="wide", initial_sidebar_state="expanded")

lang = st.sidebar.radio("Language / زبان", ["fa", "en"], index=0)
cfg = load_config()
RTL = lang == "fa"

T = {
    "fa": {"title": "🪙 داشبورد معاملات هوشمند XAUUSD", "price": "قیمت فعلی",
           "regime": "رژیم بازار", "news": "ریسک خبری", "quality": "کیفیت داده",
           "balance": "موجودی", "equity": "اکوییتی", "daily": "سود/زیان روز",
           "open": "پوزیشن باز", "kill": "کیل سوئیچ", "signals": "سیگنال‌های اخیر",
           "trades": "معاملات اخیر", "ai": "وضعیت AI", "health": "سلامت سیستم",
           "win_rate": "نرخ برد", "pf": "ضریب سود"},
    "en": {"title": "🪙 XAUUSD AI Trading Dashboard", "price": "Price",
           "regime": "Regime", "news": "News Risk", "quality": "Data Quality",
           "balance": "Balance", "equity": "Equity", "daily": "Daily P/L",
           "open": "Open Positions", "kill": "Kill Switch", "signals": "Recent Signals",
           "trades": "Recent Trades", "ai": "AI Status", "health": "System Health",
           "win_rate": "Win Rate", "pf": "Profit Factor"},
}[lang]


def rtl(text: str) -> str:
    return f"<div style='direction:rtl;text-align:right'>{text}</div>" if RTL else text


state = {}
state_path = Path(cfg.paths.logs_dir) / "state.json"
if state_path.exists():
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
    except Exception:
        state = {}

st.title(T["title"]) if not RTL else st.markdown(rtl(f"<h2>{T['title']}</h2>"), unsafe_allow_html=True)

acc = state.get("account", {})
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric(T["price"], state.get("price") or "—")
# v1.5 (dashboard fix): the state key is `current_regime` (trader.py) — the
# old `regime` lookup always rendered "—".
c2.metric(T["regime"], state.get("current_regime") or "—")
c3.metric(T["news"], state.get("news_risk") or "—")
c4.metric(T["quality"], f"{state.get('data_quality', 0):.0f}" if state else "—")
c5.metric(T["kill"], "🚨 ACTIVE" if state.get("kill_switch", {}).get("active") else "OK")

# v1.5 (Mission 38): decision-grade monitoring panel — ML probabilities,
# SMC bias, AI status, spread and data freshness that the trader already
# publishes but the dashboard never displayed.
with st.expander("Decision state / وضعیت تصمیم", expanded=True):
    m1, m2, m3, m4, m5 = st.columns(5)
    ml_prob = state.get("ml_probability") or {}
    m1.metric("ML BUY", ml_prob.get("BUY", "—"))
    m1.metric("ML SELL", ml_prob.get("SELL", "—"))
    m1.metric("ML NO_EDGE", ml_prob.get("NO_EDGE", "—"))
    m2.metric("SMC bias", state.get("smc_bias", "—"))
    m2.metric("AI", state.get("ai_status", "—"))
    m3.metric("Spread", state.get("spread", "—"))
    m3.metric("Freshness (min)", state.get("data_freshness_minutes", "—"))
    risk_status = state.get("risk_status", {})
    m4.metric("Daily loss %", risk_status.get("daily_loss_pct", "—"))
    m4.metric("Drawdown %", risk_status.get("drawdown_pct", "—"))
    m5.metric("Mode", state.get("mode", "—"))
    m5.metric("Connected", "YES" if state.get("mt5_connected") else "NO")
    if state.get("last_signal"):
        st.caption("Last wait reasons: " + ", ".join(map(str, state["last_signal"])))

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric(T["balance"], acc.get("balance", "—"))
c2.metric(T["equity"], acc.get("equity", "—"))
c3.metric(T["daily"], state.get("daily_pnl", "—"))
c4.metric(T["open"], state.get("open_positions", "—"))
stats = state.get("trade_stats", {})
c5.metric(T["win_rate"], f"{stats.get('win_rate_pct', 0):.1f}%")

left, right = st.columns(2)
with left:
    st.subheader(T["signals"])
    try:
        j = Journal(Path(cfg.paths.logs_dir) / "journal.db")
        df = pd.DataFrame(j.recent_signals(15))
        if not df.empty:
            st.dataframe(df[["ts", "decision", "score", "regime", "news_risk", "reasons"]])
        else:
            st.info("—")
        st.subheader(T["ai"])
        st.json(j.ai_stats())
        j.close()
    except Exception as e:
        st.warning(str(e))
with right:
    st.subheader(T["health"])
    for h in state.get("health", []):
        st.write(f"{h['name']}: **{h['status']}** — {h['detail']}")
    st.subheader(T["trades"])
    try:
        j = Journal(Path(cfg.paths.logs_dir) / "journal.db")
        tdf = pd.DataFrame(j.recent_trades(15))
        st.dataframe(tdf) if not tdf.empty else st.info("—")
        j.close()
    except Exception:
        st.info("—")
