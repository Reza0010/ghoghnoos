"""PHASE 13/14/15/16 — Concrete AI providers (config-driven, keyless code)."""

from __future__ import annotations

import time

import httpx

from app.ai.base import AIProvider, OpenAICompatibleProvider
from app.core import exceptions as exc

DEFAULT_URLS = {
    "zai": "https://api.z.ai/api/paas/v4",
    "groq": "https://api.groq.com/openai/v1",
    "openrouter": "https://openrouter.ai/api/v1",
}
DEFAULT_MODELS = {
    "zai": "glm-4.6",
    "groq": "llama-3.3-70b-versatile",
    "openrouter": "openai/gpt-4o-mini",
}


class ZAIProvider(OpenAICompatibleProvider):
    name = "zai"


class GroqProvider(OpenAICompatibleProvider):
    name = "groq"


class OpenRouterProvider(OpenAICompatibleProvider):
    name = "openrouter"


class GeminiProvider(AIProvider):
    name = "gemini"

    async def _complete(self, system: str, user: str) -> tuple[str, dict | None]:
        url = f"{self.base_url}/models/{self.model}:generateContent"
        payload = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {"temperature": self.temperature, "maxOutputTokens": self.max_tokens},
        }
        started = time.perf_counter()
        try:
            resp = await self.client.post(
                url, json=payload, headers={"x-goog-api-key": self.api_key}
            )
        except httpx.TimeoutException as e:
            raise exc.AITimeoutError(f"{self.name}: timeout") from e
        except httpx.HTTPError as e:
            raise exc.AIServerError(f"{self.name}: transport error: {e}") from e
        finally:
            self.last_latency_ms = int((time.perf_counter() - started) * 1000)
        if resp.status_code == 429:
            raise exc.AIRateLimitError(f"{self.name}: rate limited (429)")
        if resp.status_code >= 500:
            raise exc.AIServerError(f"{self.name}: server error {resp.status_code}")
        if resp.status_code >= 400:
            raise exc.AIProviderError(f"{self.name}: HTTP {resp.status_code}")
        data = resp.json()
        try:
            text = data["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError, TypeError) as e:
            raise exc.AIInvalidResponseError(f"{self.name}: unexpected response shape") from e
        usage = data.get("usageMetadata") or {}
        return text, {"input_tokens": usage.get("promptTokenCount"),
                      "output_tokens": usage.get("candidatesTokenCount")}
