"""PHASE 65 (§17) — Cost-aware AI gate.

The AI is NEVER called per candle. A real AI call only happens when ALL of:
1. an ML setup is detected        (ensemble-level ML gate passed)
2. SMC confirms the direction     (no SMC conflict)
3. the risk pre-check passes      (quality/spread/daily-loss quick gates)

This module is the single authoritative place implementing that policy so the
trader loop, the backtester AI mode and test scripts behave identically.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class GateResult:
    allowed: bool
    reasons: list[str]


def should_call_ai(
    ml_actionable: bool,
    ml_side: str | None,
    smc_bias: float,
    smc_conflict_margin: float,
    quality_ok: bool,
    spread_ok: bool,
    daily_loss_ok: bool,
    min_smc_alignment: float = 0.0,
) -> GateResult:
    reasons: list[str] = []
    if not ml_actionable:
        reasons.append("GATE_NO_ML_SETUP")
    if not quality_ok:
        reasons.append("GATE_DATA_QUALITY")
    if not spread_ok:
        reasons.append("GATE_SPREAD")
    if not daily_loss_ok:
        reasons.append("GATE_DAILY_LOSS")
    # SMC must not actively contradict the ML side
    if ml_side == "BUY" and smc_bias < -abs(smc_conflict_margin):
        reasons.append("GATE_SMC_CONFLICT")
    if ml_side == "SELL" and smc_bias > abs(smc_conflict_margin):
        reasons.append("GATE_SMC_CONFLICT")
    # optional: require at least weak SMC alignment
    if min_smc_alignment > 0.0 and ml_side is not None:
        aligned = smc_bias if ml_side == "BUY" else -smc_bias
        if aligned < min_smc_alignment:
            reasons.append("GATE_SMC_NOT_ALIGNED")
    return GateResult(allowed=not reasons, reasons=reasons)
