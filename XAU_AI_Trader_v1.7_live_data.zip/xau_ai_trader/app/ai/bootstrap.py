"""PHASE 65 (§12) — AI credentials bootstrap (secrets stay out of code).

Loads provider credentials from the environment or (in this sandbox) from the
platform config file, and exposes them ONLY via environment variables that the
AI gateway already understands:

    ZAI_API_KEY            → api_key_env of the zai provider
    ZAI_BASE_URL           → printed nowhere, used to build the provider
    ZAI_MODEL              → model id
    ZAI_EXTRA_HEADERS      → JSON dict of gateway-specific headers

Nothing here ever prints a key. If no credential source exists the function
returns False and the caller must report AI tests as NOT RUN (honest status).
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

POSSIBLE_CONFIG_PATHS = (
    "/etc/.z-ai-config",
    str(Path.home() / ".z-ai-config"),
    ".z-ai-config",
)


def load_zai_credentials_into_env(config_path: str | None = None) -> dict:
    """Populate ZAI_* env vars. Returns metadata {model, base_url_host, source}."""
    src = None
    cfg: dict = {}
    candidates = [config_path] if config_path else list(POSSIBLE_CONFIG_PATHS)
    for cand in candidates:
        p = Path(cand)
        if p and p.exists():
            try:
                cfg = json.loads(p.read_text(encoding="utf-8"))
                src = str(p)
                break
            except Exception:
                continue

    if not cfg and os.environ.get("ZAI_API_KEY"):
        # credentials already in env (user's own .env) — nothing to inject
        return {"source": "env", "model": os.environ.get("ZAI_MODEL", "glm-4.6"),
                "base_url": os.environ.get("ZAI_BASE_URL", "")}

    if not cfg:
        return {}

    api_key = cfg.get("apiKey") or cfg.get("api_key") or ""
    base_url = (cfg.get("baseUrl") or cfg.get("base_url") or "").rstrip("/")
    model = cfg.get("model") or "glm-4.6"
    extra: dict = {}
    if cfg.get("token"):
        extra["X-Token"] = cfg["token"]
    if cfg.get("chatId"):
        extra["X-Chat-Id"] = cfg["chatId"]
    if cfg.get("userId"):
        extra["X-User-Id"] = cfg["userId"]
    extra.setdefault("X-Z-AI-From", "Z")

    if api_key:
        os.environ.setdefault("ZAI_API_KEY", api_key)
    if base_url:
        os.environ["ZAI_BASE_URL"] = base_url
    os.environ["ZAI_MODEL"] = model
    if extra:
        os.environ["ZAI_EXTRA_HEADERS"] = json.dumps(extra)

    host = base_url.split("//")[-1].split("/")[0] if base_url else "api.z.ai"
    return {"source": src or "env", "model": model, "base_url_host": host}
