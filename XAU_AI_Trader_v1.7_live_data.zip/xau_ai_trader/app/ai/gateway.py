"""PHASE 17/46/47/48 — AI Gateway: failover, caching, cost ledger.

Chain: Z.ai → Gemini → Groq → OpenRouter → SAFE MODE(WAIT).
- Context-hash cache avoids re-calling AI when the market state is unchanged.
- Cost ledger records provider/model/latency/tokens/status per call.
- All providers failing → SAFE MODE output (WAIT) — the system never
  depends on AI availability for safety decisions.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.ai.providers import DEFAULT_MODELS, DEFAULT_URLS, GeminiProvider, GroqProvider, OpenRouterProvider, ZAIProvider
from app.ai.schemas import AIOutput, SAFE_MODE_OUTPUT
from app.config.schema import AIConfig
from app.config.loader import get_env
from app.core import exceptions as exc
from app.core.security import mask_secrets

logger = logging.getLogger(__name__)

PROVIDER_CLASSES = {
    "zai": ZAIProvider,
    "gemini": GeminiProvider,
    "groq": GroqProvider,
    "openrouter": OpenRouterProvider,
}


@dataclass
class GatewayResult:
    output: AIOutput
    provider: str | None = None
    cached: bool = False
    degraded: bool = False
    errors: list[str] = field(default_factory=list)
    latency_ms: int = 0
    retries: int = 0  # PHASE 67 §14 — retry count of the winning provider
    # v1.7 — how many REAL provider attempts were made in this analyze() call.
    # 0 means every provider was skipped (cooldown/cost limit) — the trader
    # treats that as a neutral WAIT (no fresh AI failure happened).
    attempts_made: int = 0


@dataclass
class _CacheEntry:
    output: AIOutput
    provider: str
    created: float


class AIGateway:
    def __init__(self, cfg: AIConfig, ledger=None) -> None:
        self.cfg = cfg
        self.ledger = ledger  # optional journal with log_ai_call()
        self.providers: dict[str, object] = {}
        self.order: list[str] = []
        self._cache: dict[str, _CacheEntry] = {}
        self._daily_counts: dict[str, dict] = {}
        # v1.7 — per-provider cooldown (unix ts until which a provider is
        # skipped WITHOUT an HTTP attempt). Set on rate-limit/timeout/server
        # errors so a saturated provider is not re-hit every poll cycle.
        self._cooldown_until: dict[str, float] = {}
        cooldown_s = 120.0
        if getattr(cfg, "rate_limit", None) is not None:
            cooldown_s = float(getattr(cfg.rate_limit, "rate_limit_cooldown_s", 120.0) or 120.0)
        self._cooldown_s = cooldown_s
        # PHASE 67 §14 — optional rate limiting (opt-in via cfg.rate_limit)
        self.limiter = None
        if getattr(cfg, "rate_limit", None) is not None and cfg.rate_limit.enabled:
            from app.ai.rate_limiter import RateLimiter

            self.limiter = RateLimiter(cfg.rate_limit)
        self._build_providers()

    def _build_providers(self) -> None:
        for ps in self.cfg.providers:
            if not ps.enabled:
                continue
            api_key = get_env(ps.api_key_env)
            if not api_key:
                logger.info("AI provider '%s' disabled — env %s not set", ps.name, ps.api_key_env)
                continue
            cls = PROVIDER_CLASSES.get(ps.name)
            if cls is None:
                logger.warning("unknown AI provider name: %s", ps.name)
                continue
            base_url = ps.base_url or DEFAULT_URLS.get(ps.name, "")
            model = ps.model or DEFAULT_MODELS.get(ps.name, "")
            extra_headers: dict = {}
            if ps.extra_headers_env:
                import json as _json
                import os as _os

                raw = _os.environ.get(ps.extra_headers_env, "")
                if raw:
                    try:
                        extra_headers = _json.loads(raw)
                    except Exception:
                        logger.warning("extra_headers_env %s is not valid JSON — ignored",
                                       ps.extra_headers_env)
            self.providers[ps.name] = cls(
                api_key=api_key, model=model, base_url=base_url,
                timeout_seconds=ps.timeout_seconds, temperature=ps.temperature,
                max_tokens=ps.max_tokens, extra_headers=extra_headers,
            )
        self.order = [n for n in (self.cfg.failover_order or list(self.providers))
                      if n in self.providers]

    @property
    def available_providers(self) -> list[str]:
        return list(self.order)

    def provider_status(self) -> dict:
        """v1.7 — cooldown/skip status per provider (for the panel)."""
        now = time.time()
        out = {}
        for name in self.order:
            until = self._cooldown_until.get(name, 0.0)
            out[name] = {
                "cooldown_left_s": round(max(0.0, until - now), 1),
                "daily_requests": (self._daily_counts.get(name, {}).get("requests", 0)),
            }
        return out

    # ------------------------------------------------------------ cache ---
    @staticmethod
    def context_hash(state: dict) -> str:
        def _round(o):
            if isinstance(o, float):
                return round(o, 2)
            if isinstance(o, dict):
                return {k: _round(v) for k, v in sorted(o.items())}
            if isinstance(o, list):
                return [_round(v) for v in o]
            return o

        canonical = json.dumps(_round(state), sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()

    # ----------------------------------------------------------- limits ---
    def _under_limits(self, name: str) -> bool:
        today = datetime.now(timezone.utc).date().isoformat()
        rec = self._daily_counts.setdefault(name, {"date": today, "requests": 0, "tokens": 0})
        if rec["date"] != today:
            rec = {"date": today, "requests": 0, "tokens": 0}
            self._daily_counts[name] = rec
        ps = next((p for p in self.cfg.providers if p.name == name), None)
        if ps and rec["requests"] >= ps.max_requests_per_day:
            return False
        est_cost = rec["tokens"] / 1000.0 * self.cfg.estimated_cost_per_1k_tokens
        if est_cost >= self.cfg.cost_daily_limit_usd:
            return False
        return True

    def _record_usage(self, name: str, usage: dict | None) -> None:
        today = datetime.now(timezone.utc).date().isoformat()
        rec = self._daily_counts.setdefault(name, {"date": today, "requests": 0, "tokens": 0})
        if rec["date"] != today:
            rec.update({"date": today, "requests": 0, "tokens": 0})
        rec["requests"] += 1
        rec["tokens"] += int((usage or {}).get("input_tokens") or 0) + int((usage or {}).get("output_tokens") or 0)

    # ----------------------------------------------------------- analyze ---
    async def analyze(self, state: dict, news_texts: list[str] | None = None) -> GatewayResult:
        if not self.cfg.enabled or not self.providers:
            return GatewayResult(output=SAFE_MODE_OUTPUT.model_copy(), degraded=True,
                                 errors=["AI_DISABLED_OR_UNCONFIGURED"])

        h = self.context_hash(state)
        entry = self._cache.get(h)
        if entry and (time.time() - entry.created) < self.cfg.cache_ttl_seconds:
            return GatewayResult(output=entry.output.model_copy(), provider=entry.provider, cached=True)
        # v1.5 (AI-N6): evict expired cache entries — the cache was unbounded
        # and grew forever on a long-running live loop.
        if entry:
            expired = [k for k, v in self._cache.items()
                       if (time.time() - v.created) >= self.cfg.cache_ttl_seconds]
            for k in expired:
                self._cache.pop(k, None)

        errors: list[str] = []
        attempts_made = 0
        now = time.time()
        for name in self.order:
            if not self._under_limits(name):
                errors.append(f"{name}:COST_OR_RATE_LIMIT")
                continue
            # v1.7 — skip providers parked in cooldown (no HTTP, no failure
            # counting); they auto-return when the cooldown expires.
            until = self._cooldown_until.get(name, 0.0)
            if until > now:
                errors.append(f"{name}:COOLDOWN({int(until - now)}s)")
                continue
            attempts_made += 1
            provider = self.providers[name]
            started = time.perf_counter()
            try:
                if self.limiter is not None:
                    lr = await self.limiter.execute(
                        name,
                        lambda: self._call(provider, state, news_texts),
                        request_hash=h, model=getattr(provider, "model", ""))
                    output, usage = lr.output, lr.usage
                    retries = lr.retries
                else:
                    retries = 0
                    output, usage = await self._call(provider, state, news_texts)
                latency = int((time.perf_counter() - started) * 1000)
                self._record_usage(name, usage)
                self._log_call(name, getattr(provider, "model", ""), latency, "OK", usage, "")
                self._cache[h] = _CacheEntry(output, name, time.time())
                gr = GatewayResult(output=output, provider=name, errors=errors,
                                   latency_ms=latency)
                gr.retries = retries  # §14 evidence: retry count surfaced
                gr.attempts_made = attempts_made
                self._cooldown_until.pop(name, None)  # healthy → clear parking
                return gr
            except (exc.AITimeoutError, exc.AIRateLimitError, exc.AIServerError,
                    exc.AIInvalidResponseError, exc.AIProviderError) as e:
                latency = int((time.perf_counter() - started) * 1000)
                status = e.__class__.__name__.replace("AI", "").replace("Error", "").upper()
                errors.append(f"{name}:{e}")
                self._log_call(name, getattr(provider, "model", ""), latency, status, None, str(e))
                logger.warning("AI provider %s failed → failover: %s", name, e)
                # v1.7 — park the provider after transient capacity errors so
                # the next poll cycles don't hammer it (and don't inflate the
                # AI-failure streak). Invalid-response is NOT parked: same
                # payload → same result, but it doesn't hurt to try again.
                if isinstance(e, (exc.AIRateLimitError, exc.AITimeoutError,
                                  exc.AIServerError)):
                    self._cooldown_until[name] = time.time() + self._cooldown_s
            except Exception as e:  # unexpected → treat as provider failure
                errors.append(f"{name}:UNEXPECTED:{e}")
                self._log_call(name, getattr(provider, "model", ""), 0, "ERROR", None, str(e))
                logger.exception("unexpected AI error on %s", name)

        if self.cfg.on_all_fail == "PROCEED_WITHOUT_AI":
            # v1.5 (AI-N7): the semantics actually live in trader.py
            # (require_ai_for_trade + on_all_fail=WAIT → WAIT). Keep the
            # SAFE_MODE return; the dead if/else was collapsed to one path.
            return GatewayResult(output=SAFE_MODE_OUTPUT.model_copy(), degraded=True,
                                 errors=errors, attempts_made=attempts_made)
        return GatewayResult(output=SAFE_MODE_OUTPUT.model_copy(), degraded=True,
                             errors=errors, attempts_made=attempts_made)

    async def _call(self, provider, state: dict, news_texts):
        output = await provider.analyze(state, news_texts)
        usage = getattr(provider, "_last_usage", None)
        return output, usage

    def _log_call(self, provider: str, model: str, latency: int, status: str, usage, error: str) -> None:
        if self.ledger is not None:
            try:
                self.ledger.log_ai_call(
                    provider=provider, model=model, latency_ms=latency, status=status,
                    input_tokens=(usage or {}).get("input_tokens") if usage else None,
                    output_tokens=(usage or {}).get("output_tokens") if usage else None,
                    error=mask_secrets(error) if error else "",
                )
            except Exception:
                logger.debug("ai ledger write failed", exc_info=True)

    async def aclose(self) -> None:
        for p in self.providers.values():
            await p.aclose()
