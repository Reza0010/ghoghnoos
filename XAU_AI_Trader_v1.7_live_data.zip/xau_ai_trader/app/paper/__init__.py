"""Paper trading mode.

Paper execution is implemented by ``app.execution.paper.PaperExecutor`` and
driven by ``app.trader.TradingSystem`` (started via ``python main.py --mode
paper``). This package intentionally contains no separate runner: one
orchestrator serves all modes to avoid duplicated trading-loop logic.
"""

from app.execution.paper import PaperExecutor

__all__ = ["PaperExecutor"]
