"""PHASE 39 — Trade & Signal Journal (SQLite, WAL, thread-safe).

Tables: signals, trades, ai_calls, experiments. Also mirrors optionally to
JSONL. Every decision (including WAIT) can be journaled for later analytics.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

from app.core.exceptions import JournalError

logger = logging.getLogger(__name__)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    symbol TEXT NOT NULL,
    mode TEXT NOT NULL,
    decision TEXT NOT NULL,
    score REAL,
    confidence REAL,
    price REAL,
    components TEXT,
    reasons TEXT,
    regime TEXT,
    news_risk TEXT,
    quality_score REAL
);
CREATE TABLE IF NOT EXISTS trades (
    ticket INTEGER PRIMARY KEY,
    signal_id INTEGER,
    symbol TEXT NOT NULL,
    mode TEXT NOT NULL,
    side TEXT NOT NULL,
    lot REAL,
    entry_price REAL,
    entry_time TEXT,
    sl REAL, tp REAL,
    exit_price REAL,
    exit_time TEXT,
    pnl REAL, fees REAL, swap REAL,
    mfe REAL, mae REAL,
    exit_reason TEXT,
    magic INTEGER,
    comment TEXT
);
CREATE TABLE IF NOT EXISTS ai_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    provider TEXT, model TEXT,
    latency_ms INTEGER, status TEXT,
    input_tokens INTEGER, output_tokens INTEGER,
    error TEXT
);
CREATE TABLE IF NOT EXISTS experiments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    experiment_id TEXT, name TEXT,
    dataset TEXT, params TEXT, metrics TEXT, result TEXT
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    kind TEXT NOT NULL,
    payload TEXT
);
CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts);
CREATE INDEX IF NOT EXISTS idx_trades_exit ON trades(exit_time);
CREATE INDEX IF NOT EXISTS idx_events_kind ON events(kind);
"""


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Journal:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        # v1.5 (N9): actually enable WAL as the docstring always claimed —
        # durability for the audit trail under concurrent access.
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.Error as e:  # pragma: no cover - depends on fs
            logger.warning("WAL mode unavailable: %s", e)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def _exec(self, sql: str, params: tuple = ()) -> int:
        with self._lock:
            try:
                cur = self._conn.execute(sql, params)
                self._conn.commit()
                return cur.lastrowid or 0
            except sqlite3.Error as e:
                raise JournalError(f"journal write failed: {e}") from e

    def _query(self, sql: str, params: tuple = ()) -> list[dict]:
        with self._lock:
            cur = self._conn.execute(sql, params)
            cols = [c[0] for c in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    # ------------------------------------------------------------- writers --
    def log_signal(self, symbol: str, mode: str, decision: str, score: float = 0.0,
                   confidence: float = 0.0, price: float = 0.0, components: dict | None = None,
                   reasons: list[str] | None = None, regime: str = "", news_risk: str = "",
                   quality_score: float = 0.0) -> int:
        return self._exec(
            "INSERT INTO signals (ts, symbol, mode, decision, score, confidence, price, components, reasons, regime, news_risk, quality_score) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (_utcnow(), symbol, mode, decision, score, confidence, price,
             json.dumps(components or {}), json.dumps(reasons or []),
             regime, news_risk, quality_score),
        )

    def log_trade_open(self, ticket: int, symbol: str, mode: str, side: str, lot: float,
                       entry_price: float, entry_time: str, sl: float, tp: float,
                       magic: int = 0, comment: str = "", signal_id: int | None = None) -> None:
        # v1.5 (N11/finding 11): plain INSERT — a duplicate ticket (possible
        # symptom of a double-submitted order) now RAISES instead of silently
        # overwriting the evidence of the duplication.
        self._exec(
            "INSERT INTO trades (ticket, signal_id, symbol, mode, side, lot, entry_price, entry_time, sl, tp, magic, comment) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (ticket, signal_id, symbol, mode, side, lot, entry_price, entry_time, sl, tp, magic, comment),
        )

    def log_event(self, payload: dict) -> None:
        """Generic immutable event record (ORDER_INTENT / ORDER_UNKNOWN /
        ORDER_REJECTED / ORDER_ACK / RECONCILIATION_RESULT ...). Required by
        the v1.5 order state machine for post-hoc reconstructability."""
        import json as _json

        self._exec(
            "INSERT INTO events (ts, kind, payload) VALUES (?,?,?)",
            (_utcnow(), str(payload.get("kind", "EVENT")),
             _json.dumps(payload, default=str)),
        )

    def log_trade_close(self, ticket: int, exit_price: float, exit_time: str, pnl: float,
                        fees: float = 0.0, swap: float = 0.0, mfe: float = 0.0, mae: float = 0.0,
                        exit_reason: str = "") -> None:
        self._exec(
            "UPDATE trades SET exit_price=?, exit_time=?, pnl=?, fees=?, swap=?, mfe=?, mae=?, exit_reason=? WHERE ticket=?",
            (exit_price, exit_time, pnl, fees, swap, mfe, mae, exit_reason, ticket),
        )

    def log_ai_call(self, provider: str, model: str, latency_ms: int, status: str,
                    input_tokens: int | None = None, output_tokens: int | None = None,
                    error: str = "") -> None:
        self._exec(
            "INSERT INTO ai_calls (ts, provider, model, latency_ms, status, input_tokens, output_tokens, error) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (_utcnow(), provider, model, latency_ms, status, input_tokens, output_tokens, error),
        )

    def log_experiment(self, experiment_id: str, name: str, dataset: str, params: dict,
                       metrics: dict, result: str = "") -> None:
        self._exec(
            "INSERT INTO experiments (ts, experiment_id, name, dataset, params, metrics, result) VALUES (?,?,?,?,?,?,?)",
            (_utcnow(), experiment_id, name, dataset, json.dumps(params), json.dumps(metrics), result),
        )

    # -------------------------------------------------------------- readers --
    def trades_today(self) -> list[dict]:
        today = datetime.now(timezone.utc).date().isoformat()
        return self._query(
            "SELECT * FROM trades WHERE substr(exit_time,1,10)=? OR (exit_time IS NULL AND substr(entry_time,1,10)=?)",
            (today, today),
        )

    def daily_pnl(self) -> float:
        """Net realized P/L today = pnl − fees + swap (fees stored as positive cost)."""
        today = datetime.now(timezone.utc).date().isoformat()
        rows = self._query("SELECT pnl, fees, swap FROM trades WHERE substr(exit_time,1,10)=?", (today,))
        return sum((r["pnl"] or 0) - (r["fees"] or 0) + (r["swap"] or 0) for r in rows)

    def open_trades(self) -> list[dict]:
        return self._query("SELECT * FROM trades WHERE exit_time IS NULL")

    def recent_trades(self, limit: int = 20) -> list[dict]:
        return self._query("SELECT * FROM trades ORDER BY entry_time DESC LIMIT ?", (limit,))

    def recent_signals(self, limit: int = 20) -> list[dict]:
        return self._query("SELECT * FROM signals ORDER BY id DESC LIMIT ?", (limit,))

    def ai_stats(self, days: int = 1) -> dict:
        rows = self._query("SELECT provider, status, latency_ms, input_tokens, output_tokens FROM ai_calls")
        stats: dict = {}
        for r in rows:
            s = stats.setdefault(r["provider"], {"calls": 0, "ok": 0, "errors": 0,
                                                 "avg_latency_ms": 0, "tokens": 0})
            s["calls"] += 1
            s["ok" if r["status"] == "OK" else "errors"] += 1
            s["avg_latency_ms"] += r["latency_ms"] or 0
            s["tokens"] += (r["input_tokens"] or 0) + (r["output_tokens"] or 0)
        for s in stats.values():
            if s["calls"]:
                s["avg_latency_ms"] = int(s["avg_latency_ms"] / s["calls"])
        return stats

    def closed_trade_stats(self, limit: int = 200) -> dict:
        rows = self._query(
            "SELECT pnl FROM trades WHERE exit_time IS NOT NULL ORDER BY exit_time DESC LIMIT ?",
            (limit,),
        )
        pnls = [r["pnl"] or 0.0 for r in rows]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]
        return {
            "n_closed": len(pnls),
            "win_rate_pct": (len(wins) / len(pnls) * 100.0) if pnls else 0.0,
            "profit_factor": (sum(wins) / abs(sum(losses))) if losses and sum(wins) > 0 else (float("inf") if wins else 0.0),
            "expectancy": (sum(pnls) / len(pnls)) if pnls else 0.0,
        }
