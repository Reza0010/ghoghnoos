"""PHASE 50 — Programmatic data-leakage audit (v1.5: actually enforced).

Run BEFORE every training — train_service.train_models() now calls
run_full_audit() inside the real training path (previously the function
existed but was dead code, and the "audit runs before every training"
claim in DATA_LEAKAGE_AUDIT.md was false).

v1.5 upgrades (audit findings 5/14/15):
- split purity asserts a REAL gap: test_min >= train_max + max(horizon, embargo) + 1
- scaler audit checks BOTH center AND scale against train-only recomputation
- label horizon check PASSes only when tail labels are NaN/invalid, not
  silently zero
- label alignment verifies labels ⊆ feature index at decision time t
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class AuditCheck:
    name: str
    passed: bool
    detail: str


@dataclass
class LeakageAuditReport:
    checks: list[AuditCheck] = field(default_factory=list)

    @property
    def all_passed(self) -> bool:
        return all(c.passed for c in self.checks)

    def to_markdown(self) -> str:
        lines = ["| Check | Result | Detail |", "|---|---|---|"]
        for c in self.checks:
            lines.append(f"| {c.name} | {'✅ PASS' if c.passed else '❌ FAIL'} | {c.detail} |")
        return "\n".join(lines)


def check_causal_features(build_fn, frames: dict[str, pd.DataFrame], probe_points: int = 3) -> AuditCheck:
    """Recompute features on truncated data; rows at t must be identical."""
    full, _ = build_fn(frames)
    n = len(full)
    step = max(1, n // (probe_points + 1))
    diffs = 0
    for k in range(1, probe_points + 1):
        t = full.index[-k * step]
        trunc = {tf: df[df.index <= t] for tf, df in frames.items()}
        sub, _ = build_fn(trunc)
        if t not in sub.index:
            diffs += 1
            continue
        r1 = full.loc[t].fillna(-999.0)
        r2 = sub.loc[t].fillna(-999.0)
        diffs += int((r1 != r2).sum())
    return AuditCheck(
        "causal_features",
        diffs == 0,
        f"{diffs} differing feature values across {probe_points} probe points "
        + ("— features use future data!" if diffs else "— features are strictly causal"),
    )


def check_label_horizon(labels: pd.Series, horizon: int) -> AuditCheck:
    """The last `horizon` bars have no full future window.

    v1.5 (finding 16): they must be NaN (invalid), never silently merged
    into NO_EDGE (0)."""
    tail = labels.iloc[-horizon:]
    ok = bool(tail.isna().all())
    return AuditCheck("label_horizon_tail", ok,
                      f"last {horizon} bars are NaN/invalid: {ok} "
                      "(tail rows without future data must not carry labels)")


def check_label_alignment(features: pd.DataFrame, labels: pd.Series) -> AuditCheck:
    """Every labelled index must exist in the feature index (merged at t)."""
    labelled = labels[labels.notna()].index
    missing = labelled.difference(features.index)
    ok = len(missing) == 0
    return AuditCheck("label_alignment", ok,
                      f"{len(missing)} labelled rows missing from feature index")


def check_split_purity(train_idx: np.ndarray, test_idx: np.ndarray,
                       purge: int, embargo: int) -> AuditCheck:
    """Real gap assertion (v1.5, finding 14): the FIRST test sample must start
    at least max(purge, embargo) bars after the LAST train sample. The old
    version tested a window around train_max that the temporal split could
    never violate regardless of its actual gap."""
    t_max = int(train_idx.max()) if len(train_idx) else -1
    t_min = int(test_idx.min()) if len(test_idx) else 10 ** 18
    required = max(int(purge), int(embargo))
    gap = t_min - t_max
    ok = gap > required
    return AuditCheck("split_purity_purge_embargo", ok,
                      f"gap between last train and first test sample = {gap} bars "
                      f"(required > {required})")


def check_scaler_leakage(scaler_state: dict, train_idx: np.ndarray, full_X: pd.DataFrame) -> AuditCheck:
    """Scaler center AND scale must match train-only statistics (v1.5, finding 15).

    The old check compared centers only — a scaler fitted on full data with a
    similar center but a contaminated scale (e.g. different IQR) passed."""
    if scaler_state.get("kind") == "none":
        return AuditCheck("scaler_train_only", True, "scaler disabled")
    X_train = full_X.iloc[train_idx]
    if scaler_state["kind"] == "standard":
        recomputed_center = X_train.mean(axis=0)
        recomputed_scale = X_train.std(axis=0)
        kind_desc = "mean/std"
    else:  # robust
        recomputed_center = X_train.median(axis=0)
        q1 = X_train.quantile(0.25)
        q3 = X_train.quantile(0.75)
        recomputed_scale = (q3 - q1)
        kind_desc = "median/IQR"
    center = np.asarray(scaler_state["center"], dtype=float)
    scale = np.asarray(scaler_state.get("scale", np.ones_like(center)), dtype=float)
    c_diff = np.abs(np.asarray(recomputed_center.values, dtype=float) - center)
    c_rel = np.where(np.abs(center) > 1e-9, c_diff / (np.abs(center) + 1e-9), c_diff)
    recomputed_scale_vals = np.asarray(recomputed_scale.values, dtype=float)
    # sklearn convention: RobustScaler/StandardScaler store scale_=1.0 for
    # zero-variance features (division guard). Replicate it before comparing,
    # otherwise a legitimately constant train feature (e.g. session_overlap=0)
    # looks like a scale leak.
    recomputed_scale_vals = np.where(recomputed_scale_vals == 0.0, 1.0,
                                     recomputed_scale_vals)
    s_diff = np.abs(recomputed_scale_vals - scale)
    s_rel = np.where(np.abs(scale) > 1e-9, s_diff / (np.abs(scale) + 1e-9), s_diff)
    bad_c = int((c_rel > 0.05).sum())
    bad_s = int((s_rel > 0.05).sum())
    return AuditCheck("scaler_train_only", bad_c == 0 and bad_s == 0,
                      f"{kind_desc}: {bad_c} center + {bad_s} scale mismatches >5% "
                      "vs train-only recomputation")


def run_full_audit(features, labels, train_idx, test_idx, purge, embargo,
                   scaler_state=None, X_scaled=None, horizon=None) -> LeakageAuditReport:
    """Full audit over the real training objects (v1.5 signature).

    Checks: label horizon validity, label/feature alignment, split purity
    (train→test) and scaler center+scale leakage against train-only stats.
    ``X_scaled`` must be the UNSCALED feature matrix (the scaler audit
    recomputes raw train statistics to compare against the stored center).
    """
    report = LeakageAuditReport()
    h = int(horizon if horizon is not None else purge)
    report.checks.append(check_label_horizon(labels, max(h, 1)))
    report.checks.append(check_label_alignment(features, labels))
    report.checks.append(check_split_purity(np.asarray(train_idx), np.asarray(test_idx),
                                            purge, embargo))
    if scaler_state is not None and X_scaled is not None:
        report.checks.append(check_scaler_leakage(scaler_state, np.asarray(train_idx), X_scaled))
    return report
