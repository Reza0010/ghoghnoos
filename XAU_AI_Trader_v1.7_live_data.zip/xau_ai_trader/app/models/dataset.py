"""Dataset assembly with strict temporal splits and train-only scaler."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler, StandardScaler

from app.config.schema import DatasetConfig
from app.core.exceptions import LeakageError


@dataclass
class Dataset:
    X: pd.DataFrame
    y: pd.Series                      # encoded {0,1,2}
    returns: pd.Series                # next-bar return for trading metrics
    feature_names: list[str]
    feature_version: str
    scaler_state: dict | None = None
    meta: dict = field(default_factory=dict)

    def scaled(self, scaler_state: dict) -> pd.DataFrame:
        return _apply_scaler(self.X, scaler_state)


def _fit_scaler(X: pd.DataFrame, kind: str) -> dict:
    """Fit a scaler and export a versioned, sklearn-attribute-correct state.

    v1.4 fix: the previous code read ``model.center_`` for BOTH scaler kinds
    (and its hasattr fallback called the same missing attribute) — Standard-
    Scaler has ``mean_``/``scale_``, NOT ``center_``, so ``scaler: standard``
    crashed at fit time. Attribute map is now explicit per kind and the
    exported state carries ``schema_version`` for future migrations.
    """
    if kind == "none":
        return {"kind": "none", "schema_version": 2}
    if kind == "standard":
        model = StandardScaler()
        model.fit(X.values)
        center = np.asarray(model.mean_, dtype=float)
    elif kind == "robust":
        model = RobustScaler()
        model.fit(X.values)
        center = np.asarray(model.center_, dtype=float)
    else:
        raise ValueError(f"unknown scaler kind {kind!r} (expected "
                         "'none' | 'standard' | 'robust')")
    scale = np.asarray(model.scale_, dtype=float)
    return {"kind": kind,
            "center": center.tolist(),
            "scale": scale.tolist(),
            "schema_version": 2}


def _apply_scaler(X: pd.DataFrame, state: dict) -> pd.DataFrame:
    if state["kind"] == "none":
        return X.copy()
    center = np.asarray(state["center"], dtype=float)
    scale = np.asarray(state["scale"], dtype=float)
    scale_safe = np.where(scale == 0, 1.0, scale)
    arr = (X.values - center) / scale_safe
    return pd.DataFrame(arr, index=X.index, columns=X.columns)


def assemble_dataset(
    features: pd.DataFrame,
    labels: pd.Series,
    close: pd.Series,
    cfg: DatasetConfig,
    feature_version: str = "",
) -> Dataset:
    df = features.join(labels, how="inner").dropna(subset=["label"])
    # drop warmup rows with any NaN (indicators need history)
    df = df.dropna(axis=0, how="any")
    if len(df) < cfg.min_rows:
        raise LeakageError(
            f"dataset too small after cleaning: {len(df)} rows (min {cfg.min_rows}) — "
            "increase history or reduce indicator windows"
        )
    X = df.drop(columns=["label"])
    y = (df["label"].astype(int) + 1).astype(int)  # {-1,0,1} → {0,1,2}
    returns = close.reindex(df.index).pct_change().shift(-1)
    state = _fit_scaler(X, cfg.scaler)  # fit on FULL X here is only for inference sets;
    # training pipelines must refit on train split only (see train.py)
    return Dataset(X=X, y=y, returns=returns, feature_names=list(X.columns),
                   feature_version=feature_version, scaler_state=state,
                   meta={"rows": int(len(df)), "first": str(df.index[0]), "last": str(df.index[-1])})
