"""PHASE 6 — LightGBM 3-class classifier wrapper (BUY / NO_EDGE / SELL)."""

from __future__ import annotations

import json
from pathlib import Path

import lightgbm as lgb
import numpy as np

from app.config.schema import LGBMParams
from app.core.exceptions import ModelNotTrainedError


class LGBMModel:
    name = "lightgbm"

    def __init__(self, params: LGBMParams | None = None) -> None:
        self.params = params or LGBMParams()
        self.model: lgb.LGBMClassifier | None = None
        self.best_iteration: int | None = None

    def fit(self, X, y, X_val=None, y_val=None) -> None:
        params = {
            "n_estimators": self.params.n_estimators,
            "learning_rate": self.params.learning_rate,
            "num_leaves": self.params.num_leaves,
            "max_depth": self.params.max_depth,
            "min_child_samples": self.params.min_child_samples,
            "subsample": self.params.subsample,
            "colsample_bytree": self.params.colsample_bytree,
            "reg_lambda": self.params.reg_lambda,
            "objective": "multiclass",
            "num_class": 3,
            "class_weight": "balanced",
            "verbosity": -1,
            "random_state": 42,
        }
        model = lgb.LGBMClassifier(**params)
        if X_val is not None and y_val is not None:
            try:
                # lightgbm >= 4.6: eval_set is deprecated in favour of eval_X/eval_y
                model.fit(X, y, eval_X=X_val, eval_y=y_val,
                          callbacks=[lgb.early_stopping(self.params.early_stopping_rounds, verbose=False)])
            except TypeError:  # lightgbm < 4.6 keeps the eval_set signature
                model.fit(X, y, eval_set=[(X_val, y_val)],
                          callbacks=[lgb.early_stopping(self.params.early_stopping_rounds, verbose=False)])
            self.best_iteration = model.best_iteration_
        else:
            model.fit(X, y)
        self.model = model

    def predict_proba(self, X) -> np.ndarray:
        if self.model is None:
            raise ModelNotTrainedError("LightGBM model is not trained/loaded")
        return self.model.predict_proba(X)

    def feature_importance(self, feature_names: list[str], top: int = 20) -> list[dict]:
        if self.model is None:
            raise ModelNotTrainedError("LightGBM model is not trained/loaded")
        imp = self.model.feature_importances_
        order = np.argsort(imp)[::-1][:top]
        return [{"feature": feature_names[i], "importance": float(imp[i])} for i in order]

    def save(self, directory: str | Path) -> None:
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.model.booster_.save_model(str(directory / "model.txt"))
        (directory / "params.json").write_text(json.dumps(self.params.model_dump()), encoding="utf-8")

    def load(self, directory: str | Path) -> None:
        directory = Path(directory)
        booster = lgb.Booster(model_file=str(directory / "model.txt"))
        model = lgb.LGBMClassifier(objective="multiclass", num_class=3, verbosity=-1)
        # mark as fitted for sklearn's check_is_fitted (booster_ is a read-only
        # property, so we register the trained booster via the private handle
        # and a trailing-underscore attribute set)
        model._Booster = booster
        model.fitted_ = True  # lightgbm sklearn check: __sklearn_is_fitted__ → fitted_
        model._n_classes = 3
        model._classes = np.arange(3)
        model._n_features = booster.num_feature()
        try:
            model.n_features_in_ = booster.num_feature()
        except AttributeError:
            # newer lightgbm exposes n_features_in_ as a read-only property
            # backed by _n_features (set above) — nothing more to do
            pass
        self.model = model
