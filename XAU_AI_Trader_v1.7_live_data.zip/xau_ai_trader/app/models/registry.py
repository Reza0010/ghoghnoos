"""PHASE 38 — Model Registry: versioned metadata for every trained model."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from app.core.exceptions import ModelError

REGISTRY_FILE = "registry.json"


class ModelRegistry:
    def __init__(self, base_dir: str | Path) -> None:
        self.base = Path(base_dir)
        self.base.mkdir(parents=True, exist_ok=True)
        self.index_path = self.base / REGISTRY_FILE
        if self.index_path.exists():
            self.index = json.loads(self.index_path.read_text(encoding="utf-8"))
        else:
            self.index = {}

    def _persist(self) -> None:
        self.index_path.write_text(json.dumps(self.index, indent=2), encoding="utf-8")

    def register(
        self,
        model_id: str,
        algo: str,
        directory: str,
        params: dict,
        metrics: dict,
        dataset_version: str = "",
        feature_version: str = "",
        extra: dict | None = None,
    ) -> dict:
        entry = {
            "model_id": model_id,
            "algo": algo,
            "version": 1,
            "training_date": datetime.now(timezone.utc).isoformat(),
            "dataset_version": dataset_version,
            "feature_version": feature_version,
            "parameters": params,
            "metrics": metrics,
            "path": str(directory),
            "extra": extra or {},
        }
        if model_id in self.index:
            entry["version"] = self.index[model_id].get("version", 1) + 1
        self.index[model_id] = entry
        self._persist()
        return entry

    def get(self, model_id: str) -> dict:
        if model_id not in self.index:
            raise ModelError(f"model_id '{model_id}' not found in registry")
        return self.index[model_id]

    def latest(self, algo_prefix: str | None = None) -> dict | None:
        candidates = [e for e in self.index.values()
                      if algo_prefix is None or e["algo"].startswith(algo_prefix)]
        if not candidates:
            return None
        return max(candidates, key=lambda e: e["training_date"])

    def list(self) -> list[dict]:
        return list(self.index.values())
