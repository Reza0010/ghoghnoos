"""PHASE 7 — Triple Barrier labeling (v1.5: executable-fill semantics).

Contract (Mission 6):
- signal time = t, execution time = t+1 open
- BUY  entry = open_{t+1} + spread/2 + slippage   (ask side, adverse)
- SELL entry = open_{t+1} - spread/2 - slippage   (bid side, adverse)
- barriers are built FROM the executable entry, not from close[t]
- barrier touches are evaluated on executable-side marks exactly like the
  backtest engine: for a LONG trade the bid mark is ``mid - spread/2``
- the final ``horizon`` bars have no full future window → label = NaN,
  ``valid_label = False``; a real NO_EDGE is ``label == 0`` with
  ``valid_label == True`` (first-class class, never conflated with
  "no future data")

All cost parameters are explicit PRICE units (never points) to keep the
system-wide unit contract unambiguous (Mission 19).

Labels touch the future BY DESIGN — they are merged to features at time t and
never used as inputs; purged CV + embargo prevent train/test contamination.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

CLASS_LABELS = {0: "SELL", 1: "NO_EDGE", 2: "BUY"}  # y_enc = y_raw + 1


def _first_hit(hit: np.ndarray) -> int:
    return int(np.argmax(hit)) if hit.any() else 10 ** 9


def triple_barrier_labels(
    df: pd.DataFrame,
    horizon: int = 48,
    tp_atr_mult: float = 2.0,
    sl_atr_mult: float = 1.0,
    atr_col: str = "atr",
    ambiguous: str = "zero",
    spread_price: float = 0.0,
    slippage_price: float = 0.0,
    commission_price: float = 0.0,
) -> pd.Series:
    """Triple-barrier labels anchored on the executable entry price.

    Returns a float Series where invalid rows (tail without a full future
    horizon, or non-positive/NaN ATR) are **NaN** — use :func:`label_validity`
    to obtain the companion ``valid_label`` mask. ``label == 0`` (valid) is a
    genuine NO_EDGE observation.

    Parameters are PRICE-unit round costs:
    - ``spread_price``: full bid/ask spread in price units
    - ``slippage_price``: one-way adverse slippage in price units
    - ``commission_price``: round-turn commission expressed in price units
      (shifts both barriers outward so the label requires net profitability)
    """
    close = df["close"].values
    high = df["high"].values
    low = df["low"].values
    open_ = df["open"].values
    atr = df[atr_col].values
    n = len(df)
    labels = np.full(n, np.nan, dtype=np.float64)
    half_spread = float(spread_price) / 2.0
    slip = float(slippage_price)

    for i in range(n - horizon):
        a = atr[i]
        if np.isnan(a) or a <= 0:
            continue
        # executable LONG entry at t+1 open (ask side, adverse fill)
        entry = open_[i + 1] + half_spread + slip
        tp = entry + tp_atr_mult * a + float(commission_price) / 2.0
        sl = entry - sl_atr_mult * a - float(commission_price) / 2.0
        # executable-side marks for a LONG: bid = mid - spread/2
        hi_bid = high[i + 1: i + 1 + horizon] - half_spread
        lo_bid = low[i + 1: i + 1 + horizon] - half_spread
        hit_up = hi_bid >= tp
        hit_dn = lo_bid <= sl
        first_up = _first_hit(hit_up)
        first_dn = _first_hit(hit_dn)
        if first_up == 10 ** 9 and first_dn == 10 ** 9:
            labels[i] = 0          # real NO_EDGE (full future window existed)
            continue
        if first_up == first_dn:   # both barriers hit on the SAME bar
            if ambiguous == "sl_first":
                labels[i] = -1
            else:
                labels[i] = 0
        elif first_up < first_dn:
            labels[i] = 1
        else:
            labels[i] = -1
    return pd.Series(labels, index=df.index, name="label")


def label_validity(df: pd.DataFrame, horizon: int, atr_col: str = "atr") -> pd.Series:
    """Boolean mask: True where a full future horizon exists AND ATR is usable.

    Tail rows (last ``horizon`` bars) and NaN/non-positive ATR rows are
    invalid — they must be excluded from training/evaluation, never merged
    into the NO_EDGE class (Mission 6 / finding 16).
    """
    n = len(df)
    valid = np.ones(n, dtype=bool)
    valid[max(0, n - horizon):] = False          # no full future window
    atr = df[atr_col].values if atr_col in df.columns else np.full(n, np.nan)
    valid &= ~(np.isnan(atr) | (atr <= 0))
    return pd.Series(valid, index=df.index, name="valid_label")
