#!/usr/bin/env python3
"""PHASE 58 — train.py: train LGBM/XGB/HMM + calibration + registry.

Usage: python train.py [--days 150] [--config config.yaml]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.core.logging import setup_logging
from app.data.market.simulated import SimulatedProvider


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--days", type=int, default=None, help="history depth (simulated provider)")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    if args.days is not None:
        cfg.provider.simulated_days = args.days
    provider = SimulatedProvider(
        days=cfg.provider.simulated_days, seed=cfg.provider.simulated_seed,
        start_price=cfg.provider.simulated_start_price,
        annual_vol=cfg.provider.simulated_annual_vol,
    )
    provider.connect()

    from app.models.train_service import build_frames, train_models

    print(f"[train] fetching {cfg.provider.simulated_days} days of "
          f"{'SIMULATED' if cfg.provider.kind == 'simulated' else 'MT5'} data ...")
    frames = build_frames(provider, cfg)
    print(f"[train] base M5 bars: {len(frames['M5'])}")

    out = train_models(cfg, frames, register=True)

    print("[train] leakage audit:", "PASS" if out.audit.all_passed else "FAIL")
    for c in out.audit.checks:
        print(f"   - {c.name}: {'PASS' if c.passed else 'FAIL'} — {c.detail}")
    print(f"[train] dataset rows: {out.dataset_meta['rows']} "
          f"({out.dataset_meta['first']} → {out.dataset_meta['last']})")
    print("[train] LGBM test metrics:", json.dumps(out.metrics["lgbm_test"], indent=2)[:400])
    print("[train] XGB test metrics:", json.dumps(out.metrics["xgb_test"], indent=2)[:400])
    print("[train] top features:")
    for f in out.feature_importance[:8]:
        print(f"   {f['feature']}: {f['importance']:.0f}")

    # persist experiment
    from app.journal.journal import Journal

    journal = Journal(Path(cfg.paths.logs_dir) / "journal.db")
    journal.log_experiment(
        experiment_id=f"train-{out.dataset_meta['feature_version']}",
        name="lgbm_xgb_hmm", dataset=json.dumps(out.dataset_meta),
        params=cfg.lgbm.model_dump(), metrics=out.metrics, result="registered",
    )
    journal.close()
    print("[train] models registered → models/registry")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
