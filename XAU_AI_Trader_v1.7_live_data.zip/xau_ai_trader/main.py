#!/usr/bin/env python3
"""v1.4 — main.py: run the trading system.

Modes (v1.4 §54 — honest naming, no paper-backed "live" label):
    python main.py --mode paper            # default paper loop
    python main.py --mode mt5-readonly     # attach real MT5 provider, read-only
    python main.py --mode paper --once     # single iteration (smoke test)
    python main.py --mode mt5-demo         # → redirected to the demo test script
    python main.py --mode mt5-live         # HARD REFUSED (gates incomplete)
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.config.schema import TradingMode
from app.core.logging import setup_logging
from app.data.market.simulated import SimulatedProvider


def build_provider(cfg):
    if cfg.provider.kind == "public":
        from app.data.market.live_public import LivePublicProvider

        return LivePublicProvider(
            symbol=cfg.provider.public_symbol,
            refresh_seconds=cfg.provider.public_refresh_seconds,
            spread_points=cfg.provider.public_spread_points,
            timeout_seconds=cfg.provider.public_timeout_seconds,
            defaults=cfg.symbol.fallback_symbol_info,
            initial_balance=cfg.backtest.initial_balance,
            display_symbol=cfg.symbol.primary,
        )
    if cfg.provider.kind == "replay":
        from app.data.market.models import SymbolInfo
        from app.data.market.replay import ReplayProvider

        # explicit config-declared fallback specs (documented assumption, §6)
        info = SymbolInfo(name=cfg.real_data.symbol,
                          **cfg.symbol.fallback_symbol_info.model_dump())
        return ReplayProvider.from_raw_dir(
            cfg.real_data.raw_dir, cfg.real_data.symbol, cfg.real_data.timeframes,
            symbol_info=info)
    if cfg.provider.kind == "mt5":
        from app.data.mt5.provider import MT5DataProvider

        return MT5DataProvider(
            login_env=cfg.mt5.login_env, password_env=cfg.mt5.password_env,
            server=cfg.mt5.server, terminal_path=cfg.mt5.terminal_path,
            server_utc_offset_hours=cfg.mt5.server_utc_offset_hours,
            timeout_seconds=cfg.mt5.timeout_seconds,
            retry_attempts=cfg.mt5.retry_attempts,
            retry_backoff_seconds=cfg.mt5.retry_backoff_seconds,
            # v1.4 §12: execution capability stays OFF at the provider level —
            # the runtime loop never sends broker orders; the demo script owns
            # the only gated order_send path.
            allow_live_execution=False,
            deviation_points=getattr(cfg.mt5, "deviation_points", None),
        )
    return SimulatedProvider(
        days=cfg.provider.simulated_days, seed=cfg.provider.simulated_seed,
        start_price=cfg.provider.simulated_start_price,
        annual_vol=cfg.provider.simulated_annual_vol,
        initial_balance=cfg.backtest.initial_balance,
    )


def build_system(cfg, argv=None, registry_tag: str = "main"):
    from app.ai.gateway import AIGateway
    from app.execution.paper import PaperExecutor
    from app.journal.journal import Journal
    from app.models.train_service import load_bundle, load_hmm
    from app.monitoring.health import HealthRegistry
    from app.monitoring.state import StateStore
    from app.news.engine import NewsEngine
    from app.news.providers import build_news_provider
    from app.notifications.telegram import build_notifier
    from app.pipeline import AnalysisPipeline
    from app.regime.engine import RegimeEngine
    from app.risk.engine import RiskEngine
    from app.risk.kill_switch import KillSwitch
    from app.signals.ensemble import SignalEnsemble
    from app.trader import TradingSystem

    provider = build_provider(cfg)
    news_engine = NewsEngine(build_news_provider(cfg.news), cfg.news)
    regime_engine = RegimeEngine(cfg.regime)
    from app.models.train_service import make_feature_builder

    bundle = None
    hmm_model = None
    try:
        bundle = load_bundle(cfg, registry_tag=registry_tag)
        hmm_model = load_hmm(cfg, registry_tag=registry_tag)
    except Exception as e:
        logging.getLogger(__name__).warning("models not loaded: %s", e)
    feature_builder = make_feature_builder(cfg)
    pipeline = AnalysisPipeline(cfg, provider, feature_builder, regime_engine,
                                news_engine, bundle, hmm_model)
    journal = Journal(Path(cfg.paths.logs_dir) / "journal.db")
    gateway = AIGateway(cfg.ai, ledger=journal)
    kill_switch = KillSwitch(cfg.kill_switch)
    risk = RiskEngine(cfg.risk, kill_switch)
    ensemble = SignalEnsemble(cfg.ensemble)
    executor = PaperExecutor(provider, provider.get_symbol_info(cfg.symbol.primary), cfg.execution)
    system = TradingSystem(
        cfg=cfg, provider=provider, pipeline=pipeline, ensemble=ensemble,
        risk=risk, executor=executor, gateway=gateway, journal=journal,
        health=HealthRegistry(), kill_switch=kill_switch,
        state_store=StateStore(Path(cfg.paths.logs_dir) / "state.json"),
        notifiers=build_notifier(cfg.notifications),
    )
    return system


def main() -> int:
    parser = argparse.ArgumentParser(description="XAU AI Trader")
    # v1.4 §54 — honest mode naming. `--mode live` (old label) is kept ONLY
    # as a deprecated alias that HARD REFUSES with guidance, because the
    # runtime executor was paper-backed while the label said "live".
    parser.add_argument("--mode", choices=["paper", "mt5-readonly", "mt5-demo",
                                           "mt5-live", "live"],
                        default="paper")
    parser.add_argument("--config", default=None)
    parser.add_argument("--once", action="store_true", help="single iteration")
    parser.add_argument("--loops", type=int, default=None)
    parser.add_argument("--registry-tag", default=None,
                        help="model registry family: 'main' (unit-test) or 'real' "
                             "(real-data models from run_real_validation.py); "
                             "defaults to real_data.registry_tag from the config")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)
    log = logging.getLogger(__name__)

    # v1.5 (Mission 26/27): enforce the NO-AUTO-RETRAIN policy at startup —
    # previously assert_no_auto_retrain existed but was only ever called by
    # tests, while generate_final_audit claimed it was active.
    from app.monitoring.no_retrain import assert_no_auto_retrain

    assert_no_auto_retrain(cfg)

    if args.mode in ("live", "mt5-live"):
        # v1.4 §54: hard refusal. No runtime path may place live orders in
        # this build — the MT5 execution path is exercised exclusively via
        # scripts/mt5_demo_execution_test.py against a DEMO account.
        print("[LIVE HARD REFUSED] mt5-live is not enabled in this build: "
              "acceptance gates (§61) are incomplete. Use --mode paper, "
              "--mode mt5-readonly (read-only broker validation) or run the "
              "demo execution test on a DEMO account.", file=sys.stderr)
        raise SystemExit(2)
    if args.mode == "mt5-demo":
        print("[mt5-demo] use scripts/mt5_demo_execution_test.py --send on a "
              "DEMO account — the runtime loop does not place broker orders.",
              file=sys.stderr)
        raise SystemExit(2)

    # paper (default) and mt5-readonly both run the paper-backed loop;
    # mt5-readonly additionally connects the MT5 provider read-only so the
    # user can validate symbol/tick/history plumbing without any order risk.
    cfg.execution.mode = TradingMode.PAPER
    if args.mode == "mt5-readonly" and cfg.provider.kind != "mt5":
        print(f"[mt5-readonly] provider.kind={cfg.provider.kind!r} is not an "
              "MT5 provider — nothing to validate read-only.", file=sys.stderr)
        raise SystemExit(2)
    if args.mode == "mt5-readonly":
        log.info("mt5-readonly: MT5 provider attached READ-ONLY (no order "
                 "sends exist on this path)")

    registry_tag = args.registry_tag
    if registry_tag is None:
        registry_tag = getattr(cfg.real_data, "registry_tag", "main") or "main"

    system = build_system(cfg, registry_tag=registry_tag)
    try:
        asyncio.run(system.run(once=args.once, max_loops=args.loops))
    except KeyboardInterrupt:
        system.stop()
    finally:
        asyncio.run(system.gateway.aclose())
        system.journal.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
