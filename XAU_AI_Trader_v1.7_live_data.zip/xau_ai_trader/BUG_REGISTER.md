# BUG_REGISTER — XAU AI Trader v1.5 Forensic Upgrade

Every finding from the v1.4 audit brief (29 known) plus findings discovered
during the v1.5 forensic audit. Status legend: **FIXED** (root cause fixed,
test added where feasible) · **DOCUMENTED** (deliberate design decision,
recorded) · **PARTIAL** (mitigated; residual noted) · **OPEN** (accepted
with reason, mostly LOW/INFO severity).

## A. Known findings from the brief (29)

| # | Finding | Status | Fix / evidence |
|---|---------|--------|----------------|
| 1 | `copy_rates_from_pos(start_pos=0)` feeds the current/incomplete bar into the pipeline | **FIXED** | `provider.get_candles` drops any bar with `open + tf_duration > cutoff`; requests `count+8` and returns only closed bars; raises `DataError` when nothing closed remains. `tests/test_v15_upgrade.py` (contract in provider docstring). |
| 2 | `get_candles(end_time)` accepted but never enforced | **FIXED** | `end_time` now bounds the closed-bar filter at the single chokepoint; ReplayProvider/SimulatedProvider already honoured it — the three providers now share the contract. |
| 3 | `AmbiguousOrderError` retried by `MT5Executor` | **FIXED** | Executor is now single-send: no retry loop at all. AMBIGUOUS retcodes (10012/10031) raise `AmbiguousOrderError` in `_send_with_policy` (previously mislabeled as `OrderRejectedError` and retried — reproduced in audit). UNKNOWN outcome blocks trading until `reconcile_unknown()` passes. Order FSM: INTENT→PRECHECK→ORDER_CHECK→SEND→ACK→RECONCILE→FILLED/REJECTED/UNKNOWN. `tests/test_v14_safety.py` + executor state tests. |
| 4 | Backtest spread interpreted POINTS as absolute PRICE | **FIXED** | `Backtester(..., spread_units=...)` explicit; POINTS converted by `symbol.point` at the boundary; `spread_source` discloses units; `DatasetMetadata.spread_units` field added; MT5 historical downloader stamps `POINTS`. Tests: `test_spread_points_converted_to_price`, `test_spread_units_rejected_on_bad_value`. |
| 5 | Labeling anchored on `close[t]` vs t+1-open execution | **FIXED** | `triple_barrier_labels` rewritten: entry = `open[t+1] ± spread/2 ± slippage` (executable side), barriers built FROM the executable entry, touches evaluated on executable-side marks (bid for LONG), optional commission shifts barriers. Parity tests: `test_label_executable_anchor_accounts_costs`. |
| 6 | HMM posterior = tiled stationary distribution | **FIXED** | `_posterior` → hmmlearn `predict_proba` (forward-backward smoothing). Test `test_hmm_posterior_is_observation_dependent` proves rows vary (audit measured mean |tiled−true| = 0.237 on the old code). |
| 7 | RSI 0..100 into HMM clipped to [−10,10] | **FIXED** | Shared `hmm_feature_matrix()` (train + inference) maps RSI → (rsi−50)/50 ∈ [−1,1]. Test asserts RSI 70 → 0.4. Single source of truth for the 3-column contract. |
| 8 | SMC cache keyed by dataframe length → stale on rolling windows | **FIXED** | Cache invalidation by window fingerprint (first/last ts, len, last close/HL, SMC config hash) + `SMCResult.fingerprint`. Pipeline reuses the builder's cached result instead of re-analyzing with a second engine (stale-features/fresh-bias split removed). Test: `test_smc_cache_refreshes_on_same_length_rolling_window`. |
| 9 | Dead branch `if False` in ORDER_BLOCK stop logic; buffer ignored | **FIXED** | `stops.py` ORDER_BLOCK: SL = zone boundary ∓ `structure_sl_buffer_atr * atr` on the protective side. Coverage: new ORDER_BLOCK stop tests (v1.5 test file). |
| 10 | Liquidity TP direction inverted (BUY→PDL) | **FIXED** | BUY → `pdh`/`pwh` (buy-side pools above), SELL → `pdl`/`pwl`; direction guard + RR fallback kept. Verified against `smc/liquidity.py` sweep semantics. |
| 11 | Swap logic inconsistent with `swap_hour_utc` | **FIXED** | Paper executor charges only AT the rollover instant (`swap_hour_utc`, minute<5 window), positions opened after rollover are not charged the same evening. Backtester uses `swap_hour_utc` (was hard-coded midnight). |
| 12 | Triple swap day not modelled | **FIXED** | Wednesday rollover books 3× swap in both paper executor and backtester (`triple_swap_weekday`, broker `swap_rollover3days` captured in provenance). |
| 13 | `temporal_split` embargo not enforced | **FIXED** | Explicit gaps: train\|purge\|val\|purge+embargo\|test; `purge = max(purge_bars, horizon_bars)` enforced. Tests: `test_temporal_split_gap_covers_horizon`, `test_walk_forward_splits_have_real_purge_and_embargo`. |
| 14 | Weak label/feature alignment audit | **FIXED** | `run_full_audit` wired into `train_models` (was dead code): real alignment (labels ⊆ feature index), real purity (`test_min > train_max + max(purge, embargo)`), horizon-tail NaN check. Training now REFUSES on audit failure (demonstrated twice during the upgrade run). |
| 15 | Scaler audit checked center only | **FIXED** | `check_scaler_leakage` recomputes train-only center AND scale (median/IQR or mean/std) incl. sklearn zero-variance convention. |
| 16 | Tail labels conflated with real NO_EDGE | **FIXED** | Tail rows (no full future horizon) and invalid-ATR rows are NaN and dropped by `clean_feature_frame`; `check_label_horizon` PASSes only on NaN tails. Test: `test_labels_never_use_last_horizon_bars`. |
| 17 | Test metrics not evaluated on calibrated/deployed probabilities | **FIXED** | `train_models` reports `lgbm_test_raw` AND `lgbm_test_calibrated`; the registry headline metric is the calibrated (deployed) one. Brier + ECE + balanced accuracy added to `classification_metrics`. |
| 18 | NO_EDGE effectively never detected | **FIXED** | Three-part fix: (a) label-tail pollution removed (#16), (b) ensemble treats P(NO_EDGE) ≥ threshold as a hard WAIT (`ML_NO_EDGE_DOMINANT`), (c) NO_EDGE precision/recall now reported per-class. |
| 19 | Static news provider freshness unproven | **FIXED** | Provider contract: `last_update()/coverage()/is_fresh()`; engine returns UNKNOWN(WAIT) when the provider cannot prove freshness. |
| 20 | Synchronous HTTP news blocks the loop | **FIXED** | `get_events_async` via `asyncio.to_thread`; Telegram notifier gains `notify_async` (Mission 40). |
| 21 | Trend keys mismatch pipeline vs AI prompt | **DOCUMENTED** | The mismatching `build_market_state/_PRIORITY_KEYS` block is dead code superseded by `pipeline._build_state` (which emits `h1`/`h4`). Removal scheduled with the prompt-v2 work; behaviour today is unaffected. |
| 22 | v1.3/phase67 vs v1.4 provenance inconsistent | **FIXED** | All superseded PENDING reports stamped with SUPERSEDED headers (see `reports/`), `RELEASE_MANIFEST.json` regenerated from actual artifacts, provenance lint added to the manifest notes. |
| 23 | Broker data PRESENT vs PENDING across reports | **FIXED** | Same supersession pass; `BROKER_DATA_QUALITY.md` (PRESENT, verdict FAIL on H1 spread) is now the authoritative document and is referenced by the manifest. |
| 24 | RiskEngine permissive defaults | **FIXED** | `open_risk_percent=None → OPEN_RISK_UNKNOWN` (WAIT); `daily_loss_percent=None → DAILY_LOSS_UNKNOWN`; `ai_available=None → AI_AVAILABILITY_UNKNOWN`. Fail-closed tests added. |
| 25 | RiskEngine hard-coded `mt5_connected=True` | **FIXED** | `mt5_connected` is now an explicit evaluate() parameter; trader passes `provider.is_connected()`; kill-switch default is fail-closed (unknown ⇒ disconnected). |
| 26 | Margin/profit approximations instead of broker-native | **PARTIAL** | Broker-native wrappers (`order_calc_profit/order_calc_margin`) exist and the heuristic margin gate is now unconditional-fail-closed; full wiring of `order_calc_margin` into the live approval path requires the MT5 host (Windows) to verify — documented in EXECUTION_READINESS as a demo-gate item. |
| 27 | Tick-value fallback accepted in LIVE | **FIXED** | `SymbolInfo.tick_value_is_fallback` provenance flag added; LIVE risk paths must WAIT on fallback provenance (flag plumbed into sizing contract). |
| 28 | Fixed server UTC offset vs DST | **DOCUMENTED** | Offset semantics centralised (`provider.server_to_utc`); provenance text now states the offset is operator-provided, NOT measured, and DST is not handled by a fixed offset (auditable statement). Re-download of `data/raw` with measured offset required before further model work (DATA_QUALITY_REPORT). |
| 29 | Session logic must use broker session definitions + UTC | **PARTIAL** | Session flags operate on UTC (`current_session_name` tz bug fixed); true broker session tables need the MT5 host to read `symbol_info.session_dealing` windows — documented as demo-gate item. |

## B. New findings from the v1.5 forensic audit (selected)

| ID | Severity | Finding | Status |
|----|----------|---------|--------|
| data-N1 | HIGH | Weekend staleness exemption used anchor `2*last_ts − now` → false `stale_data` every Monday | **FIXED** (`_spans_weekend` on the real interval) |
| data-N2 | HIGH | `fillna(0.0)` on the ML inference row (0 = extreme tail after robust scaling) | **FIXED** (`FEATURES_NAN:<cols>` WAIT reason) |
| data-N3 | MED | `copy_rates_range` bounds interpreted as server time → silent data loss with offset>0 | **FIXED** (bounds converted to server time) |
| data-N5 | MED | `quality.stale_after_bars` config knob dead | **FIXED** (wired into `check_candles`) |
| data-N6 | MED | `current_session_name` non-UTC tz mishandled | **FIXED** |
| ml-N1 | CRITICAL | `optimize.py` tuned hyperparameters ON THE TEST SEGMENT | **FIXED** (objective = purged-CV(train) + validation only; test-blind) |
| ml-N2 | CRITICAL | HMM silently dead at inference (90-col matrix into 3-col model, error swallowed at DEBUG) | **FIXED** (shared feature helper + WARNING + `HMM_PREDICTION_FAILED` wait reason) |
| ml-N3 | HIGH | `ambiguous="sl_first"` labeled no-hit bars as SELL (sentinel comparison) | **FIXED** + test |
| ml-N4 | HIGH | Walk-forward splits had ZERO purge/embargo while reports claimed otherwise | **FIXED** + tests |
| ml-N5 | HIGH | Headline backtest metrics GROSS of costs ("net_profit" was not net) | **FIXED** (`pnl_net`, PF/expectancy net headline; gross kept as `*_gross`) |
| ml-N6 | MED | Purged K-fold computed then discarded | **FIXED** (real CV loop → per-fold log-loss in metrics/registry) |
| ml-N7 | MED | `label_periods` full-sample quantiles (look-ahead) | **FIXED** (expanding shifted quantiles) |
| ml-N9 | MED | `min_validation_samples` config dead; val double-dipping (early-stop + calibration) | **PARTIAL** (min-samples enforced; early-stop/calibration separation documented for next iteration) |
| ml-N11 | LOW | LightGBM `eval_X/eval_y` fictional API branch | **FIXED** (feature-detected `eval_set` first) |
| ml-N12 | LOW | Bundle load: missing scaler silently skipped scaling; wrong exception type | **FIXED** (hard failure on missing scaler.json; DataError contract) |
| exec-N1 | CRITICAL | Central retcode policy defeated one layer up: FATAL/AMBIGUOUS rejections re-sent by the executor (NO_MONEY sent twice — reproduced) | **FIXED** (single-send executor) |
| exec-N2 | HIGH | Margin gate skipped when `free_margin <= 0` | **FIXED** (unconditional gate + test) |
| exec-N3 | HIGH | Open-risk gate dead in paper mode (provider returns no positions) | **FIXED** (executor-authoritative in paper) |
| exec-N5 | MED | Paper equity ignored realized P&L (flat synthetic balance) | **FIXED** (`_realized_balance` accumulation) |
| exec-N6 | MED-HIGH | `trade_stops_level`/`freeze_level` never enforced pre-send | **FIXED** (broker stop-distance validation in risk engine) |
| exec-N7 | LOW-MED | Synthetic tick fallback could drive LIVE entries | **FIXED** (live mode raises → WAIT) |
| exec-N11 | INFO | No execution-layer retry tests | **FIXED** (v1.5 tests: state machine, rejection, reconciliation) |
| smc-N4 | MED | `SLMethod.FIXED` point unit hard-coded 0.01 (10× wrong stop on GC) | **FIXED** (point from symbol via `df.attrs`, ATR fallback) |
| smc-N5 | LOW | `directional_bias()` IndexError on short frames | **FIXED** |
| news-N1 | HIGH | `provider: none` fell through to static CSV (config_real documented WAIT) | **FIXED** (`NullNewsProvider`, fail-closed) |
| news-N2 | MED | Currency filter collapsed when `symbol_currency="XAU"` | **FIXED** + test |
| news-N3 | MED | Telegram sync POST inside async loop | **FIXED** (`notify_async`) |
| ai-N6 | LOW | AI gateway cache unbounded | **FIXED** (TTL eviction) |
| ai-N8 | INFO | NaN spread poisoning in backtester | **FIXED** (ffill+0 guard) |
| dash-N | MED | Dashboard regime key mismatch (`regime` vs `current_regime`); decision fields never rendered | **FIXED** (key fix + Mission-38 panel) |
| mon-N | LOW | `assert_no_auto_retrain` never called at startup; drift monitors wired nowhere | **FIXED** (startup assertion; perf-drift wiring documented) |
| health-N11 | INFO | DISABLED ranked worse than SAFE_MODE | **FIXED** |

## C. Intentionally NOT fixed (with reasons)

| Item | Reason |
|------|--------|
| Full DST-aware broker timezone engine | Requires per-broker DST tables; a fixed-offset contract with explicit provenance + audit note is honest and safe. Scheduled with the MT5-host re-download. |
| Tick-level replay backtest | No tick history is shipped in the repo; conservative OHLC sim + SL-first assumption is documented instead (Mission 18 fallback). |
| `build_market_state` dead prompt code removal | Touches AI prompt snapshotting; deferred to prompt-v2 with A/B re-baseline (Mission 21/24). |
| Early-stop/calibration slice separation | Would change all headline metrics mid-release; enforced min-validation-samples now, split documented as follow-up. |
| Cross-asset (DXY/US10Y/VIX) feature engine | Mission 22 optional adapters require external data contracts with provenance; not fabricable offline. Left as designed extension points. |
| Triple-barrier same-bar tie-break default (`sl_first` → worst case) | Kept; both-hit bars are now auditable via labels and the backtester records `*_same_bar` exit reasons. |

## D. v1.7 — Live market data upgrade (user-reported from panel session 2026-10-09)

| # | Symptom (user log) | Root cause | Status | Fix / evidence |
|---|---------------------|------------|--------|----------------|
| D1 | Panel price showed 1,497.42 — "قیمت زنده بازار نیست" | `provider.kind: simulated` — a synthetic random walk seeded at 2350 (PHASE 61 honesty label was visible but the user wanted REAL market data without MT5) | **FIXED** | New `LivePublicProvider` (`app/data/market/live_public.py`, kind=`public`): REAL candles from Yahoo Finance COMEX GC=F (M1 5d / M5 60d / H1 730d / D1 5y) + gold-api.com spot fallback; tiered background refresh; market-open detection from exchange price freshness. Journal proves the switch: WAIT 1497.25 (simulated) → 4209.30 (real GC=F). `tests/test_v17_live_market.py` (17 tests). |
| D2 | `panel trading loop crashed: mt5-readonly requires provider.kind=mt5 (got 'simulated')` | `loop_manager._run_trader` RAISED on mode/provider mismatch → thread crash | **FIXED** | `_resolve_mode()` degrades gracefully: mt5-readonly + non-MT5 provider → paper + visible note in panel Loop tab. Test `test_resolve_mode_falls_back_gracefully`. |
| D3 | 429 Too Many Requests storm → `KILL SWITCH ENGAGED: AI_FAILURES — 12 consecutive AI failures` | Gateway re-hit the rate-limited provider EVERY poll cycle; each hit incremented the AI fail streak | **FIXED** | Gateway per-provider cooldown (`rate_limit_cooldown_s`, default 120s): after 429/timeout/5xx the provider is skipped WITHOUT HTTP; `GatewayResult.attempts_made` distinguishes real failures from cooldown skips; trader counts only real attempts (cooldown-only cycles → neutral `AI_COOLDOWN_SAFE_MODE` WAIT, no streak inflation). Tests `test_gateway_cooldown_skips_http_and_counts_neutral` + `test_rate_limit_config_has_cooldown_field`. |
| D4 | Panel showed price only after the loop started | Overview price came solely from trader `state.json` | **FIXED** | Panel-wide `LiveMarketFeed` daemon + `/api/market` (price/bid/ask/spot/market-open + chart candles); collector falls back to the feed when state is stale, `price_source` labelled `public_feed` vs `trader`. |
| D5 | No way to switch data source from the panel | provider section was file-only | **FIXED** | Settings tab "Market Data Provider" card (kind/symbol/spread/refresh/timeout) → `POST /api/provider/settings` → config.yaml (+backup). `save_ai_settings` now preserves the `rate_limit` block it doesn't own. |
