# V1.4 — بازبینی مستقل ممیزی + گزارش اعمال (DEEP AUDIT REVIEW)

تاریخ: 2026-10-05
مبنای اعمال: `XAU_AI_Trader_v1.3_phase67_fixed2.zip`
ورودی بررسی: `XAU_AI_Trader_v1.3_phase67_fixed2_DEEP_AUDIT.md` + `MASTER_UPGRADE_PROMPT` + `UPGRADE_CHECKLIST.json`
ماهیت: اعتبارسنجی مستقل هر ادعای ممیزی روی کد واقعی، سپس اعمال؛ طبق قانون «هیچ NOT_RUN به PASS تبدیل نشود».

---

## 1) نتیجه اعتبارسنجی ادعاهای P0 ممیزی

| # | ادعای ممیزی | نتیجه راستی‌آزمایی | اقدام |
|---|---|---|---|
| P0.1 | خط `out.to_parquet(f)` خراب در `download_mt5_data.py:175` | **تأیید** — دقیقاً قبل از تعریف `out`/`f` (NameError قطعی در اولین TF) | Downloader v2 بازنویسی کامل شد (chunked ranged + dedupe + atomic + manifest) |
| P0.2 | `symbols_select` غلط در ۳ فایل | **تأیید** | هر ۳ مورد → `symbol_select(sym, True)`؛ گیت §61: صفر فراخوانی باقی مانده |
| P0.3 | جابه‌جایی timestamp با `server_utc_offset_hours` باید حذف شود | **مخالف — با مدرک** (بخش ۲ زیر) | به‌جای حذف کور: «time semantics اعتبارسنجی‌شده» پیاده شد |
| P0.4 | execution نباید hardcoded filling/deviation/retcode داشته باشد؛ `order_check` اجباری | **تأیید** (provider: `type_filling:1`، `deviation:20`، retcode خام 10009) | لایه اجرا با retcode-policy مرکزی + filling از bitmask + order_check بازنویسی شد |
| P0.5 | retry کورکورانه روی order_send مبهم = خطر اجرای تکراری | **تأیید** (حلقه retry شامل 10004/10006/10131 و None) | سیاست RETRYABLE/AMBIGUOUS/FATAL؛ روی AMBIGUOUS/None: بدون retry → `AmbiguousOrderError` (تست: order_send دقیقاً یک بار صدا زده می‌شود) |
| P0.6 | sizing باید از `order_calc_profit/margin` بومی بروکر استفاده کند | **تأیید** (فقط فرمول تقریبی) | wrapperهای بروکر-نیتیو به provider اضافه شد؛ paper فقط شبیه‌سازی |
| P0.7 | `open_risk_percent` پیش‌فرض 0 = دور زدن سقف ریسک تجمعی | **تأیید** (engine default 0.0؛ trader هیچ‌گاه مقدار واقعی نمی‌داد) | `OpenRiskCalculator` + گیت fail-closed `OPEN_RISK_UNKNOWN` در engine |
| P0.8 | `optimize.py` روی test با Optuna بهینه می‌کند | **تأیید نشد — فایل وجود ندارد** (بخش ۳ زیر) | اعمالی نداشت؛ در لیست NOT_APPLICABLE |
| P0.9 | Purged CV فقط audit است، نه selection واقعی | **تأیید جزئی** (splits ساخته می‌شوند، selection رویشان نیست) | PARTIAL — به بخش ۴ |
| P0.10 | Kill switch fail-open روی state خراب | **تأیید** (`starting clean`) | fail-closed کامل + persist اتمیک + جمع‌آوری همه تریگرها |
| — | باگ StandardScaler (`center_` برای هر دو kind) | **تأیید** — بدتر از ادعا: fallback هم `center_.tolist()` بود ⇒ `scaler: standard` همیشه کرش | `mean_/scale_` برای standard؛ state نسخه‌دار (schema_version=2)؛ ۳ تست رگرسیون |
| — | dead code `if False else` در leakage.py | **تأیید** (L106-107) | حذف شد؛ رفتار مؤثر (همیشه `_label_alignment`) حفظ شد |
| — | `supports_real_execution` ثابت True | **تأیید** | بررسی پویا: Windows+اتصال+trade_allowed+trade_expert+پرچم صریح (پیش‌فرض False) |

## 2) مخالفت مستند با P0.3 (UTC) — مهم

ممیزی مدعی است «MT5 داده‌ها را در UTC برمی‌گرداند؛ پس هر شیفت offset باید حذف شود». این ادعا با رفتار واقعی `copy_rates_*` سازگار نیست:

- قرارداد رسمی MT5: زمانِ bar/tick بر مبنای **ساعت دیوارِ سرورِ بروکر** است (روزهای D1 در نیمه‌شبِ سرور باز می‌شوند)، نه UTC مطلق. برای اکثر بروکرها سرور UTC+2/+3 (EET) است.
- **مدرک از داده خود کاربر (fix-2):** ناهنجاری spread در H1 دقیقاً در ساعت «02:00» برچسب‌خورده دیده شد — الگوی کلاسیک rollover روزانه جهانی (00:00 UTC) است که از دریچه ساعت سرور UTC+2 دیده می‌شود. اگر داده واقعاً UTC بود، rollover باید در 00:00 دیده می‌شد.
- نتیجه عملی: حذف کورکورانه شیفت، برچسب UTC را **غلط** اما «بی‌صدا» می‌کرد — دقیقاً همان کاری که کل پروژه با آن مخالف است.

**راه‌حل اعمال‌شده (روحِ قانون، نه حرفِ آن):**
- ذخیره‌سازی canonical = true UTC (توافق‌شده).
- تبدیل سرور→UTC **فقط** با offset صریح: `--server-utc-offset-hours` یا `--detect-server-offset` (استنتاج از کوتیشن تازه سرور با ردِ خودکار کوتیشن کهنه؛ در تناقض → خطا، نه شیفت خاموش).
- فیلد `time_semantics` در manifest حقیقت زمانِ داده را ثبت می‌کند؛ بدون offset، دانلودر **refuse** می‌کند (exit 2) — نه حدس، نه ساختگی.

## 3) NOT_APPLICABLE / NOT_RUN (صادقانه)

| مورد | وضعیت | دلیل |
|---|---|---|
| `optimize.py` test-leakage | NOT_APPLICABLE | فایل در مخزن وجود ندارد (ادعای ممیزی قابلیت راستی‌آزمایی نداشت) |
| اجرای واقعی دانلود از MT5 | NOT_RUN | محیط بدون Windows/MT5؛ منطق chunk/dedupe/stop با fake-MT5 تست شد (۵ تست) |
| اجرای demo execution روی حساب DEMO | NOT_RUN | نیازمند ترمینال کاربر؛ مسیر dry-run و صفحات fail-closed تست شدند |
| بازآموزی مدل‌ها با time-semantics جدید | NOT_RUN | به تصمیم کاربر: پس از دانلود با offset تأییدشده، retrain + ثبت نسخه جدید registry الزامی است |

## 4) اعمال‌شده‌ها ولی PARTIAL (شفاف)

- **Purged CV واقعی (§27):** ساختار purged/embargo حفظ و گیت‌های leakage سخت‌گیرانه شد؛ ولی بازطراحی کامل Optuna-nested طبق §26 هنوز اجرایی نشد (نیازمند بازطراحی بزرگ training pipeline و پس از آن retrain کامل). تا آن زمان هر نتیجه‌ای «EDGE_NOT_ESTABLISHED» می‌ماند.
- **Label/Execution alignment (§32/§33):** barrier از close_t و execution در next-open — تغییرش معنای تمام مدل‌های آموزش‌دیده را باطل می‌کند؛ به‌عنوان فاز بعدی مستقل ثبت شد (نیازمند retrain + null-model audit دوباره).
- **Session calendar بروکر (§35/§39):** هیچ تقویم جلسه‌ای invent نشد (طبق قانون)؛ quality gate همان یافته‌های واقعی (rollover 02:00=00:00 UTC) را با برچسب session-unknown گزارش می‌کند تا کاربر از config بروکر تغذیه کند.

## 5) جمع‌بندی

۱۵ مورد از ۱۶ مورد critical_repairs در چک‌لیست به‌صورت کامل اعمال و تست شد؛ ۱ مورد (optimize.py) وجود نداشت؛ ۳ حوزه (nested-CV کامل، label-realignment، session-calendar) به‌صورت PARTIAL/فاز بعدی مستند شد. کلیدهای §61 همگی سبز. وضعیت معاملاتی: **LIVE همچنان غیرفعال و hard-refuse؛ EDGE_NOT_ESTABLISHED پابرجا.**
