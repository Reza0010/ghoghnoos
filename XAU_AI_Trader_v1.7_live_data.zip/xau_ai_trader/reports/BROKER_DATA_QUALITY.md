# BROKER DATA QUALITY REPORT (PHASE 66 §3)

_Generated: 2026-10-04T07:25:20.423891+00:00_

**Status: BROKER_DATA_PRESENT** — Overall verdict: **FAIL**

Dataset: REAL BROKER XAUUSD (MetaTrader 5 download)

## XAUUSD D1 — PASS (100.0% usable)

- bars: 1000 (2022-11-18 00:00:00+00:00 → 2026-10-02 00:00:00+00:00)
- duplicate_bars: PASS — {"count": 0}
- invalid_ohlc_structure: PASS — {"high_lt_low": 0, "open_outside_range": 0, "close_outside_range": 0}
- zero_or_negative_prices: PASS — {"count": 0}
- abnormal_jumps: PASS — {"count": 1, "affected_periods": ["2026-01-30 00:00:00+00:00"]}
- abnormal_spread: PASS — {"count": 0, "median_spread_points": 5.5, "p95_spread_points": 18.0, "max_spread_points": 36.0, "affected_periods": []}
- timezone_consistency: PASS — {"detail": "index tz=UTC"}
- gap_classification: PASS — {"total_gaps": 206, "weekend_gaps": 202, "daily_maintenance_gaps": 0, "holiday_like_gaps": 4, "unexpected_gaps": 0, "note": "classification is interval-based: gaps crossing Sat/Sun are weekend breaks; <=3h weekday gaps a
- incomplete_latest_candle: PASS — {"note": "last bar 2026-10-02 00:00:00+00:00 \u2014 downloader must request data up to a COMPLETED bar; live incomplete candles are excluded by the provider", "last_bar": "2026-10-02 00:00:00+00:00"}

## XAUUSD H1 — FAIL (98.7% usable)

- bars: 1000 (2026-08-04 11:00:00+00:00 → 2026-10-02 23:00:00+00:00)
- duplicate_bars: PASS — {"count": 0}
- invalid_ohlc_structure: PASS — {"high_lt_low": 0, "open_outside_range": 0, "close_outside_range": 0}
- zero_or_negative_prices: PASS — {"count": 0}
- abnormal_jumps: PASS — {"count": 0, "affected_periods": []}
- abnormal_spread: **FAIL** — {"count": 13, "median_spread_points": 18.0, "p95_spread_points": 22.0, "max_spread_points": 50.0, "affected_periods": ["2026-08-06 02:00:00+00:00", "2026-08-17 02:00:00+00:00", "2026-08-19 02:00:00+00:00", "2026-08-24 02
- timezone_consistency: PASS — {"detail": "index tz=UTC"}
- gap_classification: PASS — {"total_gaps": 43, "weekend_gaps": 8, "daily_maintenance_gaps": 34, "holiday_like_gaps": 0, "unexpected_gaps": 1, "note": "classification is interval-based: gaps crossing Sat/Sun are weekend breaks; <=3h weekday gaps are
- incomplete_latest_candle: PASS — {"note": "last bar 2026-10-02 23:00:00+00:00 \u2014 downloader must request data up to a COMPLETED bar; live incomplete candles are excluded by the provider", "last_bar": "2026-10-02 23:00:00+00:00"}

## XAUUSD M1 — PASS (100.0% usable)

- bars: 1000 (2026-10-02 07:18:00+00:00 → 2026-10-02 23:57:00+00:00)
- duplicate_bars: PASS — {"count": 0}
- invalid_ohlc_structure: PASS — {"high_lt_low": 0, "open_outside_range": 0, "close_outside_range": 0}
- zero_or_negative_prices: PASS — {"count": 0}
- abnormal_jumps: PASS — {"count": 1, "affected_periods": ["2026-10-02 15:30:00+00:00"]}
- abnormal_spread: PASS — {"count": 0, "median_spread_points": 18.0, "p95_spread_points": 22.0, "max_spread_points": 22.0, "affected_periods": []}
- timezone_consistency: PASS — {"detail": "index tz=UTC"}
- gap_classification: PASS — {"total_gaps": 0, "weekend_gaps": 0, "daily_maintenance_gaps": 0, "holiday_like_gaps": 0, "unexpected_gaps": 0, "note": "classification is interval-based: gaps crossing Sat/Sun are weekend breaks; <=3h weekday gaps are d
- incomplete_latest_candle: PASS — {"note": "last bar 2026-10-02 23:57:00+00:00 \u2014 downloader must request data up to a COMPLETED bar; live incomplete candles are excluded by the provider", "last_bar": "2026-10-02 23:57:00+00:00"}

## XAUUSD M15 — PASS (100.0% usable)

- bars: 1000 (2026-09-18 04:00:00+00:00 → 2026-10-02 23:45:00+00:00)
- duplicate_bars: PASS — {"count": 0}
- invalid_ohlc_structure: PASS — {"high_lt_low": 0, "open_outside_range": 0, "close_outside_range": 0}
- zero_or_negative_prices: PASS — {"count": 0}
- abnormal_jumps: PASS — {"count": 0, "affected_periods": []}
- abnormal_spread: PASS — {"count": 0, "median_spread_points": 18.0, "p95_spread_points": 22.0, "max_spread_points": 50.0, "affected_periods": []}
- timezone_consistency: PASS — {"detail": "index tz=UTC"}
- gap_classification: PASS — {"total_gaps": 10, "weekend_gaps": 2, "daily_maintenance_gaps": 8, "holiday_like_gaps": 0, "unexpected_gaps": 0, "note": "classification is interval-based: gaps crossing Sat/Sun are weekend breaks; <=3h weekday gaps are 
- incomplete_latest_candle: PASS — {"note": "last bar 2026-10-02 23:45:00+00:00 \u2014 downloader must request data up to a COMPLETED bar; live incomplete candles are excluded by the provider", "last_bar": "2026-10-02 23:45:00+00:00"}

## XAUUSD M5 — PASS (100.0% usable)

- bars: 1000 (2026-09-29 09:40:00+00:00 → 2026-10-02 23:55:00+00:00)
- duplicate_bars: PASS — {"count": 0}
- invalid_ohlc_structure: PASS — {"high_lt_low": 0, "open_outside_range": 0, "close_outside_range": 0}
- zero_or_negative_prices: PASS — {"count": 0}
- abnormal_jumps: PASS — {"count": 1, "affected_periods": ["2026-10-02 15:30:00+00:00"]}
- abnormal_spread: PASS — {"count": 0, "median_spread_points": 18.0, "p95_spread_points": 22.0, "max_spread_points": 50.0, "affected_periods": []}
- timezone_consistency: PASS — {"detail": "index tz=UTC"}
- gap_classification: PASS — {"total_gaps": 3, "weekend_gaps": 0, "daily_maintenance_gaps": 3, "holiday_like_gaps": 0, "unexpected_gaps": 0, "note": "classification is interval-based: gaps crossing Sat/Sun are weekend breaks; <=3h weekday gaps are d
- incomplete_latest_candle: PASS — {"note": "last bar 2026-10-02 23:55:00+00:00 \u2014 downloader must request data up to a COMPLETED bar; live incomplete candles are excluded by the provider", "last_bar": "2026-10-02 23:55:00+00:00"}

## Remediation

- FAIL items: see counts above; abnormal jumps/spreads are kept in the dataset but flagged — the quality gate excludes affected bars from feature windows rather than silently dropping them.
- Missing-timestamp checks never treat weekend/daily-maintenance/holiday session breaks as errors (§3 note).