# PHASE 65 — REAL-WORLD VALIDATION REPORT

> Generated 2026-10-01 (UTC) by the Phase-65 pipeline. Every number below is
> traceable to a JSON report in `reports/`. **No synthetic-data result is
> reported as a real XAUUSD result anywhere in this document.**

---

## 0. Validation status board (§30)

| Layer | Status | Data | Notes |
|---|---|---|---|
| SYNTHETIC TEST | ✅ 137/137 tests pass | synthetic (unit tests only) | never used for performance claims |
| REAL HISTORICAL TEST | ✅ DONE | **REAL** COMEX gold (GC=F) via Yahoo Finance | see §2–§7 |
| PAPER TRADING (replay) | ✅ DONE | same REAL dataset, online loop | §8 |
| PAPER TRADING (live MT5) | ⛔ NOT RUN | requires Windows + MT5 terminal | honest limitation |
| DEMO TRADING | ⛔ NOT RUN | requires Windows + MT5 demo account | checklist implemented, §9 |
| LIVE TRADING | 🔒 DISABLED BY DESIGN | — | `LIVE_TRADING_ENABLED=false` (§21) |

---

## 1. Dataset (§2/§3/§4)

| File | TF | Bars | Range (UTC) | Source | Spread col |
|---|---|---|---|---|---|
| `data/raw/GC_M15.parquet` | M15 | 4,548 | 2026-07-23 → 2026-10-01 | Yahoo Finance `GC=F` | ❌ |
| `data/raw/GC_H1.parquet` | H1 | 13,731 | 2024-05-09 → 2026-10-01 | Yahoo Finance `GC=F` | ❌ |
| `data/raw/GC_D1.parquet` | D1 | 6,106 | 2000-08-30 → 2026-10-01 | Yahoo Finance `GC=F` | ❌ |
| `data/raw/GC_M5.parquet` | M5 | 13,615 | 2026-07-23 → 2026-10-01 | Yahoo Finance `GC=F` | ❌ |

- **Instrument**: COMEX Gold Futures front month (GC=F) — **REAL market prices**,
  real exchanged contract volume. This is **NOT broker XAUUSD spot**; basis and
  session differences exist and are disclosed here.
- Every file carries a `<name>.meta.json` sidecar (`app/data/dataset_meta.py`):
  broker, symbol, timeframe, timezone, start, end, download_date, bar_count,
  spread_available, source (§4).
- 441 vendor OHLC-violating rows in the raw D1 history were **dropped and the
  count recorded** in metadata (transparent cleaning, never silent fixing).
- **MT5 broker downloader**: `scripts/download_mt5_data.py` (M1…D1, symbol
  configurable XAUUSD/XAUUSDm/GOLD, writes the same parquet+meta format plus
  `*_broker_specs.json` with digits/point/tick/contract/lots/spread/swap — §6).
  It runs **only on Windows** with a terminal; on Linux it exits honestly.
- **Broker specs (§6)**: `NOT AVAILABLE` in this environment. Sizing used the
  retail-CFD symbol defaults (contract 100 oz, min lot 0.01) — a **documented
  assumption**, to be replaced by real broker specs from MT5.

## 2. Data quality (§5)

`data/data_quality_report.json` — full §5 check battery on real data:

| Dataset | Score | Verdict |
|---|---|---|
| GC_M15 / GC_M5 / GC_H1 / GC_D1 | **100 / 100** | PASS |

Checks executed: missing candles, duplicate timestamps, timestamp ordering,
OHLC consistency, weekend gaps, CME daily maintenance breaks (17:00–18:00 ET —
classified as real exchange structure), holiday/early-close gaps, abnormal
spread, zero-volume share, timezone sanity, staleness.
CME full-day holidays (25–36 h weekday pauses) are recognised as real closures;
an intraday drop during continuous trading still scores as an error.

## 3. Real training pipeline (§7/§8)

`scripts/run_real_validation.py` executed: Raw → Validation → Features → SMC →
Triple-Barrier Labels → **strict temporal split (no random)** → Train →
Calibration → Walk-Forward → OOS Backtest → breakdowns → drift.

- Split (M15, 60 d): TRAIN 2,950 rows (07-27 → 09-10) / VAL 582 / **TEST 582
  (09-23 → 10-01)**, purge+embargo 64 bars. Leakage audit: **PASS**.
- Models registered under `*_real` (lgbm_real / xgb_real / hmm_real) — separate
  from the synthetic unit-test family.

**Out-of-sample ML metrics (REAL data, test segment):**

| Model | Accuracy | F1 macro | ROC-AUC OvR |
|---|---|---|---|
| LGBM (real) | 0.357 | 0.249 | 0.410 |
| XGB (real) | 0.507 | 0.338 | 0.441 |

- Walk-forward (4 folds, 2,400 OOS predictions): **OOS accuracy 0.482** with
  high fold variance (0.63 / 0.37 / 0.49 / 0.44) — classic real-market
  instability on only 60 days of M15 data. **No edge is claimed.**
- HMM regime model **skipped** on this dataset (covariance degeneracy, logged);
  rule-based regime engine used instead. Honest limitation, not hidden.

## 4. Real backtest (§16)

`reports/real_validation_summary.json`, `reports/real_backtest_trades.csv`.
Test segment only, costs: assumed_spread 0.30 (§ assumption), slippage 5 pts,
commission 7 $/lot, swap applied, SL-first double-hit rule, 1-bar execution
delay with **signal_time / order_time / fill_time recorded per trade (§26)**.

**Primary config (conservative gates)**: 0 signals → **0 trades** — the
ensemble returned WAIT on every evaluated bar. Per Directive 0 this is a valid
outcome and is reported as such.

**Threshold sensitivity (evaluation only, relaxed gates — NOT the production
setting):**

| Gate (conf/margin/score) | Signals | Trades | PF | Win rate | MaxDD |
|---|---|---|---|---|---|
| 0.45 / 0.10 / 0.45 | 13 | 9 | 2.02 | 44.4 % | −1.37 % |
| 0.40 / 0.08 / 0.40 | 16 | 11 | 2.02 | 45.5 % | −1.88 % |
| 0.35 / 0.06 / 0.35 | 23 | 15 | 1.54 | 46.7 % | −3.19 % |

Period covered: 09-23 → 10-01 (≈7 trading days). Sessions (0.45 gate):
OVERLAP 3 trades / NEW_YORK 3 / ASIA 2 / LONDON 1. **9–15 trades is far too
few for statistical significance — these are pipeline-validation numbers, not
an edge claim.**

## 5. AI provider — REAL test (§12/§17)

`reports/ai_provider_test.json` — **REAL API calls** (provider `zai`, model
`glm-4-plus`, gateway host `internal-api.z.ai` from this sandbox's own
credential file; keys never printed or committed):

| Metric | Value |
|---|---|
| Calls | 15 / 15 **OK**, error rate **0.0** |
| Avg latency | 1,725 ms (p95 reported in file) |
| Tokens | 13,717 total (~815 in / ~100 out per call) |
| JSON validity | 100 % schema-valid `AIOutput` |

The AI **cannot** set lot size / risk % / SL / TP / max drawdown — the output
schema contains only decision/classification fields and the deterministic risk
engine computes all execution parameters (§13, enforced in code).

Cost-aware gating (§17): `app/ai/gate.py` allows a real AI call only when an ML
setup exists **and** SMC does not conflict **and** the risk pre-check passes.
The AB-test run made **16 AI calls** for 33 candidate setups (vetoes: 10,
agreements: 6).

## 6. AI consistency — 100 REAL market states (§14)

`reports/ai_consistency_test.json` (100 states built from the real dataset,
each answered through the live API; 10 identical-state repeat pairs):

| Metric | Value |
|---|---|
| Invalid JSON / schema violations | **0** (valid rate 1.0) |
| Agreement with ML direction | 0.26 (AI is largely independent — mostly WAITs) |
| Confidence std | 0.356 (high dispersion) |
| Hallucination ratio (numbers in evidence not present in state) | mean **0.169** |
| BUY/SELL contradictions on identical states | **0 / 10 pairs** |

Honest reading: output format is stable and contradiction-free, but the
high confidence dispersion and the 0.17 hallucination ratio mean AI reasoning
text must never be trusted as a data source — it is a filtered vote only.

## 7. A/B test (§15)

`reports/ab_test_report.json` — same REAL test segment, same cost model,
relaxed gate for evaluation (production gate = 0 trades, see §4):

| Variant | Trades | Win rate | PF | Expectancy | MaxDD | Sharpe | Sortino |
|---|---|---|---|---|---|---|---|
| ML only | 45 | 44.4 % | 1.54 | 13.4 $ | −2.84 % | 6.72 | 76.4 |
| ML + SMC | 33 | 39.4 % | 1.27 | 7.1 $ | −3.56 % | 2.48 | 8.36 |
| ML + SMC + REGIME | 33 | 39.4 % | 1.27 | 7.1 $ | −3.56 % | 2.48 | 8.36 |
| ML + SMC + REGIME + **AI** | **4** | 75.0 % | 5.71 | 60.9 $ | −0.91 % | 6.64 | 6.64* |

**Honest conclusion (§15)**: on this window, adding SMC to ML *reduced*
PF (1.54 → 1.27) and the regime veto changed nothing. The AI variant shows the
best ratios but on **4 trades only — statistically meaningless**. The truthful
summary: *there is no evidence yet that AI improves performance; it mainly
reduces trade count (selectivity).* Longer real data is required before any
conclusion.

## 8. Paper trading replay + paper-vs-backtest (§18/§19)

`reports/paper_replay_report.json`, `paper_replay_journal.jsonl`.
The ONLINE loop was replayed bar-by-bar over the last 352 real M15 bars
(2026-09-25 → 10-01), decisions made only on data available at each bar; every
signal journaled including WAIT reasons. **No real orders were sent** and the
replay provider refuses execution by design.

- Journal: 352 bars → 342 WAIT, 1 filled position (1 closed, est. P/L +91.12 $
  at the documented assumptions), 8 ensemble SELL signals suppressed while the
  single position was open (max_open_positions=1).
- **Paper vs backtest** on the identical signal: net P/L 91.12 $ (paper loop)
  vs 91.40 $ (vectorised backtester) — engines consistent; residual difference
  comes from fill/rounding paths. Spread handling identical (assumed 0.30,
  disclosed). True live paper mode remains MT5/Windows-only.

## 9. Demo execution test + reconciliation (§20/§21/§27)

`reports/demo_execution_test.json` — status **NOT_RUN**: requires Windows + a
running MT5 terminal + **DEMO** account (the script refuses non-demo accounts).
The implemented checklist: market order, SL set, TP set, modify, close,
invalid-lot rejection, invalid-price rejection, connection-loss + reconnect,
and **broker reconciliation** (§27): every MT5 deal with our magic number must
exist in the internal journal — any mismatch is CRITICAL and disables trading.
`LIVE_TRADING_ENABLED` remains **false** everywhere (§21) and nothing in this
phase turns it on.

## 10. Drift (§23/§24) — current verdict: **WARNING**

`reports/drift_report.json`:

- Data drift (train vs latest real window): PSI ACTION-level on **36.7 % of
  features** (threshold 20 %) → verdict WARNING. KS top features listed in the
  report; prediction-distribution PSI per class included.
- Model rolling performance (50/100/200 trades): INSUFFICIENT_TRADES (real
  backtest produced 0–15 trades per setting) — will become meaningful as the
  journal grows.
- **Action**: human review required before further trading. **Automatic
  retraining is FORBIDDEN (§25)** — drift is a Human-Review → manual-retrain
  trigger only, and no code path retrains automatically.

## 11. Risk engine (deterministic, unchanged)

Risk Engine > AI remains enforced: sizing, SL/TP placement, RR minimums,
daily-loss cap, drawdown kill-switch, spread/quality/news vetoes all computed
deterministically from `config` — the AI vote can only add a WAIT/veto, never
increase exposure. Risk parameters used in this phase: risk 0.5 %/trade,
min RR 2.0, ATR SL ×1.5.

## 12. AI cost accounting (§17)

- Provider test: 15 calls, 13,717 tokens. Consistency test: 120 calls (100
  states + 20 repeats). AB test: 16 gated calls.
- Gateway enforces per-provider daily request caps and a USD cost ceiling
  (`config.ai.cost_daily_limit_usd`), with a JSONL ledger via the journal.

## 13. Known limitations (honest list)

1. **Broker XAUUSD specs and spread are NOT in the dataset** — costs use a
   documented `assumed_spread=0.30`; real broker validation needs
   `scripts/download_mt5_data.py` on Windows.
2. **Instrument basis**: COMEX futures prices ≠ broker spot XAUUSD; sessions
   and microstructure differ.
3. Only **60 days** of real M15 history were available from the public source
   (Yahoo limits) → small OOS trade counts; walk-forward fold variance is high.
4. HMM was skipped on the real M15 dataset (numerical degeneracy) — regime
   rules used; to revisit with more data.
5. Real news provider **NOT IMPLEMENTED** (§11) — backtests ran NEWS-NEUTRAL
   (disclosed); live mode stays WAIT on news-unavailable per config.
6. Live paper / demo / live trading untested here (Windows + MT5 required);
   the execution checklist and reconciliation are implemented and waiting.
7. Drift verdict is WARNING — trading must not proceed to live until human
   review (§25).

## 14. Phase-65 verdict

The system has moved from a synthetic-only laboratory to a **real-data
validation platform**: real-data adapter + provenance metadata + MT5
downloader + quality suite + strict temporal training + walk-forward +
cost-modelled backtest + gated real-AI integration + consistency testing +
drift monitoring — all demonstrated end-to-end on REAL gold market data, with
every synthetic artefact quarantined for unit tests. **No profitability claim
is made.** REAL VALIDATION with broker XAUUSD data awaits only: (a) running
`scripts/download_mt5_data.py` on Windows, (b) `config_real.yaml`
`real_data.symbol` pointing at the broker symbol, (c) re-running
`scripts/run_real_validation.py`.

---

# PHASE 66 APPENDIX — BROKER-REAL VALIDATION & STATISTICAL EDGE AUDIT

_Generated by scripts/generate_final_audit.py — full evidence: `reports/PHASE_66_FINAL_AUDIT.md`._

**Verdict: EDGE_NOT_ESTABLISHED.** On the real GC=F dataset (strict 60/20/20
chronological split, purge+embargo 64, leakage audit PASS):

- Primary variant (ML+SMC+regime): **44 trades, PF 1.24, expectancy 6.46** —
  bootstrap 10k: PF 95% CI (0.64, 2.27), expectancy CI (−12.22, +25.98) includes
  zero → EDGE_NOT_ESTABLISHED. Sample warning: LOW_STATISTICAL_POWER.
- **EXECUTION_FRAGILE**: PF 0.96 at 2× spread — profitability disappears under
  modest execution deterioration.
- Random-signal baseline (100 seeds, identical costs/window): 95th-percentile PF
  3.15 — no deterministic variant clears chance.
- Walk-forward 7 folds: OOS accuracy 0.538; fold PF 0.31–1.61 (inconsistent).
- ML models show no OOS predictive power on the test segment
  (LGBM AUC 0.436, XGB 0.623).
- AI ablation: no AI variant meets improvement criteria (sample size + CI +
  walk-forward + stability). Phase 65 +AI result (PF 5.71 on 4 trades) remains
  statistically meaningless — stated, not celebrated.
- AI agreement 0.26 = systematic conservatism (WAIT 74%) + SMC-conflict vetoes;
  usefulness test p=0.113 → NO_SIGNIFICANT_SELECTION_VALUE. Agreement NOT forced.
- AI repeatability: valid rate 1.0 (77 retained records, Phase 65) / fresh
  multi-send rate-limited (429→degrade→WAIT verified). Status: PARTIAL_RATE_LIMITED.
- Drift: DATA_DRIFT=WARNING (d1/H1 trend families), CONCEPT_DRIFT=PRESENT —
  NO automatic retraining (§25); human review required.
- Fail-safe matrix: 18/18 automated scenarios → NO_NEW_TRADE or HALT.
- Broker XAUUSD data, GC=F-vs-broker comparison, MT5 demo execution: PENDING
  Windows/MT5 (tools implemented, nothing faked).

Final classification (§26): EDGE_NOT_ESTABLISHED · INSUFFICIENT_DATA ·
EXECUTION_NOT_VALIDATED · AI_VALIDATED=no · NEWS_NOT_VALIDATED ·
BROKER_DATA_VALIDATED=no · DRIFT_WARNING.
