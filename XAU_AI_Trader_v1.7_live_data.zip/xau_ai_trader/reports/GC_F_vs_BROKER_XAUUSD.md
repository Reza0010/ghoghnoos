# GC=F vs BROKER XAUUSD COMPARISON (PHASE 66 §4)

_Generated: 2026-10-04T07:23:52.553137+00:00_

**Standing rule: GC=F (COMEX gold futures, Yahoo public data) and broker
XAUUSD (spot CFD) are RELATED but NOT interchangeable instruments.**
Differences are structural, not cosmetic:

- **basis**: futures carry contango/backwardation vs spot
- **calendar**: CME maintenance breaks & holiday calendar ≠ broker server week
- **spread/execution**: broker XAUUSD has a live floating spread; GC=F here has none
- **tick size**: GC=F $0.10 contract ticks vs broker point conventions
- **timezone**: CME timestamps vs broker server time offsets

## Measured comparison (overlapping period)

- overlap bars: 838 (2026-09-18 04:00:00+00:00 → 2026-10-01 19:00:00+00:00)
- ohlc_corr_open: 0.9782
- ohlc_corr_high: 0.9789
- ohlc_corr_low: 0.9781
- ohlc_corr_close: 0.9783
- return_corr: 0.0292
- volatility_corr: 0.387
- atr_corr: 0.5601
- price_basis: {"mean_abs_diff": 33.54, "mean_signed_diff": 32.662, "p95_abs_diff": 60.921, "note": "futures-vs-spot basis, broker markup and contract spec differences"}
- timestamp_profile: {"gcf_median_gap_s": 900.0, "xauusd_median_gap_s": 900.0, "gcf_weekend_gap_bars": 2, "xauusd_weekend_gap_bars": 2}
- session asia: GC=F vol 0.001763 vs XAUUSD vol 0.001926
- session london: GC=F vol 0.003177 vs XAUUSD vol 0.002220
- session ny: GC=F vol 0.002522 vs XAUUSD vol 0.002558

## Explicit differences — do NOT treat as interchangeable

Any figure above <1.0 correlation, the price basis, timestamp gaps and
spread asymmetries are documented reasons why GC=F results cannot be
assumed to transfer to broker XAUUSD execution.
