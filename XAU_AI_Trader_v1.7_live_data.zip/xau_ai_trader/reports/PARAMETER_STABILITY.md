# PARAMETER STABILITY (PHASE 66 §12)

_Generated: 2026-10-02T04:41:30.910965+00:00 — dataset: REAL GC=F M15, test segment 2026-09-20 23:00 → 2026-10-01 19:00, primary variant ML+SMC+regime (F). Neighbourhood sweeps at ±10%/±20%; NO best-pick search._

> A strategy that only works at one precise threshold must be marked **unstable**.

## min_ml_confidence

| value | signals | trades | PF | expectancy | MaxDD % |
|---|---|---|---|---|---|
| 0.32 | 103 | 44 | 1.236908909482352 | 6.46 | -4.416413991052531 |
| 0.36 | 103 | 44 | 1.236908909482352 | 6.46 | -4.416413991052531 |
| 0.4 | 103 | 44 | 1.236908909482352 | 6.46 | -4.416413991052531 |
| 0.44 | 103 | 44 | 1.236908909482352 | 6.46 | -4.416413991052531 |
| 0.48 | 103 | 44 | 1.236908909482352 | 6.46 | -4.416413991052531 |

**Classification: STABLE** — PF>1 in 100% of the neighbourhood (PF range 1.24–1.24).

## atr_sl_mult

| value | signals | trades | PF | expectancy | MaxDD % |
|---|---|---|---|---|---|
| 1.2 | 103 | 58 | 1.046669884723883 | 1.37 | -6.0141014405104105 |
| 1.35 | 103 | 49 | 1.0135686257938035 | 0.39 | -4.677537942200422 |
| 1.5 | 103 | 44 | 1.236908909482352 | 6.46 | -4.416413991052531 |
| 1.65 | 103 | 40 | 1.1908816461340554 | 5.14 | -3.940214947817107 |
| 1.8 | 103 | 30 | 1.6989173463074427 | 15.70 | -2.576336273633005 |

**Classification: STABLE** — PF>1 in 100% of the neighbourhood (PF range 1.01–1.70).

## min_rr

| value | signals | trades | PF | expectancy | MaxDD % |
|---|---|---|---|---|---|
| 1.6 | 103 | 57 | 0.9852041461893006 | -0.40 | -6.200483422574921 |
| 1.8 | 103 | 48 | 1.0523833739944541 | 1.47 | -4.814705425605284 |
| 2.0 | 103 | 44 | 1.236908909482352 | 6.46 | -4.416413991052531 |
| 2.2 | 103 | 43 | 1.0383364104007655 | 1.16 | -5.117393152292329 |
| 2.4 | 103 | 40 | 1.128804312750465 | 3.91 | -4.985686449778436 |

**Classification: STABLE** — PF>1 in 80% of the neighbourhood (PF range 0.99–1.24).

## Interpretation rules

- **STABLE**: PF>1 across ≥80% of the neighbourhood — performance is not a knife-edge.
- **CLIFF/UNSTABLE**: PF>1 in ≤40% — overfitting risk HIGH; do not trade.
- **MIXED**: between the two — treat with suspicion; examine which side of the cliff.
- Small trade counts make PF itself high-variance: always read with sample-size warnings.

## Overfitting-risk notes

- These sweeps vary ONE parameter at a time on a single test segment; they measure local robustness, not global validity.
- Walk-forward (§11) and bootstrap CIs (§9) are the primary validity evidence; this report is a necessary secondary check.