# XAU_AI_Trader_v1.4 — RELEASE NOTES (production candidate)

Date: 2026-10-05 · Base: `XAU_AI_Trader_v1.3_phase67_fixed2.zip`
Inputs honoured: `DEEP_AUDIT.md` + `MASTER_UPGRADE_PROMPT` (§0–§62) + `UPGRADE_CHECKLIST.json`

## 1. Files changed (source)

| File | Change |
|---|---|
| `scripts/download_mt5_data.py` | **Full rewrite (Downloader v2)** — fixes P0.1 broken loop (`out.to_parquet(f)` NameError); chunked `copy_rates_range` with per-TF adaptive sizes, 1-bar overlap, timestamp dedupe, deterministic sort; stop on target-start (not fixed rounds); atomic parquet write (`os.replace`); refuses overwrite without `--overwrite` (archives old file); central `data/raw/broker_manifest.json` (schema v2, sha256 per file, `time_semantics`, account login REDACTED); server→UTC offset REQUIRED (`--server-utc-offset-hours` or `--detect-server-offset` via fresh-quote inference, contradiction → refuse) |
| `app/data/mt5/provider.py` | symbols_select→`symbol_select(sym,True)` (Market-Watch `_ensure_selected` guard, once per symbol); **execution layer rewritten**: central retcode policy, `order_check` gate before every send, filling mode chosen from broker bitmask, spread-aware deviation (`mt5.deviation_points` config override), broker-native `order_calc_profit`/`order_calc_margin`, `AMBIGUOUS` outcome → `AmbiguousOrderError` (never blind-retried), RETRYABLE requotes refresh price; `supports_real_execution` now a dynamic, fail-closed capability (Windows+connected+trade_allowed+trade_expert+explicit `allow_live_execution`) |
| `app/data/mt5/historical.py` | symbols_select → `symbol_select(sym, True)` |
| `app/execution/mt5_retcodes.py` | **NEW** — single source of truth: retcode→{SUCCESS, SUCCESS_PARTIAL, RETRYABLE, AMBIGUOUS, FATAL}, named values (`RETCODE_DONE`…), `choose_filling_mode(bitmask)` |
| `app/execution/paper.py` | raw `10009` → `rc.RETCODE_DONE` |
| `app/risk/kill_switch.py` | **fail-closed rewrite**: corrupt/unreadable state → ENGAGED (`STATE_CORRUPT`, persisted, never auto-resets); atomic persist; persist failure → trading blocked (`KILL_SWITCH_STATE_PERSIST_FAILED`); `check()` collects ALL simultaneous triggers; auto-reset stays default OFF |
| `app/risk/open_risk.py` | **NEW** — `OpenRiskCalculator`: real open risk from provider positions (SL-distance × tick math per symbol); position without SL or unknown specs → risk UNKNOWN (fail-closed) |
| `app/risk/engine.py` | `open_risk_percent=None` → rejection `OPEN_RISK_UNKNOWN` (the old default-0.0 bypass is gone); MAX_OPEN_RISK gate unchanged otherwise |
| `app/trader.py` | wires `OpenRiskCalculator` into the runtime evaluate() call |
| `app/models/dataset.py` | **StandardScaler crash fixed** (`mean_/scale_` vs Robust `center_/scale_`; old code crashed for `scaler: standard`); scaler state versioned (`schema_version: 2`); unknown kind → ValueError |
| `app/models/leakage.py` | dead `if False else` branches removed (L106–107) |
| `app/config/schema.py` | + `mt5.deviation_points`, + `execution.demo_send_enabled` (default false), + `risk.ai_can_change_{risk,lot,sl,tp}` + `ai_can_override_risk` (all default false — AI-proofing explicit) |
| `main.py` | **mode redesign (§54)**: `--mode paper` (default) / `mt5-readonly` (read-only broker validation) / `mt5-demo` (redirects to demo script) / `mt5-live` and legacy `live` → **HARD REFUSED** with guidance; provider built with `allow_live_execution=False` always |
| `scripts/mt5_demo_execution_test.py` | **§24 rewrite**: official `symbol_select`, broker-reality request (bitmask filling, spread-aware deviation, stops_level-aware distances), mandatory `order_check` step, **double-gated send** (`--send` AND `MT5_DEMO_SEND=1`; default = safe DRY RUN through order_check), retcode-policy classification, login redacted in report, AMBIGUOUS → halt without retry |

## 2. Tests

Added `tests/test_v14_safety.py` (17) + `tests/test_v14_downloader.py` (5):

- fake-MT5 contract: `symbol_select(sym, True)` ordering before `order_check`→`order_send`; filling from bitmask; spread-aware deviation
- AMBIGUOUS (None) → `AmbiguousOrderError` with **exactly one** order_send call (no duplicate risk); REQUOTE retries with refreshed price; FATAL stops deterministically
- broker-native calc wrappers; dynamic `supports_real_execution` flag matrix
- open risk: 0.5 lot, 10 USD SL → 5.0% → `MAX_OPEN_RISK` rejection; no-SL position → `OPEN_RISK_UNKNOWN`
- kill switch: corrupt state engages + survives restart; persist failure blocks; all simultaneous triggers collected; STATE_CORRUPT never auto-resets
- scaler: standard == sklearn transform (regression for the crash), robust == sklearn, versioned state, unknown kind raises
- downloader logic: chunk overlap dedupe + deterministic sort + target-start stop; short history returned honestly (no fabrication); overwrite refusal; archive-on-overwrite; offset-detection sanity

**Results (this environment):** `python -m compileall -q .` → 0 errors; `pytest -q -W error::FutureWarning` → **203 passed, 0 failed, 0 warnings** (181 pre-existing + 22 new; the 1 pre-existing skip unchanged).

## 3. Windows/MT5 tests actually executed here

**None — NOT_RUN (honest).** This environment has no Windows/MT5 terminal. Everything broker-touching is covered by contract tests against a deterministic fake-MT5 and must be re-validated on your machine.

## 4. Remaining limitations (no sugar-coating)

1. `optimize.py` from the audit does **not exist** in the repo — that P0 claim could not be actioned (NOT_APPLICABLE).
2. Purged CV is enforced for audits but not yet a true nested walk-forward hyperparameter **selection** loop (§26/§27 = PARTIAL).
3. Label semantics still barrier-from-`close_t` with next-open execution (§32 PARTIAL) — changing it requires full retrain + fresh null-model audit.
4. No broker session calendar is invented (§35/§39) — supply broker session config; until then session labels stay honest-unknown.
5. The audit's UTC claim (§6/P0.3 "MT5 returns UTC") is **disputed with evidence** (rollover at 02:00 label = 00:00 UTC seen through a UTC+2 server clock); the implemented contract requires an explicit/validated server offset instead of silently keeping or dropping shifts — see `reports/V1_4_DEEP_AUDIT_REVIEW.md` §2.
6. EDGE_NOT_ESTABLISHED remains the standing research verdict; nothing in v1.4 changes trading behaviour (all safety defaults off).

## 5. Exact commands to reproduce / validate

```powershell
# on Windows, inside the extracted project folder
python -m compileall -q .
python -m pytest -q

# 1) detect server offset (market open!) then download 1000-bar smoke sets
python scripts/download_mt5_data.py --symbol XAUUSD.ecn --timeframes M1 M5 M15 H1 D1 `
    --bars-per-tf 1000 --detect-server-offset
# 2) quality gate, then 10000 bars, then extend only if terminal allows
python scripts/broker_data_quality.py --symbol XAUUSD.ecn

# 3) demo execution — DRY RUN first (no order leaves the terminal)
python scripts/mt5_demo_execution_test.py --symbol XAUUSD.ecn
#    real demo order only when you intend it (DEMO account + both gates):
#    set MT5_DEMO_SEND=1 and add --send

# 4) runtime loop (paper; live hard-refuses)
python main.py --mode paper --once
python main.py --mode mt5-readonly      # read-only broker plumbing check
python main.py --mode mt5-live          # → HARD REFUSED (expected)
```
