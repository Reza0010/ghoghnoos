# DRIFT ANALYSIS (PHASE 66 §23)

_Generated: 2026-10-02T03:27:57.501830+00:00 — REAL GC=F dataset, reference = first 60% (2026-07-27 08:30:00+00:00 → 2026-09-03 09:45:00+00:00), current = last 40% (2026-09-03 10:00:00+00:00 → 2026-10-01 19:00:00+00:00)_

## Verdicts

| phenomenon | verdict | evidence |
|---|---|---|
| DATA_DRIFT | **WARNING** | 25% of features above warning PSI |
| CONCEPT_DRIFT | **PRESENT** | label base-rate shift {"-1": 0.0232, "0": 0.0217, "1": -0.0449}; simple-rule accuracy 0.543 → 0.436 |
| MARKET_REGIME_CHANGE | see table below | volatility & ADX mix |

## Top drifted features (PSI / KS)

| feature | PSI | KS |
|---|---|---|
| d1_slope | 8.4364 | 0.7128 |
| d1_trend | 7.6495 | 0.4563 |
| d1_adx | 7.5045 | 0.8431 |
| d1_di_diff | 7.4904 | 0.6415 |
| d1_rsi | 7.4869 | 0.6733 |
| d1_ret | 7.0769 | 0.6456 |
| d1_atr_pct | 6.7924 | 0.7486 |
| pwh_norm | 5.9051 | 0.6219 |
| pwl_norm | 5.2144 | 0.5045 |
| h1_trend | 2.9708 | 0.3975 |
| dist_fvg_bull_norm | 1.4983 | 0.2961 |
| ema200_slope | 0.7778 | 0.3178 |
| ema200_dist | 0.7698 | 0.3131 |
| dist_fvg_bear_norm | 0.5403 | 0.2365 |
| h1_rsi | 0.4292 | 0.2117 |

## Drifted feature families

| family | features | ACTION-level | WARNING-level | max PSI |
|---|---|---|---|---|
| d1 | 7 | 7 | 0 | 8.436 |
| other | 25 | 4 | 5 | 5.905 |
| h1 | 7 | 4 | 1 | 2.971 |
| ema | 10 | 4 | 2 | 0.778 |
| macd | 2 | 0 | 1 | 0.134 |
| adx | 1 | 0 | 1 | 0.124 |
| di | 1 | 0 | 0 | 0.097 |
| rsi | 2 | 0 | 0 | 0.066 |
| vol | 2 | 0 | 0 | 0.053 |
| bb | 2 | 0 | 0 | 0.042 |
| stoch | 2 | 0 | 0 | 0.035 |
| atr | 3 | 0 | 0 | 0.027 |
| ret | 4 | 0 | 0 | 0.026 |
| range | 2 | 0 | 0 | 0.008 |
| session | 4 | 0 | 0 | 0.0 |

## Regime / volatility shift

| window | ATR% mean | ATR% p90 | ADX mean | trending share |
|---|---|---|---|---|
| reference(first 60%) | 0.002 | 0.0027 | 27.1259 | 0.4983 |
| current(rest) | 0.002 | 0.0027 | 24.9002 | 0.3877 |

## Interpretation & required human decision

- The largest PSI values concentrate in **daily/H1 trend features** (d1_adx, d1_rsi, d1_slope, ema200_*) — consistent with a directional market phase change rather than a data-pipeline fault.
- DATA_DRIFT with stable label base-rate would indicate pure distribution move: here the base-rate shift is {"-1": 0.0232, "0": 0.0217, "1": -0.0449} → both DATA and CONCEPT dimensions moved.
- **NO automatic retraining has been triggered or permitted (§25).** Required human decision: collect more data / schedule a supervised revalidation with new walk-forward + leakage audit, or accept reduced performance in the new regime.
- SAFE MODE policy: while drift ACTION-level features dominate, the fail-safe matrix keeps the system in NO_NEW_TRADE for live/paper-realtime operation.