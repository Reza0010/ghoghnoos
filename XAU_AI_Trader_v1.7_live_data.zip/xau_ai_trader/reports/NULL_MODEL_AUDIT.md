# PHASE 67 §9/§10/§11 — NULL MODEL AUDIT

Generated (UTC): 2026-10-02T06:20:37.203656+00:00
**Data**: REAL public COMEX gold futures (GC=F) research proxy — NOT broker XAUUSD, NOT synthetic
**Test window**: 2026-09-20 23:00 → 2026-10-01 19:00 (M15 bars, chronological 60/20/20 split, purge+embargo; leakage audit PASS)
**Costs applied identically everywhere**: spread=0.3 (documented assumption — no broker spread column), slippage=5.0 pts, commission=7.0/lot, swap L-8.0/S-2.0

> This report NEVER claims broker XAUUSD evidence. The broker-data
> portion of Phase 67 is stopped at §1 (no Windows/MT5 on this host).

## 1. Observed strategy (what the null is compared against)

| metric | value |
|---|---|
| variant | ML_SMC_REGIME (Phase 66 primary, relaxed evaluation gate) |
| trades | 44 (3 long / 41 short) — **LOW_STATISTICAL_POWER** |
| profit factor | 1.237 |
| expectancy (gross) | 6.46 |
| net profit | 284.17 (2.84%) |
| max drawdown | -3.68% |
| Sharpe (daily) | 2.54 |
| bootstrap PF CI95 | 0.638 – 2.267 |
| bootstrap expectancy CI95 | -12.22 – 25.98 |
| P(PF ≤ 1) | 0.2531 |
| P(expectancy ≤ 0) | 0.2531 |
| bootstrap verdict | **EDGE_NOT_ESTABLISHED** (95% expectancy CI includes zero ; 95% PF CI lower bound <= 1) |
| Monte Carlo (10k sequences) worst DD | -7.73% |
| Phase 66 cross-check | consistent=True (P66 PF 1.236908909482352) |

## 2. Simulator validation (prerequisite for the null)

The null model must use the SAME exit machinery as the real backtester. Both simulator implementations were compared to `app/backtest/engine.Backtester` on the observed signals:

| implementation | trades matched | max |Δpnl| | status |
|---|---|---|---|
| vectorised | 44 | 0.00e+00 | VALIDATED |
| reference_loop | 44 | 0.00e+00 | VALIDATED |

## 3. Phase 66 random-baseline diagnosis (the p95 PF ≈ 3.15 mystery)

Phase 66 reported `random baseline p95 PF ≈ 3.15` and no variant cleared it. Investigation:

- The Phase 66 RANDOM baseline frequency-matched the ML gate (skip 98.5% of bars) → **median 2 trades per seed**.
- On 1–4 trades, PF = (sum of wins)/(sum of losses) is a ratio of two coin-flip outcomes: the sampling distribution is extremely heavy-tailed and its 95th percentile is huge, regardless of any strategy quality.
- A PF benchmark computed at n≈2 can never be cleared by an n=44 strategy with PF≈1.24 — the comparison was sample-size-mismatched, **a small-sample artifact, not evidence of or against an edge**.
- The Phase 67 null conditions on the strategy's ACTUAL trade count and long/short mix, which is the comparison §9 demands.

## 4. Null model results

10,000 simulations per family. Families:

| family | entry times | sides |
|---|---|---|
| N1_TIMING_NULL | uniform random (i.i.d.) | exact permutation of observed 3L/41S multiset |
| N2_TIMING_DIRECTION_NULL | uniform random (i.i.d.) | i.i.d. 50/50 coin flip |
| N3_DIRECTION_NULL | observed timestamps | permuted sides (3L/41S preserved) |
| N4_TIMING_SHIFT_NULL | observed timestamps shifted ±12h | observed sides unchanged |

**Methodology — independent per-trade simulation.** The observed strategy occupies ~99% of the test window in trade time (44 trades × mean 3.95h ≈ 174h of a 175.5h bar-span) — it is almost always in a position. A one-position-at-a-time renewal null with uniformly drawn entries cannot reproduce 44 trades in-window (uniform draws sprinkle entries across the remaining range and strand the tail; early probes achieved a median of ~4 trades), and conditioning on feasibility would smuggle the strategy's own near-continuous re-entry timing INTO the null. Each null trade is instead simulated alone in the window (bit-identical to the engine for one-position portfolios — validated in §2), so every simulation carries EXACTLY 44 trades by construction. All families preserve trade count, spread, commission, slippage, swap, risk-percent sizing, ATR-SL / minRR-TP rules and the SL-first both-hit assumption. No future information is used in any draw.

### Null PF distributions vs observed PF (1.237)

| family | null PF p50 / p95 / p99 | null expectancy p50 | null ret% p50 | null maxDD% p50 | exact-N rate |
|---|---|---|---|---|---|
| N1_TIMING_NULL | 0.959 / 1.627 / 2.008 (inf 0.0%) | -1.22 | -0.54% | -5.24% | 100.0% |
| N2_TIMING_DIRECTION_NULL | 0.932 / 1.555 / 1.897 (inf 0.0%) | -2.05 | -0.90% | -4.36% | 100.0% |
| N3_DIRECTION_NULL | 1.044 / 1.287 / 1.399 (inf 0.0%) | 1.27 | 0.56% | -4.24% | 100.0% |
| N4_TIMING_SHIFT_NULL | 1.073 / 1.690 / 2.047 (inf 0.0%) | 2.07 | 0.91% | -4.43% | 100.0% |

### Holding-time divergence (a first-class finding)

- Observed strategy mean holding: **15.8 bars (15-min)**.
- Null mean holdings: N1 TIMING NULL: 8 bars; N2 TIMING DIRECTION NULL: 8 bars; N3 DIRECTION NULL: 6 bars; N4 TIMING SHIFT NULL: 7 bars;
- Interpretation: the divergence (in whichever direction it falls) is itself evidence about entry-timing selection. It is NOT sufficient for an edge — the PF/expectancy p-values below decide that — but it is reported transparently because holding-time behaviour feeds back into cost exposure and swap.


### Empirical p-values (Davison–Hinkley)

| family | P(null PF ≥ obs) | P(null exp ≥ obs) | P(null return ≥ obs) | P(null Sharpe ≥ obs) | separated? |
|---|---|---|---|---|---|
| N1_TIMING_NULL | 0.2159 | 0.2162 | 0.2162 | 0.0001 | NO |
| N2_TIMING_DIRECTION_NULL | 0.1869 | 0.1858 | 0.1858 | 0.0001 | NO |
| N3_DIRECTION_NULL | 0.1219 | 0.1207 | 0.1207 | 0.0001 | NO |
| N4_TIMING_SHIFT_NULL | 0.3108 | 0.3109 | 0.3109 | 0.0001 | NO |

### §9 verdict: **EDGE_NOT_ESTABLISHED**

Rule: EDGE requires p_pf<0.05 AND p_expectancy<0.05 AND observed PF > null PF p95 in EVERY family — otherwise EDGE_NOT_ESTABLISHED (§9)

Interpretation: the observed PF does not separate from the trade-count-conditioned chance distribution. With 44 trades (LOW_STATISTICAL_POWER) and bootstrap PF CI95 covering values below 1, the null model CONFIRMS the Phase 66 classification:
**EDGE_NOT_ESTABLISHED** — not because the strategy is proven bad, but because the evidence cannot exclude chance.

## 5. §10 Bootstrap (10,000 resamples)

- PF CI95: 0.638 – 2.267 (median 1.239)
- Expectancy CI95: -12.22 – 25.98
- Total-return CI95: -537.48 – 1143.23
- Drawdown distribution: p50 -3.20% / p95 -1.70% / p99 -1.32% / worst -15.09%
- **P(PF ≤ 1) = 0.2531**
- **P(expectancy ≤ 0) = 0.2531**
- Verdict: **EDGE_NOT_ESTABLISHED** — negative intervals are reported, never hidden.

## 6. §11 Cost sensitivity (identical signals, costs scaled)

| scenario | spread× | slippage× | trades | PF | expectancy | net | MaxDD% |
|---|---|---|---|---|---|---|---|
| BASE | 1.0 | 1.0 | 44 | 1.237 | 6.46 | 284.17 | -4.42 |
| 1.25x_spread | 1.25 | 1.0 | 44 | 1.123 | 3.48 | 153.16 | -4.48 |
| 1.5x_spread | 1.5 | 1.0 | 44 | 1.118 | 3.34 | 146.82 | -4.50 |
| 2x_spread | 2.0 | 1.0 | 45 | 0.959 | -1.24 | -55.58 | -4.62 |
| 3x_spread | 3.0 | 1.0 | 45 | 0.839 | -5.10 | -229.52 | -5.50 |
| 1.5x_slippage | 1.0 | 1.5 | 44 | 1.233 | 6.36 | 280.02 | -4.43 |
| 2x_slippage | 1.0 | 2.0 | 44 | 1.229 | 6.27 | 275.87 | -4.44 |
| 3x_slippage | 1.0 | 3.0 | 44 | 1.221 | 6.08 | 267.57 | -4.46 |

- Breakpoint: PF ≤ 1 at **spread ×2.0**, slippage ×> 3.
- Verdict: **EXECUTION_FRAGILE** — a small cost deterioration destroys the statistical characteristics.

## 7. Reproduce

```
python scripts/phase67_null_model_audit.py [--config config_real.yaml] [--null-sims 10000]
```

Seeds are fixed → outputs are reproducible bit-for-bit.
