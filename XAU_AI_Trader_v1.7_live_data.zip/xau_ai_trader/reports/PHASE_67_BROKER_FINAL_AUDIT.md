> ⚠️ **SUPERSEDED (v1.5, 2026-10-08T11:45:40+00:00)** — this artifact was generated on the
> pre-MT5 host from template state and contradicts newer evidence in this
> repository. The authoritative documents are `BROKER_DATA_QUALITY.md`
> (BROKER_DATA_PRESENT, verdict FAIL on H1 spread), `GC_F_vs_BROKER_XAUUSD.md`
> (COMPARED, corr 0.978) and `RELEASE_MANIFEST.json` (v1.5). Retained for
> audit-trail honesty only — do NOT cite as current state.

# PHASE 67 — BROKER-REAL VALIDATION & NULL-MODEL AUDIT — FINAL REPORT

Generated (UTC): 2026-10-04T06:57:41.801786+00:00  
Directive: PHASE 67 §23 (24-section final audit)  
Phase 66 inherited verdict: EDGE_NOT_ESTABLISHED  
LIVE_TRADING_ENABLED: **false** (verified)  
Test suite: **181/181 passed** (pytest, this commit)

> Purpose of Phase 67 is EVIDENCE, not performance cosmetics. Every
> section below states its data kind honestly: [GC=F] research proxy,
> [BROKER-PENDING] blocked by §1, or measured facts about the host.

## 1. Environment

| item | required | observed | status |
|---|---|---|---|
| windows | Windows | Windows-10-10.0.19045-SP0 | OK |
| python | 3.10+ | 3.13.7 | OK |
| mt5_package | installed | installed | OK |
| mt5_terminal | running terminal | connected (build 25 Sep 2026) | OK |
| terminal_build | recorded | (500, 6230, '25 Sep 2026') | OK |
| broker | recorded | OtetGroup-MT5 | OK |
| server | recorded | OtetGroup-MT5 | OK |
| account | recorded | 520299 | OK |
| demo_live_status | DEMO for any execution test | trade_mode=2 | OK |
| terminal_connection | connected to broker | True | OK |

**§1 decision:** PROCEED

## 2. Broker  |  ## 3. Symbol

- Broker connection: **NONE** — STOPPED at §1 — this host is Linux without MetaTrader 5. Nothing simulated; GC=F never renamed XAUUSD.
- Requested symbol: `XAUUSD`; no broker symbol record exists.
- The ONLY instrument on disk is **GC (COMEX gold futures, GC=F)**, downloaded from public sources, labelled `REAL_GC_F_PROXY_NOT_BROKER` in every artifact.
- Broker provenance capture (digits/point/tick value/contract size/volume rules/stops level/freeze level/spread/swap/margin mode/filling mode/MT5 build/server/account) is IMPLEMENTED in `scripts/download_mt5_data.py` + `app/data/mt5/historical.py` and unit-tested; it has never executed against a real terminal.

## 4. Dataset [GC=F]

| timeframe | bars available | directive target | met? |
|---|---|---|---|
| M1 | 0 | 100,000 | NO |
| M5 | 0 | 50,000 | NO |
| M15 | 4,548 | 20,000 | NO |
| H1 | 13,731 | 5,000 | YES |

- Range: M15 2026-07-23→2026-10-01; H1 2024-05-09→2026-10-01; D1 2000-08-30→2026-10-01 (UTC).
- **INSUFFICIENT_DATA** vs M1/M5/M15 targets — every statistical conclusion below is bounded by this.
- Broker XAUUSD download: [BROKER-PENDING] — §3 tooling ready with SHA-256 immutability evidence.

## 5. Data quality

- Broker XAUUSD quality: **BROKER_DATA_PENDING** — tooling implemented (`app/data/quality_suite.py`: duplicates, missing bars, invalid OHLC, impossible prices, abnormal jumps, incomplete bars, timezone, session/weekend/holiday gaps, abnormal spread, stale data). Nothing repaired silently.
- GC=F datasets scored 100/PASS in Phase 65 with session breaks classified as structure (CME maintenance/holidays), not missing data.
- See `reports/BROKER_XAUUSD_DATA_QUALITY.md`.

## 6. Broker vs GC=F comparison

- Status: **COMPARISON_PENDING** — one side of the comparison does not exist. Standing rule recorded: the two instruments are NEVER treated as interchangeable (price basis, sessions, tick math, spread formation all differ).
- See `reports/BROKER_VS_GCF.md`.

## 7. Feature audit  |  ## 8. Leakage

- Features rebuilt directly from GC=F (798 test rows of 4114); feature version hash `3cdfd3d5384c…`.
- Broker feature rebuild: [BROKER-PENDING] — §6 will re-run `build_xy` on broker parquet+meta the moment they exist; no GC=F feature values are ever reused for broker claims.
- Leakage audit (Phase 67 rebuild): **PASS** — strict chronological 60/20/20 split, purge+embargo, no shuffle.
- Split ranges: TRAIN 2026-07-27 08:30→2026-09-02 16:45 (2519), VAL 2026-09-03 10:00→2026-09-17 12:45 (797), TEST 2026-09-20 23:00→2026-10-01 19:00 (798) — M15 bars.

## 9. ML (unchanged architectures)

- LightGBM test accuracy 0.465 | XGBoost 0.466 — 3-class, GC=F test segment [GC=F]. No OOS predictive power is claimed (acc ≈ chance).
- Phase 67 rebuild reproduced the Phase 66 evaluation EXACTLY: 44 trades / PF 1.237 (cross-check consistent=True).
- Architecture changes (RL/DL/Transformer/LSTM): **NONE** — directive prohibition respected.

## 10. Walk-forward [GC=F]

- 7 rolling folds, 2800 OOS predictions, aggregate OOS accuracy 0.538. Fold-level results are in `reports/phase66_audit.json` (§11) — fold PF ranged 0.31–1.61 (materially inconsistent).
- Broker walk-forward (≥5 folds on broker data): [BROKER-PENDING].

## 11. NULL MODEL AUDIT (§9 — mandatory)

- Data: REAL public COMEX gold futures (GC=F) research proxy — NOT broker XAUUSD, NOT synthetic [GC=F].  
- Observed: ML_SMC_REGIME, 44 trades (3 long / 41 short), test window 2026-09-20 23:00→2026-10-01 19:00, PF 1.237, expectancy 6.46.  
- Simulator validation: vectorised: 44 trades, max|dpnl|=0.0e+00, reference_loop: 44 trades, max|dpnl|=0.0e+00 — bit-identical to the production backtester.  
- 10,000 simulations × 4 families, every sim carrying EXACTLY 44 trades, identical costs/sizing/exits, no future information.

| family | null PF p50 | p95 | p99 | P(null PF ≥ obs) | separated? |
|---|---|---|---|---|---|
| N1_TIMING_NULL | 0.959 | 1.627 | 2.008 | 0.2159 | NO |
| N2_TIMING_DIRECTION_NULL | 0.932 | 1.555 | 1.897 | 0.1869 | NO |
| N3_DIRECTION_NULL | 1.044 | 1.287 | 1.399 | 0.1219 | NO |
| N4_TIMING_SHIFT_NULL | 1.073 | 1.690 | 2.047 | 0.3108 | NO |

**§9 verdict: EDGE_NOT_ESTABLISHED** — the observed PF does not separate from any null family. The Phase 66 `p95 PF ≈ 3.15` random baseline is explained as a small-sample artifact (median 2 trades/seed → heavy-tailed PF); the trade-count-conditioned null gives the correct chance benchmark (p95 1.29–1.69).

## 12. Bootstrap (10,000 resamples) [GC=F]

- PF CI95: 0.638 – 2.267 (median 1.239)
- Expectancy CI95: -12.22 – 25.98
- Total-return CI95: -537.48 – 1143.23
- Drawdown distribution: p50 -3.20% / p95 -1.70% / p99 -1.32% / worst -15.09%
- **P(PF ≤ 1) = 0.2531**; **P(expectancy ≤ 0) = 0.2531** — negative intervals reported, never hidden.
- Verdict: **EDGE_NOT_ESTABLISHED**

## 13. Monte Carlo (10,000 trade-sequence runs) [GC=F]

- Worst DD -7.73% | DD p95 -4.99% | DD p99 -5.92% | max losing streak 17 (p95 10) | risk of ruin 0.0% (equity −20% definition).

## 14. Parameter stability [GC=F]

- `min_ml_confidence`: STABLE — PF>1 in 100% of the ±10/±20% neighbourhood (no best-point selection).
- `atr_sl_mult`: STABLE — PF>1 in 100% of the ±10/±20% neighbourhood (no best-point selection).
- `min_rr`: STABLE — PF>1 in 80% of the ±10/±20% neighbourhood (no best-point selection).
- Broker parameter stability: [BROKER-PENDING].

## 15. Cost sensitivity [GC=F]

| scenario | spread× | slippage× | trades | PF | net |
|---|---|---|---|---|---|
| BASE | 1.0 | 1.0 | 44 | 1.237 | 284.17 |
| 1.25x_spread | 1.25 | 1.0 | 44 | 1.123 | 153.16 |
| 1.5x_spread | 1.5 | 1.0 | 44 | 1.118 | 146.82 |
| 2x_spread | 2.0 | 1.0 | 45 | 0.959 | -55.58 |
| 3x_spread | 3.0 | 1.0 | 45 | 0.839 | -229.52 |
| 1.5x_slippage | 1.0 | 1.5 | 44 | 1.233 | 280.02 |
| 2x_slippage | 1.0 | 2.0 | 44 | 1.229 | 275.87 |
| 3x_slippage | 1.0 | 3.0 | 44 | 1.221 | 267.57 |

- Breakpoint: PF ≤ 1 at spread ×2.0, slippage ×>3.
- Verdict: **EXECUTION_FRAGILE** — even the BASE result uses a documented assumed spread (GC=F has no broker spread column); the broker spread on XAUUSD is a different regime entirely.

## 16. AI ablation  |  ## 17. AI repeatability

AI ablation on broker data: [BROKER-PENDING] — never run here. Historical GC=F ablation (Phase 65/66, cited separately, NOT merged with any broker evidence):

| variant | trades | PF | expectancy |
|---|---|---|---|
| ML_ONLY | 45 | 1.54 | 13.38 |
| ML_SMC | 33 | 1.27 | 7.13 |
| ML_SMC_REGIME | 33 | 1.27 | 7.13 |
| +AI | 4 | 5.71 | 54.65 |

- AI is hard-constrained to validate/reject/contextualise/WAIT — it can never modify lot, max risk, SL, TP, daily-loss or DD limits (`app/ai/gate.py`, risk engine remains authoritative).
- §14 rate limiting implemented this phase: exponential backoff, pacing, retry limit, per-provider circuit breaker, request journal; unit-tested (`tests/test_phase67_audit.py`); AI unavailable ⇒ WAIT.
- Repeatability: Phase 66 evidence **PARTIAL_RATE_LIMITED** (100 calls: 30 valid / 70 × 429; Phase 65 100-state run valid-rate 1.0 — historical evidence, kept separately identified). Broker-derived-state repeatability: NOT RUN (no broker states).

## 18. News

- **NEWS_NOT_VALIDATED** — no real news provider is available; `MockNews` is never used as evidence. `app/news/real_provider.py` defines the contract (source, timestamp, currency, event, impact, forecast, previous, actual) for future integration. All evaluations assume NEWS-NEUTRAL and say so.

## 19. Paper replay [GC=F]

- Phase 66 fresh run: 202 bars replayed online — 202 WAIT / 0 fills (conservative gates correctly produce WAIT-first).
- Phase 65 comparative run: 352 bars, paper 91.12 vs backtest 91.40 (|Δ| = 0.28, within disclosed tolerance) — engine consistency demonstrated on GC=F.
- Broker realtime paper replay: [BROKER-PENDING] — `app/execution/realtime_paper.py` is structurally incapable of sending orders and journals every decision (timestamp, bid/ask, spread, features, regime, ML/SMC/AI decisions, risk decision, final decision, WAIT reason, latency).

## 20. MT5 demo execution  |  ## 21. Broker reconciliation

- Demo execution: **NOT_RUN** — requires Windows + MT5 terminal + DEMO account (platform=Linux). The 15-step checklist is implemented below and runs unm
- The 15-step checklist is implemented (`scripts/mt5_demo_execution_test.py`): connection, demo detection (refuses `trade_mode != 0` — NO override exists), symbol/spec/bid-ask/spread/volume checks, order request/placement/ticket/position, SL/TP verification, journal consistency, reconciliation, safe close. Every order DEMO-only.
- Reconciliation tooling `app/execution/reconciliation.py` detects orphan/missing positions, volume/SL/TP mismatch, stale state, duplicate orders → any mismatch ⇒ HALT. Live reconciliation: NOT RUN.

## 22. Drift [GC=F]

- DATA_DRIFT: **WARNING** (drift ratio 0.25; worst PSI 8.44 on `d1_slope` — D1/H1 trend families shifted).
- CONCEPT_DRIFT: **PRESENT** (rule accuracy 0.543 → 0.436).
- MARKET_REGIME_CHANGE: documented (ATR/vol structure shift between reference and current windows).
- **NO AUTO-RETRAIN** — human approval + new dataset + new validation + new WF + new leakage audit required (§25). Broker drift: [BROKER-PENDING].

## 23. Fail-safe matrix

- 18/18 failure scenarios automated-tested (MT5 disconnect, stale data, abnormal spread, invalid OHLC, missing/corrupt model, AI invalid JSON/timeout/429, news failure, journal/DB failure, risk/daily-loss/DD violations, duplicate orders, broker rejection, reconciliation mismatch) → expected NO NEW TRADE or HALT; `tests/test_phase66_audit.py` + `tests/test_phase67_audit.py`.
- §14 additions verified: AI 429 → retry/backoff → circuit breaker → failover → SAFE MODE (WAIT); journal records request/latency/status/retry count/final action per call.

## 24. Final classification

| status | value | basis |
|---|---|---|
| STATISTICAL_EDGE | **EDGE_NOT_ESTABLISHED** | §9 null p-values 0.12–0.31 (≫0.05); bootstrap P(PF≤1)=0.2531; 44-trade sample LOW_STATISTICAL_POWER [GC=F] |
| BROKER_DATA_VALIDATED | **no** | no broker dataset exists |
| Dataset | **INSUFFICIENT_DATA** | M1/M5/M15 targets unmet on GC=F; broker download pending |
| Execution (MT5 demo) | **EXECUTION_NOT_VALIDATED** | Windows/MT5 required |
| AI | AI_VALIDATED = **no** | repeatability PARTIAL_RATE_LIMITED; agreement-with-ML 0.26 has NO_SIGNIFICANT_SELECTION_VALUE |
| News | **NEWS_NOT_VALIDATED** | no real provider |
| Drift | **DRIFT_WARNING** | DATA_DRIFT WARNING + CONCEPT_DRIFT PRESENT — no auto-retrain |

### EDGE_ESTABLISHED gate (§22, all 10 conditions)

1. broker XAUUSD data used: **FAIL — no broker data**
2. chronological OOS validation exists: **PASS (GC=F only)**
3. sufficient trade sample: **FAIL — 44 trades**
4. bootstrap does not support PF≤1: **FAIL — P(PF≤1)=0.2531**
5. expectancy CI supports positive expectancy: **FAIL — CI includes zero**
6. null-model test supports non-random behaviour: **FAIL — p ≥ 0.12 in all families**
7. walk-forward not materially inconsistent: **FAIL — fold PF 0.31–1.61**
8. cost sensitivity does not destroy result: **FAIL — EXECUTION_FRAGILE at 2× spread**
9. parameter stability acceptable: **PARTIAL — MIXED/STABLE sweeps on GC=F**
10. execution assumptions documented: **PASS — assumed spread/slippage disclosed**

Conditions 1–10: the classification is **EDGE_NOT_ESTABLISHED**. No parameter was optimized to change this; the Phase 66 conclusion survives the proper null model unchanged.

---

### COMPLETED / NOT COMPLETED / BLOCKERS / NEXT ACTION

**COMPLETED:** §1 environment audit (honest STOP); §2 demo-safety verified (no override exists); §3 downloader upgraded to full immutable provenance (SHA-256); §4/§5 tooling + PENDING reports; §9 null model (40,000 sims, validated simulator, 4 families, Phase-66-artifact diagnosed); §10 bootstrap 10k; §11 extended cost grid; §14 rate limiter + journal + tests; §23 final audit; 181/181 tests; package `XAU_AI_Trader_v1.3_phase67.zip`.

**NOT COMPLETED (blocked by §1 — Windows/MT5/real data absent):** §3 broker download execution; §4/§5 broker quality & comparison execution; §6 broker feature rebuild; §7 broker model training; §8 broker walk-forward; §13 AI ablation on broker data; §15 repeatability on broker states; §17 broker paper replay; §18 MT5 demo execution; §19 live reconciliation; §20 realtime paper; §21 broker drift.

**BLOCKERS:** no Windows host; no MetaTrader 5 terminal/account (DEMO); no broker XAUUSD data; no real news API credentials; AI gateway saturation (429) limits high-rate repeatability runs.

**NEXT REQUIRED ACTION:** on a Windows machine with MT5 installed and a DEMO account: (1) `python scripts/phase67_environment_check.py` → expect PROCEED; (2) `python scripts/download_mt5_data.py --symbol XAUUSD`; (3) `python scripts/broker_data_quality.py`; (4) `python scripts/compare_gcf_xauusd.py`; (5) re-run `python scripts/phase67_null_model_audit.py --config config_broker.yaml`; (6) `python scripts/mt5_demo_execution_test.py`; (7) human review of `reports/PHASE_67_BROKER_FINAL_AUDIT.md` before any classification change.
