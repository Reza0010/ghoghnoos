> ⚠️ **SUPERSEDED (v1.5, 2026-10-08T11:45:40+00:00)** — this artifact was generated on the
> pre-MT5 host from template state and contradicts newer evidence in this
> repository. The authoritative documents are `BROKER_DATA_QUALITY.md`
> (BROKER_DATA_PRESENT, verdict FAIL on H1 spread), `GC_F_vs_BROKER_XAUUSD.md`
> (COMPARED, corr 0.978) and `RELEASE_MANIFEST.json` (v1.5). Retained for
> audit-trail honesty only — do NOT cite as current state.

# PHASE 67 §5 — BROKER XAUUSD vs GC=F COMPARISON

Generated (UTC): 2026-10-02T06:10:26.801467+00:00

**STATUS: COMPARISON_PENDING** — one side of the comparison (broker XAUUSD) does not exist on this host. Per §1 the broker-data portion is STOPPED. **The two instruments are NEVER treated as interchangeable.**

## Standing rule

GC=F is a COMEX gold FUTURES contract; broker XAUUSD is an OTC spot C FD. They differ in price basis (futures carry/contango), trading hours (CME sessions vs ~24×5 broker feed), tick size/valuation, volume meaning and spread formation. Any pipeline trained on GC=F and traded on XAUUSD inherits an UNQUANTIFIED basis risk until the comparison below is run on overlapping periods.

## What will run (tooling: scripts/compare_gcf_xauusd.py)

On overlapping periods only, the tool measures: close correlation, return correlation, ATR correlation, volatility ratio, session behaviour, candle alignment, price basis (level offset and drift), gap statistics and market-hours coverage.

Outputs `reports/gcf_vs_xauusd.json` with every metric timeframed, dated, sample-sized and method-labelled.

## Reproduce

```
# Windows (after §3 download):
python scripts/compare_gcf_xauusd.py --broker-symbol XAUUSD
```

## Interim statement (honest)

Until that run exists, ALL GC=F-derived statistics in this repo (Phase 65/66/67) are labelled `REAL_GC_F_PROXY_NOT_BROKER` and can only support research conclusions about METHODOLOGY — never claims about live broker XAUUSD behaviour.
