> ⚠️ **SUPERSEDED (v1.5, 2026-10-08T11:45:40+00:00)** — this artifact was generated on the
> pre-MT5 host from template state and contradicts newer evidence in this
> repository. The authoritative documents are `BROKER_DATA_QUALITY.md`
> (BROKER_DATA_PRESENT, verdict FAIL on H1 spread), `GC_F_vs_BROKER_XAUUSD.md`
> (COMPARED, corr 0.978) and `RELEASE_MANIFEST.json` (v1.5). Retained for
> audit-trail honesty only — do NOT cite as current state.

# PHASE 66 — FINAL AUDIT: BROKER-REAL VALIDATION & STATISTICAL EDGE

_Generated: 2026-10-02T04:41:30.910965+00:00 · LIVE_TRADING_ENABLED = false · objective: determine whether an edge exists — NOT manufacture one_

## Executive Summary

On the available REAL data (public COMEX GC=F futures, not broker XAUUSD), the primary strategy configuration (ML+SMC+regime) produced **44 trades, PF 1.24** over the OOS test segment — but the bootstrap 95% CI for expectancy includes zero and the PF CI lower bound is below 1, so the verdict is **EDGE_NOT_ESTABLISHED**. The result is also **EXECUTION_FRAGILE** (PF < 1 at 2× spread) and does NOT clear the random-signal baseline's 95th percentile PF. The ML model itself shows no OOS predictive power on the test segment (AUC 0.436). Broker XAUUSD validation, real news, and MT5 demo execution remain pending Windows/MT5 dependencies. NO PROFIT CLAIM is made anywhere in this audit.

## Broker Data

- Status: **BROKER_DATA_PENDING** — REAL COMEX GC=F futures — NOT broker XAUUSD (demonstration of the battery only)
- `MT5HistoricalProvider` implemented (§2): downloads XAUUSD M1/M5/M15/M30/H1/H4/D1 and captures every broker-specific field (digits, point, tick size/value, contract size, volume min/max/step, stops/freeze level, spread, swap long/short, server, account type, MT5 build, symbol description) verbatim into the metadata sidecar. Refuses to run on non-Windows — nothing is faked.
- Run on Windows: `python scripts/download_mt5_data.py --symbol XAUUSD`

## GC=F vs Broker XAUUSD

- Status: **PENDING_NO_BROKER_DATA** — see `reports/GC_F_vs_BROKER_XAUUSD.md`.
- Standing rule enforced: GC=F is NOT treated as broker XAUUSD; differences (basis, calendar, spread, tick size, timezone) are structural.

## Data Quality

- Battery status: **NOT_RUN** — report: `reports/BROKER_DATA_QUALITY.md`.
- The identical battery was demonstrated on REAL GC=F M15 (labelled as such): PASS with weekend/session breaks correctly NOT counted as missing data.

## Dataset Size (§5)

| TF | available | target | met |
|---|---|---|---|
| M1 | 0 | 100000 | **no** |
| M5 | 13615 | 50000 | **no** |
| M15 | 4548 | 20000 | **no** |
| H1 | 13731 | 5000 | yes |

- AVAILABLE real dataset does NOT meet directive targets for M1/M5/M15 (public-source intraday depth is limited). H1 exceeds its target. Broker XAUUSD download (Windows/MT5, §2) is the path to full-size data. NO data was fabricated; statistics below are marked with these limits.
- Statistical limitation: **INSUFFICIENT_DATA for M15-scale targets — all M15 conclusions are preliminary**

## Leakage Audit

- Verdict: **PASS** — strict chronological 60/20/20 split TRAIN ['2026-07-27 08:30', '2026-09-02 16:45'] · VAL ['2026-09-03 10:00', '2026-09-17 12:45'] · TEST ['2026-09-20 23:00', '2026-10-01 19:00']; purge+embargo 64 bars; point-in-time features; no shuffle anywhere.
  - split_purity_purge_embargo: PASS — 0 test samples inside purge/embargo zone after last train sample
  - split_purity_purge_embargo: PASS — 0 test samples inside purge/embargo zone after last train sample

## ML Performance (test segment, never seen in training)

- lgbm_test: acc 0.465 · AUC 0.436 · f1_macro 0.315
- xgb_test: acc 0.466 · AUC 0.623 · f1_macro 0.32

## Walk-Forward (§11)

- 7 rolling folds · OOS accuracy 0.538 over 2800 predictions (no future information; per-fold retraining; per-fold trading metrics use only that fold's OOS probabilities).

| fold | test period | acc | trades | PF | MaxDD % |
|---|---|---|---|---|---|
| 0 | 2026-08-18 00:15 → 2026-08-24 08:00 | 0.512 | 25 | 0.65 | -4.87 |
| 1 | 2026-08-21 18:45 → 2026-08-28 03:30 | 0.705 | 24 | 1.23 | -2.16 |
| 2 | 2026-08-27 14:15 → 2026-09-02 23:00 | 0.48 | 22 | 0.71 | -5.37 |
| 3 | 2026-09-02 09:45 → 2026-09-10 05:15 | 0.455 | 15 | 0.91 | -3.45 |
| 4 | 2026-09-09 16:00 → 2026-09-16 00:45 | 0.522 | 20 | 0.87 | -1.97 |
| 5 | 2026-09-15 11:30 → 2026-09-21 19:15 | 0.512 | 22 | 0.31 | -6.36 |
| 6 | 2026-09-21 07:00 → 2026-09-25 19:30 | 0.578 | 20 | 1.61 | -2.7 |

- Fold-level PF ranges 0.31–1.61: performance is NOT consistent across folds.

## Baseline Comparison (§7 — identical test window & costs)

| variant | trades | PF | expectancy | MaxDD % | sample warning | bootstrap verdict |
|---|---|---|---|---|---|---|
| A Buy&Hold (1 lot) | 1 | n/a | -17576.99 | -101.04 | single position | n/a |
| B Random (100 seeds) | 2.0 median | 0.0 median | -1.69 | — | — | P(PF>1)=0.33 |
| C ML only | 45 | 1.19 | 5.19 | -3.69 | LOW_STATISTICAL_POWER | EDGE_NOT_ESTABLISHED |
| D ML+technical | 26 | 0.88 | -3.6 | -2.83 | SAMPLE_TOO_SMALL | EDGE_NOT_ESTABLISHED |
| E ML+SMC | 44 | 1.24 | 6.46 | -3.68 | LOW_STATISTICAL_POWER | EDGE_NOT_ESTABLISHED |
| F ML+SMC+regime (primary) | 44 | 1.24 | 6.46 | -3.68 | LOW_STATISTICAL_POWER | EDGE_NOT_ESTABLISHED |

- **Random baseline 95th-percentile PF: 3.15** — none of the deterministic variants clears this chance threshold. P(random PF>1) = 0.33.
- Buy&Hold note: equity path truncated at first margin-call breach (2026-09-24 10:15:00+00:00); a real account would be liquidated there

## AI Ablation (§13)

- Phase 66 live re-run: **NOT_RUN** — --with-ai not passed or no credentials
- Phase 65 real-API ablation (same dataset, 70/15/15 split — cited as the AI-leg evidence):
  - ML_ONLY: trades 45 · PF 1.54 · DD -2.84%
  - ML_SMC: trades 33 · PF 1.27 · DD -3.56%
  - ML_SMC_REGIME: trades 33 · PF 1.27 · DD -3.56%
  - ML_SMC_REGIME_AI: trades 4 · PF 5.71 · DD -0.91%
  - +AI variant had 4 trades (PF 5.71) — **statistically meaningless at that sample size** (SAMPLE_TOO_SMALL); this is stated, not celebrated.
- AI improvement criteria (sample size + CIs + walk-forward + stability) are NOT met for any AI variant. AI is not claimed to improve the strategy.

## AI Agreement Analysis (§14)

- Agreement with ML: **0.26** across 77 real decisions; AI WAIT rate 0.74.
- Usefulness test: score(all ML) 0.766 vs score(AI-agreed only) 1.0 · Δ 0.234 · permutation p=0.113 → **NO_SIGNIFICANT_SELECTION_VALUE**
- Disagreement is **systematic, not random**: AI agrees with ML 46.7% when SMC aligns vs 0.128 when SMC conflicts; AI waits more in RANGING (87%) than TREND (67%). The 0.26 agreement rate reflects deliberate conservatism (mostly WAIT) plus SMC-conflict vetoes — NOT prompt instability.
- Agreement was NOT forced (WAIT is valid).

## AI Repeatability (§15)

- Single-send validity (Phase 65 real-API run): 100 states attempted, 77 valid decision records retained, valid rate **1.0**; repeat pairs in that run: same-side rate 1.0.
- Fresh multi-send (50 states × 2, cache disabled): 100 calls → 30 valid / 70 rate-limited (429); 15 completed pairs → action consistency **0.9333**
- Status: **PARTIAL_RATE_LIMITED** — gateway rate limits limited the fresh multi-send sample; the 429→degrade→WAIT behaviour itself was verified (§22).
- Safety rules: invalid JSON → WAIT · AI unavailable → WAIT · confidence below threshold → WAIT · numeric decision never depends on free-form reasoning.

## Statistical Significance (§9)

- Bootstrap: 10000 resamples of the primary variant's trades.
- PF 95% CI: (0.638, 2.267) · expectancy 95% CI: (-12.22, 25.98) · total-return CI: (-537.48, 1143.23) · MaxDD CI: (-7.53, -1.43)
- P(loss) = 0.2531 · P(PF≤1) = 0.2531
- Verdict: **EDGE_NOT_ESTABLISHED** — 95% expectancy CI includes zero; 95% PF CI lower bound <= 1

## Monte Carlo (§18)

- 10000 randomized trade-sequence runs (distribution preserved): worst DD -7.73% · 95th-pct DD -4.99% · 99th-pct DD -5.92% · max losing streak 17 · risk of ruin (−20%) 0.0%
- Used ONLY to understand downside uncertainty (§18).

## Parameter Stability (§12)

- Full tables: `reports/PARAMETER_STABILITY.md`.
- min_ml_confidence: **STABLE** (PF>1 in 100.0% of ±10/20% neighbourhood; PF range 1.24–1.24)
- atr_sl_mult: **STABLE** (PF>1 in 100.0% of ±10/20% neighbourhood; PF range 1.01–1.7)
- min_rr: **STABLE** (PF>1 in 80.0% of ±10/20% neighbourhood; PF range 0.99–1.24)
- No single-best-parameter search was performed (§12).

## Execution Cost Sensitivity (§17)

| scenario | trades | PF | net P/L |
|---|---|---|---|
| BASE | 44 | 1.24 | 284.17 |
| 1.5x_spread | 44 | 1.12 | 146.82 |
| 2x_spread | 45 | 0.96 | -55.58 |
| 2x_slippage | 44 | 1.23 | 275.87 |
| 3x_slippage | 44 | 1.22 | 267.57 |

- Verdict: **EXECUTION_FRAGILE** — profitability disappears at 2× spread (PF 0.96); the edge is not robust to modest execution deterioration.
- Cost assumptions (documented): spread 0.30 (assumed — futures dataset has no broker spread), slippage 5 pts, commission 7/lot, swap −8/−2 per lot.

## Paper Replay (§19)

- **Run A (Phase 65, 352 real M15 bars, 1 fill — engine-consistency evidence):**
  paper net P/L 91.12 vs backtest net P/L 91.4 → |Δ| = 0.28 — within tolerance max(1.0, 5% of |backtest|) = 4.57; difference stems from spread-fill timing at bar granularity (documented). PASS.
- **Run B (Phase 66, fresh 202-bar replay of the most recent window):** 202 decisions → 202 WAIT, 0 fills; paper vs backtest 0.00 vs 0.00 — identical (WAIT-first behaviour on the current regime; no divergence).
- Every decision — including all WAITs with reasons — is journaled (`reports/paper_replay_journal.jsonl`). No unexplained divergence (§19 blocker rule).

## MT5 Demo Status (§20)

- **NOT_RUN** — requires Windows + MT5 terminal + DEMO account (platform=Linux). The 15-step checklist is implemented below and runs unmodified on Windows. Nothing faked.
- 15-step checklist implemented (connection → account → demo detection → symbol → specs → bid/ask → spread → volume rules → request construction → placement → confirmation → reconciliation → SL/TP verification → journal consistency → safe closure); refuses non-demo accounts; LIVE_TRADING_ENABLED=false.

## News Status (§16)

- **NEWS_NOT_VALIDATED / NEWS_VALIDATION_PENDING** — no genuinely accessible real provider integrated; MockNews/static CSV are NOT substitutes (§16); live behaviour stays news-neutral/WAIT. RealNewsProvider contract (timestamp, event, currency, impact, previous, forecast, actual, source, URL, release time) is implemented.

## Drift Analysis (§23)

- DATA_DRIFT: **WARNING** — top drifted features: d1_slope (PSI 8.4364), d1_trend (PSI 7.6495), d1_adx (PSI 7.5045), d1_di_diff (PSI 7.4904), d1_rsi (PSI 7.4869)
- CONCEPT_DRIFT: **PRESENT** — label base-rate shift {"-1": 0.0232, "0": 0.0217, "1": -0.0449}; simple-rule accuracy 0.543 → 0.436
- MARKET_REGIME_CHANGE: volatility/ADX mix shift documented in `reports/DRIFT_ANALYSIS.md` (d1/H1 trend-feature families dominate).
- **No automatic retraining was triggered or permitted (§25)** — human review decision required; full report: `reports/DRIFT_ANALYSIS.md`.

## Fail-Safe Tests (§22)

- Automated matrix: **18/18 scenarios pass** — MT5 disconnect, stale data, abnormal spread, invalid OHLC, missing/corrupt model, invalid AI JSON, AI timeout/429, news failure, journal failure, database failure, risk-limit violation, daily-loss limit, max drawdown, duplicate order, broker rejection, reconciliation mismatch → each maps to NO_NEW_TRADE or HALT (`tests/test_phase66_audit.py`).
- Broker reconciliation (§21): orphan/missing/volume/price/SL/TP/stale detection implemented + tested; any mismatch → WAIT/HALT.

## Security Audit

- LIVE_TRADING_ENABLED=false in every config; no auto-retrain path (guarded by `assert_no_auto_retrain`, tested).
- No API keys committed; secrets via env/bootstrap only; untrusted-text sanitisation on all external content; MT5 historical provider refuses non-Windows; demo test refuses non-demo accounts.

## Final Classification (§26 — factual statuses only)

| status | applies |
|---|---|
| EDGE_ESTABLISHED | no |
| EDGE_NOT_ESTABLISHED | **YES** |
| INSUFFICIENT_DATA | **YES** |
| EXECUTION_NOT_VALIDATED | **YES** |
| AI_VALIDATED | no |
| NEWS_NOT_VALIDATED | **YES** |
| BROKER_DATA_VALIDATED | no |
| DRIFT_WARNING | **YES** |

## Methodology & Limitations (per §27)

- Dataset: REAL GC=F (Yahoo/COMEX) M15 — 2026-07-23 04:00 → 2026-10-01 19:00 — 4548 bars; features built point-in-time; split 60/20/20 chronological with purge/embargo 64.
- Observations: 4306 feature rows; test segment 798 rows; per-variant trade counts as tabled above.
- Limitations: futures not broker data; no broker spread; M1/M5/M15 below size targets; 44-trade samples; single year of data; AI calls rate-limited; news neutral assumption; Windows/MT5 execution untested.
- Reproducibility: every number in this document is generated from the JSON evidence files in `reports/` by `scripts/generate_final_audit.py`.