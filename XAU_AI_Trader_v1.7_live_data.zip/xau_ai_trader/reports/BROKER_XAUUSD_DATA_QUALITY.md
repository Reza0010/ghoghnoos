> ⚠️ **SUPERSEDED (v1.5, 2026-10-08T11:45:40+00:00)** — this artifact was generated on the
> pre-MT5 host from template state and contradicts newer evidence in this
> repository. The authoritative documents are `BROKER_DATA_QUALITY.md`
> (BROKER_DATA_PRESENT, verdict FAIL on H1 spread), `GC_F_vs_BROKER_XAUUSD.md`
> (COMPARED, corr 0.978) and `RELEASE_MANIFEST.json` (v1.5). Retained for
> audit-trail honesty only — do NOT cite as current state.

# PHASE 67 §4 — BROKER XAUUSD DATA QUALITY

Generated (UTC): 2026-10-02T06:10:26.801467+00:00

**STATUS: BROKER_DATA_PENDING** — no broker XAUUSD dataset exists on this host (Linux, no MetaTrader 5). Per §1 the broker-data portion is STOPPED. **No broker data was simulated and GC=F was never renamed XAUUSD.**

## What will run (unchanged) once broker data exists

1. `python scripts/download_mt5_data.py --symbol XAUUSD` on Windows downloads M1/M5/M15/M30/H1/H4/D1 with FULL immutable provenance (broker, server, account, trade_mode, digits, point, tick size/value, contract size, volume min/max/step, stops level, freeze level, spread, swap long/short, currency, margin mode, filling mode, timezone, per-TF start/end/bar-count, download timestamp, MT5 build + SHA-256 of every parquet).
2. `python scripts/broker_data_quality.py` executes the complete battery below and writes `reports/broker_data_quality.json`.

## Quality battery (implemented in app/data/quality_suite.py)

| check | what it detects | silent repair? |
|---|---|---|
| duplicate timestamps | duplicated bars | never — logged |
| missing bars / session gaps | weekend & holiday gaps vs genuine missing data (session-aware) | never — logged |
| invalid OHLC | high<low, non-positive, OHLC vs close bounds | never — logged |
| impossible prices | ticks/bars outside plausible range | never — logged |
| abnormal jumps | bars beyond k×ATR without news/session cause | never — logged |
| incomplete bars | partial candles at download time | never — logged |
| timezone errors | naive vs UTC-aware, broker-offset mismatches | never — logged |
| abnormal spread | spread column outliers vs rolling median | never — logged |
| stale data | duplicated OHLC rows / zero-range streaks | never — logged |

Every deletion or transformation is logged to the JSON report; nothing is repaired silently.

## Verdict rules

- score < min_score ⇒ pipeline aborts before training
- session breaks (CME maintenance, weekends, holidays) are classified as structure, NOT as missing data
- the report must reach **BROKER_DATA_VALIDATED** before any broker-statistics claim

## Reproduce

```
# Windows (MT5 running):
python scripts/download_mt5_data.py --symbol XAUUSD
python scripts/broker_data_quality.py
```

## Current host evidence

- `reports/mt5_environment.json`: MetaTrader5 package NOT INSTALLED, platform Linux → §1 STOP decision.
- GC=F datasets on disk are clearly labelled `REAL_GC_F_PROXY_NOT_BROKER` in every Phase 67 artifact.
