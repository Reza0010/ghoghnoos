#!/usr/bin/env python3
"""PHASE 34 — walkforward.py: purged walk-forward train/val/test evaluation.

No test data is ever used for training. Aggregated OOS report written to
reports/walkforward_report.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.core.logging import setup_logging


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    from app.data.market.simulated import SimulatedProvider
    from app.models.dataset import _apply_scaler, _fit_scaler
    from app.models.labels import triple_barrier_labels
    from app.models.lgbm_model import LGBMModel
    from app.models.train_service import build_frames, make_feature_builder
    from app.models.validation import classification_metrics, walk_forward_splits
    from app.models.xgb_model import XGBModel

    provider = SimulatedProvider(days=cfg.provider.simulated_days, seed=cfg.provider.simulated_seed,
                                 start_price=cfg.provider.simulated_start_price,
                                 annual_vol=cfg.provider.simulated_annual_vol)
    provider.connect()
    frames = build_frames(provider, cfg)
    fb = make_feature_builder(cfg)
    features, names = fb.build(frames, cfg.timeframes.base)
    base = frames[cfg.timeframes.base.value]
    label_frame = base[["open", "high", "low", "close"]].join(features[["atr"]], how="left")
    # v1.5: executable-fill labels; NaN tail rows are dropped (never NO_EDGE)
    labels = triple_barrier_labels(label_frame, cfg.labels.horizon_bars,
                                   cfg.labels.tp_atr_mult, cfg.labels.sl_atr_mult,
                                   ambiguous=cfg.labels.ambiguous,
                                   spread_price=cfg.validation.label_spread_price,
                                   slippage_price=cfg.validation.label_slippage_price,
                                   commission_price=cfg.validation.label_commission_price)

    df = features.copy()
    df["label"] = labels
    df = df.dropna(axis=0, how="any")
    X = df.drop(columns=["label"])
    y = (df["label"].astype(int) + 1).astype(int).values
    n = len(X)

    # v1.5 (Mission 8): REAL purge/embargo gaps between train/val/test;
    # purge must cover the label horizon. Fold count is validated against
    # validation.min_oos_folds instead of silently accepting fewer.
    try:
        wf = walk_forward_splits(n, cfg.validation.walk_forward_train_bars,
                                 cfg.validation.walk_forward_val_bars,
                                 cfg.validation.walk_forward_test_bars,
                                 cfg.validation.walk_forward_step_bars,
                                 purge=max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
                                 embargo=cfg.validation.embargo_bars,
                                 min_folds=cfg.validation.min_oos_folds)
    except ValueError as e:
        print(f"[walkforward] REFUSED: {e}")
        return 1
    if not wf:
        print("[walkforward] not enough data for the configured windows — "
              "increase provider.simulated_days or reduce walk_forward windows")
        return 1
    print(f"[walkforward] {len(wf)} folds, rows={n}")

    folds_report = []
    all_test_idx = []
    aggregate_correct = aggregate_n = 0
    for k, (tr, va, te) in enumerate(wf):
        scaler = _fit_scaler(X.iloc[tr], cfg.dataset.scaler)
        Xs = _apply_scaler(X, scaler)
        lgbm = LGBMModel(cfg.lgbm)
        lgbm.fit(Xs.iloc[tr], y[tr], Xs.iloc[va], y[va])
        xgb = XGBModel(cfg.xgb)
        xgb.fit(Xs.iloc[tr], y[tr], Xs.iloc[va], y[va])
        probs = (lgbm.predict_proba(Xs.iloc[te]) + xgb.predict_proba(Xs.iloc[te])) / 2.0
        metrics = classification_metrics(y[te], probs)
        folds_report.append({"fold": k, "train": [int(tr[0]), int(tr[-1])],
                             "test": [int(te[0]), int(te[-1])], "metrics": metrics})
        aggregate_correct += int((probs.argmax(axis=1) == y[te]).sum())
        aggregate_n += len(te)
        all_test_idx.extend(te.tolist())
        print(f"  fold {k}: acc={metrics['accuracy']:.3f} f1={metrics['f1_macro']:.3f} n={len(te)}")

    print(f"[walkforward] OOS accuracy: {aggregate_correct / max(1, aggregate_n):.3f} "
          f"({aggregate_n} out-of-sample predictions)")

    out = Path(cfg.paths.reports_dir) / "walkforward_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "n_folds": len(wf), "oos_accuracy": aggregate_correct / max(1, aggregate_n),
        "folds": folds_report,
        "purge_bars": max(cfg.validation.purge_bars, cfg.labels.horizon_bars),
        "embargo_bars": cfg.validation.embargo_bars,
        "min_oos_folds_required": cfg.validation.min_oos_folds,
        "note": ("test segments never used for training; REAL purge/embargo gaps "
                 "between train/val/test (v1.5); labels executable-fill anchored; "
                 "tail rows without future horizon excluded"),
    }, indent=2), encoding="utf-8")
    print(f"[walkforward] report → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
