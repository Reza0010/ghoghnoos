# AUDIT_REPORT — XAU AI Trader v1.4 → v1.5 Forensic Upgrade

**Date:** 2026-10-08 · **Baseline:** v1.4 production candidate (as uploaded)
· **Result:** v1.5.0-forensic-upgrade · **Tests: 229/229 PASS** (baseline 203)

## 1. Executive summary

The v1.4 codebase was audited across the full chain
DATA → FEATURES → LABELS → MODELS → SIGNAL → RISK → EXECUTION → JOURNAL by
four parallel forensic deep-dives with runtime reproduction of the worst
defects. All 29 known findings from the directive were verified (none
refuted outright; several were PARTIAL) and fixed at root cause. The audit
additionally surfaced ~35 new defects — including **three critical ones the
directive did not know about**: (1) the hyperparameter optimizer tuned
directly on the test segment, (2) the HMM was silently dead at inference
(dimension mismatch swallowed at DEBUG level), and (3) the executor
re-sent FATAL and AMBIGUOUS broker outcomes (NO_MONEY sent twice,
reproduced). The system now fails closed on unknown states end-to-end, its
validation stack enforces real purge/embargo and refuses insufficient
evidence, and every model artifact carries verifiable provenance.

## 2. All critical bugs found (headline set — full list in BUG_REGISTER.md)

1. Incomplete (forming) MT5 bar consumed by features/ML (current-bar leakage).
2. `get_candles(end_time)` silently ignored (historical windows replaced by latest data).
3. `AmbiguousOrderError` (subclass of `ExecutionError`) blindly retried by the executor — double-order risk.
4. AMBIGUOUS retcodes (TIMEOUT/CONNECTION) mislabeled as rejections one layer up — reproduced double-send with NO_MONEY and TIMEOUT.
5. Backtest spread: MT5 POINTS used as absolute PRICE (65–250× overstated cost).
6. Labeling anchored at `close[t]` while execution fills at t+1 ask/bid ± slippage.
7. HMM posterior = tiled stationary distribution (constant, data-independent).
8. HMM dead at inference: 90-column matrix into a 3-column model, exception swallowed at DEBUG.
9. RSI (0..100) clipped to [−10,10] in HMM prep (≈98% of values collapsed to 10).
10. SMC cache keyed by dataframe length — stale on rolling live windows (reproduced).
11. `optimize.py` selected hyperparameters on the TEST segment.
12. Walk-forward splits had zero purge/embargo while reports claimed otherwise.
13. Tail labels (no future) merged into NO_EDGE class.
14. `sl_first` tie-break labeled no-hit bars as SELL.
15. `fillna(0.0)` zero-filled the live ML inference row.
16. RiskEngine fail-open defaults (open risk 0.0, free-margin gate skipped at ≤0, mt5_connected hard-coded True).
17. ORDER_BLOCK stop: dead `if False` branch, structure buffer ignored.
18. Liquidity TP direction inverted (BUY aimed at previous-day LOW).
19. Synthetic-tick fallback could drive LIVE entries.
20. News `provider: none` silently fell back to the static CSV (live went news-neutral).
21. Headline backtest metrics gross of costs ("net_profit" was not net).
22. Feature version hashed names only; registry `dataset_version` positional bug; models loadable with zero provenance.

## 3. Bugs fixed (summary — evidence in BUG_REGISTER.md §A/§B)

- Data layer: closed-bar filter, end_time, server-time bounds, tz unity,
  staleness anchor, metadata units, session tz bug. (8)
- ML/validation: executable-fill labels + valid mask, HMM end-to-end,
  purge/embargo everywhere, test-blind optimizer, enforced leakage audit,
  scaler center+scale audit, calibrated-metric headline, NO_EDGE veto,
  EV layer, registry provenance + artifact hashes, bundle hardening,
  causal period quantiles, net-of-cost metrics. (14)
- Execution/risk: order state machine, single-send executor, reconciliation
  on UNKNOWN, idempotent comments, journal events table + WAL + INSERT,
  fail-closed risk engine, broker stop-distance, tick-value provenance,
  paper accounting/open-risk fixes, swap rollover + triple-swap (both
  executors), FIXED-SL units. (12)
- News/AI/UX: provider freshness contract, async HTTP/Telegram,
  `none` branch, currency filter, strict AI schema (extra=forbid) +
  structured-output request + logged salvage, cache eviction, dashboard
  regime key + decision panel, health ranking, no-auto-retrain at startup,
  dead-branch cleanups. (12)

## 4. Bugs intentionally not fixed (with reasons)

See BUG_REGISTER.md §C (DST engine, tick replay, dead prompt code removal,
calibration slice split, cross-asset adapters, same-bar tie-break default).
None are silent: each is documented with its acceptance gate.

## 5. Architecture changes

- Order path: `INTENT→PRECHECK→ORDER_CHECK→SEND→ACK→RECONCILE→terminal`
  with UNKNOWN blocking trading — Mission 2/16 satisfied structurally.
- One decision engine, adapters differ: paper executor now exposes
  positions + realized balance so the risk gate is identical in paper/live.
- New `app/signals/expected_value.py` (EV-after-costs layer) wired into the
  ensemble (Mission 13).
- Journal gained an immutable `events` table (ORDER_INTENT/ACK/UNKNOWN/
  REJECTED/RECONCILIATION_RESULT) enabling full decision reconstruction
  (Mission 39).
- Startup now enforces the no-auto-retrain policy (Mission 27).

## 6–11. Layer summaries

- **ML:** shared HMM feature contract (rsi_norm), forward-backward
  posterior, quality-weighted ensemble with NO_EDGE veto and EV gate,
  per-model OOS weights from the registry. OLD: naive average + dead HMM.
  NEW: evidence-weighted fusion. WHY: Mission 7/9/12. EVIDENCE: unit tests
  + registry metrics.
- **Validation:** purge ≥ horizon enforced in both splitters; optimizer
  test-blind; calibrated headline metrics; leakage audit hard-fails
  training. EVIDENCE: two live training refusals during this upgrade.
- **Risk:** fail-closed on every unknown; broker stop-distance; OB buffer;
  liquidity direction; EV veto. EVIDENCE: 5 new risk tests.
- **Execution:** single-send + reconciliation + idempotency + recheck.
  EVIDENCE: audit reproductions + state-machine tests.
- **News/Fundamental:** freshness contract, fail-closed none-provider,
  async I/O; cross-asset adapters remain documented extension points.
- **Backtest:** spread units, gap-through-SL worst-case fill, tp_first
  honoured, swap hour + triple swap, NaN-spread guard, net metrics with
  gross retained for comparison.

## 12. Security improvements

- `AIOutput` forbids unknown fields (injection-smuggling surface closed).
- AI structured-output requested at provider; brace-slice salvage is
  logged, not silent.
- Journal failures surfaced (no silent audit-trail loss).
- No reduction in security posture: existing sanitisation, env-only
  secrets, demo-only execution gates all retained and re-tested.

## 13–14. Tests added / result

- 26 new tests (`tests/test_v15_upgrade.py` + additions to risk/backtest/
  labels suites): SMC cache sliding window, HTF completion-time alignment,
  feature-version sensitivity, HMM posterior/normalization/contract,
  walk-forward purge/embargo + min-folds, temporal-split gap, ensemble
  NO_EDGE/weighting/EV-veto, staleness anchor, news none-branch + currency
  filter, spread units (backtest + FIXED SL), EV layer, dashboard contract,
  fail-closed risk gates, broker stops level, gap-through-SL, tp_first.
- **Result: 229 passed, 0 failed, 0 skipped** (6.6 s). `python3 main.py
  --once` smoke run: clean WAIT decision with `AI_NOT_CONFIGURED`.

## 15–19. Model/walk-forward/cost/MC results

See MODEL_VALIDATION_REPORT.md (walk-forward: 15 folds / 30,000 OOS
predictions on simulated data; optimizer test-blind; ECE ≈ 0.03; per-fold
purged-CV log-loss recorded). Cost-stress, Monte-Carlo and null-model
harnesses are retained and MUST be re-run on re-downloaded (offset-correct)
broker data before any promotion; running them on the mislabeled shipped
datasets would violate Mission 54.

## 20. Production readiness score

**42/100 — RESEARCH / PAPER-TRADING READY; NOT production-ready, honestly
and by evidence.** Scoring: code correctness & safety gates 9/10 (up from
~4/10 — all critical paths fail closed); test coverage 8/10; validation
methodology 8/10 (methodology fixed; evidence pending real data); data
provenance 5/10 (shipped broker data has the offset mislabel); execution
evidence 3/10 (no broker-host verification this release); statistical
acceptance 4/10 (walk-forward done on simulated data; null-model/ablation/
cost-stress pending on real data); monitoring/ops 5/10 (drift/no-retrain
wired, dashboards fixed).

**The honest answer to the directive's final question ("does this system
still have an edge OOS, after costs, across regimes, on a real broker,
without leakage?") is: UNKNOWN — and the system is now built so that the
answer can be measured honestly.** The next measurement requires the MT5
host session (offset-corrected re-download → walk-forward + null model +
cost stress → demo gate).
