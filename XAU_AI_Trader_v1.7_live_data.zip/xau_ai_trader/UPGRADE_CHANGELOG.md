# UPGRADE_CHANGELOG — v1.4 production candidate → v1.5.0-forensic-upgrade

All changes are in-repo (git: baseline `4202c9e` → v1.5). Nothing is a
recommendation-only note.

## Data layer
- `app/data/mt5/provider.py`: closed-bar guarantee; `end_time` enforced;
  `server_to_utc()` single time conversion (candles/ticks/positions);
  AMBIGUOUS retcodes raise `AmbiguousOrderError`; `order_check` re-run after
  retry price refresh; tick-value provenance flag.
- `app/data/mt5/historical.py`: server-time bounds for `copy_rates_range`;
  honest timezone provenance text; `spread_units="POINTS"` stamped.
- `app/data/quality.py`: staleness anchor fix (`_spans_weekend`),
  `stale_after_bars` wired.
- `app/data/dataset_meta.py`: `spread_units` field; dead line removed.
- `app/data/market/models.py`: `tick_value_is_fallback`, `stops_level_points`,
  `freeze_level_points`.

## Features / SMC / Regime
- `app/features/builder.py`: completion-time HTF alignment (time-based, gap-
  robust); SMC cache fingerprint; full-contract `feature_version`.
- `app/smc/engine.py`: `SMCResult.fingerprint`; short-frame bias fix.
- `app/features/sessions.py`: tz-convert fix.

## Models / Validation
- `app/models/labels.py`: executable-fill anchoring (t+1 open ± costs),
  NaN validity for tails, `sl_first` no-hit fix.
- `app/models/hmm_model.py`: forward-backward posterior; `hmm_feature_matrix`
  shared helper (rsi→[−1,1]); last-observation posterior; state feature list
  persisted.
- `app/models/train_service.py`: purge≥horizon split; enforced full leakage
  audit; real purged-CV loop; min-validation-samples calibration; raw+
  calibrated test metrics; full registry provenance + artifact hashes; HMM
  shared matrix; scaler.json-missing hard failure.
- `app/models/validation.py`: walk-forward purge/embargo + min-folds guard;
  balanced accuracy, Brier, ECE.
- `app/models/leakage.py`: real purity/alignment/scaler-scale/horizon checks.
- `app/models/bundle.py`: DataError contract; scaler-required guard.
- `app/models/registry.py` callers: keyword-arg provenance (dataset_version
  positional bug eliminated).
- `optimize.py`: TEST-BLIND objective (purged-CV + validation).
- `walkforward.py`: executable-fill labels, purge/embargo, min-fold refusal,
  honest report note.
- `app/analytics/periods.py`: expanding shifted vol quantiles (causal).
- `app/backtest/metrics.py`: net-of-cost headline (gross retained).

## Signals
- `app/signals/ensemble.py`: inverse-log-loss model weighting; NO_EDGE veto;
  EV-after-cost gate (Mission 12/13).
- `app/signals/expected_value.py`: NEW EV layer.

## Risk / Execution
- `app/risk/engine.py`: fail-closed unknown gates; unconditional margin gate;
  real mt5_connected; broker stop-distance validation.
- `app/risk/stops.py`: OB buffer fix (dead branch removed); liquidity TP
  direction fix; FIXED-SL point unit from symbol.
- `app/execution/mt5_exec.py`: order state machine, single-send, intent
  journal, reconcile_unknown, trade block.
- `app/execution/paper.py`: rollover-instant swap + triple swap + realized
  balance.
- `app/journal/journal.py`: events table + `log_event`, WAL, INSERT (no
  REPLACE) for trades.
- `app/trader.py`: signal-id comments, executor-authoritative paper open
  risk, live tick fail-closed, EV wiring, model-quality weights, point
  stamping, drift-monitor handle.

## News / AI / Monitoring / Dashboard
- `app/news/providers.py`: freshness contract (`last_update/coverage/
  is_fresh`), async HTTP bridge, `NullNewsProvider` for `provider: none`.
- `app/news/engine.py`: stale→UNKNOWN(WAIT); currency filter fix.
- `app/ai/schemas.py`: `extra=forbid`, logged brace-slice fallback, fence
  stripping.
- `app/ai/base.py`: `response_format=json_object`.
- `app/ai/gateway.py`: TTL eviction; dead branch cleanup.
- `app/monitoring/health.py`: SAFE_MODE > DISABLED severity.
- `app/notifications/telegram.py`: `notify_async`.
- `app/dashboard/webapp.py`: `current_regime` key fix; Mission-38 decision
  panel (ML probs, SMC bias, AI status, risk, freshness).
- `main.py`: `assert_no_auto_retrain` at startup.
- `app/backtest/engine.py`: spread units, gap-through-SL worst-case fill,
  tp_first honoured, swap hour/triple swap, NaN-spread guard.

## Reports & provenance
- NEW: `AUDIT_REPORT.md`, `BUG_REGISTER.md`, `UPGRADE_CHANGELOG.md`,
  `MODEL_VALIDATION_REPORT.md`, `DATA_QUALITY_REPORT.md`,
  `EXECUTION_READINESS.md`, `RISK_READINESS.md`, `RELEASE_MANIFEST.json`,
  `scripts/generate_release_manifest.py`.
- SUPERSEDED headers added to stale phase67 PENDING reports
  (`broker_data_quality_phase67.json` consumers, `gcf_vs_xauusd_phase67.json`,
  `PHASE_67_BROKER_FINAL_AUDIT.md`) pointing at the authoritative current
  documents.

## Tests
- NEW: `tests/test_v15_upgrade.py` (17 regression tests mapped to findings).
- UPDATED: `tests/test_labels_leakage.py` (new label contract),
  `tests/test_risk.py` (fail-closed contract), `tests/test_backtest.py`
  (same-bar annotation + 3 new tests), `tests/test_phase65_realdata.py`
  (spread-source disclosure).
- **229 passed / 0 failed.**
