# XAU AI Trader — Professional AI-Assisted Quantitative Trading Platform

AI-assisted quantitative trading platform for **XAUUSD on MetaTrader 5**,
built around one principle:

> **The goal is not to trade constantly. The goal is to trade at the right
> time — and to NOT trade at the wrong time.**
> `WAIT / NO-TRADE` is a first-class, valid output of every layer.

---

## ⚠ Honest status disclaimer (read first)

| Area | Status |
|---|---|
| Data pipeline, features, SMC, ML, risk, execution, backtest, journal, monitoring | **Implemented** (this repo, tested — 163 tests green incl. the Phase 66 fail-safe matrix) |
| MT5 connectivity | **Implemented** — requires Windows + `pip install MetaTrader5`. On Linux the system runs with the clearly-labelled **SimulatedProvider** (synthetic data) for development/testing |
| AI providers (Z.ai / Gemini / Groq / OpenRouter) | **Implemented** (HTTP integrations, failover, consensus). They require API keys; without keys the system degrades to SAFE MODE / WAIT |
| News HTTP provider | **Skeleton** — strict-schema JSON endpoint; adapt `app/news/providers.py::HTTPNewsProvider` to your calendar API. CSV & deterministic mock providers are fully working |
| Deep learning (LSTM/Transformer), RL (PPO/SAC) | **Not implemented** (optional PHASE 53/54 — deliberately omitted until the base system is validated) |
| Profitability | **NO CLAIM.** All results shown are *backtest results on simulated data* and prove nothing about live performance (PHASE 63) |

---

## Architecture

```
MetaTrader 5 ──► Market Data Engine ──► Data Validation (quality score)
                                              │
                                     Feature Engineering (multi-TF, causal)
                                              │
              ┌───────────────────────────────┼──────────────────────────┐
              ▼                               ▼                          ▼
        Technical Analysis              SMC Engine                 Macro/News
        (indicators, sessions)   (BOS/CHoCH/FVG/OB/sweeps)      (risk windows)
              └───────────────────────────────┼──────────────────────────┘
                                              ▼
                                    ML Prediction Layer
                        LightGBM ── XGBoost ── HMM(regime) ── Calibration
                                              ▼
                                     Regime Detection
                                              ▼
                                    News Risk Engine
                                              ▼
                                    AI Gateway (failover chain)
                         Z.ai → Gemini → Groq → OpenRouter → SAFE MODE
                                              ▼
                                     AI Consensus Layer
                                              ▼
                                  Signal Ensemble (weighted fusion)
                                              ▼
                              Risk Engine  (deterministic, AI-proof)
                                              ▼
                                    ┌─────────┴─────────┐
                                    ▼                   ▼
                                 EXECUTE               WAIT
                                    │
                          Paper / MT5 Execution → Journal → Monitoring → Drift
```

**Key design rules**

- **AI ≠ Trading Engine.** LLMs only do context analysis, setup validation,
  contradiction detection and market explanation. Lot size, SL, TP, risk %,
  margin and position size are computed by the deterministic Python Risk
  Engine, which **always overrides** the AI.
- **Hard risk filters** (spread, news, session, regime, daily loss, drawdown,
  open positions, ML/AI confidence, data quality) can veto every signal.
- **Kill Switch** is independent and persistent; trading stays disabled until
  manually reset (optional cooldown auto-reset).
- Everything is **config-driven** (`config.yaml`) — no magic numbers, no
  hard-coded keys/symbols/risk. Secrets only via environment variables.

---

## Installation

### Linux / macOS / Docker (development & backtesting)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env           # fill in what you have (all optional)
python healthcheck.py
```

> On Linux, `config.yaml` ships with `provider.kind: simulated` — a
> deterministic synthetic XAUUSD feed so the **whole pipeline is runnable
> end-to-end without MT5**. Simulated results are for engineering only.

### Windows (real MT5)

```bash
pip install -r requirements.txt -r requirements-windows.txt
```

1. Install & log into the MetaTrader 5 terminal.
2. In `config.yaml` set `provider.kind: mt5` and optionally `mt5.server`,
   `mt5.terminal_path`, `mt5.server_utc_offset_hours`.
3. Put `MT5_LOGIN` / `MT5_PASSWORD` in `.env` (terminal must be running; the
   Python API attaches to it).
4. Symbol aliases (`XAUUSDm`, `XAUUSD.`, `GOLD`, …) are resolved
   automatically via symbol discovery.

---

## Configuration

All parameters live in `config.yaml` (documented inline). Highlights:

| Section | What it controls |
|---|---|
| `provider` | `mt5` (Windows) or `simulated` (Linux dev) |
| `timeframes` | M1…D1 roles: H4 macro, H1 structure, M15 setup, M5 base, M1 execution |
| `quality` | min data-quality score (below → WAIT), gap/spread anomaly thresholds |
| `smc` | swing left/right, FVG min ATR, displacement body/range ATR, sweep window |
| `labels` | triple-barrier horizon, tp/sl ATR multipliers, ambiguity policy |
| `lgbm` / `xgb` / `hmm` | model hyperparameters (also Optuna-tunable) |
| `calibration` | isotonic / Platt scaling of raw probabilities |
| `validation` | purge/embargo bars, walk-forward window sizes |
| `ensemble` | ML/SMC/AI weights (sum = 1), min score/confidence, conflict margins |
| `ai` | provider list, failover order, cache TTL, daily cost cap, `on_all_fail: WAIT` |
| `risk` | risk %, max daily loss, max drawdown, spread cap, SL/TP methods, min RR |
| `kill_switch` | triggers + persistence file + optional auto-reset |
| `execution` | mode (backtest/paper/live), slippage, commission, swap, magic |
| `news` | provider, currencies, high/medium impact pre/post windows |

Secrets (`.env`): `MT5_LOGIN`, `MT5_PASSWORD`, `ZAI_API_KEY`, `GEMINI_API_KEY`,
`GROQ_API_KEY`, `OPENROUTER_API_KEY`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`,
`LIVE_CONFIRM`. Never commit `.env`.

---

## Usage (PHASE 58 CLI)

```bash
python healthcheck.py                 # self-diagnostic before anything else
python train.py --days 90             # features → labels → LGBM/XGB/HMM → calibrate → registry
python backtest.py                    # cost-modelled backtest (spread/slippage/commission/swap)
python walkforward.py                 # purged walk-forward OOS evaluation
python optimize.py --trials 40        # Optuna search with overfit penalty
python main.py --mode paper           # full trading loop (default, safe)
python main.py --mode paper --once    # single iteration smoke test
python main.py --mode live            # gated: needs live_trading_enabled + LIVE_CONFIRM=YES
python dashboard.py                   # terminal dashboard (FA/EN)
python dashboard.py --web             # optional streamlit dashboard (pip install streamlit)
```


## PHASE 67 — Broker-real validation & NULL-MODEL AUDIT (final)

Phase 67 replaces guesswork about the Phase 66 random baseline with a proper
null model, and stops honestly at the Windows/MT5 gate. Full evidence:
`reports/PHASE_67_BROKER_FINAL_AUDIT.md`.

| item | verdict (factual) |
|---|---|
| Null model (§9, mandatory) | **EDGE_NOT_ESTABLISHED** — 4 families × 10,000 sims, exact 44-trade conditioning; observed PF 1.237 vs null p95 1.29–1.69; empirical p = 0.12–0.31 |
| Phase 66 "random p95 PF ≈ 3.15" | **DIAGNOSED: small-sample artifact** — baseline median 2 trades/seed → heavy-tailed PF |
| Simulator | **bit-identical to production backtester** (44/44 trades, max \|Δpnl\| = 0.0, both implementations) |
| Bootstrap (§10, 10k) | P(PF ≤ 1) = 0.2531, P(expectancy ≤ 0) = 0.2531, PF CI95 (0.638–2.267) |
| Cost sensitivity (§11) | **EXECUTION_FRAGILE** — PF ≤ 1 at 2× spread (extended grid 1.25/1.5/2/3×) |
| AI rate limiting (§14) | exponential backoff + pacing + retry limit + circuit breaker + JSONL request journal; AI unavailable ⇒ WAIT; unit-tested |
| Broker data (§3–§8, §13, §15, §17–§21) | **BROKER_DATA_PENDING / NOT RUN** — §1 STOP: host is Linux, MetaTrader 5 absent; nothing simulated, GC=F never renamed XAUUSD |
| News | **NEWS_NOT_VALIDATED** (unchanged) |
| Tests | **181/181 PASS** (18 new Phase 67 tests) |
| Release | `XAU_AI_Trader_v1.3_phase67.zip` — reproducible (fixed seeds; rerun verified bit-identical) |

```bash
# null model audit (40,000 sims; deterministic seeds) → reports/NULL_MODEL_AUDIT.md
python scripts/phase67_null_model_audit.py --null-sims 10000

# environment gate (writes reports/MT5_ENVIRONMENT.md; on Windows expect PROCEED)
python scripts/phase67_environment_check.py

# Windows + MT5 with DEMO account — the path that upgrades any PENDING above:
python scripts/download_mt5_data.py --symbol XAUUSD   # full provenance + SHA-256
python scripts/broker_data_quality.py && python scripts/compare_gcf_xauusd.py
python scripts/mt5_demo_execution_test.py             # 15 steps, refuses LIVE
```

Key modules added in Phase 67: `app/analytics/null_model.py` (§9 engine:
validated single-trade simulator + null machinery), `app/ai/rate_limiter.py`
(§14), `scripts/phase67_null_model_audit.py`, `scripts/phase67_environment_check.py`,
`scripts/phase67_pending_reports.py`, `scripts/phase67_final_audit.py`,
`tests/test_phase67_audit.py` (18 tests → 181 total). The MT5 downloader now
captures the complete §3 provenance list (stops/freeze level, margin mode,
filling mode, account/terminal build, per-TF ranges, SHA-256 immutability).

## PHASE 66 — Broker-real validation & STATISTICAL EDGE AUDIT

The Phase 66 audit answers one question honestly: **does the system have a
statistically defensible edge?** Verdict: **EDGE_NOT_ESTABLISHED** on the
available real data. Full evidence: `reports/PHASE_66_FINAL_AUDIT.md`.

| item | verdict (factual, §26) |
|---|---|
| Statistical edge (GC=F, OOS test, 44 trades) | **EDGE_NOT_ESTABLISHED** — PF 1.24, 95% CI (0.64–2.27) incl. PF≤1 |
| Dataset | **INSUFFICIENT_DATA** — M1/M5/M15 below directive targets; H1 ok |
| Execution | **EXECUTION_NOT_VALIDATED** (no Windows/MT5 run yet) + **EXECUTION_FRAGILE** (PF<1 at 2× spread) |
| AI | **AI_VALIDATED: no** — agreement 0.26 = systematic conservatism, no significant selection value (p=0.113) |
| News | **NEWS_NOT_VALIDATED** (`NEWS_VALIDATION_PENDING`) |
| Broker data | **BROKER_DATA_VALIDATED: no** — awaits Windows MT5 download |
| Drift | **DRIFT_WARNING** — DATA_DRIFT=WARNING, CONCEPT_DRIFT=PRESENT; NO auto-retrain (§25) |

```bash
# full statistical audit: 60/20/20 split → leakage audit → baselines A–G →
# bootstrap 10k → Monte Carlo 10k → walk-forward 7 folds → cost sensitivity →
# parameter stability  (writes reports/phase66_audit.json + PARAMETER_STABILITY.md)
python scripts/phase66_statistical_audit.py            # add --with-ai for the AI leg

# AI agreement breakdown (§14) / drift investigation (§23) / broker quality (§3)
python scripts/ai_agreement_analysis.py
python scripts/drift_analysis.py
python scripts/broker_data_quality.py

# Windows + MT5 (real broker data + DEMO execution checklist, 15 steps)
python scripts/download_mt5_data.py --symbol XAUUSD
python scripts/mt5_demo_execution_test.py
```

Key modules added in Phase 66: `app/analytics/statistics.py` (§8/§9/§10/§18),
`app/analytics/variants.py` (§7 identical-conditions variants),
`app/risk/failsafe.py` (§22 18-scenario matrix), `app/execution/reconciliation.py`
(§21), `app/execution/realtime_paper.py` (§24 BROKER_REALTIME_PAPER — never sends
orders), `app/data/mt5/historical.py` (§2), `app/monitoring/no_retrain.py` (§25),
`app/news/real_provider.py` (§16), `tests/test_phase66_audit.py` (26 tests → 163 total).

## PHASE 65 — Real-world validation (real XAUUSD research pipeline)

Everything for evaluating the system on **REAL** market data (never synthetic):

```bash
# 1. REAL data — pick ONE:
python scripts/fetch_public_data.py --timeframes M15 H1 D1 M5   # Linux: real COMEX gold (GC=F, labelled)
python scripts/download_mt5_data.py --symbol XAUUSD --timeframes M15 H1 D1   # Windows+MT5: real broker data + specs

# 2. Quality battery on data/raw → data/data_quality_report.json
python scripts/data_quality_report.py

# 3. Full real validation: strict split → train(*_real) → walk-forward → OOS
#    backtest → session/period breakdowns → drift  (config_real.yaml)
python scripts/run_real_validation.py

# 4. AI (real API, gated + capped):
python scripts/ai_provider_test.py --calls 20        # latency/tokens/JSON validity
python scripts/ai_consistency_test.py --states 100   # §14 consistency battery
python scripts/ab_test.py --with-ai                  # ML vs ML+SMC vs +REGIME vs +AI

# 5. Paper replay on real data + paper-vs-backtest comparison
python scripts/paper_replay.py --bars 400 --relaxed

# 6. Drift (data PSI/KS + rolling model perf) — human-review trigger, NO auto-retrain
python scripts/drift_check.py

# 7. Windows + MT5 DEMO only: execution checklist + broker reconciliation (§20/§27)
python scripts/mt5_demo_execution_test.py
```

- The trader loop can run offline against real history:
  `python main.py --once --config config_real.yaml --registry-tag real`
- Final report: **[reports/REAL_WORLD_VALIDATION.md](reports/REAL_WORLD_VALIDATION.md)**.
- Results are separated as SYNTHETIC TEST / REAL HISTORICAL / PAPER / DEMO /
  LIVE — never mixed (§30). `LIVE_TRADING_ENABLED` stays `false` (§21).

### Live safety gates (PHASE 32)

Real orders are sent **only** when ALL of the following hold:

1. `execution.mode: live`
2. `execution.live_trading_enabled: true`
3. environment `LIVE_CONFIRM=YES`
4. provider reports `supports_real_execution` (MT5 only)

Anything else → `ConfigError` before a single order can be constructed.

---

## Data leakage policy (summary)

- Features are **strictly causal** — verified by a test that recomputes
  features on truncated data and demands byte-identical rows.
- Higher-timeframe features become available only after the HTF bar closes
  (`shift(1)` + reindex-ffill).
- Labels use the future **by design** and are never model inputs; purged CV
  with embargo prevents train/test contamination; scaler is fit on train only.
- Programmatic audit runs before training; details in
  [`DATA_LEAKAGE_AUDIT.md`](DATA_LEAKAGE_AUDIT.md).

## Security (summary)

- No secrets in code/config/logs (masking filter on every log record).
- All external content (news, AI responses) is **untrusted**: sanitised,
  schema-validated, length-capped; news is wrapped in `<untrusted_news>` with
  explicit treat-as-data instructions (prompt-injection defense).
- No arbitrary code execution, no pickle deserialization (models persist as
  native formats / JSON / npz). Full model in [`SECURITY.md`](SECURITY.md).

## Testing

```bash
pytest                      # 119 tests: indicators, features/leakage, SMC,
                            # labels, calibration, HMM, risk, sizing, SL/TP,
                            # kill switch, AI failover/consensus/injection,
                            # execution, backtest, news, regime, drift, journal,
                            # end-to-end pipeline with fake AI
```

## Docker (PHASE 59)

```bash
docker compose up trader-paper    # paper trading loop (simulated feed)
docker compose up dashboard       # streamlit dashboard on :8501
```

⚠ MT5 desktop integration **cannot run inside a Linux container** — run the
live mode natively on Windows. The container is for paper/backtest/monitoring.

## Project layout

```
app/
├── core/        logging, exceptions, security (masking, sanitisation)
├── config/      pydantic schema + YAML/env loader
├── data/        mt5/ (guarded), market/ (base+simulated), quality, storage/
├── indicators/  causal TA (EMA/RSI/MACD/ATR/BB/Stoch/ADX/ROC)
├── features/    multi-TF causal builder + sessions
├── smc/         structure, liquidity, order_blocks, fvg, displacement, engine
├── models/      labels, dataset, lgbm, xgb, hmm, calibration, validation,
│                registry, leakage audit, train_service, bundle
├── regime/      rules + HMM fusion
├── news/        providers (csv/mock/http) + risk engine
├── ai/          schemas, prompts, base, providers, gateway, consensus
├── signals/     weighted ensemble
├── risk/        sizing, stops, engine (hard filters), kill_switch
├── execution/   paper + mt5 (guarded)
├── backtest/    event engine + metrics
├── journal/     SQLite signals/trades/ai_calls/experiments
├── monitoring/  health registry, drift (PSI/KS/perf), state store
├── notifications/ telegram (optional)
├── dashboard/   terminal + streamlit (FA/EN, RTL)
├── pipeline.py  shared analysis pipeline
└── trader.py    orchestrator (startup health + main loop)
tests/           119 pytest cases
main.py train.py backtest.py walkforward.py optimize.py healthcheck.py dashboard.py
config.yaml .env.example requirements*.txt Dockerfile docker-compose.yml
README.md SECURITY.md DATA_LEAKAGE_AUDIT.md THIRD_PARTY.md
```

## راهنمای سریع (فارسی)

1. `pip install -r requirements.txt` — نصب وابستگی‌ها
2. `cp .env.example .env` — کلیدهای API را در صورت تمایل وارد کنید (اختیاری)
3. `python healthcheck.py` — بررسی سلامت سیستم
4. `python train.py --days 90` — آموزش مدل‌ها روی داده شبیه‌سازی‌شده
5. `python backtest.py` — بک‌تست با مدل هزینه واقعی
6. `python main.py --mode paper` — اجرای حلقه معاملاتی Paper (پیش‌فرض امن)

⚠ توجه: خروجی روی داده شبیه‌سازی‌شده هیچ دلیلی بر سوددهی واقعی نیست
(فاز ۶۳ — بدون ادعای سود). برای اتصال واقعی به MT5 باید روی Windows اجرا کنید
(`provider.kind: mt5`).

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `MetaTrader5 package is unavailable` | You're on Linux/macOS — use `provider.kind: simulated` or run on Windows |
| System always logs `WAIT: AI_NOT_CONFIGURED` | No AI keys in `.env` while `ai.require_ai_for_trade: true` — add a key or set `false` |
| `dataset too small` on train | Increase `--days` / `provider.simulated_days`, or lower `dataset.min_rows` |
| `WAIT: NEWS_UNAVAILABLE` | News CSV missing/empty — fill `data/news_calendar.csv` or use `news.provider: mock` |
| Kill switch stuck | `logs/kill_switch_state.json` — inspect trigger, call `.reset()` or delete file |
| Models missing | Run `python train.py` before paper/backtest |
