# THIRD_PARTY.md — Dependencies & Licenses

Runtime dependencies (pinned in `requirements.txt`). Verify exact versions
against the installed environment (`pip list`); license texts ship with each
package or at the linked source.

| Package | Purpose | License | Notes |
|---|---|---|---|
| numpy | numeric core | BSD-3-Clause | |
| pandas | dataframes, resampling | BSD-3-Clause | |
| scipy | statistical support | BSD-3-Clause | |
| scikit-learn | scaler, isotonic/Platt, metrics, splits | BSD-3-Clause | |
| lightgbm | gradient boosting classifier | MIT | |
| xgboost | gradient boosting classifier | Apache-2.0 | |
| hmmlearn | Gaussian HMM regime model | BSD-3-Clause | |
| optuna | hyperparameter search | MIT | |
| pydantic | config & AI-output validation | MIT | v2 |
| PyYAML | config parsing | MIT | |
| python-dotenv | `.env` secret loading | BSD-3-Clause | |
| httpx | async HTTP for AI/news/telegram | BSD-3-Clause | |
| pyarrow | parquet candle storage | Apache-2.0 | |
| rich | terminal dashboard tables | MIT | |
| pytest | test framework | MIT | dev |
| streamlit *(optional)* | web dashboard | Apache-2.0 | not installed by default |
| shap *(optional, not installed)* | model explainability | MIT | LightGBM/XGBoost importances currently used instead |

## Platform-specific

| Package | Platform | License | Notes |
|---|---|---|---|
| MetaTrader5 | **Windows only** | Proprietary (MetaQuotes) — free Python package, redistribution governed by MetaQuotes terms | Required for live data/execution; guarded import everywhere |

## Broker / data disclaimers

- **MetaTrader 5** and the MetaQuotes terminal are proprietary products; this
  repository only integrates through their official Python API.
- Broker symbol metadata (tick value/size, contract size, swap, commissions)
  is read live from the terminal — nothing is assumed in code.
- No market-data vendor content is bundled. The simulated provider generates
  purely synthetic numbers and ships no third-party data.

## Compliance notes

- All listed OSS licenses are permissive; none impose copyleft obligations on
  this codebase's own license choice.
- Keep this file in sync when adding/removing dependencies.
