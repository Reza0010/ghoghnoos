"""PHASE 5 — SMC engine determinism and event correctness."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.config.schema import SMCConfig
from app.indicators.ta import atr
from app.smc.engine import SMCEngine
from app.smc.structure import detect_structure, find_swings
from app.smc.types import Direction, SMCEventType


def _mk_ohlc(close, wick=0.3):
    n = len(close)
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    high = np.maximum(open_, close) + wick
    low = np.minimum(open_, close) - wick
    idx = pd.date_range("2026-01-05", periods=n, freq="5min", tz="UTC")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                         "tick_volume": np.ones(n), "real_volume": np.zeros(n),
                         "spread": np.full(n, 0.2)}, index=idx)


def test_swing_detection_confirms_later():
    close = np.array([10, 11, 12, 13, 12, 11, 12, 13, 14, 13] * 3, dtype=float)
    df = _mk_ohlc(close)
    swings = find_swings(df, left=2, right=2)
    # a swing at bar i must only be flagged at i+right (confirmation lag)
    raw_high = df["high"]
    for i in range(len(df)):
        if swings["swing_high"].iloc[i]:
            j = i - 2  # original pivot location
            assert j >= 0
            assert raw_high.iloc[j] >= raw_high.iloc[j - 1]
            assert raw_high.iloc[j] >= raw_high.iloc[j - 2]


def test_bos_bullish_detection():
    # rising market breaks above the prior swing high
    close = np.concatenate([np.full(20, 100.0) + np.sin(np.linspace(0, 9, 20)) * 2,
                            np.linspace(101, 115, 15)])
    df = _mk_ohlc(close)
    a = atr(df["high"], df["low"], df["close"], 14)
    swings = find_swings(df, 2, 2)
    events = detect_structure(df, swings, a, "M5")
    bos = [e for e in events if e.type == SMCEventType.BOS and e.direction == Direction.BULLISH]
    assert len(bos) >= 1
    e = bos[0]
    assert 0.0 <= e.strength <= 1.0
    assert e.invalidation is not None


def test_engine_event_schema(ohlc_df):
    eng = SMCEngine(SMCConfig())
    res = eng.analyze(ohlc_df, "M5")
    assert res.features is not None and len(res.features) == len(ohlc_df)
    for ev in res.events:
        d = ev.model_dump()
        assert d["type"] in SMCEventType._value2member_map_
        assert d["direction"] in Direction._value2member_map_
        assert 0.0 <= d["strength"] <= 1.0
        assert "timestamp" in d and "price" in d


def test_engine_deterministic(ohlc_df):
    eng = SMCEngine(SMCConfig())
    r1 = eng.analyze(ohlc_df, "M5")
    r2 = eng.analyze(ohlc_df, "M5")
    assert [(e.type, e.timestamp, e.price) for e in r1.events] == \
           [(e.type, e.timestamp, e.price) for e in r2.events]


def test_bias_series_causal(ohlc_df):
    eng = SMCEngine(SMCConfig())
    res = eng.analyze(ohlc_df, "M5")
    s = res.directional_bias_series(20)
    assert len(s) == len(ohlc_df)
    assert ((s >= -1.0) & (s <= 1.0)).all()


def test_fvg_detected():
    # engineered 3-bar gap: low[i] far above high[i-2]
    close = np.array([100, 100.5, 101, 105, 105.2, 105.4] * 10, dtype=float)
    df = _mk_ohlc(close)
    eng = SMCEngine(SMCConfig())
    res = eng.analyze(df, "M5")
    assert any(e.type == SMCEventType.FVG_BULL for e in res.events)
