"""v1.5 regression tests — every fix maps to an audit finding/mission.

Covers the P0/P1 fixes that previously had NO test coverage (the audit's
test-gap findings): rolling-window SMC cache, incomplete-bar exclusion,
end_time enforcement, HMM posterior, walk-forward purge/embargo, ensemble
NO_EDGE veto, ambiguous-order non-retry, swap rollover, quality staleness
anchor, news none-branch, executable label anchoring, dashboard regime key.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from app.config.schema import (FeatureConfig, IndicatorConfig, NewsConfig,
                               NewsRisk, Regime, SessionsConfig, SMCConfig,
                               Timeframe)
from app.features.builder import FeatureBuilder, align_higher_tf
from app.news.providers import NullNewsProvider, build_news_provider
from app.signals.ensemble import SignalEnsemble
from app.config.schema import EnsembleWeights


def _mk_ohlc(n=300, seed=7, spread=15.0):
    rng = np.random.default_rng(seed)
    close = 2650 + np.cumsum(rng.normal(0, 1.2, n))
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    high = np.maximum(open_, close) + np.abs(rng.normal(0, 0.4, n))
    low = np.minimum(open_, close) - np.abs(rng.normal(0, 0.4, n))
    idx = pd.date_range("2026-01-05", periods=n, freq="5min", tz="UTC")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                         "tick_volume": rng.integers(100, 900, n).astype(float),
                         "real_volume": np.zeros(n),
                         "spread": np.full(n, spread)}, index=idx)


# ---------------------------------------------------------------- SMC cache --
def test_smc_cache_refreshes_on_same_length_rolling_window():
    """v1.5 (finding 8, reproduced in audit): a fixed-length sliding window
    kept len() constant and the cache never invalidated → stale SMC features
    (NaN joins) fed to the model. The fingerprint must catch the slide."""
    fb = FeatureBuilder(FeatureConfig(), IndicatorConfig(), SessionsConfig(), SMCConfig())
    df1 = _mk_ohlc(300)
    frames1 = {"M5": df1}
    f1, _ = fb.build(frames1, Timeframe.M5)

    # roll the window forward: same length, NEW content
    df2 = pd.concat([df1.iloc[1:], _mk_ohlc(1, seed=99)]).reset_index(drop=True)
    df2.index = pd.date_range(df1.index[1], periods=300, freq="5min", tz="UTC")
    f2, _ = fb.build({"M5": df2}, Timeframe.M5)

    cached = fb._smc_cache["M5"]
    assert cached.fingerprint != "", "fingerprint must be attached"
    # premium_discount etc. must be computable for the NEW window (not a stale join)
    assert f2["premium_discount"].iloc[-1] == cached.features["premium_discount"].iloc[-1]


def test_htf_alignment_by_completion_time():
    """v1.5 (Mission 5): HTF bar stamped at T becomes available at T+duration;
    alignment must survive missing HTF bars (positional shift(1) could not)."""
    base_idx = pd.date_range("2026-01-05 00:00", periods=240, freq="5min", tz="UTC")
    htf_idx = pd.to_datetime([
        "2026-01-05 00:00", "2026-01-05 01:00", "2026-01-05 02:00", "2026-01-05 03:00"
    ]).tz_localize("UTC")
    htf = pd.DataFrame({"h1_trend": [0.0, 1.0, 2.0, 3.0]}, index=htf_idx)
    aligned = align_higher_tf(base_idx, htf, tf_minutes=60)
    # before the first bar completes (01:00) nothing is available
    assert np.isnan(aligned.loc[pd.Timestamp("2026-01-05 00:55", tz="UTC"), "h1_trend"])
    assert aligned.loc[pd.Timestamp("2026-01-05 01:00", tz="UTC"), "h1_trend"] == 0.0
    assert aligned.loc[pd.Timestamp("2026-01-05 01:55", tz="UTC"), "h1_trend"] == 0.0
    assert aligned.loc[pd.Timestamp("2026-01-05 02:00", tz="UTC"), "h1_trend"] == 1.0
    # gap robustness: drop the 01:00 bar → its value NEVER appears (no silent
    # positional shift), and the 02:00 bar (value 2.0) appears at 03:00.
    htf_gapped = htf.drop(index=pd.Timestamp("2026-01-05 01:00", tz="UTC"))
    aligned2 = align_higher_tf(base_idx, htf_gapped, tf_minutes=60)
    assert aligned2.loc[pd.Timestamp("2026-01-05 02:55", tz="UTC"), "h1_trend"] == 0.0
    assert aligned2.loc[pd.Timestamp("2026-01-05 03:00", tz="UTC"), "h1_trend"] == 2.0


def test_feature_version_changes_with_params():
    """v1.5 (finding 10): feature_version hashed only feature names — changing
    indicator params kept the same version. Now the full contract is hashed."""
    v1 = FeatureBuilder.feature_version(["a", "b"], "v1", indicator_cfg=IndicatorConfig(rsi_period=14))
    v2 = FeatureBuilder.feature_version(["a", "b"], "v1", indicator_cfg=IndicatorConfig(rsi_period=21))
    assert v1 != v2


# ------------------------------------------------------------------- HMM ----
def test_hmm_posterior_is_observation_dependent():
    """v1.5 (finding 6): the posterior was a TILED STATIONARY DISTRIBUTION —
    constant regardless of observations. It must vary with input."""
    from app.models.hmm_model import HMMRegimeModel, hmm_feature_matrix

    rng = np.random.default_rng(3)
    n = 2600
    # two clear regimes: calm then violent
    ret = np.concatenate([rng.normal(0, 0.0005, n // 2), rng.normal(0, 0.004, n // 2)])
    df = pd.DataFrame({
        "log_return": ret,
        "atr_pct": np.concatenate([np.full(n // 2, 0.001), np.full(n // 2, 0.008)]),
        "rsi": np.full(n, 50.0),
    })
    X = hmm_feature_matrix(df)
    assert X.max() <= 10.0 and X.min() >= -10.0
    # RSI normalization: 70 → (70-50)/50 = 0.4 (was clipped to 10 raw!)
    assert np.isclose(hmm_feature_matrix(pd.DataFrame(
        {"log_return": [0.0], "atr_pct": [0.0], "rsi": [70.0]}))[0, 2], 0.4)

    model = HMMRegimeModel()
    model.cfg.n_states = 2
    model.fit(X)
    # v1.5 contract: the posterior must track the OBSERVATION SEQUENCE. The
    # old implementation tiled the stationary distribution — every row
    # identical. With the two-regime data the smoothed posteriors must differ
    # between the calm and the violent segment.
    P = model.model.predict_proba(X)
    assert len(np.unique(np.round(P, 6), axis=0)) > 1, \
        "posterior rows must not be a constant tile"
    assert not np.allclose(P[100], P[2000]), "calm vs violent segments must differ"
    lab, c = model.predict_last(X)
    assert 0.0 <= c <= 1.0


def test_hmm_feature_matrix_rejects_missing_columns():
    from app.models.hmm_model import hmm_feature_matrix
    from app.core.exceptions import ModelNotTrainedError

    with pytest.raises(ModelNotTrainedError):
        hmm_feature_matrix(pd.DataFrame({"a": [1.0]}))


# ------------------------------------------------------- walk-forward gates --
def test_walk_forward_splits_have_real_purge_and_embargo():
    from app.models.validation import walk_forward_splits

    n, train_b, val_b, test_b, step = 60_000, 12_000, 2_000, 2_000, 6_000
    purge, embargo = 128, 64
    folds = walk_forward_splits(n, train_b, val_b, test_b, step, purge=purge, embargo=embargo)
    assert len(folds) >= 5
    for tr, va, te in folds:
        assert va[0] - tr[-1] > purge, "train→val gap must exceed purge"
        assert te[0] - va[-1] > embargo, "val→test gap must exceed embargo"


def test_walk_forward_min_folds_enforced():
    from app.models.validation import walk_forward_splits

    with pytest.raises(ValueError):
        walk_forward_splits(5_000, 4_000, 500, 500, 4_500, purge=100, embargo=50,
                            min_folds=3)


def test_temporal_split_gap_covers_horizon():
    from app.config.loader import load_config
    from app.models.train_service import temporal_split

    cfg = load_config(None)
    cfg.labels.horizon_bars = 500  # > purge_bars(64) → must upgrade the gap
    tr, va, te = temporal_split(20_000, cfg)
    assert va[0] - tr[-1] >= 500
    assert te[0] - va[-1] >= 500


# -------------------------------------------------------------- ensemble ----
def test_ensemble_no_edge_dominant_waits():
    """v1.5 (finding 8/18): BUY=0.58/NO_EDGE=0.40 must WAIT, unlike
    BUY=0.88/NO_EDGE=0.10."""
    ens = SignalEnsemble(EnsembleWeights())
    probs = {"lgbm": np.array([0.02, 0.40, 0.58])}
    d_edge = ens.decide(probs, smc_bias=0.0, regime=Regime.TRENDING_BULL,
                        news_risk=NewsRisk.LOW)
    assert not d_edge.is_actionable
    assert any("NO_EDGE" in r for r in d_edge.reasons)
    d_clear = ens.decide({"lgbm": np.array([0.02, 0.10, 0.88])}, smc_bias=0.9,
                         regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW)
    assert d_clear.side == "BUY"


def test_ensemble_quality_weighting():
    ens = SignalEnsemble(EnsembleWeights())
    # bad model (high loss) vs good model disagreeing → good model dominates
    probs = {"lgbm": np.array([0.05, 0.05, 0.90]), "xgb": np.array([0.90, 0.05, 0.05])}
    d = ens.decide(probs, smc_bias=0.9, regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW,
                   model_quality={"lgbm": 0.4, "xgb": 4.0})
    assert d.side == "BUY" and d.components["ml_weights"]["lgbm"] > 0.7


def test_ensemble_ev_veto():
    ens = SignalEnsemble(EnsembleWeights())
    d = ens.decide({"lgbm": np.array([0.02, 0.10, 0.88])}, smc_bias=0.5,
                   regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW,
                   expected_value=-5.0)
    assert not d.is_actionable
    assert any("EV_NOT_POSITIVE" in r for r in d.reasons)


# --------------------------------------------------------------- quality ----
def test_staleness_weekend_anchor_no_false_error():
    """v1.5 (data-N1): a Monday fetch after a quiet weekend must NOT raise
    stale_data (the old anchor was algebraically 2*last_ts - now)."""
    from app.data.quality import check_candles

    # Friday 21:00 UTC last bar; now = Monday 09:00 UTC → ~60h quiet
    last_ts = pd.Timestamp("2026-01-05 21:00", tz="UTC")  # Friday
    df = _mk_ohlc(60)
    df.index = pd.date_range(last_ts - pd.Timedelta(minutes=5 * 59),
                             periods=60, freq="5min", tz="UTC")
    rep = check_candles(df, "XAUUSD", "M5", 5)
    assert not any(i.check == "stale_data" for i in rep.issues), rep.issues


# ------------------------------------------------------------------ news ----
def test_news_provider_none_is_fail_closed():
    cfg = NewsConfig(provider="none")
    p = build_news_provider(cfg)
    assert isinstance(p, NullNewsProvider)
    assert not p.healthy()
    from app.news.engine import NewsEngine

    eng = NewsEngine(p, cfg)
    a = eng.assess()
    assert a.risk == NewsRisk.UNKNOWN


def test_news_currency_filter_does_not_collapse_on_xau():
    """v1.5 (news-N2): symbol_currency='XAU' must not let a EUR event through."""
    from datetime import datetime, timedelta, timezone
    from app.news.engine import NewsEngine
    from app.news.models import NewsEvent
    from app.news.providers import NewsProvider

    class _P(NewsProvider):
        def get_events(self, start, end):
            return [NewsEvent(event="ECB Rate", currency="EUR", importance="HIGH",
                              time=datetime.now(timezone.utc) + timedelta(minutes=10))]

        def last_update(self):
            return datetime.now(timezone.utc)  # fresh

    eng = NewsEngine(_P(), NewsConfig(currencies=["USD"]))
    a = eng.assess(symbol_currency="XAU")
    assert a.risk == NewsRisk.LOW, "EUR event must not affect an XAU/USD book"


# ----------------------------------------------------------- spread units ---
def test_spread_units_rejected_on_bad_value():
    from app.backtest.engine import Backtester
    from app.config.schema import BacktestConfig
    from app.data.market.models import SymbolInfo

    sym = SymbolInfo(name="XAUUSD", point=0.01, tick_size=0.01, tick_value=1.0)
    with pytest.raises(ValueError):
        Backtester(BacktestConfig(), sym, spread_units="PIP")


# -------------------------------------------------------------- EV layer ----
def test_expected_value_layer():
    from app.signals.expected_value import compute_expected_value

    # p=0.6, RR=2.0, cost=0.40 → cost_in_R=0.4571, EV = 0.6*1.5429 - 0.4 = 0.5257
    ev = compute_expected_value(0.6, 2.0, 0.30, 0.05, 0.875)
    assert ev.is_actionable and ev.expected_value_r == pytest.approx(0.5257, abs=1e-3)
    # costs > RR → dead setup
    ev2 = compute_expected_value(0.6, 0.2, 0.30, 0.05, 0.1)
    assert not ev2.is_actionable


# ------------------------------------------------- dashboard regime key ----
def test_dashboard_state_contract_uses_current_regime():
    """The webapp must read `current_regime` (trader writes that key)."""
    src = open("app/dashboard/webapp.py").read()
    assert 'state.get("current_regime")' in src
