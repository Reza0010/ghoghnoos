"""v1.4 — Downloader v2 unit tests (chunked ranged history, dedupe, stop).

The download script itself requires Windows+MT5 and stays NOT_RUN in CI;
these tests exercise the pure logic: chunk planning, overlap dedupe,
target-start stop condition and atomic-write refusals.
"""

from __future__ import annotations

import importlib.util
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"


def _load_downloader():
    spec = importlib.util.spec_from_file_location(
        "download_mt5_data_v14", SCRIPTS / "download_mt5_data.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules.setdefault("download_mt5_data_v14", mod)
    spec.loader.exec_module(mod)
    return mod


class FakeRatesMT5:
    """Mimics copy_rates_range: server-wall epochs, newest→oldest chunks.

    History spans `n_bars` M5 bars ending at `end`. Each call returns at
    most `capacity` bars within [from_dt, to_dt] (server terms = raw UTC)."""

    def __init__(self, n_bars, capacity=50):
        # anchor history at REAL now (floor to 5 min) so target windows align
        now = datetime.now(timezone.utc)
        end = now - timedelta(minutes=now.minute % 5, seconds=now.second,
                              microseconds=now.microsecond)
        self.times = [int((end - timedelta(minutes=5 * i)).timestamp())
                      for i in range(n_bars)]
        self.capacity = capacity
        self.calls = []

    def copy_rates_range(self, symbol, tf, from_dt, to_dt):
        self.calls.append((from_dt, to_dt))
        lo = int(from_dt.timestamp())
        hi = int(to_dt.timestamp())
        in_range = [t for t in self.times if lo <= t <= hi]
        in_range.sort(reverse=True)          # MT5 returns newest first
        return [{"time": t, "open": 1.0, "high": 1.0, "low": 1.0,
                 "close": 1.0, "tick_volume": 1, "spread": 10,
                 "real_volume": 0.0} for t in in_range[:self.capacity]]


def test_chunked_history_dedupes_and_stops_at_target():
    mod = _load_downloader()
    fake = FakeRatesMT5(n_bars=500, capacity=120)
    # ask for 300 bars ending at the newest history bar (server offset 0)
    rows = mod._chunked_history(fake, "XAUUSD.ecn", "M5", 5, 300, 100, 0.0)
    times = [r["time"] for r in rows]
    assert len(times) == len(set(times)), "chunk overlap must be deduplicated"
    assert times == sorted(times), "rows must be deterministically sorted"
    # the oldest requested bar must be present (300 bars * 5min span)
    oldest_expected = fake.times[299]
    assert oldest_expected in set(times)
    # never requested beyond the target start + safety margin
    assert len(fake.calls) < 300 // 100 + 12


def test_chunked_history_reports_short_history_honestly():
    mod = _load_downloader()
    fake = FakeRatesMT5(n_bars=30, capacity=100)  # history ends far above target
    rows = mod._chunked_history(fake, "XAUUSD.ecn", "M5", 5, 5000, 100, 0.0)
    assert len(rows) == 30, "must return exactly what the broker has — no fabrication"


def test_atomic_write_refuses_overwrite(tmp_path):
    mod = _load_downloader()
    import pandas as pd

    df = pd.DataFrame({"a": [1]})
    f = tmp_path / "x.parquet"
    df.to_parquet(f)
    before = f.read_bytes()
    ok = mod._atomic_write_parquet(df, f, overwrite=False,
                                   archive_dir=tmp_path / "archive")
    assert ok is False
    assert f.read_bytes() == before, "existing file must not be touched"


def test_atomic_write_archives_previous_version(tmp_path):
    mod = _load_downloader()
    import pandas as pd

    df = pd.DataFrame({"a": [1, 2]})
    f = tmp_path / "x.parquet"
    df.to_parquet(f)
    ok = mod._atomic_write_parquet(df * 10, f, overwrite=True,
                                   archive_dir=tmp_path / "archive")
    assert ok is True
    archived = list((tmp_path / "archive").glob("x_*.parquet"))
    assert len(archived) == 1, "previous version must be archived, not lost"


def test_offset_detection_contradiction_refused(capsys):
    mod = _load_downloader()
    # detection says +2h, caller insists 0h -> refuse (no silent mislabel)
    import types

    fake = types.SimpleNamespace(
        symbol_info_tick=lambda s: types.SimpleNamespace(
            time=int((datetime.now(timezone.utc)
                      + timedelta(hours=2)).timestamp())),
        last_error=lambda: (0, "ok"))
    off = mod.detect_server_utc_offset(fake, "XAUUSD.ecn")
    assert abs(off - 2.0) < 0.26
