"""PHASE 21 ensemble decision matrix + PHASE 57 integration pipeline test."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from app.ai.gateway import AIGateway
from app.config.schema import (AIConfig, EnsembleWeights, NewsRisk, Regime,
                               Timeframe, TradingMode)
from app.journal.journal import Journal
from app.signals.ensemble import SignalEnsemble


def _probs(buy, no_edge=None, sell=None):
    sell = sell if sell is not None else (1 - buy - (no_edge or 0.2))
    return {"lgbm": np.array([sell, no_edge or 0.2, buy])}


# -------------------------------------------------------------- ensemble --
def test_ensemble_buy_when_aligned():
    ens = SignalEnsemble(EnsembleWeights())
    d = ens.decide(_probs(0.7), smc_bias=0.5, regime=Regime.TRENDING_BULL,
                   news_risk=NewsRisk.LOW, ai_decision="BUY", ai_confidence=0.85)
    assert d.side == "BUY" and d.is_actionable


def test_ensemble_wait_on_ml_ambiguity():
    ens = SignalEnsemble(EnsembleWeights())
    d = ens.decide(_probs(0.58, no_edge=0.2, sell=0.50),
                   smc_bias=0.5, regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW)
    assert d.side == "WAIT" and any("AMBIGUOUS" in r for r in d.reasons)


def test_ensemble_wait_on_ml_confidence():
    ens = SignalEnsemble(EnsembleWeights(min_ml_confidence=0.7))
    d = ens.decide(_probs(0.6), smc_bias=0.5, regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW)
    assert d.side == "WAIT" and any("ML_CONF_LOW" in r for r in d.reasons)


def test_ensemble_wait_on_smc_conflict():
    ens = SignalEnsemble(EnsembleWeights())
    d = ens.decide(_probs(0.7), smc_bias=-0.6, regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW)
    assert d.side == "WAIT" and any("SMC_CONFLICT" in r for r in d.reasons)


def test_ensemble_wait_when_ai_says_wait():
    ens = SignalEnsemble(EnsembleWeights())
    d = ens.decide(_probs(0.7), smc_bias=0.5, regime=Regime.TRENDING_BULL,
                   news_risk=NewsRisk.LOW, ai_decision="WAIT")
    assert d.side == "WAIT" and d.requires_confirmation


def test_ensemble_wait_on_ai_conflict():
    ens = SignalEnsemble(EnsembleWeights())
    d = ens.decide(_probs(0.7), smc_bias=0.5, regime=Regime.TRENDING_BULL,
                   news_risk=NewsRisk.LOW, ai_decision="SELL", ai_confidence=0.9)
    assert d.side == "WAIT"


def test_ensemble_news_hard_gate():
    ens = SignalEnsemble(EnsembleWeights())
    for risk in (NewsRisk.HIGH, NewsRisk.UNKNOWN):
        d = ens.decide(_probs(0.9), smc_bias=0.9, regime=Regime.TRENDING_BULL, news_risk=risk)
        assert d.side == "WAIT"


def test_ensemble_score_below_minimum_waits():
    ens = SignalEnsemble(EnsembleWeights(min_score=0.95))
    d = ens.decide(_probs(0.6), smc_bias=0.1, regime=Regime.RANGING, news_risk=NewsRisk.LOW)
    assert d.side == "WAIT"


def test_ensemble_ml_unavailable_waits():
    ens = SignalEnsemble(EnsembleWeights())
    d = ens.decide(None, smc_bias=0.5, regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW)
    assert d.side == "WAIT" and "ML_UNAVAILABLE" in d.reasons


# ------------------------------------------------------------ integration --
def test_end_to_end_pipeline_with_fake_ai(small_frames, config, tmp_path):
    """data → features → SMC → ML(tiny) → ensemble → journal (no real AI/MT5)."""
    from app.models.labels import triple_barrier_labels
    from app.models.lgbm_model import LGBMModel
    from app.models.train_service import clean_feature_frame
    from app.models.calibration import ProbabilityCalibrator
    from app.pipeline import AnalysisPipeline
    from app.news.engine import NewsEngine
    from app.news.providers import MockNewsProvider
    from app.regime.engine import RegimeEngine

    cfg = config
    fb = __import__("app.models.train_service", fromlist=["make_feature_builder"]).make_feature_builder(cfg)
    feats, names = fb.build(small_frames, cfg.timeframes.base)
    base = small_frames[cfg.timeframes.base.value]
    label_frame = base[["open", "high", "low", "close"]].join(feats[["atr"]], how="left")
    labels = triple_barrier_labels(label_frame, 24, 2.0, 1.0).reindex(feats.index).fillna(0)
    ds = clean_feature_frame(feats, labels)
    assert len(ds) > 300
    X = ds.drop(columns=["label"])
    y = (ds["label"].astype(int) + 1).astype(int).values

    # tiny but real LGBM
    n_train = int(len(X) * 0.7)
    model = LGBMModel()
    model.n_estimators = 40
    model.fit(X.iloc[:n_train], y[:n_train])
    probs = model.predict_proba(X)

    # AI gateway with a fake provider
    from tests.test_ai_gateway import FakeProvider

    gw = AIGateway(AIConfig(enabled=True))
    gw.providers = {"fake": FakeProvider("fake", "ok")}
    gw.order = ["fake"]
    res = asyncio_run(gw.analyze({"price": float(base["close"].iloc[-1])}))
    assert res.output.decision in ("BUY", "SELL", "WAIT")

    # ensemble with real probs
    ens = SignalEnsemble(cfg.ensemble)
    d = ens.decide({"lgbm": probs[-1]}, smc_bias=fb.smc_engine.analyze(base, "M5").directional_bias()[0],
                   regime=Regime.TRENDING_BULL, news_risk=NewsRisk.LOW)
    assert d.side in ("BUY", "SELL", "WAIT")

    # journal roundtrip
    j = Journal(tmp_path / "j.db")
    sid = j.log_signal("XAUUSD", "paper", d.side, score=d.score, reasons=d.reasons)
    assert sid > 0
    assert j.recent_signals(1)[0]["decision"] == d.side
    today = pd.Timestamp.now(tz="UTC").date().isoformat()
    j.log_trade_open(1, "XAUUSD", "paper", "BUY", 0.1, 2650.0,
                     f"{today}T00:00:00+00:00", 2640, 2670)
    j.log_trade_close(1, 2660.0, f"{today}T01:00:00+00:00", 100.0, fees=0.7, exit_reason="TP")
    assert j.daily_pnl() == pytest.approx(99.3)
    stats = j.closed_trade_stats()
    assert stats["n_closed"] == 1 and stats["win_rate_pct"] == 100.0
    j.close()


def asyncio_run(coro):
    import asyncio

    return asyncio.run(coro)


def test_mt5_guard_fails_cleanly_without_package():
    """On Linux the MT5 provider must raise an actionable error, not ImportError."""
    try:
        import MetaTrader5  # noqa: F401

        pytest.skip("MetaTrader5 present (Windows)")
    except ImportError:
        pass
    from app.core.exceptions import ProviderConnectionError
    from app.data.mt5.provider import MT5DataProvider

    with pytest.raises(ProviderConnectionError, match="MetaTrader5 package is unavailable"):
        MT5DataProvider()
