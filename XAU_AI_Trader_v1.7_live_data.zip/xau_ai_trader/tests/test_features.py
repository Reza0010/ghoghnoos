"""PHASE 4/50 — Feature engine: causality (no future leakage) + session logic."""

from __future__ import annotations

import numpy as np
import pandas as pd

from app.features.builder import FeatureBuilder, align_higher_tf
from app.features.sessions import current_session_name
from app.config.schema import FeatureConfig, IndicatorConfig, SessionsConfig, SMCConfig
from app.models.train_service import make_feature_builder


def test_no_future_leakage(small_frames, config):
    """Features computed on truncated data must equal the full-data row at t."""
    fb = make_feature_builder(config)
    full, _ = fb.build(small_frames, config.timeframes.base)
    t = full.index[-50]
    trunc = {tf: df[df.index <= t] for tf, df in small_frames.items()}
    sub, _ = fb.build(trunc, config.timeframes.base)
    r1 = full.loc[t].fillna(-999.0)
    r2 = sub.loc[t].fillna(-999.0)
    assert int((r1 != r2).sum()) == 0, "feature row at t changed when future data removed"


def test_htf_alignment_never_uses_incomplete_bar(small_frames, config):
    """At the exact close time of an H1 bar, features must come from the bar
    that JUST completed (open = t − 60min) — never from a bar still forming."""
    fb = make_feature_builder(config)
    feats, _ = fb.build(small_frames, config.timeframes.base)
    h1 = small_frames["H1"]
    h1_feats = fb._compact_htf_features(h1, "H1")
    t = h1.index[50] + pd.Timedelta(minutes=60)   # close time of H1 bar 50
    if t not in feats.index or t not in h1_feats.index:
        return
    completed_open = t - pd.Timedelta(minutes=60)
    assert np.isclose(feats.loc[t, "h1_rsi"],
                      h1_feats.loc[completed_open, "h1_rsi"], atol=1e-9)
    # the bar that OPENS at t (in progress) must not be its source
    in_progress = h1_feats.loc[t, "h1_rsi"]
    assert not np.isclose(feats.loc[t, "h1_rsi"], in_progress, atol=1e-9)


def test_align_shifts_one_bar():
    idx = pd.date_range("2026-01-01", periods=10, freq="5min", tz="UTC")
    hidx = pd.date_range("2026-01-01", periods=3, freq="15min", tz="UTC")
    htf = pd.DataFrame({"v": [10.0, 20.0, 30.0]}, index=hidx)
    aligned = align_higher_tf(idx, htf)
    # at 00:10 the 00:00 bar (closing 00:15) is NOT complete → must be NaN
    assert np.isnan(aligned.loc[pd.Timestamp("2026-01-01 00:10", tz="UTC"), "v"])
    # at 00:15 the 00:00 bar is complete → 10.0
    assert aligned.loc[pd.Timestamp("2026-01-01 00:15", tz="UTC"), "v"] == 10.0
    # at 00:30 the 00:15 bar is complete → 20.0
    assert aligned.loc[pd.Timestamp("2026-01-01 00:30", tz="UTC"), "v"] == 20.0


def test_session_names():
    cfg = SessionsConfig()
    assert current_session_name(pd.Timestamp("2026-01-05 03:00", tz="UTC"), cfg) == "asia"
    assert current_session_name(pd.Timestamp("2026-01-05 09:00", tz="UTC"), cfg) == "london"
    assert current_session_name(pd.Timestamp("2026-01-05 13:00", tz="UTC"), cfg) == "overlap"
    assert current_session_name(pd.Timestamp("2026-01-05 17:00", tz="UTC"), cfg) == "newyork"
    assert current_session_name(pd.Timestamp("2026-01-05 23:00", tz="UTC"), cfg) == "off"


def test_feature_version_stable():
    assert FeatureBuilder.feature_version(["a", "b"]) == FeatureBuilder.feature_version(["b", "a"])
    assert FeatureBuilder.feature_version(["a"]) != FeatureBuilder.feature_version(["a", "b"])
