"""PHASE 65 — tests for the real-data adapter, metadata, quality suite,
analytics (periods/sessions), AI gate, execution timing and replay safety."""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import pytest

from app.config.schema import BacktestConfig, SessionsConfig
from app.data.dataset_meta import DatasetMetadata, load_metadata, save_metadata
from app.data.market.models import SymbolInfo
from app.data.market.replay import ReplayProvider, load_price_file
from app.data.quality_suite import run_quality_suite
from app.core import exceptions as exc


# ------------------------------------------------------------- fixtures ----
def _mk_real_df(n=300, spread=0.30):
    rng = np.random.default_rng(11)
    close = 2650 + np.cumsum(rng.normal(0, 0.6, n))
    open_ = np.roll(close, 1); open_[0] = 2650
    high = np.maximum(open_, close) + 0.25
    low = np.minimum(open_, close) - 0.25
    idx = pd.date_range("2026-08-03 00:00", periods=n, freq="15min", tz="UTC")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                         "tick_volume": np.zeros(n), "real_volume": rng.integers(50, 5000, n),
                         "spread": np.full(n, spread)}, index=idx)


@pytest.fixture
def dataset(tmp_path):
    df = _mk_real_df()
    f = tmp_path / "TEST_M15.parquet"
    df.to_parquet(f)
    meta = DatasetMetadata(symbol="TEST", timeframe="M15", source="unit_test_source",
                           data_kind="real", instrument="test instrument", timezone="UTC",
                           spread_available=True, volume_kind="contract")
    enrich = save_metadata(meta, f)
    return f, df


# -------------------------------------------------- metadata + adapter -----
def test_metadata_sidecar_roundtrip(dataset):
    f, df = dataset
    m = load_metadata(f)
    assert m.is_real and m.symbol == "TEST" and m.timeframe == "M15"


def test_adapter_loads_real_file_with_canonical_columns(dataset):
    f, df = dataset
    out = load_price_file(f)
    assert list(out.columns) == ["open", "high", "low", "close",
                                 "tick_volume", "real_volume", "spread"]
    assert out.index.tz is not None and out.index.is_monotonic_increasing


def test_adapter_refuses_synthetic(tmp_path):
    df = _mk_real_df(50)
    f = tmp_path / "FAKE_M15.parquet"
    df.to_parquet(f)
    meta = DatasetMetadata(symbol="FAKE", timeframe="M15", source="sim",
                           data_kind="synthetic")
    save_metadata(meta, f)
    with pytest.raises(exc.DataError, match="synthetic"):
        ReplayProvider({  "M15": f})


def test_adapter_refuses_missing_metadata(tmp_path):
    df = _mk_real_df(50)
    f = tmp_path / "NOMETA_M15.parquet"
    df.to_parquet(f)
    with pytest.raises(FileNotFoundError, match="metadata sidecar"):
        ReplayProvider({"M15": f})


def test_replay_windowing_end_time(dataset):
    f, df = dataset
    provider = ReplayProvider({"M15": f})
    end = df.index[150]
    window = provider.get_candles("TEST", "M15", 50, end_time=end)
    assert len(window) == 50
    assert window.index[-1] <= end


def test_replay_execution_is_refused(dataset):
    f, _ = dataset
    provider = ReplayProvider({"M15": f})
    with pytest.raises(exc.ExecutionError, match="READ_ONLY"):
        provider.send_market_order("TEST", "BUY", 0.01, 0, 0, "c", 1)
    with pytest.raises(exc.DataError, match="no live tick"):
        provider.get_tick("TEST")


def test_replay_missing_timeframe_is_actionable_error(dataset):
    f, _ = dataset
    provider = ReplayProvider({"M15": f})
    with pytest.raises(exc.DataError, match="no H1 dataset"):
        provider.get_candles("TEST", "H1", 10)


# --------------------------------------------------------- quality suite ---
def test_quality_suite_full_report(dataset):
    f, df = dataset
    meta = load_metadata(f)
    rep = run_quality_suite(df, meta, 15)
    for chk in ("missing_candles", "duplicates", "timestamp_ordering",
                "ohlc_consistency", "timezone", "zero_volume", "flat_bars",
                "abnormal_spread", "weekend_gaps"):
        assert chk in rep["checks"], f"missing §5 check {chk}"
    assert rep["score"] >= 70


# ------------------------------------------------------------- analytics ---
def test_session_of_mapping():
    from app.analytics.periods import session_of
    cfg = SessionsConfig()
    assert session_of(pd.Timestamp("2026-09-01 03:00", tz="UTC"), cfg) == "ASIA"
    assert session_of(pd.Timestamp("2026-09-01 09:00", tz="UTC"), cfg) == "LONDON"
    assert session_of(pd.Timestamp("2026-09-01 13:00", tz="UTC"), cfg) == "OVERLAP"
    assert session_of(pd.Timestamp("2026-09-01 18:00", tz="UTC"), cfg) == "NEW_YORK"
    assert session_of(pd.Timestamp("2026-09-01 22:00", tz="UTC"), cfg) == "OFF"


def test_session_breakdown_metrics():
    from app.analytics.periods import session_breakdown
    cfg = SessionsConfig()
    trades = pd.DataFrame({
        "entry_time": ["2026-09-01T03:00:00Z", "2026-09-01T09:00:00Z",
                       "2026-09-01T13:30:00Z", "2026-09-01T18:00:00Z"],
        "pnl": [10.0, -5.0, 20.0, -8.0],
    })
    out = session_breakdown(trades, cfg)
    assert out["ASIA"]["trades"] == 1 and out["ASIA"]["win_rate"] == 1.0
    assert out["OVERLAP"]["trades"] == 1 and out["OVERLAP"]["total_pnl"] == 20.0
    assert out["NEW_YORK"]["trades"] == 1 and out["NEW_YORK"]["total_pnl"] == -8.0
    assert out["LONDON"]["total_pnl"] == -5.0


def test_label_periods_causal():
    from app.analytics.periods import label_periods, segment_summary
    rng = np.random.default_rng(3)
    n = 600
    close = pd.Series(2650 + np.cumsum(rng.normal(0.05, 1.2, n)))
    atr_pct = pd.Series(np.abs(rng.normal(0.002, 0.0008, n)))
    labels = label_periods(close, atr_pct)
    assert len(labels) == n
    assert set(labels.unique()) <= {"WARMUP", "HIGH_VOL", "LOW_VOL",
                                    "BULL_TREND", "BEAR_TREND", "RANGE"}
    assert "WARMUP" not in segment_summary(labels.iloc[100:])


# ---------------------------------------------------------------- AI gate ---
def test_ai_gate_blocks_without_ml_setup():
    from app.ai.gate import should_call_ai
    g = should_call_ai(ml_actionable=False, ml_side=None, smc_bias=0.5,
                       smc_conflict_margin=0.3, quality_ok=True, spread_ok=True,
                       daily_loss_ok=True)
    assert not g.allowed and "GATE_NO_ML_SETUP" in g.reasons


def test_ai_gate_blocks_smc_conflict():
    from app.ai.gate import should_call_ai
    g = should_call_ai(ml_actionable=True, ml_side="BUY", smc_bias=-0.8,
                       smc_conflict_margin=0.3, quality_ok=True, spread_ok=True,
                       daily_loss_ok=True)
    assert not g.allowed and "GATE_SMC_CONFLICT" in g.reasons


def test_ai_gate_allows_valid_setup():
    from app.ai.gate import should_call_ai
    g = should_call_ai(ml_actionable=True, ml_side="SELL", smc_bias=-0.5,
                       smc_conflict_margin=0.3, quality_ok=True, spread_ok=True,
                       daily_loss_ok=True)
    assert g.allowed and not g.reasons


def test_ai_gate_data_quality_veto():
    from app.ai.gate import should_call_ai
    g = should_call_ai(ml_actionable=True, ml_side="BUY", smc_bias=0.0,
                       smc_conflict_margin=0.3, quality_ok=False, spread_ok=True,
                       daily_loss_ok=True)
    assert not g.allowed


# ------------------------------------------------- backtest timing §26 -----
def test_backtest_records_signal_order_fill_times():
    from app.backtest.engine import Backtester
    from app.data.market.models import SymbolInfo

    df = _mk_real_df(240)
    df["spread"] = 0.30
    info = SymbolInfo(name="TEST")
    signals = pd.DataFrame(
        [{"side": "BUY", "sl": df["close"].iloc[10] - 3.0,
          "tp": df["close"].iloc[10] + 6.0, "lot": 0.01, "score": 0.6}],
        index=pd.DatetimeIndex([df.index[10]]))
    bt = Backtester(BacktestConfig(), info, assumed_spread=0.30)
    res = bt.run(df, signals)
    assert len(res.trades) >= 1
    t = res.trades[0]
    assert t.signal_time == df.index[10]      # signal on bar t
    assert t.order_time == df.index[11]       # order at t+1 (delay=1)
    assert t.fill_time == t.order_time        # immediate market fill assumption
    # dataset has a real spread column → it wins over the assumed spread (§26)
    assert bt.spread_source.startswith("dataset_column")


def test_backtest_spread_source_fallback():
    from app.backtest.engine import Backtester
    from app.data.market.models import SymbolInfo

    df = _mk_real_df(60)
    df["spread"] = 0.0                      # dataset has no real spread
    bt = Backtester(BacktestConfig(), SymbolInfo(name="TEST"), assumed_spread=0.45)
    bt.run(df, pd.DataFrame())
    assert bt.spread_source.startswith("assumed_spread=0.45")


def test_backtest_fallback_two_points_disclosed():
    from app.backtest.engine import Backtester
    from app.data.market.models import SymbolInfo

    df = _mk_real_df(60)
    df["spread"] = 0.0
    bt = Backtester(BacktestConfig(), SymbolInfo(name="TEST"), assumed_spread=None)
    bt.run(df, pd.DataFrame())
    assert bt.spread_source.startswith("fallback_2_points")
