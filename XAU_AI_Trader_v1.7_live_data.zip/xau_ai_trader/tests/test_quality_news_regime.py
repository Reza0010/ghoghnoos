"""Quality checker, news engine, regime engine, drift, HMM, calibration."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from app.config.schema import (DriftConfig, HMMConfig, NewsConfig, NewsRisk,
                               Regime, RegimeConfig)
from app.data.quality import check_candles
from app.models.calibration import ProbabilityCalibrator
from app.monitoring.drift import FeatureDriftMonitor, PerformanceDriftMonitor, psi
from app.news.engine import NewsEngine
from app.news.providers import MockNewsProvider, StaticCSVNewsProvider
from app.regime.engine import RegimeEngine


def _mk_df(n=300, spread=0.2, gap_at=None, dup=False, bad_ohlc=False, na_tz=False):
    rng = np.random.default_rng(6)
    close = 2650 + np.cumsum(rng.normal(0, 0.5, n))
    open_ = np.roll(close, 1)
    open_[0] = 2650
    high = np.maximum(open_, close) + 0.3
    low = np.minimum(open_, close) - 0.3
    idx = pd.date_range("2026-01-05 00:00", periods=n, freq="5min", tz="UTC" if not na_tz else None)
    df = pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                       "tick_volume": np.ones(n), "real_volume": np.zeros(n),
                       "spread": np.full(n, spread)}, index=idx)
    if gap_at is not None:
        part1 = df.iloc[:gap_at]
        part2 = df.iloc[gap_at + 20:]
        part2.index = part2.index + pd.Timedelta(minutes=100)
        df = pd.concat([part1, part2])
    if dup:
        df = pd.concat([df, df.iloc[[-1]] * 1])
    if bad_ohlc:
        df.iloc[10, df.columns.get_loc("high")] = df.iloc[10]["low"] - 1
    return df


def test_quality_perfect_data():
    r = check_candles(_mk_df(), "XAUUSD", "M5", 5)
    assert r.score >= 95 and r.passed


def test_quality_gaps_lower_score():
    good = check_candles(_mk_df(), "XAUUSD", "M5", 5).score
    bad = check_candles(_mk_df(gap_at=100), "XAUUSD", "M5", 5)
    assert bad.score < good
    assert any(i.check == "missing_candles" for i in bad.issues)


def test_quality_duplicates_detected():
    r = check_candles(_mk_df(dup=True), "XAUUSD", "M5", 5)
    assert any(i.check == "duplicates" for i in r.issues)


def test_quality_impossible_ohlc_detected():
    r = check_candles(_mk_df(bad_ohlc=True), "XAUUSD", "M5", 5)
    assert any(i.check == "impossible_ohlc" for i in r.issues)


def test_quality_tz_naive_is_error():
    r = check_candles(_mk_df(na_tz=True), "XAUUSD", "M5", 5)
    assert any(i.check == "timezone" for i in r.issues)
    assert not r.passed


def test_quality_empty():
    r = check_candles(pd.DataFrame(), "XAUUSD", "M5", 5)
    assert r.score == 0.0


# ------------------------------------------------------------------ news --
def test_news_high_impact_window_blocks():
    eng = NewsEngine(MockNewsProvider(""), NewsConfig(provider="mock"))
    # NFP: first Friday 13:30 UTC; pick a first-Friday date
    import datetime as dt

    d = dt.date(2026, 1, 2)  # first Friday of Jan 2026
    now = dt.datetime(d.year, d.month, d.day, 13, 20, tzinfo=dt.timezone.utc)
    a = eng.assess(now)
    assert a.risk == NewsRisk.HIGH and a.upcoming


def test_news_outside_window_low():
    eng = NewsEngine(MockNewsProvider(""), NewsConfig(provider="mock"))
    import datetime as dt

    now = dt.datetime(2026, 1, 5, 3, 0, tzinfo=dt.timezone.utc)  # Monday 03:00
    assert eng.assess(now).risk == NewsRisk.LOW


def test_news_static_csv(tmp_path):
    csv = tmp_path / "news.csv"
    csv.write_text("time,event,country,currency,importance\n"
                   "2026-02-10T13:30:00+00:00,US CPI,US,USD,HIGH\n", encoding="utf-8")
    eng = NewsEngine(StaticCSVNewsProvider(str(csv)), NewsConfig(provider="static_csv"))
    import datetime as dt

    a = eng.assess(dt.datetime(2026, 2, 10, 13, 25, tzinfo=dt.timezone.utc))
    assert a.risk == NewsRisk.HIGH
    assert a.upcoming[0].event == "US CPI"


# ---------------------------------------------------------------- regime --
def test_regime_trending_bull():
    eng = RegimeEngine(RegimeConfig())
    row = pd.Series({"adx": 30.0, "di_diff": 12.0, "atr_pct": 0.0015,
                     "ema20_slope": 0.001, "ema50_dist": 0.004})
    r = eng.classify(row)
    assert r.regime == Regime.TRENDING_BULL


def test_regime_trending_bear():
    eng = RegimeEngine(RegimeConfig())
    row = pd.Series({"adx": 28.0, "di_diff": -10.0, "atr_pct": 0.0015,
                     "ema20_slope": -0.001, "ema50_dist": -0.004})
    assert eng.classify(row).regime == Regime.TRENDING_BEAR


def test_regime_high_volatility():
    eng = RegimeEngine(RegimeConfig())
    row = pd.Series({"adx": 30.0, "di_diff": 12.0, "atr_pct": 0.006,
                     "ema20_slope": 0.001, "ema50_dist": 0.004})
    assert eng.classify(row).regime == Regime.HIGH_VOLATILITY


def test_regime_ranging():
    eng = RegimeEngine(RegimeConfig())
    row = pd.Series({"adx": 12.0, "di_diff": 1.0, "atr_pct": 0.0015,
                     "ema20_slope": 0.0, "ema50_dist": 0.001})
    assert eng.classify(row).regime == Regime.RANGING


def test_regime_hmm_disagreement_reduces_certainty():
    eng = RegimeEngine(RegimeConfig())
    row = pd.Series({"adx": 12.0, "di_diff": 1.0, "atr_pct": 0.0015,
                     "ema20_slope": 0.0, "ema50_dist": 0.001})
    r = eng.classify(row, hmm_label="TRENDING_BULL", hmm_conf=0.9)
    assert r.source == "rules+hmm"


# ------------------------------------------------------------------ drift --
def test_psi_identical_low():
    rng = np.random.default_rng(1)
    x = rng.normal(0, 1, 5000)
    assert psi(x, x) < 0.01
    assert psi(x, rng.normal(0, 1, 5000)) < 0.05


def test_psi_shifted_high():
    rng = np.random.default_rng(1)
    x = rng.normal(0, 1, 5000)
    assert psi(x, rng.normal(4, 1, 5000)) > 0.5


def test_feature_drift_monitor():
    rng = np.random.default_rng(2)
    ref = pd.DataFrame(rng.normal(0, 1, (2000, 3)), columns=["a", "b", "c"])
    mon = FeatureDriftMonitor(ref)
    same = mon.report(pd.DataFrame(rng.normal(0, 1, (1000, 3)), columns=["a", "b", "c"]))
    assert same["verdict"] == "NORMAL"
    shifted = mon.report(pd.DataFrame(rng.normal(6, 1, (1000, 3)), columns=["a", "b", "c"]))
    assert shifted["verdict"] in ("WARNING", "SAFE_MODE")


def test_performance_drift():
    mon = PerformanceDriftMonitor(window=30, min_winrate=0.30)
    good = [100.0 if i % 2 == 0 else -50.0 for i in range(30)]
    assert mon.check(good)["verdict"] == "NORMAL"
    bad = [-50.0] * 30
    assert mon.check(bad)["verdict"] == "SAFE_MODE"


# ----------------------------------------------------------- calibration --
def test_calibration_reliability():
    rng = np.random.default_rng(3)
    n = 3000
    # true probability of class BUY follows p
    raw = rng.dirichlet([2, 2, 2], size=n)
    y = np.array([rng.choice(3, p=row) for row in raw])
    cal = ProbabilityCalibrator("isotonic")
    cal.fit(raw, y)
    out = cal.transform(raw)
    # calibrated probabilities stay in simplex and keep the ranking
    assert np.allclose(out.sum(axis=1), 1.0, atol=1e-6)
    assert ((out >= 0) & (out <= 1)).all()
    raw_rank = raw[:, 2].argsort()
    assert (out[raw_rank[-100:], 2].mean() > out[raw_rank[:100], 2].mean())


def test_calibration_platt_roundtrip():
    cal = ProbabilityCalibrator("platt")
    rng = np.random.default_rng(4)
    raw = rng.dirichlet([3, 3, 3], size=800)
    y = np.array([rng.choice(3, p=row) for row in raw])
    cal.fit(raw, y)
    out = cal.transform(raw[:10])
    assert out.shape == (10, 3)


def test_calibration_json_roundtrip():
    cal = ProbabilityCalibrator("isotonic")
    rng = np.random.default_rng(5)
    raw = rng.dirichlet([2, 2, 2], size=500)
    y = np.array([rng.choice(3, p=row) for row in raw])
    cal.fit(raw, y)
    import json as _json

    cal2 = ProbabilityCalibrator.from_dict(_json.loads(_json.dumps(cal.to_dict())))
    np.testing.assert_allclose(cal.transform(raw), cal2.transform(raw))


# ------------------------------------------------------------------- HMM --
@pytest.mark.skipif(
    __import__("importlib.util", fromlist=["util"]).find_spec("hmmlearn") is None,
    reason="hmmlearn optional dependency not installed",
)
def test_hmm_regime_mapping():
    from app.models.hmm_model import HMMRegimeModel

    cfg = HMMConfig(n_states=4, n_iter=100, min_bars_to_train=500)
    rng = np.random.default_rng(8)
    # 4 blocks: bull trend, high vol, bear trend, calm
    n = 800
    ret = np.concatenate([
        rng.normal(0.05, 0.5, n // 4),
        rng.normal(0.0, 3.0, n // 4),
        rng.normal(-0.05, 0.5, n // 4),
        rng.normal(0.0, 0.2, n // 4),
    ])
    vol = np.concatenate([
        rng.normal(0.3, 0.05, n // 4),
        rng.normal(3.0, 0.2, n // 4),
        rng.normal(0.3, 0.05, n // 4),
        rng.normal(0.2, 0.05, n // 4),
    ])
    rsi = rng.uniform(0, 1, n)
    X = np.column_stack([ret, vol, rsi])
    model = HMMRegimeModel(cfg)
    model.fit(X)
    label, conf = model.predict_last(X[-100:])
    assert label in ("TRENDING_BULL", "TRENDING_BEAR", "RANGING", "HIGH_VOLATILITY")
    assert 0 <= conf <= 1
