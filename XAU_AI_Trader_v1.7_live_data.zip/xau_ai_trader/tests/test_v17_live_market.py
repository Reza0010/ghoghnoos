"""v1.7 — Live public market data provider, gateway cooldown, panel fallbacks.

Offline tests: all network calls are mocked. Live connectivity is verified
separally by scripts/ probes, not in CI.
"""

from __future__ import annotations

import asyncio

import pandas as pd
import pytest
import yaml

from app.config.schema import RateLimitConfig
from app.core.exceptions import ProviderConnectionError


# =========================================================== yahoo parse ==
def _yahoo_payload(n=5, base_ts=1_791_518_400, price=4200.0):
    ts = [base_ts + 60 * i for i in range(n)]
    return {
        "chart": {"result": [{
            "meta": {"symbol": "GC=F", "regularMarketPrice": price + 1,
                     "regularMarketTime": ts[-1] + 30, "currency": "USD",
                     "fullExchangeName": "COMEX"},
            "timestamp": ts,
            "indicators": {"quote": [{
                "open": [price] * n, "high": [price + 2] * n,
                "low": [price - 2] * n, "close": [price + 0.5] * n,
                "volume": [100] * n}]},
        }]}}


def test_parse_yahoo_chart_ok():
    from app.data.market.live_public import parse_yahoo_chart

    df, meta = parse_yahoo_chart(_yahoo_payload())
    assert len(df) == 5
    assert df.index.tz is not None
    assert meta["regular_market_price"] == 4201.0
    assert meta["exchange"] == "COMEX"


def test_parse_yahoo_chart_garbage_raises_honest():
    from app.data.market.live_public import parse_yahoo_chart

    with pytest.raises(ProviderConnectionError):
        parse_yahoo_chart({"chart": {"result": []}})
    with pytest.raises(ProviderConnectionError):
        parse_yahoo_chart({"chart": {"error": "bad"}})


def test_normalize_yahoo_frame_schema():
    from app.data.market.live_public import normalize_yahoo_frame, parse_yahoo_chart

    df, _ = parse_yahoo_chart(_yahoo_payload(n=3))
    out = normalize_yahoo_frame(df, spread_price=0.30)
    assert list(out.columns) == ["open", "high", "low", "close",
                                 "tick_volume", "real_volume", "spread"]
    assert (out["spread"] == 0.30).all()
    assert (out["real_volume"] == 0).all()
    assert (out["tick_volume"] == 100).all()


# ============================================================ provider ==
class _FakeHTTP:
    """Monkeypatch target: records calls, returns canned payloads."""
    def __init__(self, fail=False):
        self.calls: list[tuple[str, str]] = []
        self.fail = fail

    def __call__(self, url, timeout):
        self.calls.append((url, timeout))
        if self.fail:
            raise ProviderConnectionError("network down")
        if "query1.finance.yahoo.com" in url:
            n = 400 if "range=5d" in url else (3000 if "range=60d" in url
                                               else (2000 if "range=730d" in url else 500))
            payload = _yahoo_payload(n=n, base_ts=1_791_518_400 - n * 60)
            # parse_yahoo_chart expects enough rows; shrink columns accordingly
            return payload
        return {"price": 4183.6, "updatedAt": "2026-10-09T04:25:10Z"}


@pytest.fixture()
def provider(monkeypatch):
    from app.data.market.live_public import LivePublicProvider

    p = LivePublicProvider(refresh_seconds=30, spread_points=30,
                           start_refresh_thread=False)
    fake = _FakeHTTP()
    monkeypatch.setattr("app.data.market.live_public._http_get_json", fake)
    return p, fake


def test_provider_connect_and_full_schema(provider):
    p, _ = provider
    assert p.connect() is True
    assert p.is_connected()
    for tf in ("M1", "M5", "M15", "M30", "H1", "H4", "D1"):
        df = p.get_candles("XAUUSD", tf, 50)
        assert list(df.columns) == ["open", "high", "low", "close",
                                    "tick_volume", "real_volume", "spread"]
        assert df.index.is_monotonic_increasing
        assert (df["spread"] == 0.30).all()


def test_provider_tick_spread_from_assumption(provider):
    p, _ = provider
    p.connect()
    tick = p.get_tick("XAUUSD")
    assert tick.ask - tick.bid == pytest.approx(0.30)
    assert tick.bid < tick.last < tick.ask


def test_provider_refresh_merges_without_duplicates(provider):
    p, _ = provider
    p.connect()
    n1 = len(p.get_candles("XAUUSD", "M1", 100000))
    p.refresh()                       # same fake timestamps → no dupes
    m1 = p.get_candles("XAUUSD", "M1", 100000)
    assert len(m1) == n1
    assert m1.index.is_unique


def test_provider_degraded_but_serves_cache(provider):
    p, fake = provider
    p.connect()
    fake.fail = True                  # network dies after seeding
    p.refresh()
    assert p.is_degraded
    assert p.last_error
    # cached data still served — honest staleness, not fabrication
    df = p.get_candles("XAUUSD", "M5", 10)
    assert len(df) == 10


def test_provider_connect_fails_honest_when_no_data(monkeypatch):
    from app.data.market.live_public import LivePublicProvider

    monkeypatch.setattr("app.data.market.live_public._http_get_json",
                        _FakeHTTP(fail=True))
    p = LivePublicProvider(start_refresh_thread=False)
    with pytest.raises(ProviderConnectionError):
        p.connect()
    assert not p.is_connected()


def test_provider_market_open_freshness(provider):
    import time as _time
    from app.data.market.live_public import LivePublicProvider

    p, _ = provider
    p.connect()
    # fake meta regular_market_time is "now-ish" (fixed epoch) → manipulate
    p._meta["regular_market_time"] = _time.time() - 60
    assert p.market_open() is True
    p._meta["regular_market_time"] = _time.time() - 3600   # stale → closed
    assert p.market_open() is False


def test_provider_end_time_filter(provider):
    p, _ = provider
    p.connect()
    full = p.get_candles("XAUUSD", "M5", 100000)
    cut = p.get_candles("XAUUSD", "M5", 100000,
                        end_time=full.index[-3].to_pydatetime())
    assert len(cut) == len(full) - 2


def test_provider_snapshot_shape(provider):
    p, _ = provider
    p.connect()
    snap = p.snapshot()
    for key in ("price", "market_open", "spot", "degraded", "frames",
                "spread_points", "source"):
        assert key in snap
    assert snap["price"] == 4201.0     # meta price wins (freshest)
    assert snap["spot"] == 4183.6


# ==================================================== gateway cooldown ==
class _RateLimitedProvider:
    name = "p1"
    model = "fake"
    calls = 0

    async def aclose(self):
        return None


def test_gateway_cooldown_skips_http_and_counts_neutral():
    from app.ai.gateway import AIGateway
    from app.ai.schemas import AIOutput
    from app.config.schema import AIConfig

    gw = AIGateway(AIConfig(enabled=True))
    calls = {"n": 0}

    async def _call(provider, state, news):
        calls["n"] += 1
        raise exc_429()

    def exc_429():
        from app.core import exceptions as e
        return e.AIRateLimitError("p1: 429")

    gw.providers = {"p1": _RateLimitedProvider()}
    gw.order = ["p1"]
    gw._call = _call

    r1 = asyncio.run(gw.analyze({"price": 1.0}))
    assert r1.degraded and r1.attempts_made == 1
    assert calls["n"] == 1

    # second call within cooldown → NO http attempt, attempts_made == 0
    r2 = asyncio.run(gw.analyze({"price": 1.0}))
    assert r2.degraded and r2.attempts_made == 0
    assert calls["n"] == 1                       # provider not re-hit
    assert any("COOLDOWN" in e for e in r2.errors)
    # cooldown status visible for the panel
    assert gw.provider_status()["p1"]["cooldown_left_s"] > 0


def test_rate_limit_config_has_cooldown_field():
    cfg = RateLimitConfig()
    assert cfg.rate_limit_cooldown_s == 120.0


# ===================================================== loop mode resolve ==
def test_resolve_mode_falls_back_gracefully():
    from app.panel.loop_manager import TradingLoopManager

    mode, note = TradingLoopManager._resolve_mode("mt5-readonly", "simulated")
    assert mode == "paper" and note and "fell back" in note

    mode, note = TradingLoopManager._resolve_mode("mt5-readonly", "public")
    assert mode == "paper" and note

    mode, note = TradingLoopManager._resolve_mode("auto", "mt5")
    assert mode == "mt5-readonly" and note is None

    mode, note = TradingLoopManager._resolve_mode("auto", "public")
    assert mode == "paper" and note is None

    mode, note = TradingLoopManager._resolve_mode("paper", "public")
    assert mode == "paper" and note is None


# ================================================== provider settings IO ==
def _mini_config(tmp_path):
    cfg = tmp_path / "config.yaml"
    cfg.write_text(yaml.safe_dump({
        "app_name": "xau-ai-trader",
        "provider": {"kind": "simulated", "simulated_days": 90},
        "ai": {"enabled": True, "providers": [{"name": "zai", "enabled": True,
                                               "api_key_env": "ZAI_API_KEY"}],
               "rate_limit": {"enabled": True, "max_retries": 1,
                              "rate_limit_cooldown_s": 150}},
    }), encoding="utf-8")
    return cfg


def test_save_provider_settings_roundtrip(tmp_path):
    from app.panel.settings_store import AISettingsStore

    store = AISettingsStore(tmp_path, str(_mini_config(tmp_path)))
    r = store.save_provider_settings({"kind": "public",
                                      "public_spread_points": 25})
    assert r["ok"] and r["kind"] == "public"
    data = yaml.safe_load(store.config_path.read_text(encoding="utf-8"))
    assert data["provider"]["kind"] == "public"
    assert data["provider"]["public_spread_points"] == 25.0
    # untouched sections survive
    assert data["ai"]["providers"][0]["name"] == "zai"
    # backups created
    assert list(tmp_path.glob("config.yaml.bak-*"))


def test_save_provider_settings_rejects_bad_kind(tmp_path):
    from app.panel.settings_store import AISettingsStore, SettingsStoreError

    store = AISettingsStore(tmp_path, str(_mini_config(tmp_path)))
    with pytest.raises(SettingsStoreError):
        store.save_provider_settings({"kind": "moon-data"})


def test_save_ai_settings_preserves_rate_limit(tmp_path):
    from app.panel.settings_store import AISettingsStore

    store = AISettingsStore(tmp_path, str(_mini_config(tmp_path)))
    payload = {
        "ai": {"enabled": True, "require_ai_for_trade": True,
               "on_all_fail": "WAIT", "failover_order": ["zai"]},
        "providers": [{"name": "zai", "enabled": True,
                       "api_key_env": "ZAI_API_KEY", "model": "glm-4.6"}],
    }
    r = store.save_ai_settings(payload)
    assert r["ok"]
    data = yaml.safe_load(store.config_path.read_text(encoding="utf-8"))
    assert data["ai"]["rate_limit"]["rate_limit_cooldown_s"] == 150
