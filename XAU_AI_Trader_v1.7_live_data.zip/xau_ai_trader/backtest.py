#!/usr/bin/env python3
"""PHASE 58 — backtest.py: run the backtester on trained models.

Usage: python backtest.py [--config config.yaml] [--out reports/backtest.json]

⚠ SIMULATED-data backtests say nothing about real-market performance
(PHASE 63 — no profit claims; results are reported as backtest results only).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from app.config.loader import load_config
from app.config.schema import Regime
from app.core.logging import setup_logging


def classify_regime(features: pd.DataFrame, i: int, cfg) -> Regime:
    adx = features["adx"].iloc[i]
    if adx >= cfg.regime.adx_trend_min:
        return Regime.TRENDING_BULL if features["di_diff"].iloc[i] > 0 else Regime.TRENDING_BEAR
    if features["atr_pct"].iloc[i] >= cfg.regime.high_vol_atr_pct:
        return Regime.HIGH_VOLATILITY
    if features["atr_pct"].iloc[i] <= cfg.regime.low_vol_atr_pct:
        return Regime.LOW_VOLATILITY
    return Regime.RANGING


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=None)
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    from app.backtest.engine import Backtester
    from app.data.market.simulated import SimulatedProvider
    from app.models.train_service import build_frames, load_bundle, load_hmm, make_feature_builder
    from app.news.engine import NewsEngine
    from app.news.providers import MockNewsProvider
    from app.pipeline import AnalysisPipeline
    from app.regime.engine import RegimeEngine
    from app.risk.sizing import calc_lot
    from app.signals.ensemble import SignalEnsemble

    provider = SimulatedProvider(days=cfg.provider.simulated_days, seed=cfg.provider.simulated_seed + 1,
                                 start_price=cfg.provider.simulated_start_price,
                                 annual_vol=cfg.provider.simulated_annual_vol)
    provider.connect()
    frames = build_frames(provider, cfg)
    bundle = load_bundle(cfg)
    fb = make_feature_builder(cfg)

    pipeline = AnalysisPipeline(cfg, provider, fb, RegimeEngine(cfg.regime),
                                NewsEngine(MockNewsProvider(""), cfg.news), bundle, load_hmm(cfg))
    md = pipeline.fetch(cfg.symbol.primary)
    features, names = fb.build(md.frames, cfg.timeframes.base)
    X = features[names]

    # vectorised calibrated predictions over the full causal feature matrix
    probs = bundle.average_proba(X.fillna(0.0))

    base = md.frames[cfg.timeframes.base.value]
    smc_bias = fb.smc_engine.analyze(base, cfg.timeframes.base.value) \
        .directional_bias_series(cfg.features.event_recent_bars)

    ensemble = SignalEnsemble(cfg.ensemble)
    news_engine = NewsEngine(MockNewsProvider(""), cfg.news)  # deterministic, offline
    atr = features["atr"]
    close = base["close"]
    info = provider.get_symbol_info(cfg.symbol.primary)

    sig_index: list = []
    sig_data: list[dict] = []
    for i in range(0, len(X), 5):
        ts = X.index[i]
        row_probs = np.array([probs[i, 0], probs[i, 1], probs[i, 2]])
        news = news_engine.assess(ts.to_pydatetime())
        regime = classify_regime(features, i, cfg)
        decision = ensemble.decide(
            ml_probs={"ens": row_probs},
            smc_bias=float(smc_bias.iloc[i]) if i < len(smc_bias) else 0.0,
            regime=regime, news_risk=news.risk,
        )
        if not decision.is_actionable:
            continue
        a = atr.iloc[i]
        if np.isnan(a) or a <= 0:
            continue
        entry = close.iloc[i]
        sign = 1.0 if decision.side == "BUY" else -1.0
        sl = entry - sign * cfg.risk.atr_sl_mult * a
        sl_dist = abs(entry - sl)
        if sl_dist <= 0:
            continue
        tp = entry + sign * cfg.risk.min_rr * sl_dist
        lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent, sl_dist, info)
        if lot <= 0:
            continue
        sig_index.append(ts)
        sig_data.append({"side": decision.side, "sl": float(sl), "tp": float(tp),
                         "lot": lot, "score": decision.score})
    signals = pd.DataFrame(sig_data, index=pd.DatetimeIndex(sig_index))

    bt = Backtester(cfg.backtest, info,
                    commission_per_lot=cfg.execution.commission_per_lot,
                    swap_long=cfg.execution.swap_long_per_lot,
                    swap_short=cfg.execution.swap_short_per_lot,
                    slippage_points=cfg.execution.slippage_points)
    result = bt.run(base, signals)

    print("=" * 64)
    print("BACKTEST RESULT — SIMULATED DATA (not indicative of live performance)")
    print("=" * 64)
    for k, v in result.summary.items():
        print(f"  {k:>22}: {v}")
    if result.monthly is not None and len(result.monthly):
        print("\nMonthly P/L:")
        print(result.monthly.to_string(index=False))

    out = Path(args.out or Path(cfg.paths.reports_dir) / "backtest_report.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "summary": result.summary,
        "monthly": result.monthly.to_dict(orient="records") if result.monthly is not None else [],
        "disclaimer": "Simulated-data backtest. NOT a profit claim.",
    }, indent=2, default=str), encoding="utf-8")
    print(f"\n[backtest] report → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
