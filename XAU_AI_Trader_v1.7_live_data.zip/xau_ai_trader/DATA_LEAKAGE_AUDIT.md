# DATA_LEAKAGE_AUDIT.md — PHASE 50

This document records every leakage vector considered, its mitigation, the
enforcing code, and the test that proves it. The programmatic audit
(`app/models/leakage.py`) runs the same checks before every training run.

## 1. Feature leakage (future data in inputs)

| Vector | Risk | Mitigation | Enforcement |
|---|---|---|---|
| Indicator look-ahead | Rolling/EMA outputs accidentally centred or shifted backwards | All indicators are trailing-only (`rolling(...).mean()`, `ewm`, `shift(1)` for previous-bar refs). No negative shifts on outputs | `tests/test_indicators.py::test_rsi_causal`, `test_atr_positive_and_causal` |
| Higher-timeframe leakage | An M5 row at 10:10 uses the H1 bar stamped 10:00 that only *closes* at 11:00 | `align_higher_tf` shifts HTF rows by one bar **before** reindex-ffill, so an HTF bar stamped T is only visible from T+tf | `tests/test_features.py::test_align_shifts_one_bar`, `test_htf_alignment_never_uses_incomplete_bar` |
| Whole-matrix leakage | Any feature row at time t changes when future candles are appended | Causal-recompute audit: features rebuilt on truncated frames must be identical at t | `tests/test_features.py::test_no_future_leakage` (also `check_causal_features` in `app/models/leakage.py`) |
| SMC event features | Detection algorithms that need `right` bars of confirmation emitting at the pivot bar | Swings emit `right` bars later (`shift(right)`); BOS/CHoCH/sweeps emitted on the confirming close | `tests/test_smc.py::test_swing_detection_confirms_later` |
| Label-aware features | Features derived from label statistics (e.g. target encoding by future class) | No feature is derived from labels anywhere in the builder | code review + causal audit covers it |

## 2. Label leakage

| Vector | Risk | Mitigation | Enforcement |
|---|---|---|---|
| Horizon overrun | Labels computed beyond data end silently reuse nothing / or mis-scan | Last `horizon` bars are label-free (forced 0) | `tests/test_labels_leakage.py::test_labels_never_use_last_horizon_bars` + `check_label_horizon` |
| Same-bar ambiguity | TP and SL both inside one future bar → optimistic labelling | Configurable `ambiguous: zero` (default) treats the bar as NO_EDGE; `sl_first` available (conservative) | `tests/test_labels_leakage.py::test_flat_market_labels_no_edge` |
| ATR in barriers | Barrier computed with *future* ATR | Barriers use ATR at time t only (causal feature column) | `app/models/train_service.py::build_xy` |
| Feature/label misalignment | Label of t+H merged onto row t+H (inverted merge) | Labels are indexed at the **decision** bar t; merge is inner-join on t | `check_label_alignment` + dataset assembly |

## 3. Train/test contamination

| Vector | Risk | Mitigation | Enforcement |
|---|---|---|---|
| Overlapping label windows at split boundary | Label at t uses bars up to t+H; a train sample adjacent to the test start leaks test-window outcomes | **Purge** = drop train/val samples within `purge_bars` (≥ label horizon) of the split boundary; **Embargo** = drop train samples `embargo_bars` after each validation fold | `purged_kfold`, `temporal_split`, `check_split_purity`; `tests/test_labels_leakage.py::test_purged_kfold_no_overlap`, `test_split_purity_check` |
| Scaler fitted on full data | Test statistics leak into train normalisation | Scaler (`Robust`/`Standard`) fit on **train rows only**; audit recomputes train-only stats and compares centers | `check_scaler_leakage`; `tests/test_labels_leakage.py` (purity) + `app/models/train_service.py` |
| Walk-forward reuse | Test segment re-used for training in later folds | Each fold trains strictly on indices before its validation/test windows; test indices never enter any fit | `walk_forward_splits`; walkforward.py |
| Optuna overfitting | Hyperparams tuned directly on test | Objective measured on the test segment **with an overfit-gap penalty** (val→test accuracy gap) and a warning to confirm via walk-forward | `optimize.py` |

## 4. Timestamp / session leakage

| Vector | Risk | Mitigation | Enforcement |
|---|---|---|---|
| Timezone mismatch | Broker server time vs UTC shifts features/session flags | All internal timestamps are tz-aware UTC; MT5 offset configurable (`mt5.server_utc_offset_hours`); quality checker flags tz-naive frames as errors | `tests/test_quality_news_regime.py::test_quality_tz_naive_is_error` |
| Duplicate/out-of-order bars | Bars arriving twice or out of order distort rolling stats | Quality checker errors on duplicates/non-monotonic index → WAIT | `tests/test_quality_news_regime.py::test_quality_duplicates_detected` |
| In-progress live bar | Predictions computed on a forming candle | Pipelines use provider-closed candles only; live loop predicts on the last completed M5 bar | `tests/test_features.py::test_align_shifts_one_bar` |

## 5. Normalization leakage

- Fit: `_fit_scaler(X.iloc[train_idx])` — train rows only.
- Apply: same stored statistics applied to val/test/live.
- Audit: `check_scaler_leakage` recomputes train-only centers and fails on >5% mismatch.

## 6. Audit verdict

- Programmatic audit (`app/models/leakage.py`) — **implemented, runs pre-training**.
- Proving test suite — **119/119 passing**, including the two strongest
  guarantees: *causal feature recompute* and *purge/embargo purity*.
- Honest limitation: the causal audit samples `probe_points` timestamps
  (default 3) per run rather than exhaustively hashing all rows — full-matrix
  equivalence is covered by the deterministic construction of the pipeline
  itself (pure functions of past data only).
