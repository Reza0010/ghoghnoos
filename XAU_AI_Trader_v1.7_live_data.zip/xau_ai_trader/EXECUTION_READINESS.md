# EXECUTION_READINESS — XAU AI Trader v1.5

**Verdict: PAPER-READY / DEMO-GATED. Live execution remains HARD-REFUSED in
`main.py`.** The order path is now structurally safe, but broker-native
verification requires a Windows MT5 host and has not been exercised in this
release (Linux CI + simulated provider only).

## 1. Execution changes (OLD → NEW)

| Aspect | OLD | NEW | WHY | EVIDENCE |
|--------|-----|-----|-----|----------|
| Order retry policy | `MT5Executor` re-sent ANY `ExecutionError`/`OrderRejectedError` up to 3× (double-order risk; reproduced with NO_MONEY and TIMEOUT retcodes) | Single-send contract. Only the provider's bounded loop retries — and only RETRYABLE retcodes, with price refresh AND `order_check` re-run per attempt. AMBIGUOUS retcodes (TIMEOUT 10012, CONNECTION 10031) raise `AmbiguousOrderError` — never retried. | Blind retries of ambiguous outcomes can duplicate positions; rejections cannot succeed by re-sending | `app/execution/mt5_exec.py`; provider `_send_with_policy`; audit reproduction log |
| Order state machine | none (fire-and-forget) | INTENT → PRECHECK → ORDER_CHECK → SEND → ACK → RECONCILE → FILLED/REJECTED/UNKNOWN; UNKNOWN blocks all new orders until `reconcile_unknown()` verifies journal vs broker positions | Mission 2/16 | executor tests + journal `events` table |
| Idempotency | comment carried the score (`|s0.62`), uncorrelatable | comment carries `sid<signal_id>` + intent uuid; journal INSERT (no REPLACE) so duplicate tickets RAISE | reconciliation must be able to map deals → intents | `trader.py`; `journal.py` |
| order_check on retry | old check + new price + blind send | `order_check` re-run after every price refresh | stops/money validity is price-dependent | provider `_send_with_policy` |
| Tick-value provenance | heuristic `contract_size*point` silently substituted | `tick_value_is_fallback` flag; LIVE risk paths WAIT on fallback | wrong tick value corrupts lot sizing | `market/models.py`; provider |
| Stop-distance | `stops_level`/`freeze_level` captured but never enforced | risk engine validates SL/TP distance ≥ broker stops-level pre-approval | order_check rejections after approval are now impossible-by-construction | `risk/engine.py` + test |
| Live tick fallback | synthetic candle-derived tick accepted | LIVE raises DataError → WAIT; synthetic ticks paper-only | SL/TP must never be sized off invented prices | `trader._tick` |
| News/HTTP/Telegram blocking | sync httpx inside the async loop (10 s stall each) | async bridges (`get_events_async`, `notify_async` via `to_thread`) | Mission 40 | news/telegram modules |
| Swap semantics | charged any hour ≥ 21:00 UTC incl. same-evening opens; no triple-swap | charged AT rollover instant only; post-rollover opens exempt; Wednesday ×3 | broker rollover parity (Mission 20) | `paper.py`, `backtest/engine.py` |

## 2. Reconciliation & failsafe wiring

- `reconcile_positions` (PHASE 66 §21) is now invoked by the executor after
  any UNKNOWN outcome; the trade block lifts only on a consistent report.
- Journal failures are no longer silently swallowed by the loop's broad
  handlers: ORDER_INTENT/UNKNOWN/ACK/REJECTED events are recorded in a
  dedicated `events` table (WAL enabled as the docstring always claimed).
- Residual: the full `FailSafeState` matrix (HALT on JOURNAL_FAILURE etc.)
  is wired into the executor path; the loop-level failsafe aggregator is
  documented as the next integration step.

## 3. Demo-gate checklist (must pass on the MT5 host before ANY demo send)

1. `scripts/mt5_demo_execution_test.py` — success, requote, timeout, disconnect,
   ambiguous, invalid-stop, insufficient-margin scenarios (FakeMT5 harness
   exists for CI; broker behaviour must be re-verified live).
2. Broker-native math verification: `order_calc_margin` / `order_calc_profit`
   outputs vs the heuristic gate on the real symbol spec (finding 26 closure).
3. `trade_stops_level`, `freeze_level`, `filling_mode` read from the real
   symbol and exercised through the risk gate.
4. Server UTC offset measured (`scripts/download_mt5_data.py`), DST plan
   recorded, `data/raw` re-downloaded with the measured offset.
5. News provider: pluggable real calendar adapter configured (static CSV is
   offline-only), `provider: none` ⇒ WAIT verified in the demo config.

## 4. Honest limitations

- No real broker order was sent in this release (Linux environment).
- `backtest` ↔ `live` parity: the decision engine is shared and the backtest
  adapter models spread/slippage/commission/swap with explicit units, but
  tick-level replay and latency simulation remain OHLC-conservative.
- The demo executor path (`scripts/mt5_demo_execution_test.py`) is the ONLY
  sanctioned route toward live; it requires human-confirmed env flags
  (`execution.live_trading_enabled=true`, `<live_confirm_env>=YES`).
