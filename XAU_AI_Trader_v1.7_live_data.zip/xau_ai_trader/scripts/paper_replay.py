#!/usr/bin/env python3
"""PHASE 65 (§18/§19) — Paper-trading REPLAY on real data + paper-vs-backtest.

Simulates the ONLINE trading loop bar-by-bar over the most recent real M15
window (the trader never sees future bars: every decision uses data sliced at
``end_time=bar_close``). Every signal — including WAIT with reasons — is
journaled. No real orders are sent (PAPER only).

Then compares replay-paper behaviour with the vectorised backtest on the same
window (§19): signal frequency, fills, spread/cost handling, execution delay.

Usage: python scripts/paper_replay.py [--bars 400] [--config config_real.yaml]
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.config.schema import Regime
from app.core.logging import setup_logging


def classify_regime(features: pd.DataFrame, i: int, cfg) -> Regime:
    adx = features["adx"].iloc[i]
    if adx >= cfg.regime.adx_trend_min:
        return Regime.TRENDING_BULL if features["di_diff"].iloc[i] > 0 else Regime.TRENDING_BEAR
    if features["atr_pct"].iloc[i] >= cfg.regime.high_vol_atr_pct:
        return Regime.HIGH_VOLATILITY
    if features["atr_pct"].iloc[i] <= cfg.regime.low_vol_atr_pct:
        return Regime.LOW_VOLATILITY
    return Regime.RANGING


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--bars", type=int, default=400)
    parser.add_argument("--relaxed", action="store_true",
                        help="use the relaxed evaluation gate (0.40/0.08/0.40) so the "
                             "paper-vs-backtest comparison has actionable signals")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    from app.ai.testing import ml_side_from_state
    from app.data.market.models import SymbolInfo
    from app.data.market.replay import ReplayProvider
    from app.data.multi_tf import MarketData, MultiTimeframeEngine
    from app.models.train_service import load_bundle, make_feature_builder
    from app.news.engine import NewsAssessment
    from app.config.schema import NewsRisk
    from app.regime.engine import RegimeEngine
    from app.risk.sizing import calc_lot
    from app.signals.ensemble import SignalEnsemble
    from app.smc.engine import SMCEngine

    rd = cfg.real_data
    symbol = rd.symbol
    provider = ReplayProvider.from_raw_dir(rd.raw_dir, symbol, rd.timeframes)
    provider.connect()
    info = SymbolInfo(name=symbol, **cfg.symbol.fallback_symbol_info.model_dump())
    bundle = load_bundle(cfg, registry_tag="real")
    fb = make_feature_builder(cfg)
    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    smc_engine = fb.smc_engine or SMCEngine(cfg.smc)
    ens_update = {"min_ml_confidence": cfg.ensemble.min_ml_confidence,
                  "ml_conflict_margin": cfg.ensemble.ml_conflict_margin,
                  "min_score": cfg.ensemble.min_score}
    gate_label = "primary (conservative)"
    if args.relaxed:
        ens_update = {"min_ml_confidence": 0.40, "ml_conflict_margin": 0.08,
                      "min_score": 0.40}
        gate_label = "relaxed (evaluation only)"
    ensemble = SignalEnsemble(cfg.ensemble.model_copy(update=ens_update))
    news = NewsAssessment(risk=NewsRisk.LOW, reasons=["NEWS_NEUTRAL_PAPER_ASSUMPTION"])

    base_tf = cfg.timeframes.base.value
    full = provider.full_range(base_tf)
    replay_ts = full.index[-args.bars:-cfg.labels.horizon_bars]
    print(f"[paper] replaying {len(replay_ts)} REAL {base_tf} bars "
          f"({replay_ts[0]} → {replay_ts[-1]}) — no real orders are sent")

    # ------------------------------------------------------------ replay ----
    journal_rows: list[dict] = []
    fills: list[dict] = []
    open_pos = None
    t0 = time.perf_counter()
    for n, ts in enumerate(replay_ts):
        try:
            md = mtf.fetch(symbol, end_time=ts)
        except Exception as e:
            journal_rows.append({"ts": str(ts), "action": "WAIT",
                                 "reasons": [f"DATA_ERROR:{type(e).__name__}"]})
            continue
        quality = md.worst_score()
        if quality < cfg.quality.min_score:
            journal_rows.append({"ts": str(ts), "action": "WAIT",
                                 "reasons": [f"DATA_QUALITY_{quality:.0f}"]})
            continue
        features, names = fb.build(md.frames, cfg.timeframes.base)
        smc = smc_engine.analyze(md.frames[base_tf], base_tf)
        ml_probs = bundle.predict(features.iloc[[-1]].fillna(0.0))
        ml_probs = {k: v[0] for k, v in ml_probs.items()}
        regime = RegimeEngine(cfg.regime).classify(features.iloc[-1], None, None, 0.0)
        decision = ensemble.decide(
            ml_probs=ml_probs,
            smc_bias=float(smc.directional_bias()[0]),
            regime=regime.regime, news_risk=news.risk)
        price = float(md.frames[base_tf]["close"].iloc[-1])
        atr = float(features.iloc[-1].get("atr", 0.0) or 0.0)
        entry = {"ts": str(ts), "action": decision.side, "price": price,
                 "score": round(decision.score, 3), "reasons": decision.reasons[:4],
                 "regime": regime.regime.value, "quality": round(quality, 1)}
        if decision.is_actionable and open_pos is None and atr > 0:
            sign = 1.0 if decision.side == "BUY" else -1.0
            sl = price - sign * cfg.risk.atr_sl_mult * atr
            dist = abs(price - sl)
            tp = price + sign * cfg.risk.min_rr * dist
            lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent, dist, info)
            if lot > 0:
                entry.update({"sl": round(sl, 2), "tp": round(tp, 2), "lot": lot})
                # simulated fill at NEXT bar open (execution delay, spread+slippage)
                nxt = full.index[full.index.get_loc(ts) + 1]
                nxt_bar = full.loc[nxt]
                sprd = float(cfg.backtest.assumed_spread)
                fill = float(nxt_bar["open"]) + sprd / 2 + cfg.execution.slippage_points * info.point \
                    if decision.side == "BUY" \
                    else float(nxt_bar["open"]) - sprd / 2 - cfg.execution.slippage_points * info.point
                open_pos = {"side": decision.side, "entry_ts": str(nxt), "entry": fill,
                            "sl": sl, "tp": tp, "lot": lot, "signal_ts": str(ts)}
                fills.append(open_pos)
                entry["action"] = f"FILLED_{decision.side}"
        elif open_pos is not None:
            bar = full.loc[ts]
            side = open_pos["side"]
            hit_sl = bar["low"] <= open_pos["sl"] if side == "BUY" else bar["high"] >= open_pos["sl"]
            hit_tp = bar["high"] >= open_pos["tp"] if side == "BUY" else bar["low"] <= open_pos["tp"]
            if hit_sl or hit_tp:
                px = open_pos["sl"] if hit_sl else open_pos["tp"]
                d = 1.0 if side == "BUY" else -1.0
                pnl = (px - open_pos["entry"]) * d / info.tick_size * info.tick_value * open_pos["lot"] \
                    - cfg.execution.commission_per_lot * open_pos["lot"]
                fills[-1].update({"exit_ts": str(ts), "exit_price": px,
                                  "exit_reason": "SL" if hit_sl else "TP", "pnl": round(pnl, 2)})
                open_pos = None
        journal_rows.append(entry)
        if (n + 1) % 100 == 0:
            print(f"  {n+1}/{len(replay_ts)} bars replayed ({time.perf_counter() - t0:.0f}s)")
            # incremental checkpoint (long replays must survive timeouts)
            Path(cfg.paths.reports_dir).mkdir(parents=True, exist_ok=True)
            Path(cfg.paths.reports_dir, "paper_replay_journal.jsonl").write_text(
                "\n".join(json.dumps(r, default=str) for r in journal_rows), encoding="utf-8")

    actions = pd.Series([r["action"] for r in journal_rows])
    waits = int((actions == "WAIT").sum())
    trades = [f for f in fills if "exit_reason" in f]
    print(f"[paper] journal: {len(journal_rows)} bars → WAIT={waits}, "
          f"fills={len(fills)}, closed={len(trades)}")

    # ------------------------------------------- paper vs backtest (§19) ----
    # same window through the vectorised backtester for comparison
    from app.backtest.engine import Backtester

    warm = full.index[max(0, full.index.get_loc(replay_ts[0]) - 200)]
    window = full[full.index >= warm]
    bt_sig = pd.DataFrame(
        [{"side": f["side"], "sl": f["sl"], "tp": f["tp"], "lot": f["lot"],
          "score": 0.5} for f in fills],
        index=pd.DatetimeIndex([f["signal_ts"] for f in fills]))
    bt = Backtester(cfg.backtest, info,
                    commission_per_lot=cfg.execution.commission_per_lot,
                    slippage_points=cfg.execution.slippage_points,
                    assumed_spread=cfg.backtest.assumed_spread)
    bt_res = bt.run(window, bt_sig)

    paper_pnl = sum(f.get("pnl", 0.0) for f in fills)
    bt_pnl = bt_res.summary.get("net_pl", 0.0)
    comparison = {
        "paper_signals": len(fills),
        "paper_closed_trades": len(trades),
        "paper_net_pnl_est": round(paper_pnl, 2),
        "backtest_trades": bt_res.summary.get("n_trades"),
        "backtest_net_pnl": round(bt_pnl, 2),
        "signal_frequency_per_day": round(len(fills) /
                                          max(1e-9, (replay_ts[-1] - replay_ts[0]).total_seconds() / 86400), 2),
        "spread_source": bt.spread_source,
        "execution_delay": f"1 bar ({cfg.timeframes.base.value}); paper simulates "
                           "order at next-bar open, backtester identical (§26)",
        "notes": [
            "Both engines use the same documented assumed_spread (dataset has no broker spread).",
            "Paper-vs-backtest differences here measure engine consistency, NOT live behaviour.",
            "True live paper trading requires MT5 on Windows (app/trader.py, mode=paper).",
        ],
    }
    print(f"[paper-vs-backtest] signals={len(fills)} vs trades={bt_res.summary.get('n_trades')}; "
          f"pnl={paper_pnl:.2f} vs {bt_pnl:.2f}")

    out = Path(cfg.paths.reports_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "paper_replay_journal.jsonl").write_text(
        "\n".join(json.dumps(r, default=str) for r in journal_rows), encoding="utf-8")
    report = {
        "phase": "65 §18/§19 — paper replay on real data",
        "generated": datetime.now(timezone.utc).isoformat(),
        "mode": "PAPER (no real orders sent — provider is read-only by design)",
        "window": {"bars": len(replay_ts), "start": str(replay_ts[0]), "end": str(replay_ts[-1])},
        "gate": gate_label,
        "journal_summary": {"bars": len(journal_rows), "wait": waits,
                            "fills": len(fills), "closed": len(trades),
                            "actions": actions.value_counts().to_dict()},
        "fills": fills,
        "paper_vs_backtest": comparison,
        "disclaimer": "Replay paper results on real historical data — NOT live "
                      "performance; live paper requires MT5/Windows.",
    }
    (out / "paper_replay_report.json").write_text(json.dumps(report, indent=2, default=str),
                                                  encoding="utf-8")
    print(f"[paper] report → {out / 'paper_replay_report.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
