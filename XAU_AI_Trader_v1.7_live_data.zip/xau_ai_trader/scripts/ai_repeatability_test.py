#!/usr/bin/env python3
"""PHASE 66 (§15) — AI REPEATABILITY test on identical market states.

≥100 identical real market states, each sent MULTIPLE times (default 2) with
the cache DISABLED (no fake consistency). Measures per pair:

  - JSON validity / schema validity
  - action consistency (same decision)
  - confidence consistency (|Δconfidence|)
  - reasoning consistency (normalised token overlap)
  - latency, token usage

Hard rules verified here: invalid JSON → WAIT, AI unavailable → WAIT,
confidence below threshold → WAIT (enforced downstream in the gateway/ensemble
— this test documents the observed rates).

Output: reports/ai_repeatability.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.core.logging import setup_logging


def _norm_tokens(s: str) -> set[str]:
    return set(re.findall(r"[a-z]+", (s or "").lower()))


async def run(cfg, n_states: int, repeats: int, offset: int = 0,
              pacing: float = 4.5) -> dict:
    import os

    from app.ai.bootstrap import load_zai_credentials_into_env
    from app.ai.gateway import AIGateway
    from app.ai.testing import build_state_at_time, sample_state_timestamps
    from app.config.schema import AIConfig, AIProviderSettings
    from app.data.market.replay import ReplayProvider
    from app.data.multi_tf import MultiTimeframeEngine
    from app.models.train_service import load_bundle, make_feature_builder

    cred = load_zai_credentials_into_env(None)
    if not cred and not os.environ.get("ZAI_API_KEY"):
        return {"status": "NOT_RUN",
                "reason": "no AI credentials (ZAI_API_KEY) — nothing faked (§15/§30)",
                "live_trading": "remains disabled"}

    provider = ReplayProvider.from_raw_dir(cfg.real_data.raw_dir, cfg.real_data.symbol,
                                           cfg.real_data.timeframes)
    provider.connect()
    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    mtf.fetch(cfg.real_data.symbol)
    bundle = load_bundle(cfg, registry_tag="real")
    fb = make_feature_builder(cfg)

    t0 = time.perf_counter()
    ts_list_all = sample_state_timestamps(provider, cfg, offset + n_states)
    ts_list = ts_list_all[offset:offset + n_states]
    states = []
    for ts in ts_list:
        st = build_state_at_time(cfg, provider, bundle, ts, mtf=mtf, feature_builder=fb)
        if st:
            states.append(st)
    build_s = time.perf_counter() - t0
    print(f"built {len(states)} identical states in {build_s:.0f}s")
    if len(states) < 100:
        print("WARNING: fewer than 100 states available — results marked limited")

    base_url = os.environ.get("ZAI_BASE_URL", "https://api.z.ai/api/paas/v4")
    ai_cfg = AIConfig(enabled=True, require_ai_for_trade=False, cache_ttl_seconds=0,
                      providers=[AIProviderSettings(
                          name="zai", api_key_env="ZAI_API_KEY", base_url=base_url,
                          model=os.environ.get("ZAI_MODEL", "glm-4.6"),
                          timeout_seconds=45.0, max_requests_per_day=100000,
                          extra_headers_env="ZAI_EXTRA_HEADERS")],
                      failover_order=["zai"])
    gateway = AIGateway(ai_cfg)

    rows, pairs = [], []
    try:
        for si_abs, st in enumerate(states):
            si = offset + si_abs          # global state index for merged reports
            responses = []
            for rep in range(repeats):
                t1 = time.perf_counter()
                try:
                    res = await gateway.analyze(st, [])
                    # rate-limited (429→degraded): back off and retry once so the
                    # repeatability sample is fair — the 429 itself is recorded
                    retries = 0
                    while res.degraded and retries < 1:
                        retries += 1
                        await asyncio.sleep(15.0 * retries)
                        res = await gateway.analyze(st, [])
                    lat = (time.perf_counter() - t1) * 1000
                    if res.degraded:
                        rows.append({"state": si, "rep": rep, "json_valid": False,
                                     "schema_valid": False, "degraded": True,
                                     "retries": retries,
                                     "latency_ms": round(lat, 1)})
                        responses.append(None)
                        continue
                    o = res.output
                    usage = getattr(gateway, "_last_usage", None) or {}
                    rows.append({
                        "state": si, "rep": rep, "json_valid": True, "schema_valid": True,
                        "decision": o.decision, "confidence": round(float(o.confidence), 3),
                        "reasoning_tokens": len(_norm_tokens(getattr(o, "reasoning", ""))),
                        "tokens_in": usage.get("prompt_tokens"), "tokens_out": usage.get("completion_tokens"),
                        "latency_ms": round(lat, 1)})
                    responses.append(o)
                except Exception as e:
                    rows.append({"state": si, "rep": rep, "json_valid": False,
                                 "schema_valid": False, "error": str(e)[:120],
                                 "latency_ms": round((time.perf_counter() - t1) * 1000, 1)})
                    responses.append(None)
                await asyncio.sleep(pacing)   # pacing — internal gateway rate limit
            ok = [r for r in responses if r is not None]
            if len(ok) == 2:
                a, b = ok
                tok_a, tok_b = _norm_tokens(getattr(a, "reasoning", "")), \
                    _norm_tokens(getattr(b, "reasoning", ""))
                pairs.append({
                    "state": si,
                    "same_action": a.decision == b.decision,
                    "conf_delta": round(abs(float(a.confidence) - float(b.confidence)), 3),
                    "reasoning_overlap": round(len(tok_a & tok_b) / max(1, len(tok_a | tok_b)), 3)})
            if (si + 1) % 20 == 0:
                print(f"  {si+1}/{len(states)} states sent x{repeats}")
    finally:
        await gateway.aclose()

    df = __import__("pandas").DataFrame(rows)
    pdf = __import__("pandas").DataFrame(pairs)
    valid = df[df.get("json_valid") == True] if "json_valid" in df else df.iloc[0:0]  # noqa: E712
    result = {
        "phase": "66 §15 — AI repeatability (identical states, cache disabled)",
        "generated": datetime.now(timezone.utc).isoformat(),
        "status": "OK" if len(pdf) else "NO_PAIRS",
        "n_states": int(len(states)), "repeats_per_state": repeats,
        "total_calls": int(len(rows)),
        "json_valid_rate": round(float(df["json_valid"].mean()), 4) if len(df) else None,
        "schema_valid_rate": round(float(df["schema_valid"].mean()), 4) if len(df) else None,
        "action_consistency": round(float(pdf["same_action"].mean()), 4) if len(pdf) else None,
        "confidence_delta_mean": round(float(pdf["conf_delta"].mean()), 4) if len(pdf) else None,
        "confidence_delta_p95": round(float(pdf["conf_delta"].quantile(0.95)), 4) if len(pdf) else None,
        "reasoning_overlap_mean": round(float(pdf["reasoning_overlap"].mean()), 4) if len(pdf) else None,
        "latency_ms_mean": round(float(df["latency_ms"].mean()), 1) if len(df) else None,
        "latency_ms_p95": round(float(df["latency_ms"].quantile(0.95)), 1) if len(df) else None,
        "tokens_per_call_mean": (round(float(valid[["tokens_in", "tokens_out"]]
                                            .dropna().sum(axis=1).mean()), 1)
                                 if len(valid) and valid["tokens_in"].notna().any() else None),
        "safety_rules": {
            "invalid_json": "→ gateway degrades → system WAITs (no numeric decision depends on it)",
            "ai_unavailable": "→ WAIT",
            "confidence_below_threshold": "→ WAIT (ensemble gate)"},
        "note": "The numerical trading decision NEVER depends on free-form reasoning text "
                "(§15). Reasoning consistency is measured for diagnostics only.",
        "records": rows,
    }
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--states", type=int, default=100)
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--out-suffix", default="")
    parser.add_argument("--pacing", type=float, default=4.5)
    args = parser.parse_args()
    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)
    report = asyncio.run(run(cfg, args.states, args.repeats, args.offset, args.pacing))
    out = Path(cfg.paths.reports_dir) / f"ai_repeatability{args.out_suffix}.json"
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print(f"[repeatability] status={report['status']} "
          f"action_consistency={report.get('action_consistency')} "
          f"json_valid_rate={report.get('json_valid_rate')} → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
