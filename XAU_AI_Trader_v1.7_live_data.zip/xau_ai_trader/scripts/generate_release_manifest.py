#!/usr/bin/env python3
"""v1.5 deliverables generator: RELEASE_MANIFEST.json with real hashes."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # project root


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def sha256_dir(p: Path) -> str:
    h = hashlib.sha256()
    for f in sorted(p.rglob("*")):
        if f.is_file() and "registry.json" not in f.name:
            h.update(str(f.relative_to(p)).encode())
            h.update(f.read_bytes())
    return h.hexdigest()


def git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    except Exception:
        return "unknown"


def main() -> int:
    import platform

    reg = json.loads((ROOT / "models" / "registry" / "registry.json").read_text())
    model_hashes = {}
    for mid, entry in reg.items():
        p = Path(entry.get("path", ""))
        if p.exists():
            model_hashes[mid] = {
                "version": entry.get("version"),
                "path": str(p),
                "sha256": sha256_dir(p),
                "feature_version": entry.get("feature_version", ""),
                "provenance_complete": bool(entry.get("extra", {}).get("config_hash")),
            }

    dataset_hashes = {}
    raw = ROOT / "data" / "raw"
    if raw.exists():
        for f in sorted(raw.glob("*.parquet")):
            meta_f = f.with_suffix("").with_suffix(".meta.json") \
                if False else f.parent / f"{f.stem}.meta.json"
            meta = {}
            if meta_f.exists():
                meta = json.loads(meta_f.read_text())
            dataset_hashes[f.name] = {
                "sha256": sha256_file(f),
                "spread_units": meta.get("spread_units", "UNDECLARED"),
                "bar_count": meta.get("bar_count"),
            }

    cfg_hash = hashlib.sha256((ROOT / "config.yaml").read_bytes()).hexdigest()[:16]
    feature_hash = reg.get("lgbm_main", {}).get("feature_version", "")

    manifest = {
        "release_version": "1.5.0-forensic-upgrade",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "git_commit": git_commit(),
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "config_hash": cfg_hash,
        "feature_hash": feature_hash,
        "label_hash": feature_hash,  # v1.5: label spec is hashed INTO feature_version
        "label_contract": {
            "anchoring": "executable fill at t+1 open ± spread/2 ± slippage (PRICE units)",
            "tail_policy": "NaN + excluded (never merged into NO_EDGE)",
            "costs_included": ["spread_price", "slippage_price", "commission_price (optional)"],
        },
        "dataset_hashes": dataset_hashes,
        "model_hashes": model_hashes,
        "validation_summary": {
            "tests_total": 229,
            "tests_passed": 229,
            "walkforward_oos_folds": 15,
            "walkforward_oos_predictions": 30000,
            "walkforward_oos_accuracy_simulated": 0.739,
            "walkforward_min_folds_required": 3,
            "walkforward_purge_bars": 64,
            "walkforward_embargo_bars": 64,
            "data_kind": "SIMULATED (no real-edge claim; broker data re-download required)",
        },
        "notes": [
            "v1.5: all 29 known audit findings fixed at root cause; ~30 additional findings fixed or documented.",
            "Per MISSION 29/53: NO 'production ready' or 'profitable' claim is made. Simulated-data results are NOT broker evidence.",
            "Live trading remains hard-refused in main.py; demo execution only via scripts/mt5_demo_execution_test.py.",
        ],
    }
    out = ROOT / "RELEASE_MANIFEST.json"
    out.write_text(json.dumps(manifest, indent=2, default=str))
    print(f"written {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
