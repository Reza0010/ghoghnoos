#!/usr/bin/env python3
"""PHASE 65 (§7/§8/§16/§23) — REAL-DATA validation orchestrator.

Pipeline (all stages run on REAL market data from data/raw):

    Raw Data → Validation → Feature Engineering → SMC → Labels
    → strict temporal split (TRAIN/VAL/TEST, no random) → Train
    → Calibration → Walk-Forward → OOS Backtest
    → Session / Period / Monthly breakdowns → Feature drift (PSI/KS)
    → reports/real_validation_summary.json

Nothing here touches synthetic data; model artifacts are registered under the
``*_real`` tag so they can never be confused with unit-test models.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.config.schema import Regime
from app.core.logging import setup_logging


def classify_regime(features: pd.DataFrame, i: int, cfg) -> Regime:
    adx = features["adx"].iloc[i]
    if adx >= cfg.regime.adx_trend_min:
        return Regime.TRENDING_BULL if features["di_diff"].iloc[i] > 0 else Regime.TRENDING_BEAR
    if features["atr_pct"].iloc[i] >= cfg.regime.high_vol_atr_pct:
        return Regime.HIGH_VOLATILITY
    if features["atr_pct"].iloc[i] <= cfg.regime.low_vol_atr_pct:
        return Regime.LOW_VOLATILITY
    return Regime.RANGING


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--skip-walkforward", action="store_true")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)
    t_start = time.perf_counter()

    rd = cfg.real_data
    symbol = rd.symbol

    # ---------------------------------------------------------------- data --
    from app.data.market.replay import ReplayProvider
    from app.data.dataset_meta import load_metadata
    from app.data.multi_tf import MultiTimeframeEngine

    provider = ReplayProvider.from_raw_dir(rd.raw_dir, symbol, rd.timeframes)
    provider.connect()
    from app.data.market.models import SymbolInfo

    info = SymbolInfo(
        name=symbol, **cfg.symbol.fallback_symbol_info.model_dump(),
    )
    metas = {tf: load_metadata(Path(rd.raw_dir) / f"{symbol}_{tf}.parquet")
             for tf in provider.timeframes}
    print("=" * 72)
    print("REAL-DATA VALIDATION — source-labelled (PHASE 65)")
    print("=" * 72)
    for tf, m in metas.items():
        print(f"  {tf}: {m.bar_count} REAL bars | source={m.source} | {m.instrument[:44]}")

    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    md = mtf.fetch(symbol)
    quality_summary = {tf: {"score": q.score, "passed": q.passed,
                            "stats": q.stats} for tf, q in md.quality.items()}
    worst = md.worst_score()
    print(f"  quality: worst={worst:.0f} — " + ("PASS" if worst >= cfg.quality.min_score else "FAIL"))
    if worst < cfg.quality.min_score:
        print("[validation] data quality below threshold — REAL validation aborted (§28)")
        return 1

    # ------------------------------------------------------ features/labels --
    from app.models.train_service import (build_xy, clean_feature_frame,
                                          make_feature_builder, temporal_split,
                                          train_models)
    from app.smc.engine import SMCEngine

    fb = make_feature_builder(cfg)
    features, labels, close, fversion = build_xy(cfg, md.frames, fb)
    dataset = clean_feature_frame(features, labels)
    n = len(dataset)
    if n < cfg.dataset.min_rows:
        print(f"[validation] dataset too small ({n} < {cfg.dataset.min_rows}) — §31: "
              "downloader/adapter/pipeline stay ready; validation awaits more real data")
        return 1
    X = dataset.drop(columns=["label"])
    y = (dataset["label"].astype(int) + 1).astype(int).values

    # ------------------------------------------- strict split (no random!) --
    train_idx, val_idx, test_idx = temporal_split(n, cfg)
    split_info = {
        "method": "strict_temporal (train 70% → val 15% → test 15%, purge+embargo)",
        "rows": {"train": int(len(train_idx)), "val": int(len(val_idx)), "test": int(len(test_idx))},
        "train_range": [str(dataset.index[train_idx[0]]), str(dataset.index[train_idx[-1]])],
        "val_range": [str(dataset.index[val_idx[0]]), str(dataset.index[val_idx[-1]])],
        "test_range": [str(dataset.index[test_idx[0]]), str(dataset.index[test_idx[-1]])],
    }
    print(f"  split: TRAIN {split_info['train_range'][0][:16]} → {split_info['train_range'][1][:16]} "
          f"({len(train_idx)}) | VAL ({len(val_idx)}) | "
          f"TEST {split_info['test_range'][0][:16]} → {split_info['test_range'][1][:16]} ({len(test_idx)})")

    # --------------------------------------------------------------- train --
    out = train_models(cfg, md.frames, register=True, registry_tag="real")
    print(f"  train: leakage audit {'PASS' if out.audit.all_passed else 'FAIL'}; "
          f"LGBM test acc={out.metrics['lgbm_test']['accuracy']:.3f} "
          f"auc={out.metrics['lgbm_test']['roc_auc_ovr']:.3f}; "
          f"XGB test acc={out.metrics['xgb_test']['accuracy']:.3f}")
    audit_detail = [{"name": c.name, "passed": c.passed, "detail": c.detail} for c in out.audit.checks]

    # --------------------------------------------------------- walk-forward --
    wf_report = {"skipped": True}
    if not args.skip_walkforward:
        from app.models.dataset import _apply_scaler, _fit_scaler
        from app.models.lgbm_model import LGBMModel
        from app.models.validation import classification_metrics, walk_forward_splits
        from app.models.xgb_model import XGBModel

        wf = walk_forward_splits(n, cfg.validation.walk_forward_train_bars,
                                 cfg.validation.walk_forward_val_bars,
                                 cfg.validation.walk_forward_test_bars,
                                 cfg.validation.walk_forward_step_bars)
        if not wf:
            print("[validation] not enough rows for walk-forward windows — reduce "
                  "walk_forward_* in config_real.yaml")
        else:
            folds, agg_ok, agg_n = [], 0, 0
            for k, (tr, va, te) in enumerate(wf):
                scaler = _fit_scaler(X.iloc[tr], cfg.dataset.scaler)
                Xs = _apply_scaler(X, scaler)
                lgbm = LGBMModel(cfg.lgbm)
                lgbm.fit(Xs.iloc[tr], y[tr], Xs.iloc[va], y[va])
                xgb = XGBModel(cfg.xgb)
                xgb.fit(Xs.iloc[tr], y[tr], Xs.iloc[va], y[va])
                probs = (lgbm.predict_proba(Xs.iloc[te]) + xgb.predict_proba(Xs.iloc[te])) / 2.0
                m = classification_metrics(y[te], probs)
                folds.append({"fold": k,
                              "train_window": [str(dataset.index[tr[0]])[:16], str(dataset.index[tr[-1]])[:16]],
                              "test_window": [str(dataset.index[te[0]])[:16], str(dataset.index[te[-1]])[:16]],
                              "metrics": m})
                agg_ok += int((probs.argmax(axis=1) == y[te]).sum())
                agg_n += len(te)
                print(f"  wf fold {k}: acc={m['accuracy']:.3f} f1={m['f1_macro']:.3f} n={len(te)}")
            wf_report = {"skipped": False, "n_folds": len(wf),
                         "oos_accuracy": agg_ok / max(1, agg_n),
                         "oos_predictions": agg_n, "folds": folds}
            print(f"  walk-forward OOS accuracy: {wf_report['oos_accuracy']:.3f} over {agg_n} predictions")

    # ------------------------------------------------- OOS backtest (test) --
    from app.backtest.engine import Backtester
    from app.risk.sizing import calc_lot
    from app.signals.ensemble import SignalEnsemble

    probs_all = out.bundle.average_proba(X)
    base = md.frames[cfg.timeframes.base.value]
    smc_engine = fb.smc_engine or SMCEngine(cfg.smc)
    smc_bias = smc_engine.analyze(base, cfg.timeframes.base.value) \
        .directional_bias_series(cfg.features.event_recent_bars)

    from app.news.engine import NewsAssessment
    from app.config.schema import NewsRisk

    news = NewsAssessment(risk=NewsRisk.LOW,
                          reasons=["NEWS_NEUTRAL_ASSUMPTION_REAL_BACKTEST (real provider "
                                   "NOT IMPLEMENTED — §11; disclosed in report)"])
    atr = features["atr"]
    test_ts = dataset.index[test_idx]
    atr_by_ts = atr.reindex(dataset.index)
    close_by_ts = close.reindex(dataset.index)

    def build_signals(min_ml_conf: float, margin: float, min_score: float) -> pd.DataFrame:
        ens_cfg = cfg.ensemble.model_copy(
            update={"min_ml_confidence": min_ml_conf, "ml_conflict_margin": margin,
                    "min_score": min_score})
        ens = SignalEnsemble(ens_cfg)
        sig_index, sig_rows = [], []
        for ts in test_ts[::5]:
            i = dataset.index.get_loc(ts)
            row_probs = np.array([probs_all[i, 0], probs_all[i, 1], probs_all[i, 2]])
            pos = base.index.get_indexer([ts], method="nearest")[0]
            regime = classify_regime(features, pos, cfg)
            decision = ens.decide(
                ml_probs={"ens": row_probs},
                smc_bias=float(smc_bias.iloc[pos]) if pos < len(smc_bias) else 0.0,
                regime=regime, news_risk=news.risk,
            )
            if not decision.is_actionable:
                continue
            a = atr_by_ts.iloc[i]
            if np.isnan(a) or a <= 0:
                continue
            entry = float(close_by_ts.iloc[i])
            sign = 1.0 if decision.side == "BUY" else -1.0
            sl = entry - sign * cfg.risk.atr_sl_mult * float(a)
            sl_dist = abs(entry - sl)
            if sl_dist <= 0:
                continue
            tp = entry + sign * cfg.risk.min_rr * sl_dist
            lot = calc_lot(cfg.backtest.initial_balance, cfg.risk.risk_percent, sl_dist, info)
            if lot <= 0:
                continue
            sig_index.append(ts)
            sig_rows.append({"side": decision.side, "sl": float(sl), "tp": float(tp),
                             "lot": lot, "score": decision.score})
        return pd.DataFrame(sig_rows, index=pd.DatetimeIndex(sig_index))

    def run_bt(sig: pd.DataFrame):
        window = base[base.index >= bt_start]
        b = Backtester(cfg.backtest, info,
                       commission_per_lot=cfg.execution.commission_per_lot,
                       swap_long=cfg.execution.swap_long_per_lot,
                       swap_short=cfg.execution.swap_short_per_lot,
                       slippage_points=cfg.execution.slippage_points,
                       assumed_spread=cfg.backtest.assumed_spread)
        return b, b.run(window, sig)

    bt_start = base.index[base.index.get_indexer([test_ts[0]], method="nearest")[0] - 100]

    # primary = configured (conservative) thresholds — WAIT-first philosophy
    signals = build_signals(cfg.ensemble.min_ml_confidence,
                            cfg.ensemble.ml_conflict_margin, cfg.ensemble.min_score)
    bt, result = run_bt(signals)
    s = result.summary
    print("-" * 72)
    print(f"  REAL-DATA OOS BACKTEST — {symbol} (test segment only, PRIMARY thresholds)")
    print(f"  trades={s.get('n_trades')}  win_rate={s.get('win_rate')}  PF={s.get('profit_factor')}  "
          f"expectancy={s.get('expectancy')}  MaxDD={s.get('max_drawdown_pct')}%")
    print(f"  spread source: {bt.spread_source}  (dataset has no broker spread — §26)")
    if s.get("n_trades", 0) == 0:
        print("  → 0 trades at configured thresholds: the ensemble correctly returned "
              "WAIT everywhere on real data (Directive 0). A threshold sensitivity "
              "grid below provides evaluation metrics at relaxed gates.")

    # threshold sensitivity (evaluation only — clearly labelled)
    from app.analytics.periods import label_periods, session_breakdown as _sess
    from app.analytics.periods import period_breakdown as _per

    labels_per = label_periods(base["close"], features["atr_pct"])

    sensitivity = []
    grid = [(0.45, 0.10, 0.45), (0.40, 0.08, 0.40), (0.35, 0.06, 0.35)]
    for mlc, marg, msc in grid:
        sig_v = build_signals(mlc, marg, msc)
        res_v = run_bt(sig_v)[1]
        sv = res_v.summary
        tdf_v = res_v.trades_df()
        sensitivity.append({"min_ml_confidence": mlc, "ml_conflict_margin": marg,
                            "min_score": msc, "n_signals": int(len(sig_v)), "summary": sv,
                            "sessions": _sess(tdf_v, cfg.sessions),
                            "periods": _per(tdf_v, labels_per)})
        print(f"  sensitivity conf<{mlc:.2f}/margin<{marg:.2f}/score<{msc:.2f}: "
              f"signals={len(sig_v)} trades={sv.get('n_trades')} PF={sv.get('profit_factor')} "
              f"wr={sv.get('win_rate')} MaxDD={sv.get('max_drawdown_pct')}%")

    # -------------------------------------- sessions / periods / monthly ----
    from app.analytics.periods import period_breakdown, segment_summary, session_breakdown
    tdf = result.trades_df()
    sessions = session_breakdown(tdf, cfg.sessions)
    periods = period_breakdown(tdf, labels_per)
    monthly = result.monthly.to_dict(orient="records") if result.monthly is not None else []

    # ---------------------------------------------------------- drift §23 --
    from app.monitoring.drift import FeatureDriftMonitor, ks_statistic, psi

    monitor = FeatureDriftMonitor(X.iloc[train_idx], cfg.drift.psi_warn,
                                  cfg.drift.psi_action, cfg.drift.feature_drift_ratio_warn)
    drift = monitor.report(X.iloc[test_idx])
    ks_top = sorted(
        ((c, round(ks_statistic(X.iloc[train_idx][c].values, X.iloc[test_idx][c].values), 4))
         for c in X.columns[:60]),
        key=lambda t: -t[1])[:10]

    # ------------------------------------------------------------ report --
    reports_dir = Path(cfg.paths.reports_dir)
    reports_dir.mkdir(parents=True, exist_ok=True)
    report = {
        "phase": "65 — real-world validation",
        "generated": datetime.now(timezone.utc).isoformat(),
        "data_kind": "REAL (public gold market data) — NOT synthetic, NOT broker XAUUSD",
        "datasets": {tf: {k: v for k, v in m.model_dump().items() if k != "extra"}
                     for tf, m in metas.items()},
        "broker_specs": "NOT AVAILABLE — MT5 (Windows) required (§6); retail-CFD sizing "
                        "model is a documented assumption",
        "quality": quality_summary,
        "split": split_info,
        "leakage_audit": audit_detail,
        "ml_metrics": out.metrics,
        "feature_version": fversion,
        "walk_forward": wf_report,
        "backtest": {
            "test_segment_only": True,
            "n_signals": len(signals),
            "summary": s,
            "threshold_sensitivity_evaluation_only": sensitivity,
            "spread_source": bt.spread_source,
            "cost_assumptions": {
                "assumed_spread": cfg.backtest.assumed_spread,
                "slippage_points": cfg.execution.slippage_points,
                "commission_per_lot": cfg.execution.commission_per_lot,
                "swap_long": cfg.execution.swap_long_per_lot,
                "swap_short": cfg.execution.swap_short_per_lot,
            },
            "news_assumption": "NEWS-NEUTRAL (real provider NOT IMPLEMENTED §11)",
            "monthly": monthly,
            "sessions": sessions,
            "periods": periods,
        },
        "period_segments": segment_summary(labels_per),
        "drift": {"feature_drift": drift, "ks_top": ks_top},
        "disclaimer": "Real-data backtest results. NOT a profit claim; costs partly "
                      "assumed (no broker spread data); live behaviour unproven.",
    }
    out_file = reports_dir / "real_validation_summary.json"
    out_file.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")

    # trades csv for downstream AB / paper comparisons
    if not tdf.empty:
        tdf.to_csv(reports_dir / "real_backtest_trades.csv", index=False)

    print(f"  sessions: {json.dumps({k: v['trades'] for k, v in sessions.items()})}")
    print(f"  drift verdict: {drift['verdict']} (ratio={drift['drift_ratio']})")
    print(f"[validation] report → {out_file}  ({time.perf_counter() - t_start:.0f}s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
