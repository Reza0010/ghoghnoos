#!/usr/bin/env python3
"""PHASE 65 (§23/§24) — data & model drift report on REAL data.

Data drift   : PSI + KS between the TRAINING feature window and the most
               recent real-data window (train vs latest 15%).
Model drift  : rolling performance over the last 50/100/200 trades of the
               real backtest journal (reports/real_backtest_trades.csv).

Output: reports/drift_report.json with an explicit SAFE_MODE/WARNING/NORMAL
recommendation. NO automatic retraining happens anywhere (§25) — drift is a
Human-Review trigger only.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.core.logging import setup_logging


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    from app.data.market.models import SymbolInfo
    from app.data.market.replay import ReplayProvider
    from app.data.multi_tf import MultiTimeframeEngine
    from app.models.train_service import (build_xy, clean_feature_frame,
                                          make_feature_builder, temporal_split)
    from app.monitoring.drift import FeatureDriftMonitor, ks_statistic, psi

    rd = cfg.real_data
    provider = ReplayProvider.from_raw_dir(rd.raw_dir, rd.symbol, rd.timeframes)
    provider.connect()
    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    md = mtf.fetch(rd.symbol)
    fb = make_feature_builder(cfg)
    features, labels, close, _ = build_xy(cfg, md.frames, fb)
    dataset = clean_feature_frame(features, labels)
    n = len(dataset)
    train_idx, val_idx, test_idx = temporal_split(n, cfg)
    # model drift needs the most recent window — use latest 15% even if the
    # strict test split is short
    recent = dataset.index[-max(len(test_idx), int(n * 0.15)):]
    ref = dataset.iloc[train_idx]
    cur = dataset.loc[recent]

    monitor = FeatureDriftMonitor(ref, cfg.drift.psi_warn, cfg.drift.psi_action,
                                  cfg.drift.feature_drift_ratio_warn)
    data_drift = monitor.report(cur)
    ks_top = sorted(((c, round(ks_statistic(ref[c].values, cur[c].values), 4))
                     for c in ref.columns[:60]), key=lambda t: -t[1])[:10]

    # prediction drift: ML probability distribution train vs recent
    from app.models.train_service import load_bundle

    pred_drift = None
    try:
        bundle = load_bundle(cfg, registry_tag="real")
        p_ref = bundle.average_proba(ref)
        p_cur = bundle.average_proba(cur)
        pred_drift = {
            "psi_per_class": [round(psi(p_ref[:, i], p_cur[:, i]), 4) for i in range(3)],
            "classes": ["SELL", "NO_EDGE", "BUY"],
            "mean_prob_shift": {
                "SELL": round(float(p_cur[:, 0].mean() - p_ref[:, 0].mean()), 4),
                "NO_EDGE": round(float(p_cur[:, 1].mean() - p_ref[:, 1].mean()), 4),
                "BUY": round(float(p_cur[:, 2].mean() - p_ref[:, 2].mean()), 4),
            },
        }
    except Exception as e:
        pred_drift = {"error": str(e)[:120]}

    # rolling model performance (§24)
    trades_file = Path(cfg.paths.reports_dir) / "real_backtest_trades.csv"
    rolling = {"source": str(trades_file), "windows": {}}
    if trades_file.exists():
        tdf = pd.read_csv(trades_file)
        pnls = tdf["pnl"].astype(float).tolist()
        for w in (50, 100, 200):
            if len(pnls) < w:
                rolling["windows"][str(w)] = {"status": "INSUFFICIENT_TRADES",
                                              "available": len(pnls)}
                continue
            recent_p = pnls[-w:]
            wr = float(np.mean([p > 0 for p in recent_p]))
            rolling["windows"][str(w)] = {
                "win_rate": round(wr, 3),
                "expectancy": round(float(np.mean(recent_p)), 2),
                "verdict": "NORMAL" if wr >= cfg.drift.perf_winrate_min
                else ("WARNING" if wr >= cfg.drift.perf_winrate_min / 2 else "SAFE_MODE"),
            }
    else:
        rolling["note"] = "no real-backtest trade journal yet"

    verdict = "NORMAL"
    if data_drift["verdict"] in ("WARNING", "SAFE_MODE"):
        verdict = data_drift["verdict"]

    report = {
        "phase": "65 §23/§24 — drift report",
        "generated": datetime.now(timezone.utc).isoformat(),
        "data_kind": "REAL (public gold market data)",
        "reference_window": [str(ref.index[0]), str(ref.index[-1])],
        "current_window": [str(cur.index[0]), str(cur.index[-1])],
        "data_drift": data_drift,
        "ks_top_features": ks_top,
        "prediction_drift": pred_drift,
        "model_rolling_performance": rolling,
        "overall_verdict": verdict,
        "action": {
            "NORMAL": "continue monitoring",
            "WARNING": "human review required before further trading (§25)",
            "SAFE_MODE": "enter SAFE MODE — trading disabled until human review",
        }[verdict],
        "automatic_retraining": "FORBIDDEN (§25) — drift triggers Human Review → manual retrain only",
    }
    out = Path(cfg.paths.reports_dir) / "drift_report.json"
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print(f"[drift] verdict={verdict} drift_ratio={data_drift['drift_ratio']} → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
