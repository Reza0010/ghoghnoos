#!/usr/bin/env python3
"""PHASE 65 (§5) — run the full quality suite on every REAL dataset in
data/raw and write data/data_quality_report.json.

Usage: python scripts/data_quality_report.py [--raw-dir data/raw] [--symbol GC]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.schema import Timeframe
from app.data.dataset_meta import load_metadata
from app.data.market.replay import load_price_file
from app.data.quality_suite import run_quality_suite


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", default="data/raw")
    parser.add_argument("--symbol", default=None, help="filter: dataset symbol prefix")
    args = parser.parse_args()

    raw = Path(args.raw_dir)
    files = sorted(list(raw.glob("*.parquet")) + list(raw.glob("*.csv")))
    if args.symbol:
        files = [f for f in files if f.stem.startswith(args.symbol)]
    if not files:
        print(f"no datasets in {raw} — run scripts/fetch_public_data.py or "
              "scripts/download_mt5_data.py first")
        return 1

    results = []
    for f in files:
        try:
            meta = load_metadata(f)
        except FileNotFoundError as e:
            results.append({"file": f.name, "error": str(e)})
            continue
        df = load_price_file(f)
        tf_minutes = Timeframe(meta.timeframe).minutes
        rep = run_quality_suite(df, meta, tf_minutes)
        results.append(rep)
        verdict = "PASS" if rep["runtime_score_passed"] else "REVIEW"
        print(f"[quality] {f.name:>20}: score={rep['score']:.0f} bars={rep['bar_count']} "
              f"source={rep['source']} → {verdict}")
        for name, chk in rep["checks"].items():
            if not chk["passed"]:
                print(f"            ✗ {name} ({chk['severity']}): {chk['detail']}")

    out = Path("data") / "data_quality_report.json"
    out.write_text(json.dumps({
        "generated": __import__("datetime").datetime.now(
            __import__("datetime").timezone.utc).isoformat(),
        "datasets": results,
        "rule": "SYNTHETIC data is never accepted here — only data_kind=real "
                "datasets with provenance metadata (PHASE 65 §30/§31)",
    }, indent=2, default=str), encoding="utf-8")
    print(f"[quality] report → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
