#!/usr/bin/env python3
"""PHASE 65 (§12) — REAL AI provider test against live API.

Sends N real market states (built from real gold data) through the AI gateway
and records per call: provider, model, latency, status, tokens, response JSON
validity, error. Writes reports/ai_provider_test.json.

If no credentials are available the report is written with status NOT RUN and
the reason — never fabricated.

Usage:
    python scripts/ai_provider_test.py [--config config_real.yaml] [--calls 20]
        [--zai-config /path/to/.z-ai-config]
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.core.logging import setup_logging


async def run(cfg, n_calls: int, zai_config: str | None) -> dict:
    from app.ai.bootstrap import load_zai_credentials_into_env
    from app.ai.gateway import AIGateway
    from app.config.schema import AIProviderSettings
    from app.data.market.models import SymbolInfo
    from app.data.market.replay import ReplayProvider

    cred = load_zai_credentials_into_env(zai_config)
    if not cred and not __import__("os").environ.get("ZAI_API_KEY"):
        return {"status": "NOT_RUN", "reason": "no AI credentials — set ZAI_API_KEY "
                "(or pass --zai-config). Nothing was faked (PHASE 65 §12/§31)."}

    provider = ReplayProvider.from_raw_dir(
        cfg.real_data.raw_dir, cfg.real_data.symbol, cfg.real_data.timeframes)
    provider.connect()
    info = SymbolInfo(name=cfg.real_data.symbol,
                      **cfg.symbol.fallback_symbol_info.model_dump())

    from app.models.train_service import load_bundle

    bundle = load_bundle(cfg, registry_tag="real")

    from app.ai.testing import build_state_at_time, sample_state_timestamps

    ts_list = sample_state_timestamps(provider, cfg, n_calls * 2)[:n_calls]
    states = []
    for ts in ts_list:
        st = build_state_at_time(cfg, provider, bundle, ts)
        if st:
            states.append(st)
    if not states:
        return {"status": "NOT_RUN", "reason": "could not build real market states"}

    from app.config.schema import AIConfig

    base_url = __import__("os").environ.get("ZAI_BASE_URL", "https://api.z.ai/api/paas/v4")
    ai_cfg = AIConfig(enabled=True, require_ai_for_trade=False, providers=[
        AIProviderSettings(
            name="zai", api_key_env="ZAI_API_KEY", base_url=base_url,
            model=__import__("os").environ.get("ZAI_MODEL", "glm-4.6"),
            timeout_seconds=45.0, max_requests_per_day=10000,
            extra_headers_env="ZAI_EXTRA_HEADERS",
        )], failover_order=["zai"], cache_ttl_seconds=0)
    gateway = AIGateway(ai_cfg)
    report_calls = []
    ok = invalid = 0
    latencies, tokens_in, tokens_out = [], 0, 0
    t0 = time.perf_counter()
    for k, st in enumerate(states):
        t_call = time.perf_counter()
        status, err, model_used, provider_used = "ERROR", "", None, None
        usage = {}
        json_valid = False
        try:
            res = await gateway.analyze(st, [])
            provider_used = res.provider
            model_used = getattr(gateway.providers.get(res.provider), "model", None)
            status = "DEGRADED" if res.degraded else "OK"
            json_valid = not res.degraded
            usage = getattr(gateway.providers.get(res.provider), "_last_usage", None) or {}
            if not res.degraded:
                ok += 1
            else:
                invalid += 1
        except Exception as e:
            err = str(e)[:120]
            invalid += 1
        lat = int((time.perf_counter() - t_call) * 1000)
        latencies.append(lat)
        tokens_in += int(usage.get("input_tokens") or 0)
        tokens_out += int(usage.get("output_tokens") or 0)
        report_calls.append({
            "i": k, "state_time": st.get("state_time"), "provider": provider_used,
            "model": model_used, "latency_ms": lat, "status": status,
            "json_valid": json_valid, "input_tokens": usage.get("input_tokens"),
            "output_tokens": usage.get("output_tokens"), "error": err,
        })
        print(f"  call {k+1}/{len(states)}: {status} {lat}ms "
              f"in={usage.get('input_tokens')} out={usage.get('output_tokens')} {err}")
    await gateway.aclose()

    n = len(states)
    return {
        "status": "OK",
        "provider": "zai",
        "model": __import__("os").environ.get("ZAI_MODEL", "glm-4.6"),
        "endpoint_host": base_url.split("//")[-1].split("/")[0],
        "credential_source": cred.get("source", "env"),
        "n_calls": n,
        "ok": ok, "invalid": invalid,
        "error_rate": round(invalid / max(1, n), 3),
        "avg_latency_ms": int(np.mean(latencies)) if latencies else 0,
        "p95_latency_ms": int(np.percentile(latencies, 95)) if latencies else 0,
        "total_input_tokens": tokens_in,
        "total_output_tokens": tokens_out,
        "wall_seconds": round(time.perf_counter() - t0, 1),
        "note": "REAL API calls on real market states (public gold data). "
                "Keys stay in env/config — never logged.",
        "calls": report_calls,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--calls", type=int, default=20)
    parser.add_argument("--zai-config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)
    report = asyncio.run(run(cfg, args.calls, args.zai_config))
    out = Path(cfg.paths.reports_dir) / "ai_provider_test.json"
    out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    print(f"[ai_provider_test] status={report.get('status')} → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
