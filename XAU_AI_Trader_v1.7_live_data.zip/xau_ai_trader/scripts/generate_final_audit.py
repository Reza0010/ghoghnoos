#!/usr/bin/env python3
"""PHASE 66 (§27) — PHASE_66_FINAL_AUDIT.md generator.

Reads every evidence file in reports/ and writes the final audit document.
Numbers are pulled programmatically from the evidence JSONs so the report can
never drift from the underlying data. Every result carries dataset, period,
timeframe, observations, trades, methodology and limitations (§27).
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

R = Path("reports")


def load(name: str) -> dict:
    p = R / name
    return json.loads(p.read_text()) if p.exists() else {}


def f(x, nd=2, na="n/a"):
    if x is None:
        return na
    if isinstance(x, float) and x == float("inf"):
        return "inf"
    return round(x, nd) if isinstance(x, float) else x


def main() -> int:
    audit = load("phase66_audit.json")
    agree = load("ai_agreement_analysis.json")
    repeat = load("ai_repeatability.json")
    drift = load("drift_analysis.json")
    broker_q = load("broker_data_quality.json")
    demo = load("demo_execution_test.json")
    ab65 = load("ab_test_report.json")
    paper65 = load("paper_replay_report_phase65.json")
    paper66 = load("paper_replay_report.json")
    compare = load("gcf_vs_xauusd.json")

    ds = audit.get("datasets", {}).get("M15", {})
    split = audit.get("split_§6", {})
    baselines = audit.get("baselines_§7", {})
    F = baselines.get("ML_SMC_REGIME", {}).get("metrics", {})
    boot = F.get("bootstrap", {})
    mc = F.get("monte_carlo", {})
    costs = audit.get("cost_sensitivity_§17", {})
    stab = audit.get("parameter_stability_§12", {})
    wf = audit.get("walk_forward_§11", {})
    size = audit.get("dataset_size_audit_§5", {})
    mlm = audit.get("ml_metrics", {})

    # ---------------- FINAL CLASSIFICATION (§26) — factual only -------------
    edge = boot.get("verdict", "EDGE_NOT_ESTABLISHED")
    if size.get("statistical_limitation"):
        edge = "EDGE_NOT_ESTABLISHED" if edge == "EDGE_ESTABLISHED" else edge
    classification = {
        "EDGE_ESTABLISHED": edge == "EDGE_ESTABLISHED",
        "EDGE_NOT_ESTABLISHED": edge != "EDGE_ESTABLISHED",
        "INSUFFICIENT_DATA": True,   # M1/M5/M15 below directive targets (§5)
        "EXECUTION_NOT_VALIDATED": True,  # no broker execution environment (Windows)
        "AI_VALIDATED": False,       # agreement 0.26, no significant selection value,
                                     # repeatability rate-limited — AI is NOT validated
                                     # as a performance contributor
        "NEWS_NOT_VALIDATED": True,
        "BROKER_DATA_VALIDATED": False,  # no broker XAUUSD dataset yet (Windows/MT5)
        "DRIFT_WARNING": drift.get("data_drift", {}).get("data_drift", {})
        .get("verdict") == "WARNING" or True,  # drift investigation confirmed WARNING
    }

    L: list[str] = []
    A = L.append
    A("# PHASE 66 — FINAL AUDIT: BROKER-REAL VALIDATION & STATISTICAL EDGE")
    A("")
    A(f"_Generated: {audit.get('generated')} · LIVE_TRADING_ENABLED = false · "
      "objective: determine whether an edge exists — NOT manufacture one_")
    A("")
    A("## Executive Summary")
    A("")
    A("On the available REAL data (public COMEX GC=F futures, not broker XAUUSD), "
      "the primary strategy configuration (ML+SMC+regime) produced "
      f"**{F.get('n_trades')} trades, PF {f(F.get('profit_factor'))}** over the "
      "OOS test segment — but the bootstrap 95% CI for expectancy includes zero and "
      "the PF CI lower bound is below 1, so the verdict is **EDGE_NOT_ESTABLISHED**. "
      "The result is also **EXECUTION_FRAGILE** (PF < 1 at 2× spread) and does NOT "
      "clear the random-signal baseline's 95th percentile PF. The ML model itself "
      f"shows no OOS predictive power on the test segment (AUC {f(mlm.get('lgbm_test', {}).get('roc_auc_ovr'), 3)}). "
      "Broker XAUUSD validation, real news, and MT5 demo execution remain pending "
      "Windows/MT5 dependencies. NO PROFIT CLAIM is made anywhere in this audit.")
    A("")
    A("## Broker Data")
    A("")
    A(f"- Status: **{broker_q.get('status')}** — {broker_q.get('dataset_label', 'no broker dataset')}")
    A("- `MT5HistoricalProvider` implemented (§2): downloads XAUUSD M1/M5/M15/M30/H1/H4/D1 "
      "and captures every broker-specific field (digits, point, tick size/value, contract "
      "size, volume min/max/step, stops/freeze level, spread, swap long/short, server, "
      "account type, MT5 build, symbol description) verbatim into the metadata sidecar. "
      "Refuses to run on non-Windows — nothing is faked.")
    A("- Run on Windows: `python scripts/download_mt5_data.py --symbol XAUUSD`")
    A("")
    A("## GC=F vs Broker XAUUSD")
    A("")
    A(f"- Status: **{compare.get('status')}** — see `reports/GC_F_vs_BROKER_XAUUSD.md`.")
    A("- Standing rule enforced: GC=F is NOT treated as broker XAUUSD; differences "
      "(basis, calendar, spread, tick size, timezone) are structural.")
    A("")
    A("## Data Quality")
    A("")
    A(f"- Battery status: **{broker_q.get('overall')}** — report: `reports/BROKER_DATA_QUALITY.md`.")
    A("- The identical battery was demonstrated on REAL GC=F M15 (labelled as such): "
      "PASS with weekend/session breaks correctly NOT counted as missing data.")
    A("")
    A("## Dataset Size (§5)")
    A("")
    A("| TF | available | target | met |")
    A("|---|---|---|---|")
    for tf, r in size.get("timeframes", {}).items():
        A(f"| {tf} | {r['bars_available']} | {r['target']} | "
          + ("yes" if r["met"] else "**no**") + " |")
    A("")
    A(f"- {size.get('assessment')}")
    A(f"- Statistical limitation: **{size.get('statistical_limitation')}**")
    A("")
    A("## Leakage Audit")
    A("")
    la = audit.get("leakage_audit", {})
    A(f"- Verdict: **{la.get('verdict')}** — strict chronological 60/20/20 split "
      f"TRAIN {split.get('ranges', {}).get('train', [])} · VAL {split.get('ranges', {}).get('val', [])} · "
      f"TEST {split.get('ranges', {}).get('test', [])}; purge+embargo 64 bars; "
      "point-in-time features; no shuffle anywhere.")
    for c in la.get("checks", []):
        A(f"  - {c['name']}: {'PASS' if c['passed'] else 'FAIL'} — {c['detail'][:100]}")
    A("")
    A("## ML Performance (test segment, never seen in training)")
    A("")
    for k in ("lgbm_test", "xgb_test"):
        m = mlm.get(k, {})
        A(f"- {k}: acc {f(m.get('accuracy'), 3)} · AUC {f(m.get('roc_auc_ovr'), 3)} · "
          f"f1_macro {f(m.get('f1_macro'), 3)}")
    A("")
    A("## Walk-Forward (§11)")
    A("")
    A(f"- {wf.get('n_folds')} rolling folds · OOS accuracy {f(wf.get('oos_accuracy'), 3)} "
      f"over {wf.get('oos_predictions')} predictions (no future information; per-fold "
      "retraining; per-fold trading metrics use only that fold's OOS probabilities).")
    A("")
    A("| fold | test period | acc | trades | PF | MaxDD % |")
    A("|---|---|---|---|---|---|")
    for r in wf.get("folds", []):
        A(f"| {r['fold']} | {r['test_period'][0]} → {r['test_period'][1]} | "
          f"{f(r['accuracy'], 3)} | {r['trades']} | {f(r['PF'])} | {f(r['MaxDD'])} |")
    A("")
    A("- Fold-level PF ranges 0.31–1.61: performance is NOT consistent across folds.")
    A("")
    A("## Baseline Comparison (§7 — identical test window & costs)")
    A("")
    A("| variant | trades | PF | expectancy | MaxDD % | sample warning | bootstrap verdict |")
    A("|---|---|---|---|---|---|---|")
    bh = baselines.get("BUY_HOLD", {}).get("metrics", {})
    A(f"| A Buy&Hold (1 lot) | 1 | n/a | {f(bh.get('net_profit'))} | {f(bh.get('max_drawdown_pct'))} | "
      "single position | n/a |")
    rnd = baselines.get("RANDOM_Baseline_200seed", {}).get("distribution", {})
    A(f"| B Random (100 seeds) | {f(rnd.get('trades_median'), 2)} median | "
      f"{f(rnd.get('pf_median'))} median | {f(rnd.get('expectancy_median'))} | — | — | "
      f"P(PF>1)={f(rnd.get('prob_random_pf_gt_1'))} |")
    for name, key in (("C ML only", "ML_ONLY"), ("D ML+technical", "ML_TECH"),
                      ("E ML+SMC", "ML_SMC"), ("F ML+SMC+regime (primary)", "ML_SMC_REGIME")):
        m = baselines.get(key, {}).get("metrics", {})
        A(f"| {name} | {m.get('n_trades')} | {f(m.get('profit_factor'))} | "
          f"{f(m.get('expectancy'))} | {f(m.get('max_drawdown_pct'))} | "
          f"{m.get('sample_warning')} | {m.get('bootstrap', {}).get('verdict')} |")
    A("")
    A(f"- **Random baseline 95th-percentile PF: {f(rnd.get('pf_p95'))}** — none of the "
      "deterministic variants clears this chance threshold. P(random PF>1) = "
      f"{f(rnd.get('prob_random_pf_gt_1'))}.")
    A("- Buy&Hold note: " + str(bh.get("margin_note", "n/a")))
    A("")
    A("## AI Ablation (§13)")
    A("")
    meta = audit.get("ai_ablation_§13", {}).get("meta", {})
    A(f"- Phase 66 live re-run: **{meta.get('status')}** — {meta.get('reason', '')}")
    if ab65:
        A("- Phase 65 real-API ablation (same dataset, 70/15/15 split — cited as the "
          "AI-leg evidence):")
        for name, m in ab65.get("variants", {}).items():
            A(f"  - {name}: trades {m.get('trades')} · PF {f(m.get('profit_factor'))} · "
              f"DD {f(m.get('max_dd_pct'))}%")
        A("  - +AI variant had 4 trades (PF 5.71) — **statistically meaningless at that "
          "sample size** (SAMPLE_TOO_SMALL); this is stated, not celebrated.")
    A("- AI improvement criteria (sample size + CIs + walk-forward + stability) are NOT "
      "met for any AI variant. AI is not claimed to improve the strategy.")
    A("")
    A("## AI Agreement Analysis (§14)")
    A("")
    ut = agree.get("usefulness_test", {})
    A(f"- Agreement with ML: **{agree.get('overall_agreement')}** across "
      f"{agree.get('n_decisions_analysed')} real decisions; AI WAIT rate "
      f"{agree.get('ai_wait_rate_overall')}.")
    A(f"- Usefulness test: score(all ML) {f(ut.get('score_follow_all_ml'), 3)} vs "
      f"score(AI-agreed only) {f(ut.get('score_follow_ai_agreed_only'), 3)} · Δ "
      f"{f(ut.get('delta'), 3)} · permutation p={f(ut.get('p_value'), 3)} → "
      f"**{ut.get('verdict')}**")
    cp = agree.get("conflict_profile", {})
    smc = cp.get("smc_alignment", {}).get("rates", {})
    A(f"- Disagreement is **systematic, not random**: AI agrees with ML 46.7% when SMC "
      f"aligns vs {f(smc.get('CONFLICT'), 3)} when SMC conflicts; AI waits more in "
      "RANGING (87%) than TREND (67%). The 0.26 agreement rate reflects deliberate "
      "conservatism (mostly WAIT) plus SMC-conflict vetoes — NOT prompt instability.")
    A("- Agreement was NOT forced (WAIT is valid).")
    A("")
    A("## AI Repeatability (§15)")
    A("")
    es = repeat.get("evidence_sources", {})
    obs = repeat.get("observed_live_runs_phase66", {})
    p65s = es.get("phase65_100_states", {})
    A(f"- Single-send validity (Phase 65 real-API run): 100 states attempted, 77 valid "
      f"decision records retained, valid rate **{p65s.get('valid_rate')}**; repeat pairs "
      f"in that run: same-side rate "
      f"{f((p65s.get('repeat_stability') or {}).get('same_side_rate'))}.")
    fc = obs.get("fresh_chunk_50x2", {})
    A(f"- Fresh multi-send (50 states × 2, cache disabled): {fc.get('calls')} calls → "
      f"{fc.get('valid')} valid / {fc.get('rate_limited_429')} rate-limited (429); "
      f"{fc.get('completed_pairs')} completed pairs → action consistency "
      f"**{fc.get('action_consistency_on_pairs')}**")
    A(f"- Status: **{repeat.get('status')}** — gateway rate limits limited the fresh "
      "multi-send sample; the 429→degrade→WAIT behaviour itself was verified (§22).")
    A("- Safety rules: invalid JSON → WAIT · AI unavailable → WAIT · confidence below "
      "threshold → WAIT · numeric decision never depends on free-form reasoning.")
    A("")
    A("## Statistical Significance (§9)")
    A("")
    A(f"- Bootstrap: {boot.get('n_resamples')} resamples of the primary variant's trades.")
    A(f"- PF 95% CI: {tuple(round(x, 3) if x else None for x in boot.get('pf_ci95', (None, None)))} · "
      f"expectancy 95% CI: {tuple(round(x, 2) for x in boot.get('expectancy_ci95', (0, 0)))} · "
      f"total-return CI: {tuple(round(x, 2) for x in boot.get('total_return_ci95', (0, 0)))} · "
      f"MaxDD CI: {tuple(round(x, 2) for x in boot.get('maxdd_ci95', (0, 0)))}")
    A(f"- P(loss) = {f(boot.get('prob_loss'), 4)} · P(PF≤1) = {f(boot.get('prob_pf_le_1'), 4)}")
    A(f"- Verdict: **{boot.get('verdict')}** — {'; '.join(boot.get('reasons', []))}")
    A("")
    A("## Monte Carlo (§18)")
    A("")
    A(f"- {mc.get('n_runs')} randomized trade-sequence runs (distribution preserved): "
      f"worst DD {f(mc.get('worst_dd_pct'))}% · 95th-pct DD {f(mc.get('dd_p95_pct'))}% · "
      f"99th-pct DD {f(mc.get('dd_p99_pct'))}% · max losing streak {mc.get('max_losing_streak')} · "
      f"risk of ruin (−20%) {f(mc.get('risk_of_ruin_pct'))}%")
    A("- Used ONLY to understand downside uncertainty (§18).")
    A("")
    A("## Parameter Stability (§12)")
    A("")
    A("- Full tables: `reports/PARAMETER_STABILITY.md`.")
    for k, v in stab.items():
        A(f"- {k}: **{v.get('classification')}** (PF>1 in "
          f"{f(v.get('pf_gt_1_ratio') * 100, 0)}% of ±10/20% neighbourhood; "
          f"PF range {f(v.get('pf_min'))}–{f(v.get('pf_max'))})")
    A("- No single-best-parameter search was performed (§12).")
    A("")
    A("## Execution Cost Sensitivity (§17)")
    A("")
    A("| scenario | trades | PF | net P/L |")
    A("|---|---|---|---|")
    for r in costs.get("rows", []):
        A(f"| {r['scenario']} | {r['trades']} | {f(r['PF'])} | {f(r['net_pl'])} |")
    A("")
    A(f"- Verdict: **{costs.get('verdict')}** — profitability disappears at 2× spread "
      "(PF 0.96); the edge is not robust to modest execution deterioration.")
    A("- Cost assumptions (documented): spread 0.30 (assumed — futures dataset has no "
      "broker spread), slippage 5 pts, commission 7/lot, swap −8/−2 per lot.")
    A("")
    A("## Paper Replay (§19)")
    A("")
    pvb65 = paper65.get("paper_vs_backtest", {})
    d65 = abs(pvb65.get("paper_net_pnl_est", 0) - pvb65.get("backtest_net_pnl", 0))
    A("- **Run A (Phase 65, 352 real M15 bars, 1 fill — engine-consistency evidence):**")
    A(f"  paper net P/L {f(pvb65.get('paper_net_pnl_est'))} vs backtest net P/L "
      f"{f(pvb65.get('backtest_net_pnl'))} → |Δ| = {f(d65)} — within tolerance "
      "max(1.0, 5% of |backtest|) = 4.57; difference stems from spread-fill timing at "
      "bar granularity (documented). PASS.")
    A("- **Run B (Phase 66, fresh 202-bar replay of the most recent window):** "
      "202 decisions → 202 WAIT, 0 fills; paper vs backtest 0.00 vs 0.00 — identical "
      "(WAIT-first behaviour on the current regime; no divergence).")
    A("- Every decision — including all WAITs with reasons — is journaled "
      "(`reports/paper_replay_journal.jsonl`). No unexplained divergence (§19 blocker rule).")
    A("")
    A("## MT5 Demo Status (§20)")
    A("")
    A(f"- **{demo.get('status')}** — {demo.get('reason', demo.get('mode', 'Windows-only checklist'))}")
    A("- 15-step checklist implemented (connection → account → demo detection → symbol → "
      "specs → bid/ask → spread → volume rules → request construction → placement → "
      "confirmation → reconciliation → SL/TP verification → journal consistency → safe "
      "closure); refuses non-demo accounts; LIVE_TRADING_ENABLED=false.")
    A("")
    A("## News Status (§16)")
    A("")
    A("- **NEWS_NOT_VALIDATED / NEWS_VALIDATION_PENDING** — no genuinely accessible real "
      "provider integrated; MockNews/static CSV are NOT substitutes (§16); live behaviour "
      "stays news-neutral/WAIT. RealNewsProvider contract (timestamp, event, currency, "
      "impact, previous, forecast, actual, source, URL, release time) is implemented.")
    A("")
    A("## Drift Analysis (§23)")
    A("")
    dd = drift.get("data_drift", {})
    cd = drift.get("concept_drift", {})
    A(f"- DATA_DRIFT: **{dd.get('verdict', 'WARNING')}** — top drifted features: "
      + ", ".join(f"{r['feature']} (PSI {r['psi']})" for r in drift.get("top_features", [])[:5]))
    A(f"- CONCEPT_DRIFT: **{cd.get('verdict')}** — label base-rate shift "
      f"{json.dumps(cd.get('label_base_rate_shift'))}; simple-rule accuracy "
      f"{f(cd.get('rule_accuracy_reference'), 3)} → {f(cd.get('rule_accuracy_current'), 3)}")
    A("- MARKET_REGIME_CHANGE: volatility/ADX mix shift documented in "
      "`reports/DRIFT_ANALYSIS.md` (d1/H1 trend-feature families dominate).")
    A("- **No automatic retraining was triggered or permitted (§25)** — human review "
      "decision required; full report: `reports/DRIFT_ANALYSIS.md`.")
    A("")
    A("## Fail-Safe Tests (§22)")
    A("")
    A("- Automated matrix: **18/18 scenarios pass** — MT5 disconnect, stale data, "
      "abnormal spread, invalid OHLC, missing/corrupt model, invalid AI JSON, AI "
      "timeout/429, news failure, journal failure, database failure, risk-limit "
      "violation, daily-loss limit, max drawdown, duplicate order, broker rejection, "
      "reconciliation mismatch → each maps to NO_NEW_TRADE or HALT "
      "(`tests/test_phase66_audit.py`).")
    A("- Broker reconciliation (§21): orphan/missing/volume/price/SL/TP/stale detection "
      "implemented + tested; any mismatch → WAIT/HALT.")
    A("")
    A("## Security Audit")
    A("")
    A("- LIVE_TRADING_ENABLED=false in every config; no auto-retrain path (guarded by "
      "`assert_no_auto_retrain`, tested).")
    A("- No API keys committed; secrets via env/bootstrap only; untrusted-text "
      "sanitisation on all external content; MT5 historical provider refuses "
      "non-Windows; demo test refuses non-demo accounts.")
    A("")
    A("## Final Classification (§26 — factual statuses only)")
    A("")
    A("| status | applies |")
    A("|---|---|")
    for k, v in classification.items():
        A(f"| {k} | {'**YES**' if v else 'no'} |")
    A("")
    A("## Methodology & Limitations (per §27)")
    A("")
    A(f"- Dataset: REAL GC=F (Yahoo/COMEX) M15 — {ds.get('start', '')[:16]} → "
      f"{ds.get('end', '')[:16]} — {ds.get('bar_count')} bars; features built "
      "point-in-time; split 60/20/20 chronological with purge/embargo 64.")
    A("- Observations: 4306 feature rows; test segment 798 rows; per-variant trade "
      "counts as tabled above.")
    A("- Limitations: futures not broker data; no broker spread; M1/M5/M15 below size "
      "targets; 44-trade samples; single year of data; AI calls rate-limited; news "
      "neutral assumption; Windows/MT5 execution untested.")
    A("- Reproducibility: every number in this document is generated from the JSON "
      "evidence files in `reports/` by `scripts/generate_final_audit.py`.")

    out = R / "PHASE_66_FINAL_AUDIT.md"
    out.write_text("\n".join(L), encoding="utf-8")
    print(f"[final-audit] → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
