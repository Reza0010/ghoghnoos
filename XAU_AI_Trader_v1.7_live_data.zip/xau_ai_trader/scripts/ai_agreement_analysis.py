#!/usr/bin/env python3
"""PHASE 66 (§14) — AI/ML agreement analysis.

Previous finding (Phase 65): AI/ML agreement ≈ 0.26 on 100 real market states.
This script investigates WHY, without forcing agreement (WAIT is valid):

  * breakdown by regime / session / volatility / trend / setup / confidence
  * usefulness test: forward triple-barrier outcome of AI-agreed vs AI-vetoed
    states (does disagreement ADD information or is it noise/conflict?)
  * classification: USEFUL_FILTERING | RANDOM_NOISE | SYSTEMATIC_CONFLICT
    | MODEL_INSTABILITY (evidence-based, honest)

Uses the Phase 65 consistency-test records (real API responses) joined with
deterministically regenerated state timestamps — no API calls needed.

Output: reports/ai_agreement_analysis.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.loader import load_config
from app.core.logging import setup_logging


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--records", default="reports/ai_consistency_test.json")
    args = parser.parse_args()

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)

    rec_path = Path(args.records)
    if not rec_path.exists():
        print(f"[agreement] missing {rec_path} — run scripts/ai_consistency_test.py first")
        return 1
    data = json.loads(rec_path.read_text())
    records = data.get("records", [])
    n_states_requested = data.get("n_states", 100)
    decisions = [r for r in records if "decision" in r and "ml_side" in r]
    errored = [r for r in records if "error" in r or r.get("degraded")]
    print(f"records={len(records)} (decisions={len(decisions)}, "
          f"errors/degraded={len(errored)}) — agreement={data.get('agreement_with_ml')}")

    # ---------------- rebuild dataset + features (deterministic) ------------
    from app.ai.testing import sample_state_timestamps
    from app.data.market.replay import ReplayProvider
    from app.data.multi_tf import MultiTimeframeEngine
    from app.features.sessions import current_session_name
    from app.models.train_service import build_xy, clean_feature_frame, make_feature_builder
    from app.smc.engine import SMCEngine

    provider = ReplayProvider.from_raw_dir(cfg.real_data.raw_dir, cfg.real_data.symbol,
                                           cfg.real_data.timeframes)
    provider.connect()
    ts_list = sample_state_timestamps(provider, cfg, n_states_requested)

    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    md = mtf.fetch(cfg.real_data.symbol)
    fb = make_feature_builder(cfg)
    features, labels, close, _ = build_xy(cfg, md.frames, fb)
    dataset = clean_feature_frame(features, labels)
    base = md.frames[cfg.timeframes.base.value]
    smc = fb.smc_engine or SMCEngine(cfg.smc)
    smc_bias = smc.analyze(base, cfg.timeframes.base.value) \
        .directional_bias_series(cfg.features.event_recent_bars)

    from app.analytics.variants import classify_regime

    # volatility terciles over the dataset for bucketing
    atr_pct = features["atr_pct"].reindex(dataset.index)
    q1, q2 = atr_pct.quantile([1 / 3, 2 / 3])

    rows = []
    for r in decisions:
        k = r["i"]
        if k >= len(ts_list):
            continue
        ts = ts_list[k]
        if ts not in dataset.index:
            pos = dataset.index.get_indexer([ts], method="nearest")
            if pos[0] < 0:
                continue
            ts = dataset.index[pos[0]]
        i = dataset.index.get_loc(ts)
        pos = base.index.get_indexer([ts], method="nearest")[0]
        regime = classify_regime(features, pos, cfg).name
        adx = float(features["adx"].iloc[pos])
        vol_bucket = ("LOW" if atr_pct.iloc[i] <= q1
                      else "HIGH" if atr_pct.iloc[i] > q2 else "MID")
        trend = "TREND" if adx >= cfg.regime.adx_trend_min else "RANGE"
        session = current_session_name(ts, cfg.sessions)
        bias = float(smc_bias.iloc[pos]) if pos < len(smc_bias) else 0.0
        smc_align = ("AGREE" if (1.0 if r["ml_side"] == "BUY" else -1.0) * np.sign(bias) > 0
                     else "CONFLICT" if bias != 0 else "NEUTRAL")
        fwd_label = int(dataset["label"].iloc[i])          # +1/0/-1 forward outcome
        conf = float(r.get("confidence", 0.0))
        rows.append({
            "i": k, "decision": r["decision"], "ml_side": r["ml_side"],
            "agrees_ml": bool(r.get("agrees_ml", False)),
            "confidence": conf,
            "conf_bucket": "ZERO" if conf == 0 else "LOW" if conf < 0.4
                           else "MID" if conf < 0.7 else "HIGH",
            "regime": regime, "session": session, "volatility": vol_bucket,
            "trend": trend, "smc_alignment": smc_align,
            "forward_label": fwd_label,
        })
    df = pd.DataFrame(rows)
    print(f"joined rows={len(df)} of {len(decisions)} decisions")

    def breakdown(col: str) -> dict:
        out = {}
        for g, sub in df.groupby(col):
            out[str(g)] = {
                "n": int(len(sub)),
                "agreement_rate": round(float(sub["agrees_ml"].mean()), 3) if len(sub) else None,
                "ai_wait_rate": round(float((sub["decision"] == "WAIT").mean()), 3),
                "mean_forward_label": round(float(sub["forward_label"].mean()), 4),
            }
        return out

    # usefulness: forward outcome when AI agrees vs vetoes/waits
    agree = df[df["agrees_ml"]]
    disagree = df[~df["agrees_ml"]]
    agree_lbl = agree["forward_label"].astype(float)
    disagree_lbl = disagree["forward_label"].astype(float)
    ml_side_lbl = df["ml_side"].map({"BUY": 1, "SELL": -1}).astype(float)
    # outcome of blindly following ML on all states vs only AI-agreed states
    follow_all = float((ml_side_lbl * df["forward_label"]).mean())
    follow_agreed = float((agree["ml_side"].map({"BUY": 1, "SELL": -1}).astype(float)
                           * agree["forward_label"]).mean()) if len(agree) else 0.0

    # block permutation test: is follow_agreed − follow_all distinguishable from 0?
    rng = np.random.default_rng(2026)
    observed = follow_agreed - follow_all
    perm = []
    pick_agree = df["agrees_ml"].values.copy()
    for _ in range(2000):
        rng.shuffle(pick_agree)
        sub = df[pick_agree]
        if len(sub) == 0:
            perm.append(0.0)
            continue
        v = float((sub["ml_side"].map({"BUY": 1, "SELL": -1}).astype(float)
                   * sub["forward_label"]).mean()) - follow_all
        perm.append(v)
    perm = np.array(perm)
    p_value = float((np.abs(perm) >= abs(observed)).mean())

    if len(agree) < 10 or len(disagree) < 10:
        usefulness = "INDETERMINATE_SAMPLE"
    elif observed > 0 and p_value < 0.05:
        usefulness = "USEFUL_FILTERING"
    elif observed < 0 and p_value < 0.05:
        usefulness = "HARMFUL_FILTERING"
    else:
        usefulness = "NO_SIGNIFICANT_SELECTION_VALUE"

    # systematic conflict: does disagreement concentrate in specific buckets?
    conflict_profile = {}
    for col in ("regime", "session", "volatility", "trend", "smc_alignment", "conf_bucket"):
        rates = {g: v["agreement_rate"] for g, v in breakdown(col).items() if v["agreement_rate"] is not None}
        if rates:
            spread = max(rates.values()) - min(rates.values())
            conflict_profile[col] = {"rates": rates, "spread": round(spread, 3)}

    result = {
        "phase": "66 §14 — AI/ML agreement analysis",
        "generated": datetime.now(timezone.utc).isoformat(),
        "source_records": str(rec_path),
        "n_decisions_analysed": int(len(df)),
        "overall_agreement": data.get("agreement_with_ml"),
        "ai_wait_rate_overall": round(float((df["decision"] == "WAIT").mean()), 3),
        "breakdowns": {col: breakdown(col) for col in
                       ("regime", "session", "volatility", "trend", "smc_alignment", "conf_bucket")},
        "usefulness_test": {
            "method": "forward triple-barrier label of AI-agreed vs AI-vetoed states; "
                      "block permutation (2000 shuffles) on strategy-P&L-equivalent score",
            "score_follow_all_ml": round(follow_all, 4),
            "score_follow_ai_agreed_only": round(follow_agreed, 4),
            "delta": round(observed, 4),
            "p_value": round(p_value, 4),
            "verdict": usefulness,
        },
        "conflict_profile": conflict_profile,
        "interpretation": {
            "USEFUL_FILTERING": "AI disagreement carries information (vetoed states have worse outcomes)",
            "RANDOM_NOISE": "disagreement unrelated to outcomes — treat AI votes as noise at current rate",
            "HARMFUL_FILTERING": "AI keeps worse states — currently counterproductive",
            "NO_SIGNIFICANT_SELECTION_VALUE": "no statistically significant selection value "
                                              "detected at this agreement rate and sample size",
            "INDETERMINATE_SAMPLE": "too few agreed/disagreed states to separate signal from noise",
            "SYSTEMATIC_CONFLICT": "see conflict_profile: disagreement concentrated in identifiable conditions",
            "MODEL_INSTABILITY": "same state → different answers (see repeatability test §15)",
        }[usefulness],
        "disclaimer": "Analysis of REAL AI responses on REAL data; forward labels are "
                      "research measurements, not trading results. WAIT remains valid; "
                      "agreement was NOT forced (§14).",
    }
    out = Path(cfg.paths.reports_dir) / "ai_agreement_analysis.json"
    out.write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(json.dumps(result["usefulness_test"], indent=2))
    for col in ("regime", "session", "volatility", "trend", "smc_alignment", "conf_bucket"):
        print(f"  {col}: {json.dumps(result['breakdowns'][col])}")
    print(f"[agreement] → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
