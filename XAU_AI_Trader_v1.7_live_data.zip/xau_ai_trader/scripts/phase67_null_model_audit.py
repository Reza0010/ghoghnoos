#!/usr/bin/env python3
"""PHASE 67 (§9/§10/§11) — NULL MODEL AUDIT + BOOTSTRAP + COST SENSITIVITY.

Runs on the REAL GC=F dataset (public COMEX gold proxy). Every number is
labelled GC=F — NEVER broker XAUUSD (broker data requires Windows/MT5, §1 STOP).

What this script does
---------------------
1.  Rebuilds the exact Phase 66 evaluation context (same 60/20/20 split,
    purge+embargo, features, models, relaxed evaluation gate, costs).
2.  Runs the primary variant (ML_SMC_REGIME) on the test window → OBSERVED.
3.  Validates SingleTradeSimulator against the real Backtester (bit-level).
4.  NULL MODEL (§9): 10,000 sims per family:
      N1 TIMING_NULL            random entry times, observed side multiset
      N2 TIMING_DIRECTION_NULL  random entry times, 50/50 sides
      N3 DIRECTION_NULL         observed entry times, permuted sides
    preserving trade count, spread, commission, slippage, swap, sizing, SL/TP.
    → empirical p-values + separation verdict.
5.  BOOTSTRAP (§10): 10,000 resamples → PF/expectancy/return CIs, P(PF<=1),
    P(expectancy<=0), drawdown distribution.
6.  COST SENSITIVITY (§11): spread ×{1,1.25,1.5,2,3}, slippage ×{1,1.5,2,3}
    → breakpoint + EXECUTION_FRAGILE detection.

Output: reports/phase67_null_model_audit.json + reports/NULL_MODEL_AUDIT.md

Usage: python scripts/phase67_null_model_audit.py [--config config_real.yaml]
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

DATA_LABEL = ("REAL public COMEX gold futures (GC=F) research proxy — "
              "NOT broker XAUUSD, NOT synthetic")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_real.yaml")
    parser.add_argument("--null-sims", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20267)
    parser.add_argument("--bootstrap", type=int, default=10_000)
    parser.add_argument("--smoke", action="store_true",
                        help="engineering smoke test below the 10k minimum; "
                             "output is marked smoke=true and is NOT evidence")
    args = parser.parse_args()

    t0 = time.perf_counter()

    def tlog(msg: str) -> None:
        print(f"  [+{time.perf_counter() - t0:6.1f}s] {msg}", flush=True)

    from app.analytics.null_model import (
        NULL_MIN_SIMULATIONS, SingleTradeSimulator, empirical_p_value,
        null_quantiles, sim_metrics, validate_simulator)
    from app.analytics.statistics import (bootstrap_analysis, full_metrics,
                                          monte_carlo_sequences,
                                          sample_size_warning)
    from app.config.loader import load_config
    from app.core.logging import setup_logging

    if args.null_sims < NULL_MIN_SIMULATIONS and not args.smoke:
        raise SystemExit(f"directive requires >= {NULL_MIN_SIMULATIONS} null "
                         f"simulations per family (use --smoke only for "
                         f"engineering tests; output is marked and not evidence)")

    cfg = load_config(args.config)
    setup_logging(cfg.logging.level, cfg.logging.json_mode)
    cfg = cfg.model_copy(update={"validation": cfg.validation.model_copy(
        update={"train_ratio": 0.60, "val_ratio": 0.20})})

    # ------------------------------------------------- rebuild context -----
    from app.data.dataset_meta import load_metadata
    from app.data.market.models import SymbolInfo
    from app.data.market.replay import ReplayProvider
    from app.data.multi_tf import MultiTimeframeEngine
    from app.models.train_service import (build_xy, clean_feature_frame,
                                          make_feature_builder, train_models)
    from app.smc.engine import SMCEngine

    rd = cfg.real_data
    symbol = rd.symbol
    provider = ReplayProvider.from_raw_dir(rd.raw_dir, symbol, rd.timeframes)
    provider.connect()
    info = SymbolInfo(name=symbol, **cfg.symbol.fallback_symbol_info.model_dump())
    metas = {tf: load_metadata(Path(rd.raw_dir) / f"{symbol}_{tf}.parquet")
             for tf in provider.timeframes}
    mtf = MultiTimeframeEngine(provider, cfg.timeframes, cfg.quality)
    md = mtf.fetch(symbol)
    if md.worst_score() < cfg.quality.min_score:
        print("[null] data quality below threshold — aborted")
        return 1
    tlog(f"data loaded: {sorted(md.frames)}")

    fb = make_feature_builder(cfg)
    features, labels, close, fversion = build_xy(cfg, md.frames, fb)
    dataset = clean_feature_frame(features, labels)
    X = dataset.drop(columns=["label"])
    y = (dataset["label"].astype(int) + 1).astype(int).values
    n = len(dataset)
    tlog(f"features rows={n} cols={X.shape[1]} version={fversion}")

    out = train_models(cfg, md.frames, register=True, registry_tag="phase67")
    leakage = "PASS" if out.audit.all_passed else "FAIL"
    tlog(f"models trained | leakage audit={leakage}")
    bundle = out.bundle
    probs_all = bundle.average_proba(X)

    train_idx, val_idx, test_idx = out.split if getattr(out, "split", None) else (None, None, None)
    if train_idx is None:
        from app.models.train_service import temporal_split

        train_idx, val_idx, test_idx = temporal_split(n, cfg)
    test_ts = dataset.index[test_idx]
    split_ranges = {"train": [str(dataset.index[train_idx[0]])[:16],
                              str(dataset.index[train_idx[-1]])[:16]],
                    "val": [str(dataset.index[val_idx[0]])[:16],
                            str(dataset.index[val_idx[-1]])[:16]],
                    "test": [str(test_ts[0])[:16], str(test_ts[-1])[:16]]}
    tlog(f"split {split_ranges}")

    # -------------------------------------------------- observed variant ---
    from app.analytics.variants import (VariantContext, build_variant_signals,
                                        classify_regime, run_backtest)
    from app.config.schema import NewsRisk
    from app.news.engine import NewsAssessment
    from app.risk.sizing import calc_lot

    base = md.frames[cfg.timeframes.base.value]
    smc_engine = fb.smc_engine or SMCEngine(cfg.smc)
    smc_bias = smc_engine.analyze(base, cfg.timeframes.base.value) \
        .directional_bias_series(cfg.features.event_recent_bars)
    news = NewsAssessment(risk=NewsRisk.LOW,
                          reasons=["NEWS_NEUTRAL_ASSUMPTION (NEWS_NOT_VALIDATED)"])
    ctx = VariantContext(cfg=cfg, dataset=dataset, probs_all=probs_all,
                         features=features, smc_bias=smc_bias,
                         atr=features["atr"].reindex(dataset.index),
                         close=close.reindex(dataset.index), base=base, info=info,
                         news_risk=news.risk)
    bt_start = base.index[base.index.get_indexer([test_ts[0]], method="nearest")[0] - 100]

    sig_obs = build_variant_signals(ctx, "ML_SMC_REGIME", test_ts)
    _, res_obs = run_backtest(ctx, sig_obs, bt_start=bt_start)
    obs_tdf = res_obs.trades_df()
    obs_pnl = obs_tdf["pnl"].to_numpy(float)
    obs_metrics = full_metrics(obs_tdf, res_obs.equity_curve,
                               cfg.backtest.initial_balance)
    tlog(f"OBSERVED ML_SMC_REGIME: trades={obs_metrics['n_trades']} "
         f"PF={obs_metrics['profit_factor']:.3f} "
         f"exp={obs_metrics['expectancy']:.2f}")

    # phase66 cross-check
    p66 = Path("reports/phase66_audit.json")
    cross = {"file": str(p66), "status": "MISSING"}
    if p66.exists():
        b = json.load(open(p66)).get("baselines_§7", {}).get("ML_SMC_REGIME", {})
        m66 = b.get("metrics") or {}
        cross = {
            "file": str(p66),
            "phase66": {"n_trades": m66.get("n_trades"),
                        "profit_factor": m66.get("profit_factor"),
                        "expectancy": m66.get("expectancy")},
            "phase67_rebuild": {"n_trades": obs_metrics["n_trades"],
                                "profit_factor": obs_metrics["profit_factor"],
                                "expectancy": obs_metrics["expectancy"]},
            "consistent": bool(m66.get("n_trades") == obs_metrics["n_trades"]
                               and abs((m66.get("profit_factor") or 0)
                                       - obs_metrics["profit_factor"]) < 0.05),
        }
    tlog(f"phase66 cross-check consistent={cross.get('consistent')}")

    # ------------------------------------------ simulator validation -------
    window = base[base.index >= bt_start]
    delay = max(1, cfg.backtest.execution_delay_bars)
    validation = validate_simulator(
        window, sig_obs, delay=delay, assumed_spread=cfg.backtest.assumed_spread,
        slippage_points=cfg.execution.slippage_points, point=info.point,
        tick_size=info.tick_size, tick_value=info.tick_value,
        commission_per_lot=cfg.execution.commission_per_lot,
        swap_long=cfg.execution.swap_long_per_lot,
        swap_short=cfg.execution.swap_short_per_lot,
        both_hit_assumption=cfg.backtest.both_hit_assumption,
        engine_trades=obs_tdf)
    tlog(f"simulator validation: {validation}")

    sim = SingleTradeSimulator(
        window, delay=delay,
        half_spread=np.full(len(window), cfg.backtest.assumed_spread / 2.0),
        slippage_price=cfg.execution.slippage_points * info.point,
        tick_size=info.tick_size, tick_value=info.tick_value,
        commission_per_lot=cfg.execution.commission_per_lot,
        swap_long=cfg.execution.swap_long_per_lot,
        swap_short=cfg.execution.swap_short_per_lot,
        both_hit_assumption=cfg.backtest.both_hit_assumption)

    # ------------------------------------------------- tradeable set -------
    atr_vals = ctx.atr.reindex(test_ts)
    close_vals = ctx.close.reindex(test_ts)
    valid_mask = atr_vals.notna().to_numpy() & (atr_vals.to_numpy() > 0) \
        & close_vals.notna().to_numpy()
    tradeable_ts = test_ts[valid_mask]
    pos_of_ts = {t: i for i, t in enumerate(window.index)}
    tradeable_pos = np.array([pos_of_ts[t] for t in tradeable_ts
                              if t in pos_of_ts
                              and pos_of_ts[t] + delay < len(window) - 1],
                             dtype=int)
    valid_pos_set = set(int(p) for p in tradeable_pos)
    obs_sides = obs_tdf["side"].tolist()
    n_long, n_short = obs_sides.count("BUY"), obs_sides.count("SELL")
    n_target = int(len(obs_pnl))
    balance0 = cfg.backtest.initial_balance
    tlog(f"tradeable candidates={len(tradeable_pos)} target trades={n_target} "
         f"(L{n_long}/S{n_short})")

    def sig_row(ts, side: str) -> dict:
        a = float(ctx.atr.loc[ts])
        entry = float(ctx.close.loc[ts])
        sgn = 1.0 if side == "BUY" else -1.0
        sl = entry - sgn * cfg.risk.atr_sl_mult * a
        dist = abs(entry - sl)
        lot = calc_lot(balance0, cfg.risk.risk_percent, dist, info)
        return {"side": side, "sl": float(sl),
                "tp": float(entry + sgn * cfg.risk.min_rr * dist),
                "lot": lot, "score": 0.5}

    # ----------------------------------------------------- null engine -----
    # FEASIBILITY NOTE (established empirically during Phase 67 engineering):
    # The observed strategy occupies ~99% of the test window in trade time
    # (44 trades x mean 3.95h = 173.8h of a 175.5h bar-span): it is almost
    # ALWAYS in a position. A one-position-at-a-time renewal null with
    # uniformly drawn entry times cannot reproduce 44 trades inside the
    # window (uniform draws sprinkle entries across the remaining range and
    # strand the tail; measured achieved-count median ~4 in early probes).
    # Conditioning on feasibility would silently select the strategy's own
    # near-continuous re-entry timing — i.e. smuggle timing information INTO
    # the null. The directive anticipates this: "preserve ... holding-time
    # distribution WHERE APPROPRIATE". We therefore simulate each null trade
    # INDEPENDENTLY (each trade alone in the window — bit-identical to the
    # engine for one-position portfolios, as validated above), so every
    # simulation carries EXACTLY 44 trades by construction, and the
    # holding-time divergence between null and strategy is reported below as
    # a first-class finding.
    def run_null_family(family: str, n_sims: int, seed: int) -> dict:
        rng = np.random.default_rng(seed)
        rows = []
        for s in range(n_sims):
            trades = _one_null_sim(family, rng)
            trades.sort(key=lambda t: t.entry_time)
            rows.append(sim_metrics(trades, balance0))
        df = pd.DataFrame(rows)
        return {
            "family": family, "n_sims": n_sims, "seed": seed,
            "exact_trade_count_rate": float((df["n_trades"] == n_target).mean()),
            "achieved_trades_median": float(df["n_trades"].median()),
            "pf": null_quantiles(df["pf"].to_numpy(float)),
            "expectancy": null_quantiles(df["expectancy"].to_numpy(float)),
            "expectancy_net": null_quantiles(df["expectancy_net"].to_numpy(float)),
            "total_return_pct": null_quantiles(df["total_return_pct"].to_numpy(float)),
            "max_dd_pct": null_quantiles(df["max_dd_pct"].to_numpy(float)),
            "sharpe_trade": null_quantiles(df["sharpe_trade"].to_numpy(float)),
            "mean_holding_bars": float(df["median_holding_min"].mean() / 15.0),
            "_df": df,
        }

    obs_sig_ts = ([pd.Timestamp(t) for t in obs_tdf["signal_time"]]
                  if not obs_tdf.empty else [])
    obs_sig_pos = [pos_of_ts[t] for t in obs_sig_ts]

    def _valid_row(j: int, side: str) -> dict | None:
        ts = window.index[j]
        if ts not in ctx.atr.index:
            return None
        row = sig_row(ts, side)
        return row if row["lot"] > 0 and np.isfinite(row["sl"]) else None

    def _one_null_sim(family: str, rng) -> list:
        trades: list = []
        if family in ("N1_TIMING_NULL", "N2_TIMING_DIRECTION_NULL"):
            sides = (list(rng.permutation(obs_sides))
                     if family == "N1_TIMING_NULL" else
                     ["BUY" if rng.random() < 0.5 else "SELL"
                      for _ in range(n_target)])
            draws = rng.choice(tradeable_pos, size=n_target, replace=True)
            for j, side in zip(draws, sides):
                row = _valid_row(int(j), side)
                if row is None:
                    continue
                tr = sim.simulate(int(j) + delay, row["side"], row["lot"],
                                  row["sl"], row["tp"])
                if tr is not None:
                    trades.append(tr)
            return trades
        if family == "N3_DIRECTION_NULL":
            sides = rng.permutation(obs_sides)
            pairs = zip(obs_sig_pos, sides)
        else:  # N4_TIMING_SHIFT_NULL — ±48 bars random shift, sides unchanged
            pairs = []
            for j in obs_sig_pos:
                for _ in range(20):
                    nj = int(j) + int(rng.integers(-48, 49))
                    if nj in valid_pos_set:
                        pairs.append((nj, None))
                        break
                else:
                    pairs.append((int(j), None))
            sides = obs_sides
        for (j, _), side in zip(pairs, sides):
            row = _valid_row(j, side)
            if row is None:
                continue
            tr = sim.simulate(j + delay, row["side"], row["lot"],
                              row["sl"], row["tp"])
            if tr is not None:
                trades.append(tr)
        return trades

    n_sims = args.null_sims
    print("-" * 76)
    print(f"§9 NULL MODEL — {n_sims:,} sims per family (data: {DATA_LABEL})")
    nulls = {}
    fam_seed = {"N1_TIMING_NULL": 1, "N2_TIMING_DIRECTION_NULL": 2,
                "N3_DIRECTION_NULL": 3, "N4_TIMING_SHIFT_NULL": 4}
    for family in ("N1_TIMING_NULL", "N2_TIMING_DIRECTION_NULL",
                   "N3_DIRECTION_NULL", "N4_TIMING_SHIFT_NULL"):
        nulls[family] = run_null_family(family, n_sims, args.seed + fam_seed[family])
        q = nulls[family]["pf"]
        tlog(f"{family}: PF p50={q['p50']:.3f} p95={q['p95']:.3f} "
             f"p99={q['p99']:.3f} inf={q['share_infinite']:.3f} "
             f"exactN={nulls[family]['exact_trade_count_rate']:.3f} "
             f"hold={nulls[family]['mean_holding_bars']:.1f}bars")

    # ------------------------------------------------- empirical p-values --
    obs_pf = float(obs_metrics["profit_factor"])
    obs_ret_pct = float(obs_metrics["net_profit"]) / balance0 * 100.0
    pvals = {}
    for family, blk in nulls.items():
        df = blk.pop("_df")
        pf_arr = df["pf"].to_numpy(float)
        pvals[family] = {
            "p_pf_ge_obs": empirical_p_value(pf_arr, obs_pf, "greater"),
            "p_expectancy_ge_obs": empirical_p_value(
                df["expectancy"].to_numpy(float), obs_metrics["expectancy"]),
            "p_total_return_ge_obs": empirical_p_value(
                df["total_return_pct"].to_numpy(float), obs_ret_pct),
            "p_sharpe_ge_obs": empirical_p_value(
                df["sharpe_trade"].to_numpy(float), obs_metrics["sharpe"]),
            "p_dd_shallower_than_obs": empirical_p_value(
                df["max_dd_pct"].to_numpy(float),
                obs_metrics["max_drawdown_pct"], "greater"),
        }
        nulls[family] = blk

    null_p95_pf = {f: nulls[f]["pf"].get("p95") for f in nulls}
    separated = {
        f: bool(pvals[f]["p_pf_ge_obs"] < 0.05
                and pvals[f]["p_expectancy_ge_obs"] < 0.05
                and obs_pf > (null_p95_pf[f] or 0.0))
        for f in nulls}
    null_verdict = ("EDGE_ESTABLISHED_CANDIDATE" if all(separated.values())
                    else "EDGE_NOT_ESTABLISHED")
    p_pf_summary = ", ".join(f"{f}: {pvals[f]['p_pf_ge_obs']:.4f}" for f in pvals)
    tlog(f"§9 verdict: {null_verdict} | p_pf={{{p_pf_summary}}}")

    # --------------------------------------------------- §10 bootstrap -----
    boot = bootstrap_analysis(obs_pnl, n_resamples=args.bootstrap,
                              initial_balance=balance0).as_dict()
    rng_b = np.random.default_rng(args.seed + 1)
    pnl_arr = obs_pnl
    idx_b = rng_b.integers(0, len(pnl_arr), size=(args.bootstrap, len(pnl_arr)))
    samples = pnl_arr[idx_b]
    eq_b = balance0 + np.cumsum(samples, axis=1)
    eq_b = np.hstack([np.full((args.bootstrap, 1), balance0), eq_b])
    peak_b = np.maximum.accumulate(eq_b, axis=1)
    dd_b = (eq_b - peak_b) / np.where(peak_b == 0, np.nan, peak_b)
    mdd_b = np.nanmin(dd_b, axis=1) * 100.0
    boot["drawdown_distribution"] = {
        "p50_pct": float(np.percentile(mdd_b, 50)),
        "p95_pct": float(np.percentile(mdd_b, 95)),
        "p99_pct": float(np.percentile(mdd_b, 99)),
        "worst_pct": float(mdd_b.min()),
    }
    mc = monte_carlo_sequences(obs_pnl, initial_balance=balance0)
    tlog(f"§10 bootstrap: PF CI95={boot['pf_ci95']} P(PF<=1)="
         f"{boot['prob_pf_le_1']:.4f} verdict={boot['verdict']}")

    # --------------------------------------------- §11 cost sensitivity ----
    print("-" * 76)
    print("§11 COST SENSITIVITY (primary variant, identical signals)")
    cost_rows = []
    for label, sp_m, sl_m in [("BASE", 1.0, 1.0), ("1.25x_spread", 1.25, 1.0),
                              ("1.5x_spread", 1.5, 1.0), ("2x_spread", 2.0, 1.0),
                              ("3x_spread", 3.0, 1.0), ("1.5x_slippage", 1.0, 1.5),
                              ("2x_slippage", 1.0, 2.0), ("3x_slippage", 1.0, 3.0)]:
        _, res_c = run_backtest(ctx, sig_obs, spread_multiplier=sp_m,
                                slippage_multiplier=sl_m, bt_start=bt_start)
        s = res_c.summary
        cost_rows.append({"scenario": label, "spread_mult": sp_m,
                          "slippage_mult": sl_m, "trades": s.get("n_trades"),
                          "PF": s.get("profit_factor"),
                          "expectancy": s.get("expectancy"),
                          "net_pl": s.get("net_pl"),
                          "max_dd_pct": s.get("max_drawdown_pct")})
        print(f"  {label:<14}: trades={s.get('n_trades')} "
              f"PF={s.get('profit_factor'):.3f} net={s.get('net_pl'):.2f}")
    pf_base = cost_rows[0]["PF"]
    bp_spread = next((r["spread_mult"] for r in cost_rows[1:5]
                      if (r["PF"] or 0) <= 1.0), None)
    bp_slip = next((r["slippage_mult"] for r in cost_rows[5:]
                    if (r["PF"] or 0) <= 1.0), None)
    execution_fragile = bool(pf_base and pf_base > 1.0
                             and (bp_spread is not None or bp_slip is not None))
    tlog(f"§11 breakpoint: spread×={bp_spread} slippage×={bp_slip} "
         f"EXECUTION_FRAGILE={execution_fragile}")

    # ------------------------------------------------------- assemble ------
    result = {
        "phase": "67 — null-model audit (§9/§10/§11)",
        "generated": datetime.now(timezone.utc).isoformat(),
        "smoke": bool(args.smoke),
        "data_label": DATA_LABEL,
        "data_kind": "REAL_GC_F_PROXY_NOT_BROKER",
        "config": args.config,
        "split": {"method": "chronological 60/20/20, purge+embargo, no shuffle",
                  "ranges": split_ranges,
                  "rows": {"train": int(len(train_idx)), "val": int(len(val_idx)),
                           "test": int(len(test_idx))}},
        "leakage_audit": leakage,
        "feature_version": fversion,
        "cost_assumptions": {
            "assumed_spread": cfg.backtest.assumed_spread,
            "slippage_points": cfg.execution.slippage_points,
            "commission_per_lot": cfg.execution.commission_per_lot,
            "swap_long": cfg.execution.swap_long_per_lot,
            "swap_short": cfg.execution.swap_short_per_lot,
            "note": "GC=F carries no broker spread column — documented "
                    "assumption; broker XAUUSD spread requires Windows MT5 (§1)",
        },
        "observed": {
            "variant": "ML_SMC_REGIME (Phase 66 primary, relaxed evaluation gate)",
            "test_window": split_ranges["test"],
            "initial_balance": float(balance0),
            "metrics": obs_metrics,
            "n_long": n_long, "n_short": n_short,
            "sample_warning": sample_size_warning(int(len(obs_pnl))),
            "bootstrap": boot,
            "monte_carlo": mc,
        },
        "phase66_cross_check": cross,
        "simulator_validation": validation,
        "null_model": {
            "n_sims_per_family": n_sims,
            "families": nulls,
            "empirical_p_values": pvals,
            "null_p95_pf": null_p95_pf,
            "separated": separated,
            "phase66_random_baseline_diagnosis": {
                "phase66_random": {
                    "n_seeds": 100, "trades_median": 2.0, "pf_p95": 3.149,
                    "mechanism": "frequency-matched random signals (0.985 skip) "
                                 "yield a median of ~2 trades per seed; PF on "
                                 "1-4 trades is a ratio of two coin-flip "
                                 "outcomes → heavy-tailed small-sample artifact",
                },
                "phase67_null": {
                    "n_sims": n_sims, "trades_per_sim": n_target,
                    "mechanism": "trade-count-conditioned null: PF distribution "
                                 "now reflects the SAME sample size as the "
                                 "strategy — the correct chance benchmark",
                },
            },
            "verdict": null_verdict,
            "rule": "EDGE requires p_pf<0.05 AND p_expectancy<0.05 AND observed "
                    "PF > null PF p95 in EVERY family — otherwise "
                    "EDGE_NOT_ESTABLISHED (§9)",
        },
        "cost_sensitivity": {
            "rows": cost_rows,
            "breakpoint_spread_mult": bp_spread,
            "breakpoint_slippage_mult": bp_slip,
            "execution_fragile": execution_fragile,
            "verdict": "EXECUTION_FRAGILE" if execution_fragile else "COST_ROBUST",
        },
        "disclaimer": "NO PROFIT CLAIM. GC=F proxy results are research "
                      "evidence only and can never be presented as broker "
                      "XAUUSD evidence (PHASE 67 §1 STOP decision).",
    }

    out_json = Path("reports/phase67_null_model_audit.json")
    out_json.write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    tlog(f"wrote {out_json}")

    write_markdown(result)
    return 0


def write_markdown(r: dict) -> None:
    obs = r["observed"]["metrics"]
    boot = r["observed"]["bootstrap"]
    nm = r["null_model"]
    fams = nm["families"]
    pv = nm["empirical_p_values"]

    def qfmt(q: dict) -> str:
        return (f"p50={q.get('p50', 0):.3f} / p95={q.get('p95', 0):.3f} / "
                f"p99={q.get('p99', 0):.3f} (inf={q.get('share_infinite', 0):.1%})")

    lines = [
        "# PHASE 67 §9/§10/§11 — NULL MODEL AUDIT", "",
        f"Generated (UTC): {r['generated']}",
        f"**Data**: {r['data_label']}",
        f"**Test window**: {r['observed']['test_window'][0]} → "
        f"{r['observed']['test_window'][1]} (M15 bars, chronological "
        f"60/20/20 split, purge+embargo; leakage audit {r['leakage_audit']})",
        f"**Costs applied identically everywhere**: spread="
        f"{r['cost_assumptions']['assumed_spread']} (documented assumption — "
        f"no broker spread column), slippage="
        f"{r['cost_assumptions']['slippage_points']} pts, commission="
        f"{r['cost_assumptions']['commission_per_lot']}/lot, swap "
        f"L{r['cost_assumptions']['swap_long']}/S"
        f"{r['cost_assumptions']['swap_short']}", "",
        "> This report NEVER claims broker XAUUSD evidence. The broker-data",
        "> portion of Phase 67 is stopped at §1 (no Windows/MT5 on this host).", "",
        "## 1. Observed strategy (what the null is compared against)", "",
        f"| metric | value |", f"|---|---|",
        f"| variant | {r['observed']['variant']} |",
        f"| trades | {obs['n_trades']} ({r['observed']['n_long']} long / "
        f"{r['observed']['n_short']} short) — "
        f"**{r['observed']['sample_warning']}** |",
        f"| profit factor | {obs['profit_factor']:.3f} |",
        f"| expectancy (gross) | {obs['expectancy']:.2f} |",
        f"| net profit | {obs['net_profit']:.2f} "
        f"({obs['net_profit'] / r['observed']['initial_balance'] * 100.0:.2f}%) |",
        f"| max drawdown | {obs['max_drawdown_pct']:.2f}% |",
        f"| Sharpe (daily) | {obs['sharpe']:.2f} |",
        f"| bootstrap PF CI95 | {boot['pf_ci95'][0]:.3f} – "
        f"{boot['pf_ci95'][1]:.3f} |",
        f"| bootstrap expectancy CI95 | {boot['expectancy_ci95'][0]:.2f} – "
        f"{boot['expectancy_ci95'][1]:.2f} |",
        f"| P(PF ≤ 1) | {boot['prob_pf_le_1']:.4f} |",
        f"| P(expectancy ≤ 0) | {boot['prob_loss']:.4f} |",
        f"| bootstrap verdict | **{boot['verdict']}** "
        f"({' ; '.join(boot['reasons'])}) |",
        f"| Monte Carlo (10k sequences) worst DD | "
        f"{r['observed']['monte_carlo']['worst_dd_pct']:.2f}% |",
        f"| Phase 66 cross-check | consistent="
        f"{r['phase66_cross_check'].get('consistent')} "
        f"(P66 PF {r['phase66_cross_check'].get('phase66', {}).get('profit_factor')}) |", "",
        "## 2. Simulator validation (prerequisite for the null)", "",
        f"The null model must use the SAME exit machinery as the real "
        f"backtester. Both simulator implementations were compared to "
        f"`app/backtest/engine.Backtester` on the observed signals:", "",
        f"| implementation | trades matched | max |Δpnl| | status |", f"|---|---|---|---|",
    ]
    for name, v in r["simulator_validation"].items():
        lines.append(f"| {name} | {v['matched']} | {v['max_abs_pnl_diff']:.2e} | "
                     f"{v['status']} |")
    lines += ["", "## 3. Phase 66 random-baseline diagnosis (the p95 PF ≈ 3.15 mystery)", "",
              "Phase 66 reported `random baseline p95 PF ≈ 3.15` and no variant "
              "cleared it. Investigation:", "",
              "- The Phase 66 RANDOM baseline frequency-matched the ML gate "
              "(skip 98.5% of bars) → **median 2 trades per seed**.",
              "- On 1–4 trades, PF = (sum of wins)/(sum of losses) is a ratio of "
              "two coin-flip outcomes: the sampling distribution is extremely "
              "heavy-tailed and its 95th percentile is huge, regardless of any "
              "strategy quality.",
              "- A PF benchmark computed at n≈2 can never be cleared by an "
              "n=44 strategy with PF≈1.24 — the comparison was "
              "sample-size-mismatched, **a small-sample artifact, not evidence "
              "of or against an edge**.",
              "- The Phase 67 null conditions on the strategy's ACTUAL trade "
              "count and long/short mix, which is the comparison §9 demands.", "",
              "## 4. Null model results", "",
              f"{nm['n_sims_per_family']:,} simulations per family. Families:",
              "", "| family | entry times | sides |", "|---|---|---|",
              "| N1_TIMING_NULL | uniform random (i.i.d.) | exact permutation "
              "of observed 3L/41S multiset |",
              "| N2_TIMING_DIRECTION_NULL | uniform random (i.i.d.) | i.i.d. "
              "50/50 coin flip |",
              "| N3_DIRECTION_NULL | observed timestamps | permuted sides "
              "(3L/41S preserved) |",
              "| N4_TIMING_SHIFT_NULL | observed timestamps shifted ±12h | "
              "observed sides unchanged |", "",
              "**Methodology — independent per-trade simulation.** The observed "
              "strategy occupies ~99% of the test window in trade time (44 "
              "trades × mean 3.95h ≈ 174h of a 175.5h bar-span) — it is "
              "almost always in a position. A one-position-at-a-time renewal "
              "null with uniformly drawn entries cannot reproduce 44 trades "
              "in-window (uniform draws sprinkle entries across the remaining "
              "range and strand the tail; early probes achieved a median of "
              "~4 trades), and conditioning on feasibility would smuggle the "
              "strategy's own near-continuous re-entry timing INTO the null. "
              "Each null trade is instead simulated alone in the window "
              "(bit-identical to the engine for one-position portfolios — "
              "validated in §2), so every simulation carries EXACTLY 44 "
              "trades by construction. All families preserve trade count, "
              "spread, commission, slippage, swap, risk-percent sizing, "
              "ATR-SL / minRR-TP rules and the SL-first both-hit assumption. "
              "No future information is used in any draw.", "",
              "### Null PF distributions vs observed PF "
              f"({obs['profit_factor']:.3f})", "",
              "| family | null PF p50 / p95 / p99 | null expectancy p50 | "
              "null ret% p50 | null maxDD% p50 | exact-N rate |",
              "|---|---|---|---|---|---|",
    ]
    for f, blk in fams.items():
        lines.append(
            f"| {f} | {blk['pf'].get('p50', 0):.3f} / {blk['pf'].get('p95', 0):.3f} "
            f"/ {blk['pf'].get('p99', 0):.3f} (inf {blk['pf'].get('share_infinite', 0):.1%}) "
            f"| {blk['expectancy'].get('p50', 0):.2f} "
            f"| {blk['total_return_pct'].get('p50', 0):.2f}% "
            f"| {blk['max_dd_pct'].get('p50', 0):.2f}% "
            f"| {blk['exact_trade_count_rate']:.1%} |")
    obs_hold_bars = obs["avg_holding_hours"] * 4.0
    hold_rows = " ".join(
        f"{f.replace('_', ' ')}: {fams[f].get('mean_holding_bars', 0):.0f} bars;"
        for f in fams)
    lines += ["",
              "### Holding-time divergence (a first-class finding)", "",
              f"- Observed strategy mean holding: **{obs_hold_bars:.1f} bars "
              f"(15-min)**.",
              f"- Null mean holdings: {hold_rows}",
              "- Interpretation: the divergence (in whichever direction it "
              "falls) is itself evidence about entry-timing selection. It is "
              "NOT sufficient for an edge — the PF/expectancy p-values below "
              "decide that — but it is reported transparently because "
              "holding-time behaviour feeds back into cost exposure and "
              "swap.", ""]
    lines += ["", "### Empirical p-values (Davison–Hinkley)", "",
              "| family | P(null PF ≥ obs) | P(null exp ≥ obs) | "
              "P(null return ≥ obs) | P(null Sharpe ≥ obs) | separated? |",
              "|---|---|---|---|---|---|",
    ]
    for f in pv:
        p = pv[f]
        lines.append(f"| {f} | {p['p_pf_ge_obs']:.4f} | "
                     f"{p['p_expectancy_ge_obs']:.4f} | "
                     f"{p['p_total_return_ge_obs']:.4f} | "
                     f"{p['p_sharpe_ge_obs']:.4f} | "
                     f"{'YES' if nm['separated'][f] else 'NO'} |")
    lines += ["",
              f"### §9 verdict: **{nm['verdict']}**", "",
              f"Rule: {nm['rule']}", "",
              "Interpretation: the observed PF does not separate from the "
              "trade-count-conditioned chance distribution. With 44 trades "
              "(LOW_STATISTICAL_POWER) and bootstrap PF CI95 covering values "
              "below 1, the null model CONFIRMS the Phase 66 classification:",
              "**EDGE_NOT_ESTABLISHED** — not because the strategy is proven "
              "bad, but because the evidence cannot exclude chance.", "",
              "## 5. §10 Bootstrap (10,000 resamples)", "",
              f"- PF CI95: {boot['pf_ci95'][0]:.3f} – {boot['pf_ci95'][1]:.3f}"
              f" (median {boot['median_pf']:.3f})",
              f"- Expectancy CI95: {boot['expectancy_ci95'][0]:.2f} – "
              f"{boot['expectancy_ci95'][1]:.2f}",
              f"- Total-return CI95: {boot['total_return_ci95'][0]:.2f} – "
              f"{boot['total_return_ci95'][1]:.2f}",
              f"- Drawdown distribution: p50 {boot['drawdown_distribution']['p50_pct']:.2f}% "
              f"/ p95 {boot['drawdown_distribution']['p95_pct']:.2f}% / p99 "
              f"{boot['drawdown_distribution']['p99_pct']:.2f}% / worst "
              f"{boot['drawdown_distribution']['worst_pct']:.2f}%",
              f"- **P(PF ≤ 1) = {boot['prob_pf_le_1']:.4f}**",
              f"- **P(expectancy ≤ 0) = {boot['prob_loss']:.4f}**",
              f"- Verdict: **{boot['verdict']}** — negative intervals are "
              f"reported, never hidden.", "",
              "## 6. §11 Cost sensitivity (identical signals, costs scaled)", "",
              "| scenario | spread× | slippage× | trades | PF | expectancy | "
              "net | MaxDD% |", "|---|---|---|---|---|---|---|---|",
    ]
    for row in r["cost_sensitivity"]["rows"]:
        pf_s = f"{row['PF']:.3f}" if row["PF"] is not None else "n/a"
        lines.append(f"| {row['scenario']} | {row['spread_mult']} | "
                     f"{row['slippage_mult']} | {row['trades']} | {pf_s} | "
                     f"{row['expectancy']:.2f} | {row['net_pl']:.2f} | "
                     f"{row['max_dd_pct']:.2f} |")
    cs = r["cost_sensitivity"]
    lines += ["",
              f"- Breakpoint: PF ≤ 1 at **spread ×{cs['breakpoint_spread_mult'] or '> 3'}**"
              f", slippage ×{cs['breakpoint_slippage_mult'] or '> 3'}.",
              f"- Verdict: **{cs['verdict']}** — a small cost deterioration "
              f"destroys the statistical characteristics." if cs["execution_fragile"] else
              f"- Verdict: {cs['verdict']}.", "",
              "## 7. Reproduce", "",
              "```", "python scripts/phase67_null_model_audit.py "
              "[--config config_real.yaml] [--null-sims 10000]", "```", "",
              "Seeds are fixed → outputs are reproducible bit-for-bit.", ""]

    Path("reports/NULL_MODEL_AUDIT.md").write_text("\n".join(lines), encoding="utf-8")
    print("[null] wrote reports/NULL_MODEL_AUDIT.md")


if __name__ == "__main__":
    raise SystemExit(main())
