#!/usr/bin/env python3
"""PHASE 67 (§4/§5) — writes the broker-data PENDING reports.

The broker-data portion of Phase 67 is STOPPED at §1 (no Windows/MT5 on this
host). These reports record, honestly and reproducibly:

  reports/BROKER_XAUUSD_DATA_QUALITY.md   — §4 status: BROKER_DATA_PENDING,
        full check battery + tooling + exact Windows command
  reports/BROKER_VS_GCF.md                — §5 status: COMPARISON_PENDING,
        methodology + standing rule GC=F ≠ broker XAUUSD

Nothing here simulates broker data or renames GC=F as XAUUSD.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

NOW = datetime.now(timezone.utc).isoformat()


def write_data_quality() -> None:
    lines = [
        "# PHASE 67 §4 — BROKER XAUUSD DATA QUALITY", "",
        f"Generated (UTC): {NOW}", "",
        "**STATUS: BROKER_DATA_PENDING** — no broker XAUUSD dataset exists on "
        "this host (Linux, no MetaTrader 5). Per §1 the broker-data portion "
        "is STOPPED. **No broker data was simulated and GC=F was never "
        "renamed XAUUSD.**", "",
        "## What will run (unchanged) once broker data exists", "",
        "1. `python scripts/download_mt5_data.py --symbol XAUUSD` on Windows "
        "downloads M1/M5/M15/M30/H1/H4/D1 with FULL immutable provenance "
        "(broker, server, account, trade_mode, digits, point, tick size/value, "
        "contract size, volume min/max/step, stops level, freeze level, "
        "spread, swap long/short, currency, margin mode, filling mode, "
        "timezone, per-TF start/end/bar-count, download timestamp, MT5 build "
        "+ SHA-256 of every parquet).",
        "2. `python scripts/broker_data_quality.py` executes the complete "
        "battery below and writes `reports/broker_data_quality.json`.",
        "",
        "## Quality battery (implemented in app/data/quality_suite.py)", "",
        "| check | what it detects | silent repair? |",
        "|---|---|---|",
        "| duplicate timestamps | duplicated bars | never — logged |",
        "| missing bars / session gaps | weekend & holiday gaps vs genuine "
        "missing data (session-aware) | never — logged |",
        "| invalid OHLC | high<low, non-positive, OHLC vs close bounds | "
        "never — logged |",
        "| impossible prices | ticks/bars outside plausible range | never — "
        "logged |",
        "| abnormal jumps | bars beyond k×ATR without news/session cause | "
        "never — logged |",
        "| incomplete bars | partial candles at download time | never — "
        "logged |",
        "| timezone errors | naive vs UTC-aware, broker-offset mismatches | "
        "never — logged |",
        "| abnormal spread | spread column outliers vs rolling median | "
        "never — logged |",
        "| stale data | duplicated OHLC rows / zero-range streaks | never — "
        "logged |",
        "", "Every deletion or transformation is logged to the JSON report; "
        "nothing is repaired silently.", "",
        "## Verdict rules", "",
        "- score < min_score ⇒ pipeline aborts before training",
        "- session breaks (CME maintenance, weekends, holidays) are "
        "classified as structure, NOT as missing data",
        "- the report must reach **BROKER_DATA_VALIDATED** before any "
        "broker-statistics claim", "",
        "## Reproduce", "", "```",
        "# Windows (MT5 running):",
        "python scripts/download_mt5_data.py --symbol XAUUSD",
        "python scripts/broker_data_quality.py", "```", "",
        "## Current host evidence", "",
        "- `reports/mt5_environment.json`: MetaTrader5 package NOT INSTALLED, "
        "platform Linux → §1 STOP decision.",
        "- GC=F datasets on disk are clearly labelled "
        "`REAL_GC_F_PROXY_NOT_BROKER` in every Phase 67 artifact.", "",
    ]
    Path("reports/BROKER_XAUUSD_DATA_QUALITY.md").write_text(
        "\n".join(lines), encoding="utf-8")
    Path("reports/broker_data_quality_phase67.json").write_text(json.dumps(
        {"status": "BROKER_DATA_PENDING", "generated": NOW,
         "reason": "no Windows/MT5 host (§1 STOP); tooling ready",
         "data_simulated": False}, indent=2), encoding="utf-8")


def write_comparison() -> None:
    lines = [
        "# PHASE 67 §5 — BROKER XAUUSD vs GC=F COMPARISON", "",
        f"Generated (UTC): {NOW}", "",
        "**STATUS: COMPARISON_PENDING** — one side of the comparison (broker "
        "XAUUSD) does not exist on this host. Per §1 the broker-data portion "
        "is STOPPED. **The two instruments are NEVER treated as "
        "interchangeable.**", "",
        "## Standing rule", "",
        "GC=F is a COMEX gold FUTURES contract; broker XAUUSD is an OTC spot "
        "C FD. They differ in price basis (futures carry/contango), trading "
        "hours (CME sessions vs ~24×5 broker feed), tick size/valuation, "
        "volume meaning and spread formation. Any pipeline trained on GC=F "
        "and traded on XAUUSD inherits an UNQUANTIFIED basis risk until the "
        "comparison below is run on overlapping periods.", "",
        "## What will run (tooling: scripts/compare_gcf_xauusd.py)", "",
        "On overlapping periods only, the tool measures: close correlation, "
        "return correlation, ATR correlation, volatility ratio, session "
        "behaviour, candle alignment, price basis (level offset and drift), "
        "gap statistics and market-hours coverage.", "",
        "Outputs `reports/gcf_vs_xauusd.json` with every metric timeframed, "
        "dated, sample-sized and method-labelled.", "",
        "## Reproduce", "", "```",
        "# Windows (after §3 download):",
        "python scripts/compare_gcf_xauusd.py --broker-symbol XAUUSD",
        "```", "",
        "## Interim statement (honest)", "",
        "Until that run exists, ALL GC=F-derived statistics in this repo "
        "(Phase 65/66/67) are labelled `REAL_GC_F_PROXY_NOT_BROKER` and can "
        "only support research conclusions about METHODOLOGY — never claims "
        "about live broker XAUUSD behaviour.", "",
    ]
    Path("reports/BROKER_VS_GCF.md").write_text("\n".join(lines),
                                                encoding="utf-8")
    Path("reports/gcf_vs_xauusd_phase67.json").write_text(json.dumps(
        {"status": "COMPARISON_PENDING", "generated": NOW,
         "reason": "broker XAUUSD dataset absent (§1 STOP); tooling ready",
         "interchangeable": False, "data_simulated": False}, indent=2),
        encoding="utf-8")


if __name__ == "__main__":
    write_data_quality()
    write_comparison()
    print("[pending] wrote reports/BROKER_XAUUSD_DATA_QUALITY.md and "
          "reports/BROKER_VS_GCF.md")
