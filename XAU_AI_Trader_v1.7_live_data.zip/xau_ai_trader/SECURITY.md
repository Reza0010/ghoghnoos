# SECURITY.md — Security Model & Audit

## 1. Threat model

| Asset | Threats | Mitigations |
|---|---|---|
| API keys (Z.ai/Gemini/Groq/OpenRouter/Telegram/MT5) | Leakage via repo, logs, config, AI prompts | Env-only storage; `.gitignore` blocks `.env`; log `SecretMaskingFilter` + `mask_secrets*` helpers; keys never enter prompts or journal payloads |
| Untrusted news content | Prompt injection, log injection, control-char attacks | `sanitize_untrusted_text` (control chars removed, `<>` neutralised, length-capped) applied at model-validation layer; news injected only inside `<untrusted_news>` blocks with explicit treat-as-data instruction |
| Untrusted AI output | Malformed JSON, schema abuse, injected instructions, oversized payloads | `AIOutput` pydantic strict validation (enum decision, confidence ∈ [0,1], reason-code sanitisation, string length caps); invalid → provider skipped → failover → SAFE MODE/WAIT |
| Trading risk | Runaway losses, AI overreach | Risk Engine is deterministic and independent; AI cannot modify `MAX_RISK`, `MAX_LOT`, `MAX_DRAWDOWN`, `MAX_DAILY_LOSS`; hard filters + daily-loss stop + drawdown stop + persistent Kill Switch |
| Live execution | Accidental real orders | Triple gate: `mode: live` AND `live_trading_enabled: true` AND env `LIVE_CONFIRM=YES`; SimulatedProvider refuses order calls outright |
| Model files | Unsafe deserialization (pickle RCE) | LightGBM text booster, XGBoost JSON, HMM `.npz` (`allow_pickle=False`), calibrators as JSON thresholds, scalers as JSON stats. **No pickle anywhere.** |
| SQL journal | Injection | Parameterised sqlite statements only |
| Config | Malicious YAML / path traversal | `yaml.safe_load`; pydantic validation; paths resolved relative to project root; `is_safe_file_path` helper for any user-supplied path |
| Data feeds | Corrupted/manipulated candles | Data-quality score (gaps, duplicates, ordering, impossible OHLC, non-positive prices, spread anomalies, staleness); low score → WAIT |
| Dashboard/state | XSS through state values | Streamlit renders values as text metrics; AI text fields are sanitised before persistence |

## 2. Audit results (PHASE 51/64)

| Check | Status |
|---|---|
| No hard-coded API keys (grep across `app/`, `*.py`) | ✅ pass |
| `.env` in `.gitignore`; `.env.example` contains no real values | ✅ pass |
| Log masking filter active on root logger | ✅ pass (`tests/test_ai_gateway.py::test_reason_codes_sanitized` covers sanitisation; masking covered by `app/core/security.py` helpers) |
| AI output schema validation enforced | ✅ pass (`test_parse_ai_output_rejects_bad_confidence`, `test_schema_violation_treated_as_failure`) |
| Prompt-injection defense | ✅ pass (`test_prompt_injection_defense`, `test_news_wrapped_as_untrusted_data`, `test_system_prompt_contains_safety_rules`) |
| Kill switch persistence & reset | ✅ pass (`tests/test_risk.py::test_kill_switch_*`) |
| Live-mode triple gate | ✅ pass (`tests/test_execution.py::test_live_executor_requires_explicit_config`) |
| No `eval`/`exec`/unsafe pickle in codebase | ✅ pass (manual review) |
| Secrets excluded from AI market state | ✅ pass (market state builder emits market data only) |

## 3. Known limitations & residual risks

1. **HTTP news provider** is a strict-schema skeleton — point it at your own
   calendar endpoint and review its payload handling before use.
2. **MT5 filling mode** is hard-set to IOC in `MT5DataProvider`; some brokers
   require FOK/RETURN — verify against your broker's symbol modes before live
   use.
3. Telegram messages are sent over HTTPS but the bot token grants full bot
   control — restrict the bot to your chat and rotate tokens if leaked.
4. The gateway cost ledger estimates cost from token counts using a config
   constant — real invoices differ per provider/model.
5. Log files may contain market narratives produced by LLMs (sanitised) — do
   not treat them as verified facts.

## 4. Reporting

If you find a vulnerability, do NOT open a public issue with exploit details.
Document it, rotate any exposed credentials, and fix privately.
