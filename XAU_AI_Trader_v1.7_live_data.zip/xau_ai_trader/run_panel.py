#!/usr/bin/env python3
"""v1.7 — ONE-COMMAND launcher for the whole XAU AI Trader system.

    python run_panel.py

What it does (in order):
  1. Verifies the Python version and the project's required packages;
     missing ones are installed automatically with pip (skip: --no-install).
  2. Starts the control panel web server (default http://127.0.0.1:8788)
     and opens your browser automatically.
  3. From the panel you can START/STOP the trading loop (paper or
     mt5-readonly), configure AI API providers/keys, and watch all real
     system data live.

Windows shortcut: double-click START_PANEL.bat (it calls this file).

Useful flags:
    --port 8788          panel port
    --host 127.0.0.1     bind address (0.0.0.0 = LAN access)
    --token SECRET       require X-Panel-Token on write endpoints (recommended
                         when binding to 0.0.0.0)
    --config PATH        alternative config.yaml
    --with-trader        also start the paper trading loop immediately
    --no-install         never run pip
    --no-browser         do not open the browser
"""

from __future__ import annotations

import argparse
import importlib
import os
import subprocess
import sys
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MIN_PY = (3, 10)

# packages required by the core system (panel itself is stdlib-only)
REQUIRED = [
    ("numpy", "numpy"),
    ("pandas", "pandas"),
    ("yaml", "PyYAML"),
    ("pydantic", "pydantic"),
    ("dotenv", "python-dotenv"),
    ("httpx", "httpx"),
    ("pyarrow", "pyarrow"),
    ("rich", "rich"),
    ("sklearn", "scikit-learn"),
    ("lightgbm", "lightgbm"),
    ("xgboost", "xgboost"),
    ("hmmlearn", "hmmlearn"),
]
OPTIONAL = [("MetaTrader5", "MetaTrader5")]  # Windows-only broker bridge


def banner() -> None:
    print("=" * 66)
    print("  🪙  XAU AI Trader  —  Control Panel v1.7 (live market data)")
    print("=" * 66)


def check_python() -> bool:
    if sys.version_info < MIN_PY:
        print(f"✖ Python {MIN_PY[0]}.{MIN_PY[1]}+ is required "
              f"(found {sys.version.split()[0]})")
        return False
    print(f"✔ Python {sys.version.split()[0]}")
    return True


def find_missing() -> list[str]:
    missing = []
    for module, pkg in REQUIRED:
        try:
            importlib.import_module(module)
        except Exception:
            missing.append(pkg)
    return missing


def install(missing: list[str]) -> bool:
    if not missing:
        return True
    print(f"→ installing missing packages: {', '.join(missing)}")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet",
                               "--disable-pip-version-check", *missing])
        print("✔ dependencies ready")
        return True
    except subprocess.CalledProcessError as e:
        print(f"✖ pip install failed (exit {e.returncode}). Install manually:\n"
              f"    {sys.executable} -m pip install {' '.join(missing)}")
        return False


def check_optional() -> None:
    for module, pkg in OPTIONAL:
        try:
            importlib.import_module(module)
        except Exception:
            print(f"ℹ optional package '{pkg}' not installed "
                  f"(needed only for real MT5 connection on Windows)")


def main() -> int:
    parser = argparse.ArgumentParser(description="XAU AI Trader — one-command panel")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8788)
    parser.add_argument("--config", default=None)
    parser.add_argument("--token", default=None,
                        help="panel write-token (or PANEL_TOKEN env)")
    parser.add_argument("--with-trader", action="store_true",
                        help="start the paper trading loop immediately at boot")
    parser.add_argument("--no-install", action="store_true")
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    banner()
    if not check_python():
        return 2

    os.environ.setdefault("XAU_PROJECT_ROOT", str(ROOT))
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))

    missing = find_missing()
    if missing and not args.no_install:
        if not install(missing):
            return 2
    elif missing:
        print(f"✖ missing packages and --no-install set: {', '.join(missing)}")
        return 2
    else:
        print("✔ all dependencies present")

    check_optional()

    # import AFTER dependency check so the error message stays friendly
    try:
        from app.panel.server import serve
    except Exception as e:
        print(f"✖ panel import failed: {type(e).__name__}: {e}")
        return 2

    token = args.token or os.environ.get("PANEL_TOKEN")
    if args.host == "0.0.0.0" and not token:
        print("⚠ binding to 0.0.0.0 without --token: write endpoints are OPEN "
              "on your LAN. Prefer:  python run_panel.py --host 0.0.0.0 --token SECRET")

    try:
        httpd, url = serve(ROOT, args.host, args.port, args.config, token,
                           open_browser=not args.no_browser)
    except OSError as e:
        print(f"✖ cannot bind {args.host}:{args.port} — {e}\n"
              f"  try another port:  python run_panel.py --port {args.port + 1}")
        return 2

    if args.with_trader:
        try:
            from app.panel.server import PanelServer  # reuse resolved config path
            ps = PanelServer(ROOT, args.host, args.port, args.config, token)
            r = ps.loop_mgr.start(mode="paper")
            print(("▶ trading loop: " + r.get("state", "?")) if r.get("ok")
                  else ("✖ loop start refused: " + r.get("error", "?")))
        except Exception as e:
            print(f"✖ trading loop failed to start: {e}")

    print(f"✔ panel ready → {url}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n■ stopping panel…")
        try:
            ps.loop_mgr.stop(timeout=8)  # type: ignore[name-defined]
        except Exception:
            pass
    print("■ panel stopped. goodbye.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
