"""نقطه ورود MinerMedia AI — سیم‌کشی لایه‌ها بدون منطق در UI.

اجرا: python app.py
داده‌ها: %APPDATA%\\MinerMediaAI (ویندوز) یا ~/.local/share/MinerMediaAI
توسعه/تست: MINERMEDIA_DATA_DIR=/مسیر/دلخواه
"""
from __future__ import annotations

import sys
import threading


def main() -> int:
    # ---------- آدرس داده (قبل از هر ایمپورت وابسته به paths) ----------
    argv = sys.argv[1:]
    if "--data-dir" in argv:
        i = argv.index("--data-dir")
        if i + 1 < len(argv):
            import os
            os.environ["MINERMEDIA_DATA_DIR"] = argv[i + 1]
            del argv[i:i + 2]

    try:
        from PySide6.QtGui import QFont
        from PySide6.QtWidgets import QApplication

        from config import defaults as cfg
        from config.settings import AppSettings
        from core.logging_setup import setup_logging
        from core.paths import get_data_dir, get_db_path, get_media_dir
        from database.db import Database
        from database.repositories import (ChannelsRepo, DraftsRepo, LogsRepo,
                                           MarketRepo, MediaRepo, NewsRepo,
                                           PostsRepo, SettingsRepo)
        from security.secret_store import create_secret_store
        from services.ai.provider import AIProvider
        from services.ai.studio import ContentStudioService
        from services.market_data.service import MarketDataService
        from services.media.library import MediaLibraryService
        from services.news.service import NewsService
        from services.nobitex.client import NobitexClient
        from ui.fonts import load_fonts
        from ui.theme import apply_theme
        from workers.market_worker import MarketWorker
        from workers.news_worker import NewsWorker
        from workers.scheduler import SchedulerService
    except ImportError as exc:
        missing = getattr(exc, "name", None) or str(exc)
        print("[MinerMedia AI] خطا: ماژول «%s» نصب نیست." % missing,
              file=sys.stderr)
        print("راه‌حل:  pip install -r requirements.txt", file=sys.stderr)
        print("(اگر از محیط مجازی استفاده می‌کنید، ابتدا آن را فعال کنید: "
              ".venv\\Scripts\\activate)", file=sys.stderr)
        print("نکته: requirements-dev.txt فقط ابزار تست است و وابستگی‌های "
              "اصلی برنامه را نصب نمی‌کند.", file=sys.stderr)
        return 2

    setup_logging()
    log = __import__("logging").getLogger("minermedia.app")
    log.info("starting MinerMedia AI v%s | data dir: %s",
             cfg.APP_VERSION, get_data_dir())

    app = QApplication(argv)
    apply_theme(app)
    family = load_fonts()
    app.setFont(QFont(family, 10))

    # ---------- لایه داده ----------
    db = Database(get_db_path())
    db.migrate()
    channels_repo = ChannelsRepo(db)
    posts_repo = PostsRepo(db)
    market_repo = MarketRepo(db)
    market_repo.seed_defaults(cfg.DEFAULT_WATCHLIST)
    news_repo = NewsRepo(db)
    drafts_repo = DraftsRepo(db)
    settings_repo = SettingsRepo(db)
    logs_repo = LogsRepo(db)
    media_repo = MediaRepo(db)

    settings = AppSettings(settings_repo)
    secret_store = create_secret_store(get_data_dir())
    if secret_store.insecure:
        logs_repo.add("WARNING", "SECURITY",
                      "بک‌اند رمز امن در دسترس نیست؛ فایل محلی (حالت توسعه) استفاده شد.")

    # ---------- بازیابی پس از بستن ناگهانی ----------
    recovered = posts_repo.recover_at_startup()
    n_pending = recovered.get("pending", 0)
    n_unknown = recovered.get("unknown", 0)
    if n_pending:
        logs_repo.add("INFO", "SCHEDULER",
                      f"{n_pending} پست claim‌شده ولی ارسال‌نشده به صف بازگشت "
                      "(ارسالی در کار نبود — بدون خطر تکرار).")
    if n_unknown:
        logs_repo.add("WARNING", "SCHEDULER",
                      f"{n_unknown} پست حین ارسال با برنامهٔ بسته روبه‌رو شد؛ "
                      "نتیجه نامشخص است — تصمیم ارسال دوباره با شما است.")

    # ---------- سرویس‌ها ----------
    nobitex = NobitexClient()
    market_service = MarketDataService(nobitex, market_repo,
                                       settings.market_refresh_sec)
    news_service = NewsService(news_repo)

    def ai_key_provider() -> str:
        return secret_store.get_secret("ai.api_key") or ""

    ai_provider_holder = {}

    def build_ai_provider() -> AIProvider:
        return AIProvider(settings.ai_base_url, ai_key_provider,
                          settings.ai_text_model)

    ai_provider_holder["provider"] = build_ai_provider()

    class _AiProxy:
        """پروکسی تا تغییر تنظیمات AI بدون ری‌استارت اعمال شود."""
        @property
        def configured(self):
            return ai_provider_holder["provider"].configured

        def chat(self, *a, **kw):
            return ai_provider_holder["provider"].chat(*a, **kw)

        def generate_image(self, *a, **kw):
            return ai_provider_holder["provider"].generate_image(*a, **kw)

    ai_proxy = _AiProxy()
    studio = ContentStudioService(ai_proxy, drafts_repo, market_service)
    media_service = MediaLibraryService(media_repo, get_media_dir())

    # ---------- Workerها ----------
    scheduler = SchedulerService(posts_repo, channels_repo, secret_store)
    scheduler.start()

    def interval_provider() -> float:
        return settings.market_refresh_sec

    def symbols_provider() -> list:
        return [w.symbol for w in market_repo.list_watch(visible_only=True)]

    market_worker = MarketWorker(market_service, interval_provider,
                                 symbols_provider)
    market_worker.start()

    # ---------- Worker اخبار (زمان‌بندی‌شده، مستقل از UI و قیمت) ----------
    def news_interval_provider() -> float:
        return settings.news_refresh_sec

    def news_sources_provider() -> list:
        return settings.enabled_news_sources

    news_worker = NewsWorker(news_service, news_interval_provider,
                             news_sources_provider)
    news_worker.start()

    # ---------- Threadهای kick لحظه‌ای — ثبت‌شده تا در خاموشی منتظرشان بمانیم ----------
    _kick_threads: list[threading.Thread] = []
    _kick_lock = threading.Lock()

    def kick_market_worker() -> None:
        """به‌روزرسانی فوری قیمت‌ها در Thread جدا — هرگز UI را بلاک نمی‌کند."""
        def _immediate():
            try:
                result = market_service.refresh(symbols_provider())
                market_worker._emit(result)
            except Exception as exc:  # noqa: BLE001
                log.error("immediate market refresh failed: %s", exc)
        t = threading.Thread(target=_immediate, daemon=True,
                             name="market-kick")
        with _kick_lock:
            _kick_threads.append(t)
            # پاک‌سازی threadهای تمام‌شده
            _kick_threads[:] = [x for x in _kick_threads if x.is_alive()]
        t.start()

    def kick_threads() -> list[threading.Thread]:
        with _kick_lock:
            return list(_kick_threads)

    # ---------- UI ----------
    class Ctx:
        pass

    ctx = Ctx()
    ctx.db = db
    ctx.settings = settings
    ctx.secret_store = secret_store
    ctx.channels_repo = channels_repo
    ctx.posts_repo = posts_repo
    ctx.market_repo = market_repo
    ctx.news_repo = news_repo
    ctx.drafts_repo = drafts_repo
    ctx.logs_repo = logs_repo
    ctx.market_service = market_service
    ctx.news_service = news_service
    ctx.studio = studio
    ctx.media_service = media_service
    ctx.scheduler = scheduler
    ctx.market_worker = market_worker
    ctx.news_worker = news_worker
    ctx.kick_market_worker = kick_market_worker
    ctx.kick_threads = kick_threads

    class _AiView:
        """نمای AI برای UI (configured + chat با پشتیبانی تنظیمات زنده)."""
        configured = property(lambda self: ai_proxy.configured)
        chat = staticmethod(lambda *a, **kw: ai_proxy.chat(*a, **kw))
        generate_image = staticmethod(lambda *a, **kw: ai_proxy.generate_image(*a, **kw))

    ctx.ai_provider = _AiView()

    def rebuild_ai_provider() -> None:
        ai_provider_holder["provider"] = build_ai_provider()

    ctx.rebuild_ai_provider = rebuild_ai_provider

    from ui.main_window import MainWindow
    window = MainWindow(ctx)
    ctx.main_window = window
    window.show()

    exit_code = app.exec()
    log.info("MinerMedia AI exited (code=%s)", exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
