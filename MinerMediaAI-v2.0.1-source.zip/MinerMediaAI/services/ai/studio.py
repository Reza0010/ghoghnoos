"""استودیوی تولید محتوای تخصصی ماینینگ.

قواعد سخت‌گیرانه (طبق مأموریت):
- مدل نباید شماره پایه، ولتاژ، کد خطا، مدل چیپ یا روش تعمیر را اختراع کند.
- اخبار باید تاریخ و لینک منبع داشته باشند.
- قیمت‌ها فقط از MarketDataService (داده واقعی) تزریق می‌شوند، نه از حافظه مدل.
- عدم قطعیت باید صریح بیان شود.
"""
from __future__ import annotations

import json

from config import defaults as cfg
from core.timeutils import utc_iso
from database.repositories import DraftsRepo
from models.entities import ContentDraft, GenerationRecord, NewsItem
from services.ai.provider import AIProvider
from services.market_data.service import MarketDataService

SYSTEM_RULES = """تو دستیار تولید محتوای تخصصی «تعمیرات ماینر و ماینینگ» هستی.

قواعد اجباری:
1. هرگز شماره پایه، ولتاژ دقیق، کد خطا، مدل چیپ یا روش تعمیر را از خودت اختراع نکن.
   اگر اطلاعات فنی قطعی لازم است و در دسترس نیست، صریح بنویس «نیازمند تأیید فنی».
2. برای مطالب فنی فقط از اطلاعات داده‌شده یا دانش عمومی ایمن استفاده کن و عدم قطعیت را اعلام کن.
3. اخبار باید تاریخ و منبع داشته باشند؛ هرگز خبر قدیمی را جدید معرفی نکن.
4. قیمت ارزها را فقط از بخش «داده بازار» که به تو داده می‌شود نقل کن؛ از حدس زدن قیمت خودداری کن.
5. خروجی را دقیقاً در قالب JSON خواسته‌شده بده؛ متناسب با کانال تلگرام، فارسی روان و حرفه‌ای.
6. ایمنی کاربر مهم است: در محتوای تعمیراتی، هشدار ایمنی لازم را ذکر کن (برق ۲۲۰/۳۸۰ ولت، تخلیه خازن، ESD)."""


def _market_snapshot_text(market_service: MarketDataService | None,
                          symbols: list[str]) -> str:
    """عکس لحظه‌ای قیمت از داده واقعی — فقط در صورت تازگی داده."""
    if market_service is None:
        return ""
    lines = []
    for sym in symbols[:8]:
        info = market_service.display_price(sym, "TOMAN", allow_estimated=True)
        if not info:
            info = market_service.display_price(sym, "USDT")
        if not info:
            lines.append(f"- {sym}: ناموجود (منبع در دسترس نیست)")
            continue
        from core.units import format_amount, format_percent
        q = market_service.get_quote(sym, f"{sym}IRT") or \
            market_service.get_quote(sym, f"{sym}USDT")
        chg = format_percent(q.day_change_pct) if q else "—"
        tag = " (تخمینی)" if info.get("estimated") else ""
        lines.append(
            f"- {sym}: {format_amount(info['price'])} {info['unit']}{tag} | "
            f"تغییر ۲۴س: {chg} | منبع: {info['source']} | زمان: {info['fetched_at']}"
            + (" | داده کهنه" if info.get("stale") else ""))
    if not lines:
        return ""
    return "\n".join(["داده بازار (فقط از این مقادیر استفاده کن و واحد را دقیق بگو):"] + lines)


_TYPE_HINTS = {
    "short_post": "یک پست آموزشی کوتاه (۱۲۰ تا ۲۰۰ کلمه) با یک نکته قابل استفاده",
    "tutorial": "آموزش تخصصی مرحله‌به‌مرحله با شماره‌گذاری مراحل و هشدارهای ایمنی",
    "news_flash": "خبر فوری کوتاه (۳ تا ۵ جمله) با ذکر تاریخ و منبع",
    "news_analysis": "تحلیل خبر: خلاصه خبر + دو تا سه نکته تحلیلی و اثر احتمالی",
    "part_intro": "معرفی یک قطعه/ابزار تعمیراتی: کاربرد، محل استفاده، نکته خرید",
    "troubleshooting": "فهرست نکات عیب‌یابی به‌صورت «علت ← بررسی ← اقدام»",
    "comparison": "مقایسه فنی دو گزینه در قالب جدول متنی ساده و جمع‌بندی",
    "image_post": "پست کوتاه مناسب انتشار همراه با یک تصویر (توضیح تصویر هم بده)",
    "caption_hashtag": "کپشن کوتاه جذاب + ۵ هشتگ مرتبط فارسی و انگلیسی",
    "series": "پست اول یک مجموعه دنباله‌دار با معرفی نقشه محتوای ۵ قسمتی",
}


class ContentStudioService:
    def __init__(self, provider: AIProvider, drafts_repo: DraftsRepo,
                 market_service: MarketDataService | None = None):
        self.provider = provider
        self.repo = drafts_repo
        self.market = market_service

    @staticmethod
    def categories() -> list[tuple[str, str]]:
        return list(cfg.CONTENT_CATEGORIES)

    @staticmethod
    def content_types() -> list[tuple[str, str]]:
        return list(cfg.CONTENT_TYPES)

    def generate(self, category: str, ctype: str, brief: str,
                 use_market_data: bool = False,
                 temperature: float | None = None,
                 max_tokens: int | None = None) -> ContentDraft:
        cat_title = dict(self.categories()).get(category, category)
        type_hint = _TYPE_HINTS.get(ctype, ctype)
        market_text = ""
        if use_market_data and category in ("coin_market", "mining_industry",
                                            "bitcoin_network"):
            from config import defaults as d
            market_text = _market_snapshot_text(
                self.market, [s for s, _ in d.DEFAULT_WATCHLIST])
        user = (
            f"دسته محتوا: {cat_title}\n"
            f"نوع محتوا: {type_hint}\n"
            f"خواسته کاربر: {brief or '—'}\n\n"
            f"{market_text}\n\n"
            'خروجی را فقط به این شکل JSON بده:\n'
            '{"title": "...", "body": "...", "hashtags": ["#..."], '
            '"needs_technical_check": true|false, "uncertainty_notes": ["..."]}'
        )
        rec = GenerationRecord(category=category, ctype=ctype, provider="openai-compatible")
        try:
            result = self.provider.chat(
                SYSTEM_RULES, user,
                temperature=cfg.DEFAULT_AI_TEMPERATURE if temperature is None else temperature,
                max_tokens=cfg.DEFAULT_AI_MAX_TOKENS if max_tokens is None else max_tokens)
        except Exception as exc:  # noqa: BLE001 — ثبت در تاریخچه و بازپخش
            rec.ok, rec.error = False, exc.user_message
            self.repo.add_generation(None, category, ctype, rec.provider,
                                     getattr(self.provider, "_model", ""), None,
                                     None, False, exc.user_message)
            raise
        parsed = self._parse_json(result.text)
        draft = ContentDraft(
            id=None, category=category, ctype=ctype,
            title=str(parsed.get("title", "")).strip(),
            body=str(parsed.get("body", "")).strip(),
            hashtags=" ".join(parsed.get("hashtags", []) or []),
            meta=json.dumps({
                "needs_technical_check": bool(parsed.get("needs_technical_check")),
                "uncertainty_notes": parsed.get("uncertainty_notes", []),
                "market_data_used": bool(market_text),
                "model": result.model,
            }, ensure_ascii=False), status="draft")
        draft_id = self.repo.create(draft)
        draft.id = draft_id
        self.repo.add_generation(draft_id, category, ctype, "openai-compatible",
                                 result.model, result.prompt_tokens,
                                 result.completion_tokens, True)
        return draft

    def news_to_draft(self, item: NewsItem, mode: str = "summary") -> ContentDraft:
        """تبدیل خبر به پیش‌نویس تلگرام — با حفظ منبع و تاریخ.

        بدون دسترسی به متن/مدل واقعی، این متد خطای صادقانه می‌دهد.
        """
        if not item.title:
            from core.errors import ValidationError
            raise ValidationError("empty news", "خبر انتخابی نامعتبر است.")
        style = ("خلاصه مستقل و کوتاه (۳ تا ۶ جمله) از خبر زیر — از کپی کامل "
                 "متن خودداری کن") if mode == "summary" else \
                ("تحلیل کوتاه خبر زیر با دو نکته تحلیلی — از کپی کامل متن "
                 "خودداری کن")
        user = (
            f"{style}.\n\n"
            f"عنوان خبر: {item.title}\n"
            f"منبع: {item.source}\n"
            f"تاریخ انتشار: {item.published_at or 'نامشخص'}\n"
            f"لینک: {item.link}\n"
            f"خلاصه/متن اولیه: {item.summary or '—'}\n\n"
            'خروجی فقط JSON: {"title": "...", "body": "...", "hashtags": ["#..."], '
            '"needs_technical_check": false, "uncertainty_notes": ["..."]}'
        )
        result = self.provider.chat(SYSTEM_RULES, user, temperature=0.5)
        parsed = self._parse_json(result.text)
        body = str(parsed.get("body", "")).strip()
        source_line = (f"\n\nمنبع: {item.source} — {item.link}\n"
                       f"تاریخ خبر: {item.published_at or 'نامشخص'}")
        draft = ContentDraft(
            id=None, category="mining_industry", ctype="news_flash",
            title=str(parsed.get("title", "")).strip() or item.title,
            body=body + source_line,
            hashtags=" ".join(parsed.get("hashtags", []) or []),
            meta=json.dumps({"news_id": item.id, "news_guid": item.guid,
                             "source_link": item.link,
                             "published_at": item.published_at},
                            ensure_ascii=False), status="review")
        draft_id = self.repo.create(draft)
        draft.id = draft_id
        self.repo.add_generation(draft_id, draft.category, draft.ctype,
                                 "openai-compatible", result.model,
                                 result.prompt_tokens, result.completion_tokens, True)
        return draft

    @staticmethod
    def _parse_json(text: str) -> dict:
        """پارس مقاوم JSON از پاسخ مدل (با یا بدون کدبلاک)."""
        text = (text or "").strip()
        if "```" in text:
            for part in text.split("```"):
                part = part.strip()
                if part.startswith("json"):
                    part = part[4:].strip()
                if part.startswith("{"):
                    text = part
                    break
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end > start:
            text = text[start:end + 1]
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                return data
        except (ValueError, TypeError):
            pass
        # fallback صادقانه: کل متن به‌عنوان بدنه پست
        return {"title": "", "body": text or "(پاسخ مدل خالی بود)",
                "hashtags": [], "needs_technical_check": True,
                "uncertainty_notes": ["خروجی مدل JSON نبود؛ بازبینی دستی لازم است."]}
