"""ارائه‌دهنده هوش مصنوعی سازگار با OpenAI (chat/completions).

- هر سرویس سازگار با OpenAI کار می‌کند: OpenAI، OpenRouter، Together، Groq،
  DeepSeek، Ollama/LM Studio محلی و ...
- کلید API فقط از SecretStore خوانده می‌شود و در لاگ/خطا درز نمی‌کند.
- خطاها: 401/403/404 → AIError دائمی؛ 429 → RateLimitError؛ 5xx/شبکه → موقت.
"""
from __future__ import annotations

import base64

import requests

from core.errors import AIError, NetworkError, RateLimitError
from core.redact import scrub_text
from dataclasses import dataclass


@dataclass
class AIResult:
    text: str
    model: str
    prompt_tokens: int | None = None
    completion_tokens: int | None = None


class AIProvider:
    def __init__(self, base_url: str, api_key_provider, text_model: str,
                 timeout: tuple[float, float] = (10.0, 120.0),
                 session: requests.Session | None = None):
        self._base = (base_url or "").strip().rstrip("/") or \
            "https://api.openai.com/v1"
        self._key_provider = api_key_provider
        self._model = (text_model or "").strip()
        self._timeout = timeout
        self._session = session or requests.Session()

    @property
    def configured(self) -> bool:
        return bool(self._model) and bool(self._key_provider())

    def _headers(self) -> dict:
        key = (self._key_provider() or "").strip()
        if not key:
            raise AIError("missing api key",
                          "کلید API هوش مصنوعی تنظیم نشده است.")
        return {"Authorization": f"Bearer {key}",
                "Content-Type": "application/json"}

    def _post(self, path: str, payload: dict) -> dict:
        url = f"{self._base}{path}"
        try:
            resp = self._session.post(url, json=payload, headers=self._headers(),
                                      timeout=self._timeout)
        except requests.exceptions.ConnectTimeout as exc:
            raise NetworkError(f"ai connect timeout: {exc}",
                               "اتصال به سرویس هوش مصنوعی برقرار نشد.",
                               phase="connect") from exc
        except requests.exceptions.ReadTimeout as exc:
            raise NetworkError(f"ai read timeout: {exc}",
                               "پاسخ مدل هوش مصنوعی دیر رسید.",
                               phase="read") from exc
        except requests.exceptions.ConnectionError as exc:
            raise NetworkError(f"ai connection error: {exc}",
                               "ارتباط با سرویس هوش مصنوعی قطع شد.",
                               phase="connect") from exc
        except requests.RequestException as exc:
            raise NetworkError(f"ai request error: {exc}",
                               "خطای شبکه هنگام تماس با مدل.", ) from exc

        if resp.status_code == 429:
            retry_after = None
            try:
                retry_after = float(resp.headers.get("Retry-After") or 0) or None
            except (TypeError, ValueError):
                retry_after = None
            raise RateLimitError("ai 429",
                                 "محدودیت نرخ سرویس هوش مصنوعی.",
                                 retry_after=retry_after)
        try:
            body = resp.json()
        except ValueError as exc:
            raise AIError(f"ai non-json http {resp.status_code}",
                          "پاسخ نامعتبر از سرویس هوش مصنوعی.",
                          status_code=resp.status_code) from exc
        if resp.status_code != 200:
            msg = ""
            try:
                msg = body.get("error", {}).get("message", "")
            except AttributeError:
                msg = str(body)[:200]
            msg = scrub_text(msg)
            raise AIError(f"ai http {resp.status_code}: {msg}",
                          f"خطای سرویس هوش مصنوعی ({resp.status_code}): "
                          f"{msg[:160] or 'نامشخص'}",
                          status_code=resp.status_code)
        return body

    # ------------------------------ متدها ------------------------------
    def chat(self, system: str, user: str, temperature: float = 0.7,
             max_tokens: int = 900) -> AIResult:
        if not self._model:
            raise AIError("no text model configured",
                          "مدل متن تنظیم نشده است.")
        payload = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        body = self._post("/chat/completions", payload)
        try:
            choice = body["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise AIError(f"ai malformed response: {list(body)[:5]}",
                          "ساختار پاسخ مدل نامعتبر است.") from exc
        usage = body.get("usage") or {}
        return AIResult(text=choice or "", model=body.get("model", self._model),
                        prompt_tokens=usage.get("prompt_tokens"),
                        completion_tokens=usage.get("completion_tokens"))

    def generate_image(self, prompt: str, size: str = "1024x1024",
                       image_model: str = "") -> bytes | None:
        model = (image_model or "").strip()
        if not model:
            raise AIError("no image model configured",
                          "مدل تصویر تنظیم نشده است.")
        body = self._post("/images/generations", {
            "model": model, "prompt": prompt, "size": size, "n": 1,
            "response_format": "b64_json"})
        try:
            b64 = body["data"][0]["b64_json"]
        except (KeyError, IndexError, TypeError) as exc:
            raise AIError("ai image: missing b64_json",
                          "ساختار پاسخ تصویر نامعتبر است.") from exc
        try:
            return base64.b64decode(b64)
        except Exception as exc:  # noqa: BLE001
            raise AIError(f"ai image decode failed: {exc}",
                          "رمزگشایی تصویر ناموفق بود.") from exc
