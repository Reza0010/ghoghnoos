"""سرویس اخبار — دریافت RSS مستقل از سرویس قیمت.

اصول:
- خرابی یک منبع هرگز کل دریافت را متوقف نمی‌کند (خطا per-source ثبت می‌شود).
- در نبود دسترسی وب، هیچ خبر «تازه» ساخته نمی‌شود؛ فقط خطا ثبت می‌شود.
- تشخیص تکراری با guid + hash(عنوان+لینک).
- خلاصه‌سازی فقط با هوش مصنوعی پیکربندی‌شده انجام می‌شود.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta

import feedparser
import requests

from config import defaults as cfg
from core.logging_setup import get_logger
from core.timeutils import parse_iso, utc_iso, utc_now
from database.repositories import NewsRepo
from models.entities import NewsItem, NewsStatus, RefreshResult

log = get_logger("minermedia.news")


@dataclass
class SourceStatus:
    name: str
    ok: bool
    added: int = 0
    error: str = ""


def news_enabled_sources(sources: list | None) -> list[tuple]:
    """نرمال‌سازی فهرست منابع (نام، url، موضوع[, فعال]) و برگرداندن فقط فعال‌ها.

    فرمت منابع در تنظیمات: [name, url, topic] یا [name, url, topic, enabled] —
    سازگار با نسخهٔ قبلی (بدون پرچم = فعال). ورودی نامعتبر نادیده گرفته می‌شود.
    """
    out: list[tuple] = []
    for s in sources or []:
        try:
            name, url = str(s[0]).strip(), str(s[1]).strip()
        except (IndexError, TypeError):
            continue
        if not name or not url.startswith(("http://", "https://")):
            continue
        enabled = bool(s[3]) if len(s) > 3 else True
        topic = str(s[2]) if len(s) > 2 and s[2] else "crypto"
        if enabled:
            out.append((name, url, topic, True))
    return out


class NewsService:
    def __init__(self, repo: NewsRepo, timeout: float = 15.0,
                 session: requests.Session | None = None,
                 max_age_days: int = cfg.NEWS_MAX_AGE_DAYS):
        self.repo = repo
        self._timeout = timeout
        self._session = session or requests.Session()
        self._headers = {"User-Agent": f"MinerMediaAI/{cfg.APP_VERSION} (+news reader)"}
        self._max_age_days = float(max_age_days)

    # ------------------------------ دریافت ------------------------------
    def _fetch_source(self, name: str, url: str) -> tuple[list[NewsItem], str]:
        """خروجی: (آیتم‌ها، خطا). خطا فقط زمانی پر است که دریافت/پارس شکست بخورد."""
        try:
            resp = self._session.get(url, headers=self._headers,
                                     timeout=self._timeout)
        except requests.RequestException as exc:
            return [], f"اتصال به منبع «{name}» ناموفق بود: {type(exc).__name__}"
        if resp.status_code != 200:
            return [], f"منبع «{name}» کد {resp.status_code} برگرداند."
        try:
            parsed = feedparser.parse(resp.content)
        except Exception as exc:  # noqa: BLE001 — feedparser خرابی‌های متنوع
            return [], f"پارس فید «{name}» ناموفق بود: {type(exc).__name__}"
        if parsed.bozo and not parsed.entries:
            return [], f"فید «{name}» نامعتبر است ({parsed.bozo_exception})."
        items = []
        skipped_old = 0
        cutoff = utc_now() - timedelta(days=self._max_age_days)
        for entry in parsed.entries[:30]:
            guid = (getattr(entry, "id", "") or getattr(entry, "link", "")
                    or "").strip()
            title = (getattr(entry, "title", "") or "").strip()
            if not guid or not title:
                continue
            link = (getattr(entry, "link", "") or "").strip()
            summary = ""
            if getattr(entry, "summary", ""):
                summary = entry.summary[:600]
            published = None
            for attr in ("published", "updated"):
                stamp = getattr(entry, attr + "_parsed", None) or getattr(entry, attr, None)
                if stamp:
                    try:
                        if hasattr(stamp, "tm_year"):
                            import calendar, datetime as _dt
                            ts = calendar.timegm(stamp)
                            published = utc_iso(_dt.datetime.fromtimestamp(
                                ts, tz=_dt.timezone.utc))
                        else:
                            published = utc_iso(parse_iso(str(stamp)))
                        break
                    except (ValueError, TypeError, OverflowError):
                        published = None
            # مدیریت صریح «خبر قدیمی»: وارد صف نمی‌شود ولی شمرده و گزارش می‌شود
            # (حذف بی‌صدا ممنوع). خبر فاقد تاریخ حذف نمی‌شود — زمان دریافت
            # به‌عنوان زمان نمایش جایگزین می‌شود و در UI صادقانه برچسب می‌خورد.
            if published:
                try:
                    if parse_iso(published) < cutoff:
                        skipped_old += 1
                        continue
                except (ValueError, TypeError):
                    pass
            items.append(NewsItem(
                id=None, guid=guid, title=title, link=link, source=name,
                topic=self._detect_topic(title + " " + summary),
                published_at=published, fetched_at=utc_iso(),
                summary=summary, status=NewsStatus.NEW.value))
        self._last_skipped_old = skipped_old
        return items, ""

    @staticmethod
    def _detect_topic(text: str) -> str:
        low = text.lower()
        topics = []
        for topic, keywords in cfg.NEWS_TOPIC_KEYWORDS.items():
            if any(k in low for k in keywords):
                topics.append(topic)
        return ",".join(topics) if topics else "general"

    def fetch_all(self, sources: list[tuple] | None = None) -> RefreshResult:
        """دریافت همه منابع فعال — هر منبع مستقل؛ خطاها جمع می‌شوند.

        - منابع فقط به‌صورت (نام، url، موضوع) یا (نام، url، موضوع، فعال) —
          منابع غیرفعال کلاً دریافت نمی‌شوند (فیلتر در news_enabled_sources).
        - خرابی یک منبع هرگز بقیه را متوقف نمی‌کند.
        - شمارش خبرهای قدیمی ردشده به‌صورت شفاف در result.notes ثبت می‌شود.
        """
        result = RefreshResult(fetched_at=utc_iso())
        srcs = sources if sources is not None else \
            news_enabled_sources(cfg.DEFAULT_NEWS_SOURCES)
        skipped_total = 0
        for src in srcs:
            name, url = str(src[0]), str(src[1])
            items, error = self._fetch_source(name, url)
            status = SourceStatus(name=name, ok=not error)
            if error:
                result.errors.append(error)
                status.error = error
            added = 0
            for item in items:
                if self.repo.upsert(item):
                    added += 1
            status.added = added
            result.updated += added
            skipped_total += getattr(self, "_last_skipped_old", 0)
        if skipped_total:
            result.notes.append(
                f"{skipped_total} خبر قدیمی‌تر از {int(self._max_age_days)} روز "
                "وارد صف نشد.")
        result.ok = not result.errors
        return result

    # ------------------------------ گردش کار ------------------------------
    def set_status(self, item_id: int, status: str) -> None:
        allowed = {s.value for s in NewsStatus}
        if status not in allowed:
            from core.errors import ValidationError
            raise ValidationError(f"bad news status {status}",
                                  "وضعیت خبر نامعتبر است.")
        self.repo.set_status(item_id, status)

    def publishable(self, item: NewsItem, require_approval: bool) -> bool:
        """انتشار خبر فقط با تأیید (پیش‌فرض) یا وضعیت‌های مجاز."""
        if require_approval:
            return item.status in (NewsStatus.APPROVED.value,
                                   NewsStatus.REVIEWED.value)
        return item.status != NewsStatus.REJECTED.value
