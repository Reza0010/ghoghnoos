"""سرویس داده بازار — تنها لایه‌ای که قیمت را تفسیر و ذخیره می‌کند.

قواعد صریح (طبق مأموریت):
1. قیمت ریالی فقط از جفت rls واقعی نوبیتکس (مستند: برحسب ریال).
2. تومان = ریال ÷ 10 — فقط برای «نمایش»، ذخیره همیشه ریال است.
3. اگر جفت ریالی نبود ولی جفت USDT + نرخ USDT/RLS تازه موجود باشد،
   قیمت «تخمینی» با ذکر هر دو منبع/زمان محاسبه می‌شود؛ در غیر این صورت
   ریال = ناموجود. هیچ‌گاه مقدار ساختگی تولید نمی‌شود.
4. هر نقل‌قول دارای source و fetched_at است؛ داده قدیمی stale علامت می‌خورد.
5. نمودار 1h/24h از نمونه‌برداری محلی برنامه (price_samples) و نمودار 7d/30d
   از کندل‌های واقعی UDF نوبیتکس — برچسب واحد/منبع جدا و صریح.
6. خطای «دسته ارزها» از خطای «نرخ USDT/RLS» مستقل است؛ fallback تک‌نمادی
   فقط برای NobitexError 400 (نماد نامعتبر) مجاز است — روی 429/قطع شبکه
   هیچ درخواست اضافه‌ای تولید نمی‌شود.
"""
from __future__ import annotations

import time
from datetime import timedelta

from core.errors import NetworkError, NobitexError, RateLimitError
from core.timeutils import parse_iso, utc_iso, utc_now
from core.units import rial_to_toman
from database.repositories import MarketRepo
from models.entities import PriceQuote, PriceUnit, RefreshResult
from services.nobitex.client import NobitexClient


class MarketDataService:
    def __init__(self, client: NobitexClient, repo: MarketRepo,
                 refresh_interval_sec: float = 60.0):
        self.client = client
        self.repo = repo
        self.refresh_interval = float(refresh_interval_sec)
        self.last_error: str = ""
        self.consecutive_errors: int = 0
        # نمادهای بدون جفت معاملاتی — از اجرای قبلی بازیابی می‌شود (مانا)
        self._invalid_symbols: set[str] = (
            set(repo.get_invalid_symbols()) if repo is not None else set())

    # ------------------------------ به‌روزرسانی ------------------------------
    def refresh(self, watch_symbols: list[str] | None = None) -> RefreshResult:
        """به‌روزرسانی همه ارزهای منتخب.

        نکته واقعی API: زوج «usdt-usdt» نامعتبر است و 400 InvalidCurrency
        می‌دهد؛ پس ارزهای عادی با dst=rls,usdt و نرخ USDT/RLS جداگانه
        (src=usdt, dst=rls) گرفته می‌شوند. در خطای دسته‌ای، به درخواست
        تک‌نمادی fallback می‌شود تا یک نماد خراب همه را از کار نیندازد.
        """
        started = time.monotonic()
        result = RefreshResult(fetched_at=utc_iso())
        symbols = [s.strip().upper()
                   for s in (watch_symbols or self._watch_symbols()) if s.strip()]
        symbols = list(dict.fromkeys(symbols))
        if not symbols:
            return result
        coins = [s for s in symbols if s != "USDT"]
        now_iso = utc_iso()
        parsed: dict[str, PriceQuote] = {}

        def _collect(stats: dict) -> None:
            for key, entry in (stats or {}).items():
                if not isinstance(entry, dict) or "-" not in key:
                    continue
                src, dst = key.split("-", 1)
                src_u = src.upper()
                if src_u not in symbols and src_u != "USDT":
                    continue
                if dst == "rls":
                    quote = self._build_quote(src_u, f"{src_u}IRT", entry,
                                              PriceUnit.RIAL, now_iso)
                elif dst == "usdt":
                    quote = self._build_quote(src_u, f"{src_u}USDT", entry,
                                              PriceUnit.USDT, now_iso)
                else:
                    continue
                parsed[f"{src_u}/{quote.market}"] = quote

        stats_errors: list[str] = []
        batch_exc: Exception | None = None
        # ۱) دسته ارزهای عادی — بدون نمادهای نامعتبر شناخته‌شده
        effective_coins = [c for c in coins if c not in self._invalid_symbols]
        if effective_coins:
            try:
                _collect(self.client.market_stats(effective_coins, ["rls", "usdt"]))
            except (NetworkError, NobitexError, RateLimitError) as exc:
                batch_exc = exc
                stats_errors.append(f"دسته: {exc.user_message}")
        # ۲) نرخ USDT/RLS — پایه قیمت «تخمینی»
        # ⚠️ خطای این درخواست از خطای دسته تفکیک شده است؛ قبلاً هر دو در یک
        # فهرست ریخته می‌شدند و خطای صرفاً نرخ، fallback تک‌نمادیِ N درخواستی
        # را راه می‌انداخت — دقیقاً وقتی که API محدود/قطع است و هیچ درخواست
        # اضافه‌ای مجاز نیست.
        try:
            _collect(self.client.market_stats(["usdt"], ["rls"]))
        except (NetworkError, NobitexError, RateLimitError) as exc:
            stats_errors.append(f"نرخ USDT/RLS: {exc.user_message}")

        # ۳) fallback تک‌نمادی — فقط با دلیل واقعی:
        #    تنها حالت مجاز: NobitexError با status 400 (نماد/جفت نامعتبر)
        #    که یادگیری نماد نامعتبر را لازم می‌کند. روی 429 و قطع شبکه هرگز
        #    درخواست اضافه تولید نمی‌شود (نه single برای نمادها، نه هیچ چیز).
        fallback_worthy = isinstance(batch_exc, NobitexError) \
            and getattr(batch_exc, "status_code", None) == 400
        if fallback_worthy and coins:
            for sym in coins:
                if sym in self._invalid_symbols:
                    continue
                try:
                    _collect(self.client.market_stats([sym], ["rls", "usdt"]))
                except NobitexError as exc:
                    if exc.status_code == 400:
                        # این ارز در نوبیتکس معامله نمی‌شود — از دسته حذف می‌شود
                        self._invalid_symbols.add(sym)
                        if self.repo is not None:
                            try:
                                self.repo.set_invalid_symbols(
                                    list(self._invalid_symbols))
                            except Exception:  # noqa: BLE001
                                pass
                        stats_errors.append(
                            f"{sym}: جفت معاملاتی در نوبیتکس یافت نشد")
                    else:
                        stats_errors.append(f"{sym}: {exc.user_message}")
                except Exception as exc:  # noqa: BLE001 — سرویس هرگز raise نمی‌کند
                    stats_errors.append(f"{sym}: {getattr(exc, 'user_message',
                                                          type(exc).__name__)}")

        # ۴) قضاوت کلی: وقتی هیچ داده‌ای برای ارزهای عادی گرفته نشد (حتی اگر
        #    نرخ USDT/RLS گرفته شده باشد) چرخه شکست خورده است — صادقانه.
        coin_quotes = any(k.split("/")[0] in coins for k in parsed)
        fatal = (not parsed) or bool(effective_coins) and not coin_quotes
        if fatal and stats_errors:
            self.consecutive_errors += 1
            self.last_error = "؛ ".join(stats_errors[:3])
            result.errors = stats_errors
            result.duration_ms = int((time.monotonic() - started) * 1000)
            if self.repo is not None:
                for sym in symbols:
                    self.repo.mark_stale(sym, f"{sym}IRT")
                    if sym != "USDT":
                        self.repo.mark_stale(sym, f"{sym}USDT")
            return result

        # ذخیره + نمونه‌برداری محلی (حداقل ۶۰ ثانیه بین نمونه‌ها)
        # نرخ USDT/RLS همیشه ذخیره می‌شود (پایه قیمت «تخمینی»)
        store_symbols = sorted(set(symbols) | {"USDT"})
        for sym in store_symbols:
            markets = [f"{sym}IRT"] if sym == "USDT" else \
                [f"{sym}IRT", f"{sym}USDT"]
            for market in markets:
                q = parsed.get(f"{sym}/{market}")
                if q is None:
                    result.missing.append(market)
                    self.repo.mark_stale(sym, market)
                    continue
                self.repo.upsert_quote(
                    symbol=sym, market=q.market, price=q.price,
                    currency=q.unit.value, source=q.source,
                    fetched_at=q.fetched_at, day_change=q.day_change_pct,
                    day_high=q.day_high, day_low=q.day_low, day_open=q.day_open,
                    best_buy=q.best_buy, best_sell=q.best_sell,
                    volume_src=q.volume_src, volume_dst=q.volume_dst,
                    is_closed=q.is_closed, stale=False)
                result.updated += 1
                self._maybe_add_sample(q)
        self.consecutive_errors = 0
        # خطای جزئی (نماد بدون جفت) وضعیت کل سرویس را خطادار نمی‌کند
        self.last_error = ""
        result.ok = True
        result.errors = stats_errors
        result.duration_ms = int((time.monotonic() - started) * 1000)
        return result

    def _maybe_add_sample(self, q: PriceQuote) -> None:
        """نمونه‌برداری محلی حداکثر هر ۶۰ ثانیه — هرگز جایگزین تاریخچه
        بازار نمی‌شود؛ فقط برای نمودارهای 1h/24h استفاده می‌شود."""
        if q.price is None:
            return
        last = self.repo.last_sample_at(q.symbol, q.market)
        if last:
            age = (utc_now() - parse_iso(last)).total_seconds()
            if age < 55:
                return
        self.repo.add_sample(q.symbol, q.market, q.price, q.unit.value,
                             q.fetched_at)

    @staticmethod
    def _build_quote(symbol: str, market: str, entry: dict, unit: PriceUnit,
                     fetched_at: str) -> PriceQuote:
        def _f(field: str) -> float | None:
            raw = entry.get(field)
            if raw in (None, ""):
                return None
            try:
                return float(raw)
            except (TypeError, ValueError):
                return None
        return PriceQuote(
            symbol=symbol, market=market, price=_f("latest"), unit=unit,
            source="nobitex", fetched_at=fetched_at,
            day_change_pct=_f("dayChange"), day_high=_f("dayHigh"),
            day_low=_f("dayLow"), day_open=_f("dayOpen"), best_buy=_f("bestBuy"),
            best_sell=_f("bestSell"), volume_src=_f("volumeSrc"),
            volume_dst=_f("volumeDst"), is_closed=bool(entry.get("isClosed")))

    # ------------------------------ خواندن ------------------------------
    def _watch_symbols(self) -> list[str]:
        return [w.symbol for w in self.repo.list_watch(visible_only=True)]

    def get_quote(self, symbol: str, market: str) -> PriceQuote | None:
        row = self.repo.get_quote(symbol.upper(), market)
        if not row:
            return None
        return PriceQuote(
            symbol=row["symbol"], market=row["market"], price=row["price"],
            unit=PriceUnit(row["currency"]), source=row["source"],
            fetched_at=row["fetched_at"], day_change_pct=row["day_change"],
            day_high=row["day_high"], day_low=row["day_low"],
            day_open=row["day_open"], best_buy=row["best_buy"],
            best_sell=row["best_sell"], volume_src=row["volume_src"],
            volume_dst=row["volume_dst"], is_closed=bool(row["is_closed"]),
            stale=bool(row["stale"]))

    def display_price(self, symbol: str, display_unit: str = "TOMAN",
                      allow_estimated: bool = True) -> dict | None:
        """قیمت نمایشی با واحد مشخص. خروجی:
        {price, unit, exact, estimated, stale, source, fetched_at, note}
        """
        symbol = symbol.upper()
        if display_unit == "USDT":
            q = self.get_quote(symbol, f"{symbol}USDT")
            if not q or q.price is None:
                return None
            return {"price": q.price, "unit": "USDT", "exact": True,
                    "estimated": False, "stale": q.stale,
                    "source": q.source, "fetched_at": q.fetched_at, "note": ""}
        # ریال/تومان: اول جفت مستقیم rls
        rial_q = self.get_quote(symbol, f"{symbol}IRT")
        if rial_q and rial_q.price is not None:
            price = rial_q.price
            if display_unit == "TOMAN":
                price = rial_to_toman(rial_q.price)
            return {"price": price, "unit": display_unit, "exact": True,
                    "estimated": False, "stale": rial_q.stale,
                    "source": rial_q.source, "fetched_at": rial_q.fetched_at,
                    "note": ""}
        if not allow_estimated:
            return None
        est = self.estimate_rial(symbol)
        if est is None:
            return None
        price = est["rial"]
        if display_unit == "TOMAN":
            price = rial_to_toman(price)
        return {"price": price, "unit": display_unit, "exact": False,
                "estimated": True, "stale": est["stale"],
                "source": f"{est['source']} × nobitex(USDT/RLS)",
                "fetched_at": est["fetched_at"], "note": est["note"]}

    def estimate_rial(self, symbol: str) -> dict | None:
        """قیمت ریالی تخمینی = latest(USDT جفت) × نرخ USDTIRT.

        فقط اگر هر دو داده تازه باشند (≤ ۲ برابر فاصله به‌روزرسانی)؛
        در غیر این صورت None — تخمین با داده کهنه ممنوع است.
        """
        symbol = symbol.upper()
        usdt_q = self.get_quote(symbol, f"{symbol}USDT")
        rate_q = self.get_quote("USDT", "USDTIRT")
        if not usdt_q or usdt_q.price is None or not rate_q or rate_q.price is None:
            return None
        max_age = max(self.refresh_interval * 2, 120)
        now = utc_now()
        age_p = (now - parse_iso(usdt_q.fetched_at)).total_seconds()
        age_r = (now - parse_iso(rate_q.fetched_at)).total_seconds()
        if age_p > max_age or age_r > max_age:
            return None
        rial = usdt_q.price * rate_q.price
        stale = usdt_q.stale or rate_q.stale
        note = (f"تخمینی = {usdt_q.market} × USDTIRT | "
                f"منابع تازه؛ هر دو از نوبیتکس")
        return {"rial": rial, "source": usdt_q.source, "fetched_at": usdt_q.fetched_at,
                "stale": stale, "note": note}

    def is_stale(self, quote: PriceQuote | dict) -> bool:
        """داده قدیمی‌تر از ۳ برابر فاصله به‌روزرسانی = کهنه."""
        fetched = quote["fetched_at"] if isinstance(quote, dict) else quote.fetched_at
        if not fetched:
            return True
        try:
            age = (utc_now() - parse_iso(fetched)).total_seconds()
        except (ValueError, TypeError):
            return True
        return age > self.refresh_interval * 3

    # ------------------------------ نمودارها ------------------------------
    def local_history(self, symbol: str, market: str,
                      hours: int) -> list[tuple[str, float]]:
        """تاریخچه محلی (نمونه‌برداری برنامه) برای بازه‌های کوتاه."""
        since = utc_iso(utc_now() - timedelta(hours=hours))
        rows = self.repo.samples(symbol.upper(), market, since)
        return [(r["sampled_at"], float(r["price"])) for r in rows if r["price"]]

    def market_history(self, symbol: str, range_key: str) -> dict | None:
        """تاریخچه واقعی بازار از UDF نوبیتکس.

        range_key: 7d (کندل ۶۰ دقیقه‌ای) یا 30d (کندل روزانه)
        خروجی: {points:[(t_iso, close)], unit, resolution, source}
        واحد: بازار IRT → تومان؛ بازار USDT → دلار
        """
        symbol = symbol.upper()
        market = f"{symbol}IRT"
        unit = "TOMAN"
        if range_key == "7d":
            resolution, countback = "60", 7 * 24
        elif range_key in ("30d", "1m"):
            resolution, countback = "D", 30
        else:
            return None
        to_ts = int(utc_now().timestamp())
        try:
            udf = self.client.udf_history(market, resolution, to_ts,
                                          countback=countback)
        except (NetworkError, NobitexError, RateLimitError):
            return None
        if udf.get("s") != "ok":
            return None
        times, closes = udf.get("t", []), udf.get("c", [])
        if not times or not closes:
            return None
        points = []
        for t, c in zip(times, closes):
            try:
                points.append((utc_iso(__import__("datetime").datetime.fromtimestamp(
                    int(t), tz=__import__("datetime").timezone.utc)), float(c)))
            except (ValueError, OverflowError, OSError):
                continue
        return {"points": points, "unit": unit, "market": market,
                "resolution": resolution, "source": "nobitex"}
