"""کلاینت عمومی API نوبیتکس — پیاده‌سازی دقیقاً بر اساس مستندات رسمی.

منبع حقیقت (استخراج‌شده از apidocs.nobitex.ir — OpenAPI market_data.yaml):
- سرور پایه: https://apiv2.nobitex.ir
- GET /market/stats          → عمومی؛ ۲۰ درخواست/دقیقه؛ پارامتر srcCurrency,
  dstCurrency (لیست با کاما). پاسخ: {"status":"ok","stats":{"src-dst":{...}}}
  با فیلدهای رشته‌ای: latest, bestSell, bestBuy, dayOpen, dayClose, dayLow,
  dayHigh, dayChange, volumeSrc, volumeDst, isClosed
  → مقادیر بازارهای rls برحسب «ریال» است (مستند رسمی: «آمار همه بازارهای ریالی»)
- GET /market/udf/history    → عمومی؛ ۶۰ درخواست/دقیقه؛ پارامتر symbol (مثل
  BTCIRT/BTCUSDT), resolution (1,5,15,30,60,180,240,360,720,D,1D,2D,3D),
  to (الزامی، timestamp ثانیه), from/countback/page. حداکثر ۵۰۰ کندل.
  پاسخ UDF: {s: ok|no_data|error, t[], o[], h[], l[], c[], v[], errmsg}
  → مقادیر نماد <SYM>IRT برحسب «تومان» است (تأیید تجربی: close IRT ×10 ==
  latest ریالی stats در همان لحظه)
- هدر User-Agent با الگوی TraderBot/<name-version> طبق «ملاحظات عمومی»
- هیچ endpoint یا فیلدی خارج از این مستندات حدس زده نشده است.
"""
from __future__ import annotations

import threading

import requests

from config import defaults as cfg
from core.errors import NetworkError, NobitexError, RateLimitError
from core.redact import scrub_text

RESOLUTIONS = {"1", "5", "15", "30", "60", "180", "240", "360", "720",
               "D", "1D", "2D", "3D"}


class _RateGate:
    """کنترل نرخ داخلی: حداقل فاصله بین فراخوانی‌های هر نوع endpoint."""

    def __init__(self, min_interval_sec: float):
        self._min = float(min_interval_sec)
        self._last = 0.0
        self._lock = threading.Lock()

    def wait(self, clock=None) -> None:
        import time
        clock = clock or time.monotonic
        while True:
            with self._lock:
                now = clock()
                elapsed = now - self._last
                remain = self._min - elapsed
                if remain <= 0:
                    self._last = now
                    return
            time.sleep(min(remain, 0.25))


class NobitexClient:
    """فقط endpointهای عمومی مستندشده — بدون نیاز به توکن/کلید حساب."""

    def __init__(self, base_url: str = cfg.NOBITEX_BASE_URL,
                 timeout: tuple[float, float] = (6.0, 15.0),
                 stats_min_interval: float = cfg.NOBITEX_STATS_MIN_INTERVAL_SEC,
                 udf_min_interval: float = cfg.NOBITEX_UDF_MIN_INTERVAL_SEC,
                 session: requests.Session | None = None,
                 user_agent: str = cfg.NOBITEX_USER_AGENT):
        self._base = base_url.rstrip("/")
        self._timeout = timeout
        self._session = session or requests.Session()
        self._ua = user_agent
        self._stats_gate = _RateGate(stats_min_interval)
        self._udf_gate = _RateGate(udf_min_interval)

    # ------------------------------ زیرساخت ------------------------------
    def _get(self, path: str, params: dict) -> dict:
        url = f"{self._base}{path}"
        headers = {"User-Agent": self._ua}
        try:
            resp = self._session.get(url, params=params, headers=headers,
                                     timeout=self._timeout)
        except requests.exceptions.ConnectTimeout as exc:
            raise NetworkError(f"nobitex connect timeout: {exc}",
                               "اتصال به نوبیتکس برقرار نشد.",
                               phase="connect") from exc
        except requests.exceptions.ReadTimeout as exc:
            raise NetworkError(f"nobitex read timeout: {exc}",
                               "پاسخ نوبیتکس دیر رسید.", phase="read") from exc
        except requests.exceptions.ConnectionError as exc:
            raise NetworkError(f"nobitex connection error: {exc}",
                               "ارتباط با نوبیتکس قطع شد.",
                               phase="connect") from exc
        except requests.RequestException as exc:
            raise NetworkError(f"nobitex request error: {exc}",
                               "خطای شبکه هنگام دریافت قیمت‌ها.") from exc

        if resp.status_code == 429:
            retry_after = None
            try:
                retry_after = float(resp.headers.get("Retry-After") or 0) or None
            except (TypeError, ValueError):
                retry_after = None
            raise RateLimitError(
                "nobitex 429", "محدودیت نرخ نوبیتکس؛ بعداً تلاش کنید.",
                retry_after=retry_after)

        if resp.status_code != 200:
            code, message = self._parse_failed(resp)
            raise NobitexError(
                f"nobitex http {resp.status_code}: {code} {message}",
                f"خطای نوبیتکس ({resp.status_code}): {code or 'نامشخص'}",
                status_code=resp.status_code, code=code)

        try:
            body = resp.json()
        except ValueError as exc:
            raise NobitexError("nobitex non-json response",
                               "پاسخ نامعتبر از نوبیتکس.",
                               status_code=resp.status_code) from exc
        return body

    @staticmethod
    def _parse_failed(resp) -> tuple[str, str]:
        try:
            body = resp.json()
            return str(body.get("code", "")), scrub_text(str(body.get("message", "")))
        except (ValueError, AttributeError):
            return "", ""

    # ------------------------------ endpointها ------------------------------
    def market_stats(self, src_currencies: list[str],
                     dst_currencies: list[str]) -> dict[str, dict]:
        """آمار بازار برای جفت‌های src-dst. خروجی: {"src-dst": {...}}.

        مقادیر همچنان رشته و بدون تبدیل واحد برمی‌گردند؛ تفسیر واحد در لایه
        سرویس انجام می‌شود (rls=ریال طبق مستندات).
        """
        if not src_currencies or not dst_currencies:
            raise NobitexError("empty currencies",
                               "فهرست ارزهای درخواستی خالی است.")
        self._stats_gate.wait()
        body = self._get("/market/stats", {
            "srcCurrency": ",".join(s.strip().lower() for s in src_currencies),
            "dstCurrency": ",".join(d.strip().lower() for d in dst_currencies),
        })
        if not isinstance(body, dict) or body.get("status") != "ok":
            code = body.get("code", "") if isinstance(body, dict) else ""
            raise NobitexError(f"nobitex stats status={code}",
                               "پاسخ آمار بازار ناموفق بود.", code=str(code))
        stats = body.get("stats")
        if not isinstance(stats, dict):
            raise NobitexError("nobitex stats missing 'stats' field",
                               "ساختار پاسخ آمار بازار نامعتبر است.")
        return stats

    def udf_history(self, symbol: str, resolution: str, to_ts: int,
                    countback: int | None = None, from_ts: int | None = None,
                    page: int | None = None) -> dict:
        """کندل‌های OHLC در قالب TradingView UDF (حداکثر ۵۰۰ کندل).

        خروجی خام: {s, t[], o[], h[], l[], c[], v[]} — s=ok|no_data|error
        واحد مقادیر: نماد <SYM>IRT → تومان؛ <SYM>USDT → دلار (تأیید تجربی).
        """
        symbol = symbol.strip().upper()
        resolution = str(resolution).strip().upper()
        if resolution not in RESOLUTIONS:
            raise NobitexError(f"invalid resolution: {resolution}",
                               "تایم‌فریم نامعتبر است.")
        if symbol == "ALL":
            raise NobitexError("symbol 'all' not allowed for udf",
                               "نماد all برای این endpoint پشتیبانی نمی‌شود.")
        params: dict = {"symbol": symbol, "resolution": resolution,
                        "to": int(to_ts)}
        if countback is not None:
            params["countback"] = max(1, min(int(countback), 500))
        if from_ts is not None:
            params["from"] = int(from_ts)
        if page is not None:
            params["page"] = int(page)
        self._udf_gate.wait()
        body = self._get("/market/udf/history", params)
        if not isinstance(body, dict) or "s" not in body:
            raise NobitexError("nobitex udf missing 's' field",
                               "ساختار پاسخ کندل‌ها نامعتبر است.")
        if body.get("s") == "error":
            raise NobitexError(
                f"nobitex udf error: {body.get('errmsg', '')}",
                "دریافت کندل‌ها ناموفق بود.", code="UdfError")
        return body
