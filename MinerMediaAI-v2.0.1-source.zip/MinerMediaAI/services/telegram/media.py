"""اعتبارسنجی فایل‌های رسانه‌ای قبل از ارسال.

بر اساس محدودیت‌های واقعی Bot API:
- عکس: حداکثر ۱۰ مگابایت (JPG/PNG/WEBP)
- ویدیو/فایل/صدا: حداکثر ۵۰ مگابایت
- کپشن: حداکثر ۱۰۲۴ کاراکتر
"""
from __future__ import annotations

from pathlib import Path

from config import defaults as cfg
from core.errors import MediaError

FIELD_TO_KIND = {
    "sendPhoto": "photo",
    "sendVideo": "video",
    "sendDocument": "document",
    "sendAudio": "audio",
    "album": "photo",   # آلبوم: عکس/ویدیو — حداقل یکی از دو نوع
}

MB = 1024 * 1024


def validate_media_for_send(path_str: str, endpoint: str) -> Path:
    kind = FIELD_TO_KIND.get(endpoint, "document")
    if not path_str:
        raise MediaError("empty media path", "فایل رسانه‌ای انتخاب نشده است.")
    path = Path(path_str)
    if not path.exists() or not path.is_file():
        raise MediaError(f"file not found: {path.name}",
                         "فایل رسانه‌ای روی دیسک یافت نشد.")
    ext = path.suffix.lower()
    allowed = cfg.MEDIA_ALLOWED_EXT.get(kind, set())
    if endpoint == "album":
        allowed = cfg.MEDIA_ALLOWED_EXT["photo"] | cfg.MEDIA_ALLOWED_EXT["video"]
    if ext not in allowed:
        raise MediaError(
            f"extension not allowed: {ext}",
            f"پسوند {ext} برای این نوع محتوا مجاز نیست.")
    size = path.stat().st_size
    if size <= 0:
        raise MediaError("empty file", "فایل خالی است.")
    limits = {"photo": cfg.MAX_PHOTO_MB, "video": cfg.MAX_VIDEO_MB,
              "audio": cfg.MAX_AUDIO_MB, "document": cfg.MAX_DOCUMENT_MB}
    max_mb = limits.get(kind, cfg.MAX_DOCUMENT_MB)
    if endpoint == "album" and ext in cfg.MEDIA_ALLOWED_EXT["video"]:
        max_mb = cfg.MAX_VIDEO_MB
    if size > max_mb * MB:
        raise MediaError(
            f"file too large: {size} bytes (max {max_mb}MB)",
            f"حجم فایل بیش از حد مجاز است (حداکثر {max_mb} مگابایت).")
    return path.resolve()


def detect_kind(path_str: str) -> str:
    ext = Path(path_str).suffix.lower()
    for kind, exts in cfg.MEDIA_ALLOWED_EXT.items():
        if ext in exts and kind != "document":
            return kind
    return "document"
