"""کلاینت Telegram Bot API — دقیقاً طبق مستندات رسمی core.telegram.org.

نکات پیاده‌سازی:
- همه خطاها scrub می‌شوند تا توکن ربات به لاگ/پیام درز نکند.
- 429 → RateLimitError با parameters.retry_after
- 4xx → TelegramError دائمی (تلاش مجدد بی‌فایده)
- 5xx/قطع اتصال در فاز connect → NetworkError transient
- timeout در فاز read → NetworkError با phase="read" (نتیجه مبهم)
"""
from __future__ import annotations

from pathlib import Path

import requests

from config import defaults as cfg
from core.errors import (NetworkError, RateLimitError, TelegramError)
from core.logging_setup import get_logger
from core.redact import scrub_text

# کدهایی که معنی «دائمی» دارند (تلاش مجدد همان درخواست بی‌فایده است)
PERMANENT_HTTP = {400, 401, 403, 404}


class TelegramBotClient:
    def __init__(self, token_provider, timeout: tuple[float, float] = (8.0, 60.0),
                 session: requests.Session | None = None):
        self._token_provider = token_provider
        self._timeout = timeout
        self._session = session or requests.Session()

    # ------------------------------ زیرساخت ------------------------------
    def _api_url(self, method: str) -> str:
        return f"{cfg.TELEGRAM_API_BASE}/bot{self._token_provider()}/{method}"

    def _request(self, method: str, data: dict | None = None,
                 files: dict | None = None) -> dict:
        url = self._api_url(method)
        try:
            resp = self._session.post(url, data=data, files=files,
                                      timeout=self._timeout)
        except requests.exceptions.ConnectTimeout as exc:
            raise NetworkError(
                scrub_text(f"telegram connect timeout: {exc}"),
                "اتصال به تلگرام برقرار نشد.", phase="connect") from exc
        except requests.exceptions.ReadTimeout as exc:
            # اتصال برقرار شده؛ نتیجه ارسال نامشخص است
            raise NetworkError(
                scrub_text(f"telegram read timeout: {exc}"),
                "پاسخ تلگرام دریافت نشد؛ نتیجه ارسال نامشخص است.",
                phase="read") from exc
        except requests.exceptions.ConnectionError as exc:
            raise NetworkError(
                scrub_text(f"telegram connection error: {exc}"),
                "ارتباط با سرور تلگرام قطع شد.", phase="connect") from exc
        except requests.RequestException as exc:
            raise NetworkError(scrub_text(f"telegram request error: {exc}"),
                               "خطای شبکه هنگام ارتباط با تلگرام.") from exc

        if resp.status_code == 429:
            retry_after = None
            try:
                body = resp.json()
                retry_after = float(
                    body.get("parameters", {}).get("retry_after")
                    or resp.headers.get("Retry-After") or 0) or None
            except (ValueError, AttributeError):
                retry_after = None
            raise RateLimitError(
                f"telegram 429 retry_after={retry_after}",
                "محدودیت نرخ تلگرام؛ بعداً تلاش کنید.", retry_after=retry_after)

        try:
            body = resp.json()
        except ValueError as exc:
            raise TelegramError(
                f"telegram non-json response (http {resp.status_code})",
                "پاسخ نامعتبر از تلگرام.", status_code=resp.status_code) from exc

        if resp.status_code != 200 or not body.get("ok"):
            desc = scrub_text(str(body.get("description", ""))[:300])
            code = body.get("error_code", resp.status_code)
            if resp.status_code in PERMANENT_HTTP:
                raise TelegramError(
                    f"telegram {resp.status_code}: {desc}",
                    f"خطای دائمی تلگرام: {desc or resp.status_code}",
                    status_code=resp.status_code, code=str(code))
            raise NetworkError(
                f"telegram http {resp.status_code}: {desc}",
                f"خطای موقت تلگرام ({resp.status_code}).",
                phase="other", retry_after=None)
        return body.get("result", {})

    # ------------------------------ متدها ------------------------------
    def get_me(self) -> dict:
        return self._request("getMe")

    def get_chat(self, chat_id: str) -> dict:
        return self._request("getChat", data={"chat_id": chat_id})

    def test_connection(self) -> dict:
        """آزمون اتصال: getMe + بررسی دسترسی به کانال هدف."""
        me = self.get_me()
        return {"bot_username": me.get("username", ""),
                "bot_name": me.get("first_name", "")}

    def check_channel_access(self, chat_id: str) -> dict:
        """بررسی واقعی دسترسی ربات به کانال (getChat)."""
        return self.get_chat(chat_id)

    def send_message(self, chat_id: str, text: str,
                     disable_notification: bool = False) -> dict:
        if not text or not text.strip():
            raise TelegramError("empty text", "متن پیام خالی است.",
                                status_code=400)
        if len(text) > cfg.MAX_TEXT_LEN:
            raise TelegramError(
                f"text too long: {len(text)}",
                f"متن پیام طولانی است (حداکثر {cfg.MAX_TEXT_LEN} کاراکتر).",
                status_code=400)
        return self._request("sendMessage", data={
            "chat_id": chat_id, "text": text,
            "disable_notification": str(bool(disable_notification)).lower()})

    def _send_media(self, endpoint: str, field: str, chat_id: str,
                    media_path: str, caption: str = "") -> dict:
        from services.telegram.media import validate_media_for_send
        path = validate_media_for_send(media_path, endpoint)
        cap = caption if caption else ""
        if len(cap) > cfg.MAX_CAPTION_LEN:
            raise TelegramError(
                f"caption too long: {len(cap)}",
                f"کپشن طولانی است (حداکثر {cfg.MAX_CAPTION_LEN} کاراکتر).",
                status_code=400)
        with open(path, "rb") as fh:
            return self._request(endpoint, data={
                "chat_id": chat_id, "caption": cap},
                files={field: fh})

    def send_photo(self, chat_id: str, photo_path: str, caption: str = "") -> dict:
        return self._send_media("sendPhoto", "photo", chat_id, photo_path, caption)

    def send_video(self, chat_id: str, video_path: str, caption: str = "") -> dict:
        return self._send_media("sendVideo", "video", chat_id, video_path, caption)

    def send_document(self, chat_id: str, doc_path: str, caption: str = "") -> dict:
        return self._send_media("sendDocument", "document", chat_id, doc_path, caption)

    def send_audio(self, chat_id: str, audio_path: str, caption: str = "") -> dict:
        return self._send_media("sendAudio", "audio", chat_id, audio_path, caption)

    def send_album(self, chat_id: str, items: list[dict]) -> dict:
        """آلبوم رسانه‌ای (sendMediaGroup): ۲ تا ۱۰ آیتم، کپشن فقط روی اولین.

        طبق محدودیت واقعی Bot API: آلبوم فقط photo/video می‌پذیرد.
        items: [{"type": "photo"|"video", "path": str, "caption": str}]
        فایل‌ها اول اعتبارسنجی و بعد باز می‌شوند تا در خطای اعتبارسنجی
        هیچ handleای نشت کند.
        """
        if not 2 <= len(items) <= cfg.MAX_ALBUM_ITEMS:
            raise TelegramError(
                f"album size {len(items)}",
                f"آلبوم باید بین ۲ تا {cfg.MAX_ALBUM_ITEMS} آیتم باشد.",
                status_code=400)
        from services.telegram.media import validate_media_for_send
        validated = []
        for item in items:
            if item.get("type") not in ("photo", "video"):
                raise TelegramError(
                    f"album item type: {item.get('type')}",
                    "آلبوم فقط عکس یا ویدیو می‌پذیرد.", status_code=400)
            validated.append((item, validate_media_for_send(item["path"], "album")))
        media = []
        files = {}
        try:
            for i, (item, path) in enumerate(validated):
                attach = f"attach{i}"
                media.append({
                    "type": item["type"],
                    "media": attach,
                    **({"caption": item.get("caption", "")}
                       if i == 0 and item.get("caption") else {}),
                })
                files[attach] = open(path, "rb")  # noqa: SIM115 — در finally بسته می‌شود
            import json as _json
            return self._request("sendMediaGroup", data={
                "chat_id": chat_id, "media": _json.dumps(media)}, files=files)
        finally:
            for fh in files.values():
                fh.close()

    def edit_message_text(self, chat_id: str, message_id: int, text: str) -> dict:
        return self._request("editMessageText", data={
            "chat_id": chat_id, "message_id": message_id, "text": text})

    def delete_message(self, chat_id: str, message_id: int) -> dict:
        return self._request("deleteMessage", data={
            "chat_id": chat_id, "message_id": message_id})


def detect_kind(path_str: str) -> str:
    """تشخیص نوع رسانه از پسوند (برای آلبوم) — بدون حدس محتوایی."""
    from services.telegram.media import detect_kind as _detect
    return _detect(path_str)


def publish_post(client: TelegramBotClient, chat_id: str, content_type: str,
                 body: str, media_path: str = "",
                 split_long_text: bool = False) -> int:
    """انتشار پست بر اساس نوع محتوا؛ خروجی: message_id تلگرام (پیام اصلی).

    سیاست صریح متن بلند همراه رسانه (هیچ متن یا رسانه‌ای بی‌صدا حذف نمی‌شود):
    - len(body) <= MAX_CAPTION_LEN → کپشن معمولی
    - len(body) > MAX_CAPTION_LEN و split_long_text=True → رسانه بدون کپشن
      + کل متن به‌صورت پیام جداگانه (هیچ برشی حذف نمی‌شود)
    - len(body) > MAX_CAPTION_LEN و split_long_text=False → خطای دائمی
      (اعتبارسنجی قبل از زمان‌بندی نباید اجازه دهد این حالت رخ دهد؛
      اگر رکورد قدیمی این‌گونه باشد، صادقانه شکست می‌خورد نه برش ساکت)
    """
    log = get_logger("minermedia.telegram")
    if content_type == "text":
        result = client.send_message(chat_id, body)
        return int(result.get("message_id")) if result.get("message_id") else 0

    if content_type == "album":
        return _publish_album(client, chat_id, body, media_path,
                              split_long_text, log)

    # انواع تک‌رسانه‌ای: photo | video | audio | document
    senders = {
        "photo": client.send_photo,
        "video": client.send_video,
        "audio": client.send_audio,
        "document": client.send_document,
    }
    sender = senders.get(content_type)
    if sender is None:
        raise TelegramError(f"unsupported content type: {content_type}",
                            "نوع محتوا پشتیبانی نمی‌شود.", status_code=400)

    extra_msg_id = 0
    if len(body) <= cfg.MAX_CAPTION_LEN:
        result = sender(chat_id, media_path, body)
    elif split_long_text:
        # سیاست کنترل‌شده: رسانه بدون کپشن + کل متن به‌صورت پیام جداگانه
        result = sender(chat_id, media_path, "")
        text_result = client.send_message(chat_id, body)
        extra_msg_id = int(text_result.get("message_id") or 0)
        log.info("long text published as separate message (msg_id=%s)",
                 extra_msg_id)
    else:
        raise TelegramError(
            f"caption too long: {len(body)}",
            f"کپشن رسانه حداکثر {cfg.MAX_CAPTION_LEN} کاراکتر است؛ "
            "گزینهٔ «ارسال متن به‌صورت پیام جداگانه» را فعال کنید.",
            status_code=400)
    return int(result.get("message_id")) if result.get("message_id") else 0


def _publish_album(client: TelegramBotClient, chat_id: str, body: str,
                   media_path: str, split_long_text: bool, log) -> int:
    """انتشار آلبوم؛ media_path = JSON فهرست [{type, path}, ...].

    کپشن طبق محدودیت واقعی Bot API فقط روی آیتم اول می‌نشیند؛ متن بلندتر
    از سقف کپشن با سیاست split_long_text کنترل می‌شود (پیام جداگانه یا خطا).
    """
    import json as _json
    try:
        raw_items = _json.loads(media_path) if media_path else []
    except ValueError as exc:
        raise TelegramError(
            f"album media_path is not valid JSON: {exc}",
            "فهرست فایل‌های آلبوم نامعتبر است.", status_code=400) from exc
    if not isinstance(raw_items, list) or len(raw_items) < 2:
        raise TelegramError(
            f"album items: {len(raw_items) if isinstance(raw_items, list) else 'n/a'}",
            "آلبوم حداقل به ۲ فایل نیاز دارد.", status_code=400)

    items = []
    for it in raw_items:
        if not isinstance(it, dict) or not it.get("path"):
            raise TelegramError("album item missing path",
                                "یکی از فایل‌های آلبوم مسیر ندارد.",
                                status_code=400)
        items.append({"type": it.get("type") or detect_kind(it["path"]),
                      "path": it["path"]})

    extra_msg_id = 0
    if len(body) <= cfg.MAX_CAPTION_LEN:
        if body:
            items[0]["caption"] = body
        result = client.send_album(chat_id, items)
    elif split_long_text:
        result = client.send_album(chat_id, items)
        text_result = client.send_message(chat_id, body)
        extra_msg_id = int(text_result.get("message_id") or 0)
        log.info("album long text published as separate message (msg_id=%s)",
                 extra_msg_id)
    else:
        raise TelegramError(
            f"album caption too long: {len(body)}",
            f"کپشن آلبوم حداکثر {cfg.MAX_CAPTION_LEN} کاراکتر است؛ "
            "گزینهٔ «ارسال متن به‌صورت پیام جداگانه» را فعال کنید.",
            status_code=400)
    return int(result[0].get("message_id")) if isinstance(result, list) \
        and result and result[0].get("message_id") else 0
