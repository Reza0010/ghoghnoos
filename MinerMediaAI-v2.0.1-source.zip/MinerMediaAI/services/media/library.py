"""کتابخانه رسانه — ایندکس، اعتبارسنجی و کپی امن فایل‌ها به پوشه داده."""
from __future__ import annotations

import hashlib
import shutil
import uuid
from pathlib import Path

from core.errors import MediaError
from core.timeutils import utc_iso
from database.repositories import MediaRepo
from models.entities import MediaAsset
from services.telegram.media import detect_kind, validate_media_for_send


class MediaLibraryService:
    def __init__(self, repo: MediaRepo, media_dir: Path):
        self.repo = repo
        self.media_dir = Path(media_dir)
        self.media_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _sha1(path: Path) -> str:
        h = hashlib.sha1()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 16), b""):
                h.update(chunk)
        return h.hexdigest()

    def add_file(self, src_path: str, note: str = "") -> MediaAsset:
        """کپی امن فایل به پوشه رسانه + ایندکس در دیتابیس."""
        src = Path(src_path)
        if not src.exists() or not src.is_file():
            raise MediaError(f"not a file: {src}", "فایل انتخابی معتبر نیست.")
        kind = detect_kind(str(src))
        # اعتبارسنجی محدودیت‌های Bot API قبل از پذیرش
        validate_media_for_send(str(src), {
            "photo": "sendPhoto", "video": "sendVideo",
            "audio": "sendAudio"}.get(kind, "sendDocument"))
        dest = self.media_dir / f"{uuid.uuid4().hex[:12]}_{src.name}"
        shutil.copy2(src, dest)
        asset = MediaAsset(
            id=None, path=str(dest.resolve()), filename=src.name, kind=kind,
            size=dest.stat().st_size, sha1=self._sha1(dest),
            added_at=utc_iso(), note=note)
        asset.id = self.repo.upsert(asset)
        return asset

    def scan_dir(self) -> int:
        """ایندکس فایل‌های موجود در پوشه رسانه (بدون کپی)."""
        count = 0
        for path in sorted(self.media_dir.iterdir()):
            if not path.is_file():
                continue
            kind = detect_kind(str(path))
            if self.repo.upsert(MediaAsset(
                    id=None, path=str(path.resolve()), filename=path.name,
                    kind=kind, size=path.stat().st_size,
                    sha1=self._sha1(path), added_at=utc_iso())):
                count += 1
        return count

    def list(self) -> list[MediaAsset]:
        return self.repo.list()

    def delete(self, asset_id: int, remove_file: bool = True) -> None:
        path = self.repo.delete(asset_id)
        if path and remove_file:
            p = Path(path)
            if p.exists() and self.media_dir in p.resolve().parents:
                p.unlink()
