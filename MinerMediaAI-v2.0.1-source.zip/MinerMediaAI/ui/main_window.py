"""پنجره اصلی — نوار کنار RTL با ۹ صفحه و پل سیگنال Workerها."""
from __future__ import annotations

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMainWindow,
                               QPushButton, QStackedWidget, QVBoxLayout,
                               QWidget)

from config import defaults as cfg
from core.logging_setup import get_logger
from core.redact import scrub_text
from ui.icons import icon
from ui.theme import ACCENT, TEXT_DIM, TEXT_MUTED

log = get_logger("minermedia.ui")

NAV = [
    ("dashboard", "نمای کلی", "overview"),
    ("channels", "مدیریت کانال‌ها", "channels"),
    ("queue", "تقویم و صف انتشار", "queue"),
    ("studio", "استودیوی تولید محتوا", "studio"),
    ("market", "قیمت ارزهای دیجیتال", "market"),
    ("news", "اخبار ماینینگ", "news"),
    ("media", "کتابخانه رسانه", "media"),
    ("reports", "گزارش‌ها و آمار", "reports"),
    ("settings", "تنظیمات و APIها", "settings"),
]


class WorkerBridge(QObject):
    """پل Threadها به سیگنال‌های Qt (ارسال امن به UI Thread)."""

    scheduler_event = Signal(dict)
    market_refreshed = Signal(object)
    news_refreshed = Signal(object)

    def on_scheduler_event(self, event: dict) -> None:
        self.scheduler_event.emit(event)

    def on_market_result(self, result) -> None:
        self.market_refreshed.emit(result)

    def on_news_result(self, result) -> None:
        self.news_refreshed.emit(result)


class MainWindow(QMainWindow):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setWindowTitle(f"{ctx.settings.app_name} — {cfg.DEFAULT_APP_SUBTITLE}")
        self.resize(1280, 800)
        self.setMinimumSize(1024, 640)

        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ---------------- نوار کنار ----------------
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(240)
        side_lay = QVBoxLayout(sidebar)
        side_lay.setContentsMargins(12, 16, 12, 12)
        side_lay.setSpacing(4)
        self.brand = QLabel(ctx.settings.app_name)
        self.brand.setStyleSheet(f"font-size: 17px; font-weight: 800; color: {ACCENT};")
        self.brand_sub = QLabel(cfg.DEFAULT_APP_SUBTITLE)
        self.brand_sub.setStyleSheet(f"color: {TEXT_DIM}; font-size: 10px;")
        side_lay.addWidget(self.brand)
        side_lay.addWidget(self.brand_sub)
        side_lay.addSpacing(14)
        self.nav_buttons = []
        for icon_name, title, key in NAV:
            btn = QPushButton(f"  {title}")
            btn.setProperty("class", "nav")
            btn.setIcon(icon(icon_name, 18))
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, k=key: self.navigate(k))
            side_lay.addWidget(btn)
            self.nav_buttons.append((key, btn))
        side_lay.addStretch(1)
        self.foot_version = QLabel(f"v{cfg.APP_VERSION}")
        self.foot_version.setStyleSheet(f"color: {TEXT_DIM}; font-size: 10px;")
        side_lay.addWidget(self.foot_version)
        root.addWidget(sidebar)

        # ---------------- صفحه‌ها ----------------
        self.stack = QStackedWidget()
        self.pages = {}
        for icon_name, title, key in NAV:
            page_cls = {
                "overview": ("ui.overview_page", "OverviewPage"),
                "channels": ("ui.channels_page", "ChannelsPage"),
                "queue": ("ui.queue_page", "QueuePage"),
                "studio": ("ui.studio_page", "StudioPage"),
                "market": ("ui.market_page", "MarketPage"),
                "news": ("ui.news_page", "NewsPage"),
                "media": ("ui.media_page", "MediaPage"),
                "reports": ("ui.reports_page", "ReportsPage"),
                "settings": ("ui.settings_page", "SettingsPage"),
            }[key]
            import importlib
            module = importlib.import_module(page_cls[0])
            page = getattr(module, page_cls[1])(ctx)
            self.pages[key] = page
            self.stack.addWidget(page)
        root.addWidget(self.stack, 1)
        self.setCentralWidget(central)

        # ---------------- پل Workerها ----------------
        self.bridge = WorkerBridge()
        self.bridge.scheduler_event.connect(self._on_scheduler_event)
        self.bridge.market_refreshed.connect(self._on_market_refreshed)
        self.bridge.news_refreshed.connect(self._on_news_refreshed)
        if self.ctx.scheduler:
            self.ctx.scheduler.add_listener(self.bridge.on_scheduler_event)
        if self.ctx.market_worker:
            self.ctx.market_worker.add_listener(self.bridge.on_market_result)
        if getattr(self.ctx, "news_worker", None):
            self.ctx.news_worker.add_listener(self.bridge.on_news_result)

        self.navigate("overview")

    # ------------------------------------------------------------------
    def navigate(self, key: str) -> None:
        for k, btn in self.nav_buttons:
            btn.setChecked(k == key)
        self.stack.setCurrentWidget(self.pages[key])
        page = self.pages[key]
        if hasattr(page, "refresh"):
            try:
                page.refresh()
            except Exception as exc:  # noqa: BLE001
                log.error("page refresh failed (%s): %s", key,
                          scrub_text(str(exc)))

    def apply_app_name(self) -> None:
        self.setWindowTitle(f"{self.ctx.settings.app_name} — "
                            f"{cfg.DEFAULT_APP_SUBTITLE}")
        self.brand.setText(self.ctx.settings.app_name)

    # ------------------------------------------------------------------
    def _on_scheduler_event(self, event: dict) -> None:
        status = event.get("status", "")
        post_id = event.get("post_id", "?")
        if status == "sent":
            self.statusBar().showMessage(f"پست {post_id} منتشر شد.", 8000)
        elif status == "failed":
            err = scrub_text(str(event.get("error", ""))[:120])
            self.statusBar().showMessage(f"پست {post_id} ناموفق: {err}", 10000)
        elif status == "unknown":
            self.statusBar().showMessage(
                f"پست {post_id}: نتیجه ارسال نامشخص — بررسی دستی لازم است.", 12000)
        if self.stack.currentWidget() in (self.pages["overview"],
                                          self.pages["queue"]):
            self.pages[self.stack.currentWidget() is self.pages["overview"]
                       and "overview" or "queue"].refresh()

    def _on_market_refreshed(self, result) -> None:
        page = self.pages["overview"]
        if self.stack.currentWidget() is page:
            page.refresh()

    def _on_news_refreshed(self, result) -> None:
        """نتیجه Worker زمان‌بندی‌شده اخبار — وضعیت شفاف، بدون فریز UI."""
        if getattr(result, "updated", 0):
            self.statusBar().showMessage(
                f"دریافت خودکار اخبار: {result.updated} خبر جدید.", 8000)
        if getattr(result, "errors", None):
            first = scrub_text(str(result.errors[0])[:100])
            self.statusBar().showMessage(
                f"دریافت اخبار: {len(result.errors)} منبع خطا داشت — {first}",
                10000)
        page = self.pages["news"]
        if self.stack.currentWidget() is page:
            page.refresh()

    # ------------------------------------------------------------------
    def closeEvent(self, event) -> None:  # noqa: N802
        from PySide6.QtWidgets import QApplication, QMessageBox
        reply = QMessageBox.question(
            self, "خروج",
            "برنامه بسته شود؟ Workerها به‌ترتیب ایمن متوقف می‌شوند و در صورت "
            "در جریان بودن ارسال/دریافت، تا پایان آن (با سقف مشخص) منتظر "
            "می‌مانیم؛ دیتابیس فقط پس از توقف واقعی Workerها بسته می‌شود.",
            QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            event.ignore()
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            from core.shutdown import (close_database_safely,
                                       shutdown_background_workers)
            report = shutdown_background_workers(self.ctx)
            self._last_shutdown_report = dict(report)
            db_closed = close_database_safely(self.ctx.db, report)
            if not db_closed:
                still = [k for k, v in report.items() if not v]
                QMessageBox.warning(
                    self, "خروج",
                    "برخی عملیات پس‌زمینه تا سقف زمان توقف تمام نشدند:\n"
                    + "، ".join(still)
                    + "\n\nدیتابیس بسته نشد تا نوشتن روی اتصال بسته رخ ندهد؛ "
                      "خروج برنامه اتصال را آزاد می‌کند و داده‌ها سالم می‌مانند.")
        except Exception as exc:  # noqa: BLE001
            log.error("shutdown error: %s", scrub_text(str(exc)))
        finally:
            QApplication.restoreOverrideCursor()
        event.accept()
