"""پالت رنگ و استایل سراسری — تم تیره حرفه‌ای با هویت صنعت ماینینگ.

رنگ تأکیدی: نارنجی بیت‌کوین (#f7931a) + فیروزه‌ای برای موفقیت.
بدون گرادیان افراطی و جلوه‌های تزئینی؛ خوانایی و سرعت اولویت است.
"""
from __future__ import annotations

BG = "#0b0f14"            # پس‌زمینه اصلی
BG_SIDEBAR = "#0e141b"
SURFACE = "#121a23"       # سطح کارت‌ها
SURFACE_2 = "#17212d"
BORDER = "#22303f"
TEXT = "#e8eef5"
TEXT_MUTED = "#93a4b6"
TEXT_DIM = "#64748b"
ACCENT = "#f7931a"        # نارنجی بیت‌کوین
ACCENT_HOVER = "#ffa633"
SUCCESS = "#22c55e"
DANGER = "#ef4444"
WARNING = "#f59e0b"
INFO = "#3b82f6"

APP_QSS = f"""
* {{
    font-family: 'Vazirmatn', 'Segoe UI', 'Tahoma';
    outline: none;
}}
QMainWindow, QDialog {{
    background-color: {BG};
}}
QWidget {{
    color: {TEXT};
    font-size: 13px;
}}
QLabel {{ background: transparent; }}
QLabel.muted {{ color: {TEXT_MUTED}; font-size: 12px; }}
QLabel.h1 {{ font-size: 20px; font-weight: 700; }}
QLabel.h2 {{ font-size: 15px; font-weight: 700; }}

/* ---------- نوار کنار ---------- */
#Sidebar {{
    background-color: {BG_SIDEBAR};
    border-left: 1px solid {BORDER};
}}
QPushButton.nav {{
    text-align: right;
    padding: 10px 14px;
    border: none;
    border-radius: 8px;
    color: {TEXT_MUTED};
    font-size: 13.5px;
    background: transparent;
    margin: 2px 8px;
}}
QPushButton.nav:hover {{ background: {SURFACE_2}; color: {TEXT}; }}
QPushButton.nav:checked {{
    background: rgba(247,147,26,0.14);
    color: {ACCENT};
    font-weight: 700;
}}

/* ---------- کارت ---------- */
#Card, QFrame.card {{
    background-color: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 12px;
}}
#CardTitle {{
    color: {TEXT_MUTED};
    font-size: 12px;
    font-weight: 600;
}}
#CardValue {{
    font-size: 21px;
    font-weight: 800;
    color: {TEXT};
}}
#CardSub {{ color: {TEXT_DIM}; font-size: 11px; }}

/* ---------- دکمه‌ها ---------- */
QPushButton {{
    background-color: {SURFACE_2};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 7px 14px;
    color: {TEXT};
}}
QPushButton:hover {{ border-color: {ACCENT}; }}
QPushButton:disabled {{ color: {TEXT_DIM}; border-color: {BORDER}; }}
QPushButton.primary {{
    background-color: {ACCENT};
    border: none;
    color: #14100a;
    font-weight: 700;
}}
QPushButton.primary:hover {{ background-color: {ACCENT_HOVER}; }}
QPushButton.primary:disabled {{ background-color: #5a4622; color: #9a8a6b; }}
QPushButton.danger {{
    background: transparent;
    border: 1px solid {DANGER};
    color: {DANGER};
}}
QPushButton.danger:hover {{ background: rgba(239,68,68,0.12); }}
QPushButton.ghost {{ background: transparent; }}

/* ---------- ورودی‌ها ---------- */
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit {{
    background-color: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 6px 10px;
    selection-background-color: {ACCENT};
}}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus, QSpinBox:focus {{
    border-color: {ACCENT};
}}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{
    background: {SURFACE};
    border: 1px solid {BORDER};
    selection-background-color: rgba(247,147,26,0.2);
}}

/* ---------- جدول ---------- */
QTableWidget {{
    background-color: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 10px;
    gridline-color: {BORDER};
    alternate-background-color: {SURFACE_2};
}}
QTableWidget::item {{ padding: 5px 8px; }}
QTableWidget::item:selected {{ background: rgba(247,147,26,0.18); }}
QHeaderView {{
    background-color: {SURFACE_2};
    border: none;
}}
QHeaderView::section {{
    background-color: {SURFACE_2};
    color: {TEXT_MUTED};
    border: none;
    border-bottom: 1px solid {BORDER};
    padding: 7px 8px;
    font-weight: 700;
}}
QAbstractScrollArea::corner {{ background: {SURFACE}; border: none; }}
QTableCornerButton::section {{
    background: {SURFACE};
    border: none;
}}

/* ---------- اسکرول‌بار ---------- */
QScrollBar:vertical {{ background: transparent; width: 8px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {BORDER}; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {TEXT_DIM}; }}
QScrollBar:horizontal {{ background: transparent; height: 8px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {BORDER}; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}

/* ---------- تب ---------- */
QTabWidget::pane {{ border: 1px solid {BORDER}; border-radius: 10px; background: {SURFACE}; }}
QTabBar::tab {{
    background: transparent;
    color: {TEXT_MUTED};
    padding: 8px 16px;
    margin: 4px;
    border-radius: 8px;
}}
QTabBar::tab:selected {{ color: {ACCENT}; background: rgba(247,147,26,0.12); }}

/* ---------- متفرقه ---------- */
QProgressBar {{
    background: {SURFACE_2}; border: none; border-radius: 5px; height: 10px; text-align: center;
}}
QProgressBar::chunk {{ background: {ACCENT}; border-radius: 5px; }}
QToolTip {{
    background: {SURFACE_2}; color: {TEXT}; border: 1px solid {BORDER};
    padding: 4px 8px; border-radius: 6px;
}}
QCheckBox::indicator, QRadioButton::indicator {{ width: 16px; height: 16px; }}
QSplitter::handle {{ background: {BORDER}; width: 1px; }}
"""


def apply_theme(app) -> None:
    """اعمال تم تیره و راست‌چین‌سازی کامل."""
    from PySide6.QtCore import Qt
    app.setStyle("Fusion")
    app.setLayoutDirection(Qt.RightToLeft)
    app.setStyleSheet(APP_QSS)
