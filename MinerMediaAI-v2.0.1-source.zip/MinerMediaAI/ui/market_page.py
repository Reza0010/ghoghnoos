"""صفحه بازار — فهرست منتخب، جست‌وجو، نمودار با منابع/واحدهای صریح."""
from __future__ import annotations

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QComboBox, QDialog, QHBoxLayout, QLabel,
                               QLineEdit, QMessageBox, QPushButton,
                               QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget)

from core.errors import MinerMediaError
from core.timeutils import format_local
from core.units import format_amount, format_compact, format_percent, smart_price_decimals
from ui.theme import TEXT_DIM
from ui.widgets import LineChart, SectionHeader, StatusPill

RANGES = [("1h", "۱ ساعت (محلی)"), ("24h", "۲۴ ساعت (محلی)"),
          ("7d", "۷ روز (بازار)"), ("30d", "۳۰ روز (بازار)")]

# رنگ‌های متمایز وضعیت قیمت — خوانایی و تشخیص فوری (مأموریت ۶)
from PySide6.QtGui import QColor  # noqa: E402
COLOR_STALE = QColor("#ef4444")     # داده کهنه — قرمز
COLOR_ESTIMATED = QColor("#f59e0b") # قیمت تخمینی — کهربایی
COLOR_NORMAL = QColor("#e5e7eb")    # عادی


class HistoryWorker(QThread):
    """دریافت تاریخچه UDF در Thread جدا — بدون فریز UI."""

    loaded = Signal(str, object, str, str)   # range_key, points, unit, market
    failed = Signal(str, str)                # range_key, message

    def __init__(self, ctx, symbol: str, range_key: str):
        super().__init__()
        self.ctx, self.symbol, self.range_key = ctx, symbol, range_key

    def run(self) -> None:
        svc = self.ctx.market_service
        if self.range_key in ("1h", "24h"):
            hours = 1 if self.range_key == "1h" else 24
            # داده محلی: اولویت با بازار IRT (تومان) — در نبود آن USDT
            local = svc.local_history(self.symbol, f"{self.symbol}IRT", hours)
            if local:
                self.loaded.emit(self.range_key, local, "تومان (نمونه‌برداری محلی)",
                                 f"{self.symbol}IRT")
            else:
                local_u = svc.local_history(self.symbol, f"{self.symbol}USDT", hours)
                if local_u:
                    self.loaded.emit(self.range_key, local_u,
                                     "USDT (نمونه‌برداری محلی)", f"{self.symbol}USDT")
                else:
                    self.failed.emit(
                        self.range_key,
                        "داده محلی کافی نیست؛ برنامه در حال نمونه‌برداری است. "
                        "نمودار محلی جایگزین تاریخچه کامل بازار نیست.")
            return
        res = svc.market_history(self.symbol, self.range_key)
        if res and res["points"]:
            unit = "تومان (IRT)" if res["unit"] == "TOMAN" else res["unit"]
            self.loaded.emit(self.range_key, res["points"], f"{unit} — منبع: نوبیتکس",
                             res["market"])
        else:
            self.failed.emit(self.range_key,
                             "دریافت تاریخچه بازار ناموفق بود یا داده‌ای برای "
                             "این بازه موجود نیست.")


class AddSymbolDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("افزودن ارز به فهرست منتخب")
        self.setMinimumWidth(380)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("نماد ارز (مثل SOL یا ARIA):"))
        self.symbol_edit = QLineEdit()
        lay.addWidget(self.symbol_edit)
        lay.addWidget(QLabel("نام نمایشی (اختیاری):"))
        self.name_edit = QLineEdit()
        lay.addWidget(self.name_edit)
        note = QLabel("قیمت فقط در صورت وجود جفت معاملاتی واقعی در نوبیتکس "
                      "نمایش داده می‌شود؛ در غیر این صورت «ناموجود» می‌ماند.")
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        lay.addWidget(note)
        btns = QHBoxLayout()
        ok = QPushButton("افزودن")
        ok.setObjectName("primary")
        ok.clicked.connect(self.accept)
        cancel = QPushButton("انصراف")
        cancel.clicked.connect(self.reject)
        btns.addStretch(1)
        btns.addWidget(cancel)
        btns.addWidget(ok)
        lay.addLayout(btns)

    def values(self) -> tuple[str, str]:
        return self.symbol_edit.text().strip().upper(), self.name_edit.text().strip()


class MarketPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self._hist_worker = None
        self._selected_symbol = "BTC"
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        head = SectionHeader("قیمت ارزهای دیجیتال")
        self.unit_combo = QComboBox()
        for unit, label in (("TOMAN", "تومان"), ("RIAL", "ریال"), ("USDT", "USDT")):
            self.unit_combo.addItem(label, unit)
        self.unit_combo.setCurrentText(
            {"TOMAN": "تومان", "RIAL": "ریال", "USDT": "USDT"}[
                ctx.settings.market_display_unit])
        self.unit_combo.currentIndexChanged.connect(self._unit_changed)
        add_btn = QPushButton(" افزودن ارز")
        add_btn.clicked.connect(self._add_symbol)
        refresh_btn = QPushButton(" به‌روزرسانی اکنون")
        refresh_btn.setObjectName("primary")
        from ui.icons import icon
        refresh_btn.setIcon(icon("refresh", 16, "#14100a"))
        refresh_btn.clicked.connect(self._refresh_now)
        head.layout().addWidget(QLabel("واحد نمایش:"))
        head.layout().addWidget(self.unit_combo)
        head.layout().addWidget(add_btn)
        head.layout().addWidget(refresh_btn)
        root.addWidget(head)

        info = QLabel("منبع: API عمومی نوبیتکس — آمار برحسب ریال برگردانده می‌شود "
                      "(مستند رسمی) و تومان = ریال ÷ ۱۰. قیمت‌های «تخمینی» صریح "
                      "برچسب می‌خورند. داده کهنه با پسوند «کهنه» مشخص می‌شود.")
        info.setWordWrap(True)
        info.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        root.addWidget(info)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            ["ارز", "قیمت", "تغییر ۲۴س", "کمترین ۲۴س", "بیشترین ۲۴س",
             "حجم", "زمان/منبع", "حذف"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.clicked.connect(self._on_row)
        root.addWidget(self.table, 2)

        # ---------- نمودار ----------
        chart_head = SectionHeader("نمودار قیمت")
        self.range_combo = QComboBox()
        for key, label in RANGES:
            self.range_combo.addItem(label, key)
        self.range_combo.currentIndexChanged.connect(self._load_chart)
        self.symbol_combo = QComboBox()
        self.symbol_combo.currentIndexChanged.connect(self._load_chart)
        self.chart_status = StatusPill("missing")
        chart_head.layout().addWidget(QLabel("ارز:"))
        chart_head.layout().addWidget(self.symbol_combo)
        chart_head.layout().addWidget(QLabel("بازه:"))
        chart_head.layout().addWidget(self.range_combo)
        chart_head.layout().addWidget(self.chart_status)
        root.addWidget(chart_head)
        self.chart = LineChart()
        root.addWidget(self.chart, 1)
        self.refresh()

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        watch = self.ctx.market_repo.list_watch()
        unit = self.unit_combo.currentData() or "TOMAN"
        self.table.setRowCount(len(watch))
        for r, w in enumerate(watch):
            self.table.setItem(r, 0, QTableWidgetItem(f"{w.symbol} — {w.display_name}"))
            info = self.ctx.market_service.display_price(w.symbol, unit)
            q = self.ctx.market_repo.get_quote(w.symbol, f"{w.symbol}IRT") or \
                self.ctx.market_repo.get_quote(w.symbol, f"{w.symbol}USDT")
            if info:
                price_item = QTableWidgetItem(
                    format_amount(
                        info["price"],
                        smart_price_decimals(info["price"], info["unit"]))
                    + (" (تخمینی)" if info["estimated"] else ""))
                # تمایز رنگی صریح: تخمینی کهربایی، عادی روشن — کهنه در ستون زمان قرمز است
                price_item.setForeground(COLOR_ESTIMATED if info["estimated"]
                                         else COLOR_NORMAL)
                self.table.setItem(r, 1, price_item)
                chg = q.get("day_change") if q else None
                self.table.setItem(r, 2, QTableWidgetItem(format_percent(chg)))
                d = lambda field: (format_amount(q.get(field), smart_price_decimals(q.get(field) or 0, unit))
                                   if q and q.get(field) else "—")
                self.table.setItem(r, 3, QTableWidgetItem(d("day_low")))
                self.table.setItem(r, 4, QTableWidgetItem(d("day_high")))
                self.table.setItem(r, 5, QTableWidgetItem(
                    format_compact(q.get("volume_src"), w.symbol)
                    if q and q.get("volume_src") else "—"))
                self.table.setItem(r, 6, QTableWidgetItem(
                    ("کهنه — " if info["stale"] else "")
                    + format_local(info["fetched_at"], self.ctx.settings.timezone)
                    + " | " + info["source"]))
                time_item = self.table.item(r, 6)
                if info["stale"]:
                    time_item.setForeground(COLOR_STALE)
                # خطای آخرین دریافت — بدون بازنویسی ستون حجم؛ در سلول زمان/منبع
                svc = self.ctx.market_service
                if getattr(svc, "last_error", ""):
                    err = " | خطا: " + svc.last_error[:80]
                    time_item.setText(time_item.text() + err)
                    time_item.setForeground(COLOR_STALE)
                    time_item.setToolTip(svc.last_error)
            else:
                for c, val in ((1, "ناموجود"), (2, "—"), (3, "—"), (4, "—"),
                               (5, "—"), (6, "در حال دریافت / بدون جفت معاملاتی")):
                    self.table.setItem(r, c, QTableWidgetItem(val))
            del_btn = QPushButton("حذف")
            del_btn.setObjectName("danger")
            del_btn.clicked.connect(lambda _=False, s=w.symbol: self._remove(s))
            self.table.setCellWidget(r, 7, del_btn)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)
        self._fill_symbol_combo()

    def _fill_symbol_combo(self) -> None:
        watch = self.ctx.market_repo.list_watch()
        current = self.symbol_combo.currentData()
        self.symbol_combo.blockSignals(True)
        self.symbol_combo.clear()
        for w in watch:
            self.symbol_combo.addItem(w.symbol, w.symbol)
        if current:
            idx = self.symbol_combo.findData(current)
            if idx >= 0:
                self.symbol_combo.setCurrentIndex(idx)
        self.symbol_combo.blockSignals(False)

    def _unit_changed(self) -> None:
        unit = self.unit_combo.currentData()
        self.ctx.settings.market_display_unit = unit
        self.refresh()

    def _add_symbol(self) -> None:
        dlg = AddSymbolDialog(self)
        if dlg.exec():
            sym, name = dlg.values()
            try:
                if self.ctx.market_repo.add_watch(sym, name):
                    self.ctx.logs_repo.add("INFO", "MARKET",
                                           f"ارز {sym} به فهرست منتخب اضافه شد.")
                    self.ctx.kick_market_worker()
                    self.refresh()
            except MinerMediaError as exc:
                QMessageBox.warning(self, "افزودن ارز", exc.user_message)

    def _remove(self, symbol: str) -> None:
        self.ctx.market_repo.remove_watch(symbol)
        self.ctx.logs_repo.add("INFO", "MARKET", f"ارز {symbol} حذف شد.")
        self.refresh()

    def _refresh_now(self) -> None:
        self.ctx.kick_market_worker()
        from PySide6.QtCore import QTimer
        QTimer.singleShot(1500, self.refresh)

    def _on_row(self, index) -> None:
        item = self.table.item(index.row(), 0)
        if item:
            self._selected_symbol = item.text().split(" — ")[0]
            idx = self.symbol_combo.findData(self._selected_symbol)
            if idx >= 0:
                self.symbol_combo.setCurrentIndex(idx)
            self._load_chart()

    # ------------------------------ نمودار ------------------------------
    def _load_chart(self) -> None:
        symbol = self.symbol_combo.currentData()
        if not symbol:
            return
        self._selected_symbol = symbol
        range_key = self.range_combo.currentData()
        self.chart.set_state("loading", "در حال دریافت داده نمودار…")
        self.chart_status.set_status("loading")
        if self._hist_worker and self._hist_worker.isRunning():
            return
        self._hist_worker = HistoryWorker(self.ctx, symbol, range_key)
        self._hist_worker.loaded.connect(self._on_chart)
        self._hist_worker.failed.connect(self._on_chart_fail)
        self._hist_worker.start()

    def _on_chart(self, range_key: str, points, unit: str, market: str) -> None:
        self.chart.set_data(points, f"واحد: {unit} | نماد: {market}",
                            f"روند قیمت {self._selected_symbol}")
        self.chart_status.set_status("ok", "واقعی/محلی")
        self.ctx.logs_repo.add("INFO", "MARKET",
                               f"نمودار {self._selected_symbol} {range_key} "
                               f"بارگذاری شد ({market}).")

    def _on_chart_fail(self, range_key: str, msg: str) -> None:
        self.chart.set_state("error", msg)
        self.chart_status.set_status("missing", "بدون داده")
