"""ویجت‌های مشترک UI: کارت آمار، نشان وضعیت، نمودارهای واقعی، پیام‌ها.

نمودارها با QPainter رسم می‌شوند (بدون وابستگی اضافه) و فقط از داده واقعی
پر می‌شوند — در نبود داده، حالت «ناموجود/در حال دریافت» نمایش داده می‌شود.
"""
from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QSizePolicy,
                               QVBoxLayout, QWidget)

from ui.theme import (ACCENT, BG, BORDER, DANGER, INFO, SUCCESS, SURFACE,
                      SURFACE_2, TEXT, TEXT_DIM, TEXT_MUTED, WARNING)

STATUS_STYLES = {
    "pending": (WARNING, "در صف"),
    "processing": (INFO, "در حال پردازش"),
    "sent": (SUCCESS, "منتشر شده"),
    "failed": (DANGER, "ناموفق"),
    "unknown": (WARNING, "نامشخص"),
    "cancelled": (TEXT_DIM, "لغو شده"),
    "draft": (TEXT_DIM, "پیش‌نویس"),
    "ok": (SUCCESS, "متصل"),
    "error": (DANGER, "خطا"),
    "stale": (WARNING, "داده کهنه"),
    "loading": (INFO, "در حال دریافت"),
    "missing": (TEXT_DIM, "ناموجود"),
}


class StatusPill(QLabel):
    """نشان رنگی وضعیت با متن فارسی."""

    def __init__(self, status: str = "missing", parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.set_status(status)

    def set_status(self, status: str, custom_text: str | None = None) -> None:
        color, label = STATUS_STYLES.get(status, (TEXT_DIM, status))
        if custom_text:
            label = custom_text
        self.setText(label)
        self.setStyleSheet(
            f"background: rgba(255,255,255,0.04); border: 1px solid {color};"
            f"border-radius: 10px; padding: 2px 10px; color: {color};"
            "font-size: 11.5px; font-weight: 700;")


class StatCard(QFrame):
    """کارت آمار با سلسله‌مراتب بصری مشخص."""

    def __init__(self, title: str, value: str = "—", sub: str = "",
                 tone: str = "normal", parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self.setMinimumHeight(92)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(4)
        self.title_label = QLabel(title)
        self.title_label.setObjectName("CardTitle")
        self.value_label = QLabel(value)
        self.value_label.setObjectName("CardValue")
        self.sub_label = QLabel(sub)
        self.sub_label.setObjectName("CardSub")
        self.sub_label.setWordWrap(True)
        lay.addWidget(self.title_label)
        lay.addWidget(self.value_label)
        lay.addWidget(self.sub_label)
        self.set_tone(tone)

    def set_tone(self, tone: str) -> None:
        colors = {"normal": TEXT, "success": SUCCESS, "danger": DANGER,
                  "warning": WARNING, "info": INFO, "accent": ACCENT}
        self.value_label.setStyleSheet(f"color: {colors.get(tone, TEXT)};"
                                       "font-size: 21px; font-weight: 800;")

    def set_value(self, value: str, sub: str | None = None,
                  tone: str | None = None) -> None:
        self.value_label.setText(value)
        if sub is not None:
            self.sub_label.setText(sub)
        if tone:
            self.set_tone(tone)


class SectionHeader(QWidget):
    """تیتر بخش + دکمه‌های اختیاری در سمت چپ."""

    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.label = QLabel(title)
        self.label.setObjectName("h1")
        lay.addWidget(self.label)
        lay.addStretch(1)


class EmptyState(QWidget):
    """حالت خالی/ناموجود صادقانه — بدون داده ساختگی."""

    def __init__(self, message: str, sub: str = "", parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignCenter)
        main = QLabel(message)
        main.setStyleSheet(f"color: {TEXT_MUTED}; font-size: 14px; font-weight: 700;")
        main.setAlignment(Qt.AlignCenter)
        lay.addWidget(main)
        if sub:
            s = QLabel(sub)
            s.setStyleSheet(f"color: {TEXT_DIM}; font-size: 12px;")
            s.setAlignment(Qt.AlignCenter)
            s.setWordWrap(True)
            lay.addWidget(s)


class LineChart(QWidget):
    """نمودار خطی سبک با داده واقعی + برچسب بازه و واحد."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(220)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._points: list[tuple[str, float]] = []
        self._unit = ""
        self._title = ""
        self._state = "missing"     # missing | loading | error | data
        self._state_text = "نمودار در دسترس نیست"

    def set_data(self, points: list[tuple[str, float]], unit: str, title: str) -> None:
        self._points = [(t, v) for t, v in points if v is not None]
        self._unit, self._title = unit, title
        self._state = "data" if len(self._points) >= 2 else "missing"
        if len(self._points) < 2:
            self._state_text = "داده کافی برای نمودار وجود ندارد"
        self.update()

    def set_state(self, state: str, text: str) -> None:
        self._state, self._state_text = state, text
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 (Qt)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        painter.fillRect(self.rect(), QColor(SURFACE))
        # عنوان
        painter.setPen(QColor(TEXT))
        f = QFont(self.font()); f.setBold(True); f.setPointSizeF(9.5)
        painter.setFont(f)
        painter.drawText(QRectF(10, 6, w - 20, 22), Qt.AlignRight | Qt.AlignVCenter,
                         self._title or "")
        # واحد
        painter.setPen(QColor(TEXT_DIM))
        f2 = QFont(self.font()); f2.setPointSizeF(7.5)
        painter.setFont(f2)
        painter.drawText(QRectF(10, 26, w - 20, 16), Qt.AlignRight | Qt.AlignVCenter,
                         self._unit)
        if self._state != "data":
            painter.setPen(QColor(TEXT_MUTED if self._state == "missing" else INFO))
            painter.drawText(self.rect().adjusted(0, 40, 0, -8),
                             Qt.AlignCenter, self._state_text)
            painter.end()
            return

        values = [v for _, v in self._points]
        vmin, vmax = min(values), max(values)
        if vmax - vmin < 1e-12:
            vmax = vmin + abs(vmin) * 0.01 + 1.0
        pad, top, bottom = 46, 52, 26
        gw, gh = w - pad * 2, h - top - bottom
        # شبکه و محور
        painter.setPen(QPen(QColor(BORDER), 1))
        for i in range(5):
            y = top + gh * i / 4
            painter.drawLine(int(pad), int(y), int(w - pad), int(y))
        fm = QFontMetrics(f2)
        painter.setPen(QColor(TEXT_DIM))
        painter.setFont(f2)
        painter.drawText(QRectF(2, top - 8, pad - 6, 16), Qt.AlignRight | Qt.AlignVCenter,
                         self._fmt(vmax))
        painter.drawText(QRectF(2, top + gh - 8, pad - 6, 16), Qt.AlignRight | Qt.AlignVCenter,
                         self._fmt(vmin))
        # مسیر داده
        n = len(self._points)
        step = gw / max(n - 1, 1)
        pts = []
        for i, (_, v) in enumerate(self._points):
            x = pad + step * i
            y = top + gh * (1 - (v - vmin) / (vmax - vmin))
            pts.append(QPointF(x, y))
        pen = QPen(QColor(ACCENT), 2)
        painter.setPen(pen)
        for i in range(1, len(pts)):
            painter.drawLine(pts[i - 1], pts[i])
        # نقطه آخر + مقدار
        painter.setBrush(QColor(ACCENT))
        painter.drawEllipse(pts[-1], 4, 4)
        painter.setPen(QColor(TEXT))
        painter.drawText(QRectF(w - pad - 150, top - 24, 150, 18),
                         Qt.AlignRight | Qt.AlignVCenter,
                         self._fmt(values[-1]) + " " + self._unit.split("(")[0].strip())
        # بازه زمانی
        painter.setPen(QColor(TEXT_DIM))
        painter.drawText(QRectF(pad, h - bottom + 4, gw, 16),
                         Qt.AlignLeft | Qt.AlignVCenter,
                         self._short_time(self._points[0][0]))
        painter.drawText(QRectF(pad, h - bottom + 4, gw, 16),
                         Qt.AlignRight | Qt.AlignVCenter,
                         self._short_time(self._points[-1][0]))
        painter.end()

    @staticmethod
    def _fmt(v: float) -> str:
        from core.units import format_compact
        s = format_compact(v, "")
        return s.replace(" ", " ")

    @staticmethod
    def _short_time(iso: str) -> str:
        try:
            from core.timeutils import format_local
            return format_local(iso, "Asia/Tehran")
        except Exception:  # noqa: BLE001
            return iso[:16]


class BarChart(QWidget):
    """نمودار ستونی (مثلاً انتشار روزانه) — داده واقعی."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(200)
        self._data: list[tuple[str, int]] = []
        self._title = ""

    def set_data(self, data: list[tuple[str, int]], title: str) -> None:
        self._data = data
        self._title = title
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        painter.fillRect(self.rect(), QColor(SURFACE))
        painter.setPen(QColor(TEXT))
        f = QFont(self.font()); f.setBold(True); f.setPointSizeF(9.5)
        painter.setFont(f)
        painter.drawText(QRectF(10, 6, w - 20, 22), Qt.AlignRight | Qt.AlignVCenter,
                         self._title)
        if not self._data:
            painter.setPen(QColor(TEXT_MUTED))
            painter.drawText(self.rect().adjusted(0, 30, 0, 0), Qt.AlignCenter,
                             "داده‌ای ثبت نشده است")
            painter.end()
            return
        pad, top, bottom = 16, 40, 28
        gw, gh = w - pad * 2, h - top - bottom
        vmax = max(v for _, v in self._data) or 1
        n = len(self._data)
        bw = max(6.0, gw / n * 0.55)
        gap = gw / n
        painter.setPen(QPen(QColor(BORDER), 1))
        for i in range(4):
            y = top + gh * i / 3
            painter.drawLine(int(pad), int(y), int(w - pad), int(y))
        for i, (label, v) in enumerate(self._data):
            x = pad + gap * i + (gap - bw) / 2
            bh = gh * (v / vmax)
            painter.setBrush(QColor(ACCENT))
            painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(QRectF(x, top + gh - bh, bw, bh), 3, 3)
            painter.setPen(QColor(TEXT_DIM))
            f2 = QFont(self.font()); f2.setPointSizeF(7)
            painter.setFont(f2)
            painter.drawText(QRectF(x - gap / 2, h - bottom + 6, gap + bw, 16),
                             Qt.AlignCenter, label[5:] if len(label) == 10 else label)
            if v:
                painter.drawText(QRectF(x - gap / 2, top + gh - bh - 16, gap + bw, 14),
                                 Qt.AlignCenter, str(v))
        painter.end()


def h_spacer() -> QWidget:
    from PySide6.QtWidgets import QSpacerItem
    return QSpacerItem(1, 1, QSizePolicy.Expanding, QSizePolicy.Minimum)
