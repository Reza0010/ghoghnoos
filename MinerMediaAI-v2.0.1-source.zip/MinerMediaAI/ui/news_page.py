"""صفحه اخبار — منابع، فیلتر، تأیید، خلاصه‌سازی و تبدیل به پیش‌نویس."""
from __future__ import annotations

from PySide6.QtCore import QThread, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QComboBox, QHBoxLayout, QLabel,
                               QLineEdit, QMessageBox, QPushButton,
                               QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget)

from core.timeutils import format_local
from ui.theme import TEXT_DIM
from ui.widgets import SectionHeader, StatusPill


class NewsFetchWorker(QThread):
    done = Signal(object)      # RefreshResult
    failed = Signal(str)

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx

    def run(self) -> None:
        try:
            sources = self.ctx.settings.enabled_news_sources
            result = self.ctx.news_service.fetch_all(sources)
            self.done.emit(result)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(f"دریافت اخبار ناموفق بود: {type(exc).__name__}")


class SummarizeWorker(QThread):
    """خلاصه‌سازی هوش مصنوعی یک خبر (اختیاری)."""

    done = Signal(int, str)
    failed = Signal(int, str)

    def __init__(self, ctx, item_id: int):
        super().__init__()
        self.ctx, self.item_id = ctx, item_id

    def run(self) -> None:
        item = self.ctx.news_repo.get(self.item_id)
        if not item:
            self.failed.emit(self.item_id, "خبر یافت نشد.")
            return
        try:
            result = self.ctx.ai_provider.chat(
                "خلاصه‌ساز خبرهای ماینینگ و ارز دیجیتال. خلاصه مستقل و کوتاه "
                "به فارسی بنویس؛ از کپی کامل متن خودداری کن.",
                f"عنوان: {item.title}\nمتن/خلاصه اولیه: {item.summary or '—'}\n"
                "خلاصه ۲ تا ۴ جمله‌ای بنویس.", temperature=0.4, max_tokens=300)
            self.ctx.db.execute("UPDATE news_items SET summary=? WHERE id=?",
                                (result.text[:1000], self.item_id))
            self.done.emit(self.item_id, result.text)
        except Exception as exc:  # noqa: BLE001
            msg = getattr(exc, "user_message", str(exc))
            self.failed.emit(self.item_id, msg)


class NewsPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self._worker = None
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        head = SectionHeader("اخبار ماینینگ و ارز دیجیتال")
        fetch_btn = QPushButton(" دریافت اخبار")
        fetch_btn.setObjectName("primary")
        from ui.icons import icon
        fetch_btn.setIcon(icon("refresh", 16, "#14100a"))
        fetch_btn.clicked.connect(self._fetch)
        sources_btn = QPushButton("مدیریت منابع")
        sources_btn.clicked.connect(self._manage_sources)
        head.layout().addWidget(sources_btn)
        head.layout().addWidget(fetch_btn)
        root.addWidget(head)

        note = QLabel("دریافت اخبار مستقل از سرویس قیمت است. خبر تأییدنشده "
                      "هرگز به‌صورت خودکار منتشر نمی‌شود (پیش‌فرض ایمن). "
                      "برای انتشار، خبر را تأیید و سپس به پیش‌نویس تلگرام تبدیل کنید.")
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        root.addWidget(note)

        filters = QHBoxLayout()
        self.status_combo = QComboBox()
        for label, val in (("همه", None), ("جدید", "new"), ("بررسی‌شده", "reviewed"),
                           ("تأییدشده", "approved"), ("ردشده", "rejected"),
                           ("تبدیل‌شده", "converted")):
            self.status_combo.addItem(label, val)
        self.topic_combo = QComboBox()
        self.topic_combo.addItem("همه موضوعات", None)
        for t in ("mining", "hardware", "bitcoin", "energy", "regulation", "crypto", "general"):
            self.topic_combo.addItem(t, t)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("جست‌وجو در عنوان/خلاصه…")
        self.search_edit.returnPressed.connect(self.refresh)
        for wdg in (self.status_combo, self.topic_combo):
            wdg.currentIndexChanged.connect(self.refresh)
        filters.addWidget(QLabel("وضعیت:"))
        filters.addWidget(self.status_combo)
        filters.addWidget(QLabel("موضوع:"))
        filters.addWidget(self.topic_combo)
        filters.addWidget(self.search_edit, 1)
        root.addLayout(filters)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["عنوان", "منبع", "موضوع", "زمان", "وضعیت", "عملیات"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.doubleClicked.connect(self._open_link)
        root.addWidget(self.table, 1)
        self.refresh()

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        items = self.ctx.news_repo.list(
            status=self.status_combo.currentData(),
            topic=self.topic_combo.currentData(),
            q=self.search_edit.text().strip() or None, limit=200)
        tz = self.ctx.settings.timezone
        self.table.setRowCount(len(items))
        for r, item in enumerate(items):
            self.table.setItem(r, 0, QTableWidgetItem(item.title[:90]))
            self.table.setItem(r, 1, QTableWidgetItem(item.source))
            self.table.setItem(r, 2, QTableWidgetItem(item.topic))
            # مدیریت صادقانه «خبر فاقد تاریخ»: زمان انتشار نامشخص است؛
            # زمان دریافت جایگزین نمایش داده نمی‌شود که گمراه‌کننده باشد.
            if item.published_at:
                ts_text = format_local(item.published_at, tz)
            else:
                ts_text = "زمان انتشار نامشخص (دریافت: " \
                          + format_local(item.fetched_at, tz) + ")"
            self.table.setItem(r, 3, QTableWidgetItem(ts_text))
            self.table.setCellWidget(r, 4, StatusPill(
                {"new": "pending", "reviewed": "loading", "approved": "ok",
                 "rejected": "error", "converted": "ok"}.get(item.status, "missing"),
                {"new": "جدید", "reviewed": "بررسی‌شده", "approved": "تأییدشده",
                 "rejected": "ردشده", "converted": "تبدیل‌شده"}.get(item.status, item.status)))
            ops = QWidget()
            lay = QHBoxLayout(ops)
            lay.setContentsMargins(2, 2, 2, 2)
            open_btn = QPushButton("لینک")
            open_btn.clicked.connect(lambda _=False, i=item: self._open(i))
            approve_btn = QPushButton("تأیید")
            approve_btn.clicked.connect(lambda _=False, i=item: self._set_status(i, "approved"))
            reject_btn = QPushButton("رد")
            reject_btn.setObjectName("danger")
            reject_btn.clicked.connect(lambda _=False, i=item: self._set_status(i, "rejected"))
            draft_btn = QPushButton("به پیش‌نویس")
            draft_btn.setToolTip("تبدیل به پیش‌نویس تلگرام با هوش مصنوعی (نیازمند تنظیم AI)")
            draft_btn.clicked.connect(lambda _=False, i=item: self._to_draft(i))
            for b in (open_btn, approve_btn, draft_btn, reject_btn):
                lay.addWidget(b)
            self.table.setCellWidget(r, 5, ops)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)

    def _open(self, item) -> None:
        if item.link:
            QDesktopServices.openUrl(QUrl(item.link))

    def _open_link(self, index) -> None:
        items = self.ctx.news_repo.list(
            status=self.status_combo.currentData(),
            topic=self.topic_combo.currentData(),
            q=self.search_edit.text().strip() or None, limit=200)
        if 0 <= index.row() < len(items):
            self._open(items[index.row()])

    def _set_status(self, item, status: str) -> None:
        self.ctx.news_service.set_status(item.id, status)
        self.ctx.logs_repo.add("INFO", "NEWS", f"خبر {item.id} → {status}")
        self.refresh()

    def _fetch(self) -> None:
        if self._worker and self._worker.isRunning():
            return
        fetch_btn = self.findChild(QPushButton)
        self._worker = NewsFetchWorker(self.ctx)
        self._worker.done.connect(self._on_fetch)
        self._worker.failed.connect(lambda m: QMessageBox.warning(self, "اخبار", m))
        self._worker.start()

    def _on_fetch(self, result) -> None:
        msg = f"{result.updated} خبر جدید اضافه شد."
        if getattr(result, "notes", None):
            msg += "\n" + "\n".join(result.notes)
        if result.errors:
            msg += "\nخطاهای منابع:\n" + "\n".join(result.errors[:5])
            QMessageBox.information(self, "دریافت اخبار", msg)
        else:
            QMessageBox.information(self, "دریافت اخبار", msg + "\nهمه منابع فعال سالم بودند.")
        self.ctx.logs_repo.add(
            "INFO", "NEWS",
            f"دریافت اخبار: {result.updated} جدید، {len(result.errors)} خطای منبع"
            + (f"، {len(result.notes)} یادداشت" if getattr(result, 'notes', None) else ""))
        self.refresh()

    def _to_draft(self, item) -> None:
        if not self.ctx.ai_provider.configured:
            QMessageBox.information(
                self, "هوش مصنوعی",
                "برای تبدیل خبر به پیش‌نویس، ابتدا سرویس AI را در تنظیمات "
                "پیکربندی کنید. بدون آن، این اقدام انجام نمی‌شود.")
            return
        if item.status not in ("approved", "reviewed") and \
                self.ctx.settings.news_require_approval:
            QMessageBox.information(
                self, "تأیید لازم",
                "خبر باید ابتدا تأیید شود؛ سپس قابل تبدیل به پیش‌نویس است.")
            return
        try:
            draft = self.ctx.studio.news_to_draft(item)
            self.ctx.news_service.set_status(item.id, "converted")
            self.ctx.logs_repo.add("INFO", "NEWS",
                                   f"خبر {item.id} به پیش‌نویس {draft.id} تبدیل شد.")
            QMessageBox.information(self, "پیش‌نویس",
                                    f"پیش‌نویس #{draft.id} در استودیو ساخته شد.")
            self.refresh()
        except Exception as exc:  # noqa: BLE001
            msg = getattr(exc, "user_message", str(exc))
            QMessageBox.warning(self, "تبدیل خبر", msg)

    def _manage_sources(self) -> None:
        from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QPlainTextEdit)
        dlg = QDialog(self)
        dlg.setWindowTitle("مدیریت منابع خبری")
        dlg.setMinimumWidth(560)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel(
            "هر خط: نام | آدرس RSS/Atom | موضوع | فعال/خاموش\n"
            "مثال: CoinDesk | https://www.coindesk.com/arc/outboundfeeds/rss/ | crypto | on\n"
            "بخش چهارم اختیاری است (on/off یا فعال/خاموش)؛ نبود آن یعنی فعال.\n"
            "منابع غیرفعال توسط Worker زمان‌بندی‌شده دریافت نمی‌شوند."))
        edit = QPlainTextEdit()
        lines = []
        for s in self.ctx.settings.news_sources:
            name, url = s[0], s[1]
            topic = s[2] if len(s) > 2 else "crypto"
            enabled = bool(s[3]) if len(s) > 3 else True
            lines.append(f"{name} | {url} | {topic} | " + ("on" if enabled else "off"))
        edit.setPlainText("\n".join(lines))
        lay.addWidget(edit)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay.addWidget(bb)
        if dlg.exec():
            parsed = []
            for line in edit.toPlainText().splitlines():
                parts = [p.strip() for p in line.split("|")]
                if len(parts) >= 2:
                    enabled = True
                    if len(parts) > 3:
                        enabled = parts[3].lower() not in ("off", "0", "خاموش", "no", "false")
                    parsed.append((parts[0], parts[1],
                                   parts[2] if len(parts) > 2 else "crypto",
                                   enabled))
            self.ctx.settings.news_sources = parsed
            self.ctx.logs_repo.add("INFO", "NEWS",
                                   "منابع خبری به‌روزرسانی شد "
                                   f"({sum(1 for p in parsed if p[3])} فعال از {len(parsed)}).")
