"""صفحه نمای کلی — همه اعداد از دیتابیس/سرویس واقعی؛ بدون مقدار ساختگی."""
from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QScrollArea, QTableWidget, QTableWidgetItem,
                               QVBoxLayout, QWidget)

from core.timeutils import format_local, utc_iso
from ui.theme import ACCENT, DANGER, TEXT_DIM, TEXT_MUTED
from ui.widgets import EmptyState, StatCard, StatusPill


class OverviewPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(14)

        header = QHBoxLayout()
        self.lbl_title = QLabel("نمای کلی")
        self.lbl_title.setObjectName("h1")
        header.addWidget(self.lbl_title)
        header.addStretch(1)
        self.pill_scheduler = StatusPill("missing")
        self.pill_market = StatusPill("missing")
        header.addWidget(QLabel("زمان‌بندی:"))
        header.addWidget(self.pill_scheduler)
        header.addWidget(QLabel("بازار:"))
        header.addWidget(self.pill_market)
        root.addLayout(header)

        body = QScrollArea()
        body.setWidgetResizable(True)
        body.setFrameShape(QFrame.NoFrame)
        inner = QWidget()
        self.inner_lay = QVBoxLayout(inner)
        self.inner_lay.setContentsMargins(0, 0, 0, 0)
        self.inner_lay.setSpacing(14)
        body.setWidget(inner)
        root.addWidget(body)

        # ---------- ردیف کارت‌های وضعیت ----------
        grid = QGridLayout()
        grid.setSpacing(12)
        self.card_channels = StatCard("کانال‌های فعال")
        self.card_scheduled = StatCard("پست‌های زمان‌بندی‌شده")
        self.card_sent_today = StatCard("منتشرشده امروز")
        self.card_pending_review = StatCard("در انتظار بررسی")
        grid.addWidget(self.card_channels, 0, 0)
        grid.addWidget(self.card_scheduled, 0, 1)
        grid.addWidget(self.card_sent_today, 0, 2)
        grid.addWidget(self.card_pending_review, 0, 3)
        self.inner_lay.addLayout(grid)

        # ---------- ردیف بازار ----------
        grid2 = QGridLayout()
        grid2.setSpacing(12)
        self.card_market_status = StatCard("سرویس قیمت ارزها")
        self.card_market_updated = StatCard("آخرین به‌روزرسانی قیمت‌ها")
        grid2.addWidget(self.card_market_status, 0, 0)
        grid2.addWidget(self.card_market_updated, 0, 1)
        self.inner_lay.addLayout(grid2)

        # ---------- جدول منتخب ارزها ----------
        self.inner_lay.addWidget(self._make_market_box())
        # ---------- خطاهای اخیر ----------
        self.inner_lay.addWidget(self._make_errors_box())
        self.inner_lay.addStretch(1)

        self.refresh_timer = QTimer(self)
        self.refresh_timer.setInterval(5000)
        self.refresh_timer.timeout.connect(self.refresh)
        self.refresh_timer.start()

    # ------------------------------------------------------------------
    def _card_frame(self, title: str) -> tuple[QFrame, QVBoxLayout]:
        frame = QFrame()
        frame.setObjectName("Card")
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(14, 12, 14, 12)
        t = QLabel(title)
        t.setObjectName("h2")
        lay.addWidget(t)
        return frame, lay

    def _make_market_box(self) -> QFrame:
        frame, lay = self._card_frame("قیمت منتخب ارزها (نوبیتکس)")
        self.market_unit_label = QLabel("")
        self.market_unit_label.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        lay.addWidget(self.market_unit_label)
        self.market_table = QTableWidget(0, 5)
        self.market_table.setHorizontalHeaderLabels(
            ["ارز", "قیمت", "تغییر ۲۴ ساعته", "حجم ۲۴ ساعته", "زمان/منبع"])
        self.market_table.horizontalHeader().setStretchLastSection(True)
        self.market_table.verticalHeader().setVisible(False)
        self.market_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.market_table.setAlternatingRowColors(True)
        self.market_table.setMinimumHeight(240)
        lay.addWidget(self.market_table)
        return frame

    def _make_errors_box(self) -> QFrame:
        frame, lay = self._card_frame("آخرین خطاهای مهم")
        self.errors_table = QTableWidget(0, 4)
        self.errors_table.setHorizontalHeaderLabels(
            ["زمان", "کانال/مقصد", "وضعیت", "خطا"])
        self.errors_table.horizontalHeader().setStretchLastSection(True)
        self.errors_table.verticalHeader().setVisible(False)
        self.errors_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.errors_table.setMinimumHeight(180)
        lay.addWidget(self.errors_table)
        return frame

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        ctx = self.ctx
        tz = ctx.settings.timezone
        # وضعیت Workerها
        if ctx.scheduler and ctx.scheduler.is_alive():
            self.pill_scheduler.set_status(
                "ok", "موقفة" if ctx.scheduler.paused else "فعال")
        else:
            self.pill_scheduler.set_status("missing", "متوقف")
        svc = ctx.market_service
        if ctx.market_worker and ctx.market_worker.is_alive():
            if svc.last_error:
                self.pill_market.set_status("error", "خطای دریافت")
            else:
                self.pill_market.set_status("loading", "فعال")
        else:
            self.pill_market.set_status("missing", "متوقف")

        # کانال‌ها
        channels = ctx.channels_repo.list()
        active = sum(1 for c in channels if c.enabled)
        self.card_channels.set_value(str(active), f"از مجموع {len(channels)} کانال")

        # صف
        counts = ctx.posts_repo.counts_by_status()
        self.card_scheduled.set_value(str(counts.get("pending", 0)),
                                      f"در پردازش: {counts.get('processing', 0)} | "
                                      f"نامشخص: {counts.get('unknown', 0)}")
        sent_today = ctx.posts_repo.published_today_count()
        self.card_sent_today.set_value(str(sent_today), "پیام‌های موفق امروز")

        news_counts = ctx.news_repo.counts_by_status()
        pending = news_counts.get("new", 0) + news_counts.get("reviewed", 0)
        self.card_pending_review.set_value(str(pending), "خبر/پیش‌نویس بررسی‌نشده")

        # بازار
        if svc.consecutive_errors:
            self.card_market_status.set_value("خطا در دریافت", svc.last_error or "",
                                              "danger")
        elif svc.last_error == "" and ctx.market_worker and ctx.market_worker.is_alive():
            self.card_market_status.set_value("فعال", "منبع: نوبیتکس (عمومی)", "success")
        else:
            self.card_market_status.set_value("ناموجود", "هنوز داده‌ای دریافت نشده")
        latest = ctx.market_repo.get_quote("BTC", "BTCIRT")
        if latest:
            self.card_market_updated.set_value(
                format_local(latest["fetched_at"], tz),
                f"منبع: {latest['source']}")
        else:
            self.card_market_updated.set_value("—", "در انتظار اولین به‌روزرسانی")

        self._fill_market_table()
        self._fill_errors()

    def _fill_market_table(self) -> None:
        ctx = self.ctx
        unit = ctx.settings.market_display_unit
        unit_name = {"RIAL": "ریال", "TOMAN": "تومان", "USDT": "USDT"}[unit]
        self.market_unit_label.setText(f"واحد نمایش: {unit_name} — منبع: نوبیتکس")
        watch = ctx.market_repo.list_watch(visible_only=True)
        rows = []
        for w in watch:
            info = ctx.market_service.display_price(w.symbol, unit)
            q = ctx.market_repo.get_quote(w.symbol, f"{w.symbol}IRT") or \
                ctx.market_repo.get_quote(w.symbol, f"{w.symbol}USDT")
            vol = None
            if q:
                from core.units import format_compact
                vol_src = q.get("volume_src") if isinstance(q, dict) else None
                vol = format_compact(vol_src, w.symbol) if vol_src else None
            rows.append((w, info, q, vol))
        self.market_table.setRowCount(len(rows))
        for r, (w, info, q, vol) in enumerate(rows):
            name_item = QTableWidgetItem(f"{w.symbol} — {w.display_name}")
            self.market_table.setItem(r, 0, name_item)
            if info:
                from core.units import format_amount, format_percent, smart_price_decimals
                price_txt = (format_amount(info["price"], smart_price_decimals(info["price"], info["unit"]))
                             + (" (تخمینی)" if info["estimated"] else ""))
                self.market_table.setItem(r, 1, QTableWidgetItem(price_txt))
                chg = format_percent(q.get("day_change") if q else None)
                item = QTableWidgetItem(chg)
                if q and q.get("day_change") is not None:
                    color = "#22c55e" if q["day_change"] >= 0 else "#ef4444"
                    item.setForeground(Qt.white)
                self.market_table.setItem(r, 2, item)
                self.market_table.setItem(r, 3, QTableWidgetItem(vol or "—"))
                stale = info["stale"]
                ts = format_local(info["fetched_at"], ctx.settings.timezone)
                txt = ("کهنه — " if stale else "") + f"{ts} | {info['source']}"
                self.market_table.setItem(r, 4, QTableWidgetItem(txt))
            else:
                self.market_table.setItem(r, 1, QTableWidgetItem("ناموجود"))
                self.market_table.setItem(r, 2, QTableWidgetItem("—"))
                self.market_table.setItem(r, 3, QTableWidgetItem("—"))
                self.market_table.setItem(r, 4,
                                          QTableWidgetItem("در حال دریافت / خطا"))
        self.market_table.resizeColumnsToContents()
        self.market_table.horizontalHeader().setStretchLastSection(True)

    def _fill_errors(self) -> None:
        errs = self.ctx.posts_repo.recent_errors(limit=8)
        self.errors_table.setRowCount(len(errs))
        tz = self.ctx.settings.timezone
        for r, e in enumerate(errs):
            self.errors_table.setItem(r, 0, QTableWidgetItem(
                format_local(e["ts"], tz)))
            self.errors_table.setItem(r, 1, QTableWidgetItem(str(e["channel_id"])))
            self.errors_table.setItem(r, 2, QTableWidgetItem(e["status"]))
            self.errors_table.setItem(r, 3, QTableWidgetItem(e["err"][:160]))
        self.errors_table.resizeColumnsToContents()
        self.errors_table.horizontalHeader().setStretchLastSection(True)
