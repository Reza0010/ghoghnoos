"""صفحه مدیریت کانال‌ها — چندکاناله با آزمون اتصال واقعی Bot API."""
from __future__ import annotations

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QCheckBox, QDialog, QFormLayout, QHBoxLayout,
                               QLabel, QLineEdit, QMessageBox, QPushButton,
                               QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget)

from core.redact import scrub_text
from core.timeutils import format_local
from ui.theme import TEXT_DIM
from ui.widgets import EmptyState, SectionHeader, StatusPill


class ChannelTestWorker(QThread):
    """آزمون اتصال در Thread جدا — UI هرگز فریز نمی‌شود."""

    finished_ok = Signal(int, str)       # channel_id, bot_username
    finished_err = Signal(int, str)      # channel_id, error

    def __init__(self, ctx, channel_id: int):
        super().__init__()
        self.ctx = ctx
        self.channel_id = channel_id

    def run(self) -> None:
        from services.telegram.client import TelegramBotClient
        channel = self.ctx.channels_repo.get(self.channel_id)
        if not channel:
            self.finished_err.emit(self.channel_id, "کانال یافت نشد.")
            return
        token = self.ctx.secret_store.get_secret(channel.token_key)
        if not token:
            self.finished_err.emit(self.channel_id,
                                   f"توکن «{channel.token_key}» ثبت نشده است.")
            return
        client = TelegramBotClient(lambda: token)
        try:
            me = client.test_connection()
            try:
                client.check_channel_access(channel.chat_id)
            except Exception as exc:  # noqa: BLE001 — دسترسی کانال جدا بررسی می‌شود
                self.ctx.channels_repo.set_test_result(
                    self.channel_id, False, scrub_text(exc.user_message))
                self.finished_err.emit(
                    self.channel_id,
                    f"ربات متصل است (@{me.get('username')}) ولی دسترسی به کانال "
                    f"تأیید نشد: {exc.user_message}")
                return
            self.ctx.channels_repo.set_test_result(self.channel_id, True, None)
            self.finished_ok.emit(self.channel_id, me.get("username", ""))
        except Exception as exc:  # noqa: BLE001
            msg = getattr(exc, "user_message", str(exc))
            self.ctx.channels_repo.set_test_result(
                self.channel_id, False, scrub_text(getattr(exc, "technical", str(exc))))
            self.finished_err.emit(self.channel_id, msg)


class ChannelDialog(QDialog):
    """افزودن/ویرایش کانال."""

    def __init__(self, parent, ctx, channel=None):
        super().__init__(parent)
        self.ctx = ctx
        self.channel = channel
        self.setWindowTitle("کانال جدید" if channel is None else "ویرایش کانال")
        self.setMinimumWidth(420)
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.name_edit = QLineEdit(channel.name if channel else "")
        self.alias_edit = QLineEdit(channel.alias if channel else "")
        self.chat_edit = QLineEdit(channel.chat_id if channel else "")
        self.chat_edit.setPlaceholderText("@channel_name یا -1001234567890")
        self.token_edit = QLineEdit()
        self.token_edit.setPlaceholderText(
            "توکن BotFather — فقط ذخیره می‌شود؛ نمایش داده نمی‌شود")
        self.token_edit.setEchoMode(QLineEdit.Password)
        form.addRow("نام:", self.name_edit)
        form.addRow("نام مستعار (اختیاری):", self.alias_edit)
        form.addRow("شناسه کانال:", self.chat_edit)
        if channel is None:
            form.addRow("توکن ربات:", self.token_edit)
        else:
            hint = QLabel(f"توکن در «{channel.token_key}» ذخیره شده؛ "
                          "برای تغییر فقط مقدار جدید در فیلد زیر بنویسید.")
            hint.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
            form.addRow(hint)
            form.addRow("توکن جدید (اختیاری):", self.token_edit)
        lay.addLayout(form)
        note = QLabel("ربات باید توسط BotFather ساخته شده و در کانال با مجوز "
                      "«ارسال پیام» ادمین شود؛ در غیر این صورت ارسال با خطای "
                      "دائمی 403 مواجه می‌شود.")
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        lay.addWidget(note)
        btns = QHBoxLayout()
        save = QPushButton("ذخیره")
        save.setObjectName("primary")
        cancel = QPushButton("انصراف")
        save.clicked.connect(self._save)
        cancel.clicked.connect(self.reject)
        btns.addStretch(1)
        btns.addWidget(cancel)
        btns.addWidget(save)
        lay.addLayout(btns)

    def _save(self) -> None:
        from core.errors import MinerMediaError
        try:
            if self.channel is None:
                token_key = "telegram.bot_token.default"
                channel_id = self.ctx.channels_repo.add(
                    self.name_edit.text(), self.chat_edit.text(),
                    self.alias_edit.text(), token_key)
                token = self.token_edit.text().strip()
                if token:
                    self.ctx.secret_store.set_secret(token_key, token)
                else:
                    raise MinerMediaError("missing token",
                                          "توکن ربات را وارد کنید.")
                self.new_channel_id = channel_id
            else:
                self.ctx.channels_repo.update(
                    self.channel.id, name=self.name_edit.text().strip(),
                    alias=self.alias_edit.text().strip(),
                    chat_id=self.chat_edit.text().strip())
                token = self.token_edit.text().strip()
                if token:
                    self.ctx.secret_store.set_secret(self.channel.token_key, token)
            self.accept()
        except MinerMediaError as exc:
            QMessageBox.warning(self, "خطا", exc.user_message)


class ChannelsPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self._workers: list[ChannelTestWorker] = []
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        head = SectionHeader("مدیریت کانال‌ها")
        add_btn = QPushButton(" افزودن کانال")
        add_btn.setObjectName("primary")
        from ui.icons import icon
        add_btn.setIcon(icon("plus", 16, "#14100a"))
        add_btn.clicked.connect(self._add_channel)
        head.layout().addWidget(add_btn)
        root.addWidget(head)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["نام", "شناسه کانال", "وضعیت", "آزمون اتصال", "آخرین خطا",
             "سابقه انتشار", "عملیات"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        root.addWidget(self.table, 1)

        note = QLabel("هر کانال توکن و صف مستقل دارد؛ نتیجه انتشار به‌صورت "
                      "جداگانه برای هر کانال ثبت می‌شود.")
        note.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        root.addWidget(note)
        self.refresh()

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        channels = self.ctx.channels_repo.list()
        self.table.setRowCount(len(channels))
        tz = self.ctx.settings.timezone
        for r, ch in enumerate(channels):
            self.table.setItem(r, 0, QTableWidgetItem(ch.display_name))
            self.table.setItem(r, 1, QTableWidgetItem(ch.chat_id))
            pill = StatusPill("ok" if ch.enabled else "cancelled",
                              "فعال" if ch.enabled else "غیرفعال")
            self.table.setCellWidget(r, 2, pill)
            if ch.last_test_ok is None:
                test_item = QTableWidgetItem("—")
            elif ch.last_test_ok:
                test_item = QTableWidgetItem(
                    f"موفق ({format_local(ch.last_test_at, tz)})")
                test_item.setForeground(Qt.green)
            else:
                test_item = QTableWidgetItem(
                    f"ناموفق ({format_local(ch.last_test_at, tz)})")
                test_item.setForeground(Qt.red)
            self.table.setItem(r, 3, test_item)
            self.table.setItem(r, 4, QTableWidgetItem(ch.last_error or "—"))
            sent = self.ctx.db.query_one(
                "SELECT COUNT(*) AS n FROM published_messages WHERE channel_id=?",
                (ch.id,))
            self.table.setItem(r, 5, QTableWidgetItem(str(int(sent["n"]))))
            ops = QWidget()
            lay = QHBoxLayout(ops)
            lay.setContentsMargins(2, 2, 2, 2)
            btn_test = QPushButton("آزمون")
            btn_test.clicked.connect(lambda _=False, cid=ch.id: self._test(cid))
            btn_edit = QPushButton("ویرایش")
            btn_edit.clicked.connect(lambda _=False, c=ch: self._edit(c))
            btn_del = QPushButton("حذف")
            btn_del.setObjectName("danger")
            btn_del.clicked.connect(lambda _=False, c=ch: self._delete(c))
            for b in (btn_test, btn_edit, btn_del):
                lay.addWidget(b)
            self.table.setCellWidget(r, 6, ops)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)

    def _add_channel(self) -> None:
        dlg = ChannelDialog(self, self.ctx)
        if dlg.exec():
            self.refresh()

    def _edit(self, channel) -> None:
        dlg = ChannelDialog(self, self.ctx, channel)
        if dlg.exec():
            self.refresh()

    def _delete(self, channel) -> None:
        reply = QMessageBox.question(
            self, "حذف کانال",
            f"کانال «{channel.display_name}» حذف شود؟\n"
            "پست‌های زمان‌بندی‌شده این کانال نیز حذف می‌شوند.")
        if reply == QMessageBox.Yes:
            self.ctx.channels_repo.delete(channel.id)
            self.ctx.logs_repo.add("INFO", "CHANNELS", f"کانال حذف شد: {channel.id}")
            self.refresh()

    def _test(self, channel_id: int) -> None:
        worker = ChannelTestWorker(self.ctx, channel_id)
        worker.finished_ok.connect(lambda cid, un: self._on_test(cid, True, un))
        worker.finished_err.connect(lambda cid, msg: self._on_test(cid, False, msg))
        self._workers.append(worker)
        worker.start()

    def _on_test(self, channel_id: int, ok: bool, msg: str) -> None:
        self.ctx.logs_repo.add("INFO" if ok else "ERROR", "CHANNELS",
                               f"آزمون کانال {channel_id}: {msg}")
        if ok:
            QMessageBox.information(self, "آزمون اتصال",
                                    f"اتصال موفق — ربات: @{msg}")
        else:
            QMessageBox.warning(self, "آزمون اتصال", msg)
        self.refresh()
