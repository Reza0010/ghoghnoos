"""بارگذاری فونت فارسی وزیرمتن (OFL) — با جایگزین‌های سیستمی ویندوز.

فایل‌ها در assets/fonts قرار دارند؛ اگر موجود نباشند، برنامه با
'Segoe UI / Tahoma' (پشتیبانی فارسی ویندوز) اجرا می‌شود.
"""
from __future__ import annotations

from pathlib import Path

from core.logging_setup import get_logger

log = get_logger("minermedia.fonts")
_FONT_FAMILY = "Vazirmatn"


def load_fonts() -> str:
    """فونت‌های bundled را ثبت می‌کند؛ نام خانوادگی فعال را برمی‌گرداند."""
    try:
        from PySide6.QtGui import QFontDatabase
    except ImportError:  # pragma: no cover
        return _FONT_FAMILY
    assets = Path(__file__).parent.parent / "assets" / "fonts"
    loaded_any = False
    if assets.exists():
        for ttf in sorted(assets.glob("Vazirmatn-*.ttf")):
            fid = QFontDatabase.addApplicationFont(str(ttf))
            families = QFontDatabase.applicationFontFamilies(fid)
            if families:
                loaded_any = True
    if not loaded_any:
        log.warning("Vazirmatn fonts not found; falling back to system fonts")
    return _FONT_FAMILY if loaded_any else "Segoe UI"


def font_family() -> str:
    return _FONT_FAMILY
