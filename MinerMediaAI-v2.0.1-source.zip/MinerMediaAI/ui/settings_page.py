"""صفحه تنظیمات — امنیت، هوش مصنوعی، بازار، اخبار، پشتیبان‌گیری."""
from __future__ import annotations

import shutil

from PySide6.QtCore import QDateTime
from PySide6.QtWidgets import (QComboBox, QDoubleSpinBox, QFileDialog,
                               QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPushButton, QSpinBox, QVBoxLayout,
                               QWidget)

from config import defaults as cfg
from core.errors import MinerMediaError
from ui.theme import TEXT_DIM
from ui.widgets import SectionHeader


def _card(title: str):
    from PySide6.QtWidgets import QFrame
    frame = QFrame()
    frame.setObjectName("Card")
    lay = QVBoxLayout(frame)
    lay.setContentsMargins(14, 12, 14, 12)
    t = QLabel(title)
    t.setObjectName("h2")
    lay.addWidget(t)
    return frame, lay


class SettingsPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.addWidget(SectionHeader("تنظیمات و مدیریت APIها"))

        # ---------------- عمومی ----------------
        card, lay = _card("عمومی")
        form = QFormLayout()
        self.app_name_edit = QLineEdit(ctx.settings.app_name)
        self.tz_combo = QComboBox()
        for tz in ("Asia/Tehran", "UTC", "Europe/Berlin", "Asia/Dubai", "Europe/London"):
            self.tz_combo.addItem(tz, tz)
        self.tz_combo.setCurrentText(ctx.settings.timezone)
        form.addRow("نام محصول (قابل شخصی‌سازی):", self.app_name_edit)
        form.addRow("منطقه زمانی:", self.tz_combo)
        lay.addLayout(form)
        save_general = QPushButton("ذخیره تنظیمات عمومی")
        save_general.setObjectName("primary")
        save_general.clicked.connect(self._save_general)
        lay.addWidget(save_general)
        root.addWidget(card)

        # ---------------- بازار ----------------
        card, lay = _card("بازار و نوبیتکس")
        form = QFormLayout()
        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(cfg.MIN_MARKET_REFRESH_SEC,
                                    cfg.MAX_MARKET_REFRESH_SEC)
        self.interval_spin.setValue(ctx.settings.market_refresh_sec)
        self.interval_spin.setSuffix(" ثانیه")
        form.addRow("فاصله به‌روزرسانی قیمت‌ها:", self.interval_spin)
        note = QLabel(f"محدودیت رسمی نوبیتکس: آمار بازار ۲۰ درخواست/دقیقه؛ "
                      f"برنامه همه ارزها را در «یک درخواست دسته‌ای» می‌گیرد. "
                      f"سند API: {cfg.NOBITEX_DOCS_URL}")
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        form.addRow(note)
        lay.addLayout(form)
        save_market = QPushButton("ذخیره تنظیمات بازار")
        save_market.clicked.connect(self._save_market)
        lay.addWidget(save_market)
        root.addWidget(card)

        # ---------------- هوش مصنوعی ----------------
        card, lay = _card("هوش مصنوعی (سازگار با OpenAI)")
        form = QFormLayout()
        self.ai_base_edit = QLineEdit(ctx.settings.ai_base_url)
        self.ai_text_edit = QLineEdit(ctx.settings.ai_text_model)
        self.ai_image_edit = QLineEdit(ctx.settings.ai_image_model)
        self.temp_spin = QDoubleSpinBox()
        self.temp_spin.setRange(0.0, 2.0)
        self.temp_spin.setSingleStep(0.1)
        self.temp_spin.setValue(ctx.settings.ai_temperature)
        self.key_edit = QLineEdit()
        self.key_edit.setEchoMode(QLineEdit.Password)
        self.key_edit.setPlaceholderText(
            "کلید فقط در Windows Credential Manager ذخیره می‌شود و بازنمایی نمی‌شود")
        form.addRow("آدرس پایه:", self.ai_base_edit)
        form.addRow("مدل متن:", self.ai_text_edit)
        form.addRow("مدل تصویر (اختیاری):", self.ai_image_edit)
        form.addRow("دما (temperature):", self.temp_spin)
        form.addRow("کلید API جدید:", self.key_edit)
        lay.addLayout(form)
        self.store_label = QLabel("")
        self.store_label.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        lay.addWidget(self.store_label)
        btns = QHBoxLayout()
        save_ai = QPushButton("ذخیره پیکربندی AI")
        save_ai.setObjectName("primary")
        save_ai.clicked.connect(self._save_ai)
        clear_key = QPushButton("حذف کلید ذخیره‌شده")
        clear_key.setObjectName("danger")
        clear_key.clicked.connect(self._clear_key)
        btns.addWidget(save_ai)
        btns.addWidget(clear_key)
        btns.addStretch(1)
        lay.addLayout(btns)
        root.addWidget(card)

        # ---------------- انتشار و اخبار ----------------
        card, lay = _card("انتشار و اخبار")
        form = QFormLayout()
        self.auto_pub = QComboBox()
        self.auto_pub.addItem("خاموش (تأیید دستی الزامی)", False)
        self.auto_pub.addItem("روشن (پیش‌نویس‌های تأییدشده)", True)
        self.auto_pub.setCurrentIndex(1 if ctx.settings.auto_publish_enabled else 0)
        self.news_approval = QComboBox()
        self.news_approval.addItem("الزام تأیید دستی خبر (پیش‌فرض ایمن)", True)
        self.news_approval.addItem("بدون الزام تأیید", False)
        self.news_approval.setCurrentIndex(0 if ctx.settings.news_require_approval else 1)
        self.news_interval_spin = QSpinBox()
        self.news_interval_spin.setRange(300, 86400)
        self.news_interval_spin.setSingleStep(60)
        self.news_interval_spin.setValue(ctx.settings.news_refresh_sec)
        self.news_interval_spin.setSuffix(" ثانیه")
        form.addRow("انتشار خودکار AI:", self.auto_pub)
        form.addRow("الزام تأیید خبر:", self.news_approval)
        form.addRow("فاصله دریافت خودکار اخبار:", self.news_interval_spin)
        lay.addLayout(form)
        save_pub = QPushButton("ذخیره تنظیمات انتشار و اخبار")
        save_pub.clicked.connect(self._save_publish_news)
        lay.addWidget(save_pub)
        root.addWidget(card)

        # ---------------- داده و پشتیبان ----------------
        card, lay = _card("پایگاه داده و پشتیبان‌گیری")
        btns = QHBoxLayout()
        backup_btn = QPushButton("تهیه نسخه پشتیبان")
        backup_btn.clicked.connect(self._backup)
        cleanup_btn = QPushButton("پاک‌سازی داده‌های قدیمی")
        cleanup_btn.clicked.connect(self._cleanup)
        btns.addWidget(backup_btn)
        btns.addWidget(cleanup_btn)
        btns.addStretch(1)
        lay.addLayout(btns)
        from core.paths import get_backup_dir, get_data_dir
        db_note = QLabel(f"فایل دیتابیس: {ctx.db.db_path}\n"
                         f"دایرکتوری داده: {get_data_dir()}\n"
                         f"پشتیبان‌ها: {get_backup_dir()}")
        db_note.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        lay.addWidget(db_note)
        root.addWidget(card)
        root.addStretch(1)
        self._update_store_label()

    # ------------------------------------------------------------------
    def _update_store_label(self) -> None:
        store = self.ctx.secret_store
        kind = store.backend_name()
        if store.insecure:
            from security.secret_store import SECRETS_WARNING
            self.store_label.setText(f"بک‌اند رمزها: {kind} — {SECRETS_WARNING}")
            self.store_label.setStyleSheet("color: #f59e0b; font-size: 11px;")
        else:
            self.store_label.setText(f"بک‌اند رمزها: {kind} (امن)")

    def _save_general(self) -> None:
        self.ctx.settings.app_name = self.app_name_edit.text()
        try:
            self.ctx.settings.timezone = self.tz_combo.currentData()
        except MinerMediaError as exc:
            QMessageBox.warning(self, "تنظیمات", exc.user_message)
            return
        self.ctx.main_window.apply_app_name()
        QMessageBox.information(self, "تنظیمات", "ذخیره شد.")

    def _save_market(self) -> None:
        self.ctx.settings.market_refresh_sec = self.interval_spin.value()
        QMessageBox.information(self, "بازار",
                                "ذخیره شد؛ در چرخه بعدی Worker اعمال می‌شود.")

    def _save_publish_news(self) -> None:
        self.ctx.settings.auto_publish_enabled = self.auto_pub.currentData()
        self.ctx.settings.news_require_approval = self.news_approval.currentData()
        self.ctx.settings.news_refresh_sec = self.news_interval_spin.value()
        QMessageBox.information(
            self, "انتشار و اخبار",
            "ذخیره شد؛ فاصله جدید اخبار در چرخه بعدی Worker اعمال می‌شود.")

    def _save_ai(self) -> None:
        self.ctx.settings.ai_base_url = self.ai_base_edit.text()
        self.ctx.settings.ai_text_model = self.ai_text_edit.text()
        self.ctx.settings.ai_image_model = self.ai_image_edit.text()
        self.ctx.settings.ai_temperature = self.temp_spin.value()
        key = self.key_edit.text().strip()
        if key:
            self.ctx.secret_store.set_secret("ai.api_key", key)
            self.key_edit.clear()
        self.ctx.rebuild_ai_provider()
        QMessageBox.information(self, "هوش مصنوعی",
                                "پیکربندی ذخیره شد؛ کلید در بک‌اند امن ثبت شد.")
        self._update_store_label()

    def _clear_key(self) -> None:
        self.ctx.secret_store.delete_secret("ai.api_key")
        QMessageBox.information(self, "هوش مصنوعی", "کلید ذخیره‌شده حذف شد.")

    def _backup(self) -> None:
        from core.paths import get_backup_dir
        dest_base = get_backup_dir() / f"minermedia-backup-{QDateTime.currentDateTime().toString('yyyyMMdd-HHmmss')}.db"
        try:
            self.ctx.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            shutil.copy2(self.ctx.db.db_path, dest_base)
            QMessageBox.information(self, "پشتیبان‌گیری",
                                    f"نسخه پشتیبان ساخته شد:\n{dest_base}")
            self.ctx.logs_repo.add("INFO", "DB", f"پشتیبان ساخته شد: {dest_base.name}")
        except OSError as exc:
            QMessageBox.warning(self, "پشتیبان‌گیری",
                                f"کپی دیتابیس ناموفق بود: {exc}")

    def _cleanup(self) -> None:
        reply = QMessageBox.question(
            self, "پاک‌سازی",
            "لاگ‌ها، نمونه‌های قیمت و اخبار قدیمی‌تر از بازه نگهداری حذف شوند؟")
        if reply != QMessageBox.Yes:
            return
        ret = self.ctx.settings.retention_days
        n_logs = self.ctx.logs_repo.cleanup(ret["logs"])
        n_samples = self.ctx.market_repo.cleanup_samples(ret["samples"])
        n_news = self.ctx.news_repo.cleanup(ret["news"])
        QMessageBox.information(
            self, "پاک‌سازی",
            f"حذف شد — لاگ: {n_logs} | نمونه قیمت: {n_samples} | خبر: {n_news}")
        self.ctx.logs_repo.add("INFO", "DB",
                               f"پاک‌سازی: لاگ {n_logs}، نمونه {n_samples}، خبر {n_news}")
