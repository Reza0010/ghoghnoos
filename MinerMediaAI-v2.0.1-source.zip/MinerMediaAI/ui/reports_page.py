"""صفحه گزارش‌ها و آمار — همه داده‌ها از SQL واقعی."""
from __future__ import annotations

from PySide6.QtWidgets import (QComboBox, QFrame, QLabel, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget)

from core.timeutils import format_local
from ui.widgets import BarChart, SectionHeader


class ReportsPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        head = SectionHeader("گزارش‌ها و آمار")
        self.days_combo = QComboBox()
        for d in (7, 14, 30, 90):
            self.days_combo.addItem(f"{d} روز اخیر", d)
        self.days_combo.currentIndexChanged.connect(self.refresh)
        head.layout().addWidget(QLabel("بازه:"))
        head.layout().addWidget(self.days_combo)
        root.addWidget(head)

        self.chart = BarChart()
        root.addWidget(self.chart)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["کانال", "منتشرشده (بازه)", "ناموفق (کل)", "نامشخص (کل)", "آخرین انتشار"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        root.addWidget(self.table, 1)

        gen_box, gen_lay = _card("تاریخچه تولید محتوا (AI)")
        self.gen_table = QTableWidget(0, 5)
        self.gen_table.setHorizontalHeaderLabels(
            ["زمان", "دسته", "نوع", "مدل", "نتیجه"])
        self.gen_table.verticalHeader().setVisible(False)
        self.gen_table.setEditTriggers(QTableWidget.NoEditTriggers)
        gen_lay.addWidget(self.gen_table)
        root.addWidget(gen_box, 1)
        self.refresh()

    def refresh(self) -> None:
        days = self.days_combo.currentData() or 14
        # نمودار روزانه (بر اساس UTC day؛ نمایش روز محلی)
        per_day = self.ctx.posts_repo.published_per_day(days)
        self.chart.set_data(per_day, f"انتشار روزانه ({days} روز اخیر)")

        # جدول کانال‌ها
        channels = self.ctx.channels_repo.list()
        self.table.setRowCount(len(channels))
        for r, ch in enumerate(channels):
            pub = self.ctx.db.query_one(
                "SELECT COUNT(*) AS n FROM published_messages WHERE channel_id=? "
                "AND sent_at >= datetime('now', ?)", (ch.id, f"-{int(days)} days"))
            failed = self.ctx.db.query_one(
                "SELECT COUNT(*) AS n FROM scheduled_posts WHERE channel_id=? "
                "AND status='failed'", (ch.id,))
            unknown = self.ctx.db.query_one(
                "SELECT COUNT(*) AS n FROM scheduled_posts WHERE channel_id=? "
                "AND status='unknown'", (ch.id,))
            last = self.ctx.db.query_one(
                "SELECT MAX(sent_at) AS ts FROM published_messages WHERE channel_id=?",
                (ch.id,))
            self.table.setItem(r, 0, QTableWidgetItem(ch.display_name))
            self.table.setItem(r, 1, QTableWidgetItem(str(int(pub["n"]))))
            self.table.setItem(r, 2, QTableWidgetItem(str(int(failed["n"]))))
            self.table.setItem(r, 3, QTableWidgetItem(str(int(unknown["n"]))))
            self.table.setItem(r, 4, QTableWidgetItem(
                format_local(last["ts"], self.ctx.settings.timezone)
                if last and last["ts"] else "—"))
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)

        # تاریخچه تولید
        rows = self.ctx.db.query(
            "SELECT g.created_at, g.category, g.ctype, g.model, g.ok, g.error "
            "FROM generation_history g ORDER BY g.created_at DESC LIMIT 50")
        self.gen_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            self.gen_table.setItem(r, 0, QTableWidgetItem(
                format_local(row["created_at"], self.ctx.settings.timezone)))
            self.gen_table.setItem(r, 1, QTableWidgetItem(row["category"]))
            self.gen_table.setItem(r, 2, QTableWidgetItem(row["ctype"]))
            self.gen_table.setItem(r, 3, QTableWidgetItem(row["model"]))
            self.gen_table.setItem(r, 4, QTableWidgetItem(
                "موفق" if row["ok"] else f"خطا: {row['error'][:60]}"))
        self.gen_table.resizeColumnsToContents()
        self.gen_table.horizontalHeader().setStretchLastSection(True)


def _card(title: str):
    frame = QFrame()
    frame.setObjectName("Card")
    lay = QVBoxLayout(frame)
    lay.setContentsMargins(14, 12, 14, 12)
    t = QLabel(title)
    t.setObjectName("h2")
    lay.addWidget(t)
    return frame, lay
