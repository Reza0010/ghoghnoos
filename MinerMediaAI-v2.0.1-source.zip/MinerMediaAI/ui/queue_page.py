"""صفحه تقویم و صف انتشار — جدول وضعیت‌ها + اقدامات امن."""
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import QDateTime, Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDateEdit, QDialog,
                               QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPushButton, QTableWidget,
                               QTableWidgetItem, QTextEdit, QTimeEdit,
                               QVBoxLayout, QWidget)

from config import defaults as cfg
from core.errors import MinerMediaError
from core.timeutils import format_local, parse_iso, utc_iso
from models.entities import PostStatus
from services.telegram.client import detect_kind
from services.telegram.media import validate_media_for_send
from ui.theme import TEXT_DIM
from ui.widgets import SectionHeader, StatusPill

ALL = "همه"

# نقشه نوع محتوا → endpoint کلاینت (برای اعتبارسنجی واقعی قبل از زمان‌بندی)
VALIDATE_ENDPOINT = {"photo": "sendPhoto", "video": "sendVideo",
                     "audio": "sendAudio", "document": "sendDocument"}


class NewPostDialog(QDialog):
    """پست دستی: متن/رسانه/آلبوم + انتخاب چند کانال + زمان‌بندی با منطقه زمانی.

    اعتبارسنجی کامل قبل از زمان‌بندی (مأموریت ۵):
    - وجود فایل، پسوند مجاز، حجم مجاز — با همان اعتبارسنجی لایه ارسال
    - کپشن بلند: یا پذیرش صریح «ارسال متن به‌صورت پیام جداگانه» یا رد شدن
    - آلبوم: ۲ تا ۱۰ فایل عکس/ویدیو
    هیچ متن یا رسانه‌ای بی‌صدا حذف نمی‌شود.
    """

    def __init__(self, parent, ctx):
        super().__init__(parent)
        self.ctx = ctx
        self.album_paths: list[str] = []
        self.setWindowTitle("پست جدید / زمان‌بندی")
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)

        form = QFormLayout()
        self.body_edit = QTextEdit()
        self.body_edit.setPlaceholderText("متن پست (حداکثر ۴۰۹۶ کاراکتر)؛ "
                                          "برای رسانه همان کپشن است")
        self.type_combo = QComboBox()
        self.type_combo.addItem("متن ساده", "text")
        self.type_combo.addItem("عکس + کپشن", "photo")
        self.type_combo.addItem("ویدیو + کپشن", "video")
        self.type_combo.addItem("صوت + کپشن", "audio")
        self.type_combo.addItem("فایل + کپشن", "document")
        self.type_combo.addItem("آلبوم (۲ تا ۱۰ عکس/ویدیو)", "album")
        self.type_combo.currentIndexChanged.connect(self._type_changed)
        self.media_edit = QLineEdit()
        self.media_edit.setReadOnly(True)
        self.media_edit.setPlaceholderText("فایل رسانه انتخاب نشده")
        browse = QPushButton("انتخاب فایل")
        browse.clicked.connect(self._browse)
        self.split_check = QCheckBox(
            "اگر متن از سقف کپشن (۱۰۲۴) گذشت، کل متن به‌صورت پیام جداگانه ارسال شود")
        self.split_check.setToolTip(
            "اگر فعال نباشد و متن بلندتر از سقف کپشن باشد، زمان‌بندی رد می‌شود "
            "— هیچ متنی بی‌صدا حذف نمی‌شود.")
        self.tz_combo = QComboBox()
        for tz in ("Asia/Tehran", "UTC", "Europe/Berlin", "Asia/Dubai"):
            self.tz_combo.addItem(tz, tz)
        self.tz_combo.setCurrentText(ctx.settings.timezone)
        self.date_edit = QDateEdit(QDateTime.currentDateTime().date())
        self.date_edit.setCalendarPopup(True)
        self.time_edit = QTimeEdit(QDateTime.currentDateTime().addSecs(300).time())
        form.addRow("نوع:", self.type_combo)
        form.addRow("فایل رسانه:", self._row(self.media_edit, browse))
        form.addRow("متن / کپشن:", self.body_edit)
        form.addRow("", self.split_check)
        form.addRow("منطقه زمانی:", self.tz_combo)
        form.addRow("تاریخ انتشار:", self.date_edit)
        form.addRow("ساعت انتشار:", self.time_edit)
        lay.addLayout(form)

        self.channels_box = QWidget()
        ch_lay = QVBoxLayout(self.channels_box)
        ch_lay.setContentsMargins(0, 4, 0, 4)
        ch_lay.addWidget(QLabel("کانال‌های هدف (انتخاب چندگانه مجاز است):"))
        self.channel_checks: list[tuple[int, QCheckBox]] = []
        for ch in ctx.channels_repo.list(include_disabled=False):
            cb = QCheckBox(f"{ch.display_name} — {ch.chat_id}")
            cb.setChecked(True)
            ch_lay.addWidget(cb)
            self.channel_checks.append((ch.id, cb))
        lay.addWidget(self.channels_box)

        self.note_label = QLabel("")
        self.note_label.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        lay.addWidget(self.note_label)

        btns = QHBoxLayout()
        submit = QPushButton("افزودن به صف")
        submit.setObjectName("primary")
        cancel = QPushButton("انصراف")
        submit.clicked.connect(self._submit)
        cancel.clicked.connect(self.reject)
        btns.addStretch(1)
        btns.addWidget(cancel)
        btns.addWidget(submit)
        lay.addLayout(btns)

    @staticmethod
    def _row(left, right) -> QWidget:
        w = QWidget()
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(left, 1)
        lay.addWidget(right)
        return w

    def _type_changed(self) -> None:
        ctype = self.type_combo.currentData()
        is_media = ctype != "text"
        self.media_edit.setEnabled(is_media)
        self.split_check.setEnabled(is_media)
        if not is_media:
            self.media_edit.clear()
            self.album_paths = []
            self.media_edit.setText("")

    def _browse(self) -> None:
        from PySide6.QtWidgets import QFileDialog
        if self.type_combo.currentData() == "album":
            paths, _ = QFileDialog.getOpenFileNames(
                self, "انتخاب فایل‌های آلبوم (۲ تا ۱۰ عکس/ویدیو)")
            if paths:
                self.album_paths = paths
                self.media_edit.setText(f"{len(paths)} فایل انتخاب شد")
            return
        path, _ = QFileDialog.getOpenFileName(self, "انتخاب فایل رسانه")
        if path:
            self.album_paths = []
            self.media_edit.setText(path)

    # ------------------------- اعتبارسنجی -------------------------
    def _validate(self) -> tuple[str, str, bool]:
        """خروجی: (content_type, media_path، split) — یا MinerMediaError."""
        body = self.body_edit.toPlainText().strip()
        ctype = self.type_combo.currentData()
        media = self.media_edit.text().strip()
        if not body and not media:
            raise MinerMediaError("empty post", "متن یا فایل رسانه لازم است.")
        if len(body) > cfg.MAX_TEXT_LEN:
            raise MinerMediaError(
                "too long", f"متن حداکثر {cfg.MAX_TEXT_LEN} کاراکتر است.")
        split = self.split_check.isChecked()
        if ctype == "text":
            if media and self.album_paths:
                # کاربر فایل کرده ولی نوع متن است → رسانه‌ای امن‌ترین تفسیر:
                if len(self.album_paths) >= 2:
                    ctype = "album"
                else:
                    ctype = "document"
            elif media and self.media_edit.isEnabled() is False:
                media = ""
            else:
                return "text", "", False
        if ctype != "text":
            if not media:
                raise MinerMediaError("no media", "فایل رسانه انتخاب نشده است.")
            if ctype == "album":
                paths = self.album_paths or []
                if not 2 <= len(paths) <= cfg.MAX_ALBUM_ITEMS:
                    raise MinerMediaError(
                        f"album size {len(paths)}",
                        f"آلبوم باید بین ۲ تا {cfg.MAX_ALBUM_ITEMS} فایل باشد.")
                for p in paths:
                    # اعتبارسنجی واقعی: وجود + پسوند عکس/ویدیو + حجم مجاز
                    validate_media_for_send(p, "album")
                items = [{"type": detect_kind(p), "path": str(Path(p).resolve())}
                         for p in paths]
                media = json.dumps(items, ensure_ascii=False)
            else:
                # اعتبارسنجی واقعی قبل از زمان‌بندی: وجود فایل، پسوند، حجم
                validate_media_for_send(media, VALIDATE_ENDPOINT[ctype])
                media = str(Path(media).resolve())
            # سیاست صریح کپشن بلند — قبل از زمان‌بندی، نه در لحظه ارسال
            if len(body) > cfg.MAX_CAPTION_LEN and not split:
                raise MinerMediaError(
                    "caption policy",
                    f"متن رسانه {len(body)} کاراکتر است و سقف کپشن "
                    f"({cfg.MAX_CAPTION_LEN}) را رد می‌کند. گزینهٔ «ارسال متن "
                    "به‌صورت پیام جداگانه» را فعال کنید یا متن را کوتاه کنید — "
                    "هیچ متنی بی‌صدا حذف نمی‌شود.")
        return ctype, media, split

    def _submit(self) -> None:
        try:
            ctype, media, split = self._validate()
            body = self.body_edit.toPlainText().strip()
            scheduled = utc_iso(__import__(
                "core.timeutils", fromlist=["parse_user_datetime"]
            ).parse_user_datetime(
                self.date_edit.date().toString("yyyy-MM-dd"),
                self.time_edit.time().toString("HH:mm"),
                self.tz_combo.currentData()))
            targets = [cid for cid, cb in self.channel_checks if cb.isChecked()]
            if not targets:
                raise MinerMediaError("no channel", "حداقل یک کانال انتخاب کنید.")
            posts = [{"channel_id": cid, "content_type": ctype, "body": body,
                      "media_path": media,
                      "scheduled_at_utc": scheduled,
                      "timezone_name": self.tz_combo.currentData(),
                      "source": "manual",
                      "split_long_text": split} for cid in targets]
            self.ctx.posts_repo.create_group(posts)
            self.ctx.logs_repo.add(
                "INFO", "QUEUE",
                f"پست دستی جدید ({ctype}) برای {len(targets)} کانال ثبت شد.")
            self.accept()
        except MinerMediaError as exc:
            self.note_label.setText(exc.user_message)


class QueuePage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        head = SectionHeader("صف انتشار و زمان‌بندی")
        new_btn = QPushButton(" پست جدید")
        new_btn.setObjectName("primary")
        from ui.icons import icon
        new_btn.setIcon(icon("plus", 16, "#14100a"))
        new_btn.clicked.connect(self._new_post)
        pause_btn = QPushButton(" توقف/ادامه زمان‌بند")
        pause_btn.clicked.connect(self._toggle_pause)
        refresh_btn = QPushButton("بازخوانی")
        refresh_btn.clicked.connect(self.refresh)
        for b in (new_btn, pause_btn, refresh_btn):
            head.layout().addWidget(b)
        root.addWidget(head)

        filters = QHBoxLayout()
        self.status_filter = QComboBox()
        self.status_filter.addItem(ALL, None)
        for st in PostStatus:
            self.status_filter.addItem(st.value, st.value)
        self.channel_filter = QComboBox()
        self.channel_filter.addItem(ALL, None)
        self.status_filter.currentIndexChanged.connect(self.refresh)
        self.channel_filter.currentIndexChanged.connect(self.refresh)
        filters.addWidget(QLabel("وضعیت:"))
        filters.addWidget(self.status_filter)
        filters.addWidget(QLabel("کانال:"))
        filters.addWidget(self.channel_filter)
        filters.addStretch(1)
        root.addLayout(filters)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            ["شناسه", "کانال", "نوع", "پیش‌نمایش", "زمان انتشار", "وضعیت",
             "تلاش", "عملیات"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        root.addWidget(self.table, 1)
        self._paused = False
        self.refresh()

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        # فیلتر کانال (بار اول پر می‌شود)
        channels = self.ctx.channels_repo.list()
        current = self.channel_filter.currentData()
        self.channel_filter.blockSignals(True)
        self.channel_filter.clear()
        self.channel_filter.addItem(ALL, None)
        for ch in channels:
            self.channel_filter.addItem(ch.display_name, ch.id)
        if current is not None:
            idx = self.channel_filter.findData(current)
            if idx >= 0:
                self.channel_filter.setCurrentIndex(idx)
        self.channel_filter.blockSignals(False)

        posts = self.ctx.posts_repo.list(
            status=self.status_filter.currentData(),
            channel_id=self.channel_filter.currentData(), limit=300)
        tz = self.ctx.settings.timezone
        self.table.setRowCount(len(posts))
        for r, p in enumerate(posts):
            self.table.setItem(r, 0, QTableWidgetItem(str(p.id)))
            self.table.setItem(r, 1, QTableWidgetItem(p.channel_name))
            self.table.setItem(r, 2, QTableWidgetItem(p.content_type))
            self.table.setItem(r, 3, QTableWidgetItem(self._preview(p)))
            self.table.setItem(r, 4, QTableWidgetItem(
                format_local(p.scheduled_at, tz) + f" ({p.timezone})"))
            self.table.setCellWidget(r, 5, StatusPill(p.status))
            self.table.setItem(r, 6, QTableWidgetItem(f"{p.attempts}/{p.max_attempts}"))
            ops = QWidget()
            lay = QHBoxLayout(ops)
            lay.setContentsMargins(2, 2, 2, 2)
            if p.status in ("pending", "draft", "failed", "unknown"):
                cancel_btn = QPushButton("لغو")
                cancel_btn.setObjectName("danger")
                cancel_btn.clicked.connect(lambda _=False, pid=p.id: self._cancel(pid))
                lay.addWidget(cancel_btn)
            if p.status == "unknown":
                mark_btn = QPushButton("علامت: منتشر شد")
                mark_btn.clicked.connect(lambda _=False, pid=p.id: self._mark_sent(pid))
                lay.addWidget(mark_btn)
                redo_btn = QPushButton("ارسال دوباره")
                redo_btn.setToolTip("خطر ارسال تکراری؛ فقط اگر مطمئنید ارسال نشده است.")
                redo_btn.setObjectName("danger")
                redo_btn.clicked.connect(lambda _=False, pid=p.id: self._resend(pid))
                lay.addWidget(redo_btn)
            if p.status == "failed":
                retry_btn = QPushButton("به صف برگرداندن")
                retry_btn.clicked.connect(lambda _=False, pid=p.id: self._requeue(pid))
                lay.addWidget(retry_btn)
            self.table.setCellWidget(r, 7, ops)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setStretchLastSection(True)

    @staticmethod
    def _preview(p) -> str:
        """پیش‌نمایش خوانا — آلبوم JSON نمایش خام نمی‌گیرد."""
        if p.content_type == "album":
            try:
                items = json.loads(p.media_path) if p.media_path else []
                return f"آلبوم ({len(items)} رسانه) {p.body[:40]}".strip()
            except ValueError:
                return "آلبوم (فهرست نامعتبر)"
        text = p.body or Path(p.media_path).name
        return text[:60]

    def _new_post(self) -> None:
        dlg = NewPostDialog(self, self.ctx)
        if dlg.exec():
            self.refresh()

    def _toggle_pause(self) -> None:
        self._paused = not self._paused
        if self._paused:
            self.ctx.scheduler.pause()
            self.ctx.logs_repo.add("WARNING", "SCHEDULER", "زمان‌بند متوقف شد.")
        else:
            self.ctx.scheduler.resume()
            self.ctx.logs_repo.add("INFO", "SCHEDULER", "زمان‌بند ادامه یافت.")
        self.refresh()

    def _cancel(self, post_id: int) -> None:
        if self.ctx.posts_repo.cancel(post_id):
            self.ctx.logs_repo.add("INFO", "QUEUE", f"پست {post_id} لغو شد.")
            self.refresh()

    def _mark_sent(self, post_id: int) -> None:
        """کاربر در تلگرام تأیید کرده که پیام ارسال شده است."""
        self.ctx.posts_repo.mark_sent(post_id, None)
        self.ctx.logs_repo.add(
            "INFO", "QUEUE",
            f"پست {post_id} به‌صورت دستی «منتشرشده» علامت خورد.")
        self.refresh()

    def _resend(self, post_id: int) -> None:
        reply = QMessageBox.warning(
            self, "ارسال دوباره",
            "نتیجه ارسال قبلی نامشخص بوده است. اگر پیام قبلاً منتشر شده باشد، "
            "ارسال دوباره باعث «تکرار پست» می‌شود. ادامه می‌دهید؟",
            QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.ctx.posts_repo.set_status(post_id, "pending")
            self.ctx.posts_repo.reschedule(post_id, utc_iso())
            self.ctx.logs_repo.add("WARNING", "QUEUE",
                                   f"پست {post_id} با تأیید کاربر برای ارسال دوباره "
                                   "صف شد (خطر تکرار پذیرفته شد).")
            self.refresh()

    def _requeue(self, post_id: int) -> None:
        post = self.ctx.posts_repo.get(post_id)
        if post:
            self.ctx.posts_repo.set_status(post_id, "pending")
            self.ctx.posts_repo.schedule_retry(post_id, 5, "بازگشت دستی به صف")
            self.refresh()
