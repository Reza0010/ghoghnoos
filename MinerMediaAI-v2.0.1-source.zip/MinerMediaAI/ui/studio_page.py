"""استودیوی تولید محتوای AI — گردش کار کامل با تأیید دستی."""
from __future__ import annotations

import json

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFormLayout,
                               QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QSplitter, QTableWidget,
                               QTableWidgetItem, QTextBrowser, QTextEdit,
                               QVBoxLayout, QWidget)

from config import defaults as cfg
from core.errors import MinerMediaError
from core.timeutils import format_local
from ui.theme import DANGER, TEXT_DIM, WARNING
from ui.widgets import SectionHeader, StatusPill


class GenerateWorker(QThread):
    done = Signal(int)              # draft_id
    failed = Signal(str)

    def __init__(self, ctx, category: str, ctype: str, brief: str,
                 use_market: bool):
        super().__init__()
        self.ctx, self.category, self.ctype = ctx, category, ctype
        self.brief, self.use_market = brief, use_market

    def run(self) -> None:
        try:
            draft = self.ctx.studio.generate(
                self.category, self.ctype, self.brief,
                use_market_data=self.use_market)
            self.done.emit(draft.id)
        except MinerMediaError as exc:
            self.failed.emit(exc.user_message)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(f"خطای غیرمنتظره: {type(exc).__name__}")


class ScheduleDialog(QDialog):
    """زمان‌بندی پیش‌نویس تأییدشده برای یک یا چند کانال."""

    def __init__(self, parent, ctx, draft):
        super().__init__(parent)
        self.ctx, self.draft = ctx, draft
        self.setWindowTitle("زمان‌بندی انتشار")
        self.setMinimumWidth(460)
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.date_edit = _DateEdit()
        self.time_edit = _TimeEdit()
        self.tz_combo = QComboBox()
        for tz in ("Asia/Tehran", "UTC"):
            self.tz_combo.addItem(tz, tz)
        self.tz_combo.setCurrentText(ctx.settings.timezone)
        form.addRow("تاریخ:", self.date_edit)
        form.addRow("ساعت:", self.time_edit)
        form.addRow("منطقه زمانی:", self.tz_combo)
        lay.addLayout(form)
        lay.addWidget(QLabel("کانال‌های هدف:"))
        self.channel_checks = []
        for ch in ctx.channels_repo.list(include_disabled=False):
            from PySide6.QtWidgets import QCheckBox
            cb = QCheckBox(f"{ch.display_name} — {ch.chat_id}")
            lay.addWidget(cb)
            self.channel_checks.append((ch.id, cb))
        self.err_label = QLabel("")
        self.err_label.setStyleSheet(f"color: {DANGER}; font-size: 11px;")
        lay.addWidget(self.err_label)
        btns = QHBoxLayout()
        ok = QPushButton("ثبت در صف")
        ok.setObjectName("primary")
        cancel = QPushButton("انصراف")
        ok.clicked.connect(self._ok)
        cancel.clicked.connect(self.reject)
        btns.addStretch(1)
        btns.addWidget(cancel)
        btns.addWidget(ok)
        lay.addLayout(btns)

    def _ok(self) -> None:
        import core.timeutils as tu
        targets = [cid for cid, cb in self.channel_checks if cb.isChecked()]
        if not targets:
            self.err_label.setText("حداقل یک کانال انتخاب کنید.")
            return
        try:
            scheduled = tu.utc_iso(tu.parse_user_datetime(
                self.date_edit.date().toString("yyyy-MM-dd"),
                self.time_edit.time().toString("HH:mm"),
                self.tz_combo.currentData()))
        except ValueError:
            self.err_label.setText("تاریخ/ساعت نامعتبر است.")
            return
        is_media = bool(self.draft.media_path)
        ctype = "photo" if is_media else "text"
        posts = [{"channel_id": cid, "content_type": ctype,
                  "body": self.draft.body + (f"\n\n{self.draft.hashtags}".strip()),
                  "media_path": self.draft.media_path,
                  "scheduled_at_utc": scheduled,
                  "timezone_name": self.tz_combo.currentData(),
                  "source": "studio"} for cid in targets]
        self.ctx.posts_repo.create_group(posts)
        self.ctx.drafts_repo.set_status(self.draft.id, "scheduled")
        self.ctx.logs_repo.add("INFO", "STUDIO",
                               f"پیش‌نویس {self.draft.id} برای {len(targets)} کانال "
                               "زمان‌بندی شد.")
        self.accept()


def _DateEdit():
    from PySide6.QtCore import QDateTime
    from PySide6.QtWidgets import QDateEdit
    de = QDateEdit(QDateTime.currentDateTime().date())
    de.setCalendarPopup(True)
    return de


def _TimeEdit():
    from PySide6.QtCore import QDateTime, QTime
    from PySide6.QtWidgets import QTimeEdit
    return QTimeEdit(QTime.currentTime().addSecs(600))


class StudioPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self._worker = None
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.addWidget(SectionHeader("استودیوی تولید محتوا"))

        top = QHBoxLayout()
        form = QFormLayout()
        self.cat_combo = QComboBox()
        for cid, title in cfg.CONTENT_CATEGORIES:
            self.cat_combo.addItem(title, cid)
        self.type_combo = QComboBox()
        for tid, title in cfg.CONTENT_TYPES:
            self.type_combo.addItem(title, tid)
        self.brief_edit = QLineEdit()
        self.brief_edit.setPlaceholderText(
            "موضوع/خواسته خاص (مثلاً: عیب‌یابی خطای.temperature در هش‌برد)")
        self.market_check = QCheckBox("استفاده از قیمت‌های واقعی نوبیتکس")
        self.market_check.setChecked(True)
        form.addRow("دسته محتوا:", self.cat_combo)
        form.addRow("نوع محتوا:", self.type_combo)
        form.addRow("خواسته:", self.brief_edit)
        form.addRow("", self.market_check)
        top.addLayout(form, 2)
        side = QVBoxLayout()
        self.gen_btn = QPushButton(" تولید پیش‌نویس")
        self.gen_btn.setObjectName("primary")
        from ui.icons import icon
        self.gen_btn.setIcon(icon("studio", 18, "#14100a"))
        self.gen_btn.clicked.connect(self._generate)
        self.status_pill = StatusPill("missing")
        self.ai_hint = QLabel("")
        self.ai_hint.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        self.ai_hint.setWordWrap(True)
        side.addWidget(self.gen_btn)
        side.addWidget(self.status_pill)
        side.addWidget(self.ai_hint)
        side.addStretch(1)
        top.addLayout(side, 1)
        root.addLayout(top)

        split = QSplitter(Qt.Horizontal)
        left = QWidget()
        left_lay = QVBoxLayout(left)
        left_lay.setContentsMargins(0, 0, 0, 0)
        left_lay.addWidget(QLabel("پیش‌نویس‌ها:"))
        self.drafts_table = QTableWidget(0, 4)
        self.drafts_table.setHorizontalHeaderLabels(
            ["شناسه", "دسته", "عنوان", "وضعیت"])
        self.drafts_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.drafts_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.drafts_table.verticalHeader().setVisible(False)
        self.drafts_table.clicked.connect(self._on_select)
        left_lay.addWidget(self.drafts_table)
        split.addWidget(left)

        right = QWidget()
        right_lay = QVBoxLayout(right)
        right_lay.setContentsMargins(0, 0, 0, 0)
        right_lay.addWidget(QLabel("ویرایش پیش‌نویس:"))
        self.title_edit = QLineEdit()
        self.body_edit = QTextEdit()
        self.meta_label = QLabel("")
        self.meta_label.setWordWrap(True)
        self.meta_label.setStyleSheet(f"color: {WARNING}; font-size: 11px;")
        right_lay.addWidget(QLabel("عنوان:"))
        right_lay.addWidget(self.title_edit)
        right_lay.addWidget(self.meta_label)
        right_lay.addWidget(QLabel("متن پست:"))
        right_lay.addWidget(self.body_edit, 1)
        btns = QHBoxLayout()
        self.save_btn = QPushButton("ذخیره")
        self.save_btn.clicked.connect(self._save)
        self.approve_btn = QPushButton(" تأیید نهایی")
        self.approve_btn.setObjectName("primary")
        self.approve_btn.setIcon(icon("check", 16, "#14100a"))
        self.approve_btn.clicked.connect(self._approve)
        self.schedule_btn = QPushButton(" زمان‌بندی انتشار")
        self.schedule_btn.clicked.connect(self._schedule)
        self.reject_btn = QPushButton("رد")
        self.reject_btn.setObjectName("danger")
        self.reject_btn.clicked.connect(self._reject)
        self.preview_btn = QPushButton("پیش‌نمایش")
        self.preview_btn.clicked.connect(self._preview)
        for b in (self.save_btn, self.approve_btn, self.schedule_btn,
                  self.preview_btn, self.reject_btn):
            btns.addWidget(b)
        right_lay.addLayout(btns)
        split.addWidget(right)
        split.setSizes([420, 620])
        root.addWidget(split, 1)
        self.current_draft = None
        self.refresh()

    # ------------------------------------------------------------------
    def refresh(self) -> None:
        drafts = self.ctx.drafts_repo.list(limit=100)
        self.drafts_table.setRowCount(len(drafts))
        for r, d in enumerate(drafts):
            self.drafts_table.setItem(r, 0, QTableWidgetItem(str(d.id)))
            cat = dict(cfg.CONTENT_CATEGORIES).get(d.category, d.category)
            self.drafts_table.setItem(r, 1, QTableWidgetItem(cat))
            self.drafts_table.setItem(r, 2, QTableWidgetItem(d.title[:70]))
            self.drafts_table.setCellWidget(r, 3, StatusPill(d.status))
        self.drafts_table.resizeColumnsToContents()
        self.drafts_table.horizontalHeader().setStretchLastSection(True)
        configured = self.ctx.ai_provider.configured
        self.ai_hint.setText(
            "سرویس AI پیکربندی شده است." if configured else
            "سرویس AI پیکربندی نشده — از صفحه تنظیمات، آدرس پایه، مدل و کلید "
            "API را وارد کنید.")
        self.gen_btn.setEnabled(configured)

    def _generate(self) -> None:
        if self._worker and self._worker.isRunning():
            return
        self.status_pill.set_status("loading", "در حال تولید…")
        self.gen_btn.setEnabled(False)
        self._worker = GenerateWorker(
            self.ctx, self.cat_combo.currentData(),
            self.type_combo.currentData(), self.brief_edit.text().strip(),
            self.market_check.isChecked())
        self._worker.done.connect(self._on_generated)
        self._worker.failed.connect(self._on_failed)
        self._worker.start()

    def _on_generated(self, draft_id: int) -> None:
        self.gen_btn.setEnabled(True)
        self.status_pill.set_status("ok", "تولید شد")
        self.ctx.logs_repo.add("INFO", "STUDIO", f"پیش‌نویس {draft_id} تولید شد.")
        self.refresh()

    def _on_failed(self, msg: str) -> None:
        self.gen_btn.setEnabled(self.ctx.ai_provider.configured)
        self.status_pill.set_status("error", "خطا")
        QMessageBox.warning(self, "تولید محتوا", msg)

    def _on_select(self, index) -> None:
        draft = self.ctx.drafts_repo.get(int(
            self.drafts_table.item(index.row(), 0).text()))
        if not draft:
            return
        self.current_draft = draft
        self.title_edit.setText(draft.title)
        self.body_edit.setPlainText(draft.body)
        try:
            meta = json.loads(draft.meta or "{}")
        except ValueError:
            meta = {}
        notes = meta.get("uncertainty_notes", [])
        warn = []
        if meta.get("needs_technical_check"):
            warn.append("این محتوا نیازمند بررسی فنی است.")
        warn.extend(notes)
        if meta.get("market_data_used"):
            warn.append("قیمت‌ها از داده واقعی نوبیتکس در زمان تولید تزریق شده‌اند.")
        self.meta_label.setText(" | ".join(warn))

    def _save(self) -> None:
        if not self.current_draft:
            return
        self.ctx.drafts_repo.update(
            self.current_draft.id, title=self.title_edit.text().strip(),
            body=self.body_edit.toPlainText())
        self.ctx.logs_repo.add("INFO", "STUDIO",
                               f"پیش‌نویس {self.current_draft.id} ویرایش شد.")
        self.refresh()

    def _approve(self) -> None:
        if not self.current_draft:
            QMessageBox.information(self, "پیش‌نویس", "ابتدا یک پیش‌نویس انتخاب کنید.")
            return
        self._save()
        self.ctx.drafts_repo.set_status(self.current_draft.id, "approved")
        self.refresh()

    def _reject(self) -> None:
        if not self.current_draft:
            return
        self.ctx.drafts_repo.set_status(self.current_draft.id, "rejected")
        self.refresh()

    def _schedule(self) -> None:
        if not self.current_draft:
            QMessageBox.information(self, "پیش‌نویس", "ابتدا یک پیش‌نویس انتخاب کنید.")
            return
        if self.current_draft.status != "approved":
            QMessageBox.information(
                self, "تأیید لازم",
                "پیش‌نویس باید ابتدا «تأیید نهایی» شود؛ انتشار خودکار "
                "پیش‌فرض خاموش است.")
            return
        self._save()
        dlg = ScheduleDialog(self, self.ctx, self.current_draft)
        if dlg.exec():
            self.refresh()

    def _preview(self) -> None:
        if not self.current_draft:
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("پیش‌نمایش پست")
        lay = QVBoxLayout(dlg)
        browser = QTextBrowser()
        text = f"<h3>{self.title_edit.text()}</h3>" + \
            self.body_edit.toPlainText().replace("\n", "<br>")
        browser.setHtml(text)
        lay.addWidget(browser)
        dlg.resize(480, 520)
        dlg.exec()
