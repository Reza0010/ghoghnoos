"""صفحه کتابخانه رسانه — افزودن امن فایل‌ها با اعتبارسنجی محدودیت Bot API."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox,
                               QPushButton, QVBoxLayout, QWidget)

from core.errors import MinerMediaError
from ui.theme import TEXT_DIM
from ui.widgets import SectionHeader

KIND_LABELS = {"photo": "عکس", "video": "ویدیو", "audio": "صدا",
               "document": "فایل"}
SIZE_LIMITS = {"photo": 10, "video": 50, "audio": 50, "document": 50}


class MediaPage(QWidget):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        head = SectionHeader("کتابخانه رسانه")
        add_btn = QPushButton(" افزودن فایل")
        add_btn.setObjectName("primary")
        from ui.icons import icon
        add_btn.setIcon(icon("upload", 16, "#14100a"))
        add_btn.clicked.connect(self._add_file)
        scan_btn = QPushButton("ایندکس پوشه رسانه")
        scan_btn.clicked.connect(self._scan)
        head.layout().addWidget(scan_btn)
        head.layout().addWidget(add_btn)
        root.addWidget(head)

        info = QLabel(
            "محدودیت‌های واقعی Bot API: عکس حداکثر ۱۰MB (JPG/PNG/WEBP)؛ "
            "ویدیو/فایل/صدا حداکثر ۵۰MB. فایل‌های بزرگ‌تر پذیرفته نمی‌شوند.")
        info.setWordWrap(True)
        info.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        root.addWidget(info)

        self.list = QListWidget()
        self.list.setSelectionMode(QListWidget.ExtendedSelection)
        root.addWidget(self.list, 1)
        ops = QHBoxLayout()
        del_btn = QPushButton(" حذف انتخاب‌شده‌ها")
        del_btn.setObjectName("danger")
        del_btn.clicked.connect(self._delete_selected)
        ops.addWidget(del_btn)
        ops.addStretch(1)
        self.count_label = QLabel("")
        self.count_label.setStyleSheet(f"color: {TEXT_DIM};")
        ops.addWidget(self.count_label)
        root.addLayout(ops)
        self.refresh()

    def refresh(self) -> None:
        assets = self.ctx.media_service.list()
        self.list.clear()
        for a in assets:
            exists = Path(a.path).exists()
            note = "" if exists else "  [فایل روی دیسک یافت نشد]"
            item = QListWidgetItem(
                f"{a.filename}  |  {KIND_LABELS.get(a.kind, a.kind)}  |  "
                f"{a.size / 1048576:.1f}MB{note}")
            item.setData(Qt.UserRole, a.id)
            self.list.addItem(item)
        self.count_label.setText(f"{len(assets)} فایل — پوشه: {self.ctx.media_service.media_dir}")

    def _add_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "انتخاب فایل رسانه", "",
            "رسانه‌ها (*.jpg *.jpeg *.png *.webp *.mp4 *.mp3 *.ogg *.m4a *.pdf *.zip *.txt *.csv);;همه فایل‌ها (*)")
        if not path:
            return
        try:
            asset = self.ctx.media_service.add_file(path)
            self.ctx.logs_repo.add("INFO", "MEDIA",
                                   f"فایل افزوده شد: {asset.filename}")
            self.refresh()
        except MinerMediaError as exc:
            QMessageBox.warning(self, "فایل نامعتبر", exc.user_message)

    def _scan(self) -> None:
        n = self.ctx.media_service.scan_dir()
        QMessageBox.information(self, "ایندکس", f"{n} فایل جدید ایندکس شد.")
        self.refresh()

    def _delete_selected(self) -> None:
        rows = [self.list.item(i) for i in range(self.list.count())
                if self.list.item(i).isSelected()]
        if not rows:
            return
        reply = QMessageBox.question(self, "حذف فایل",
                                     f"{len(rows)} فایل حذف شود؟")
        if reply == QMessageBox.Yes:
            for item in rows:
                self.ctx.media_service.delete(item.data(Qt.UserRole))
            self.refresh()

