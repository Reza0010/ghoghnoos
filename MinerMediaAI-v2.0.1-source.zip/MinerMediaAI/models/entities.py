"""مدل‌های داده برنامه (dataclass + enum)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


# ---------------------------------------------------------------------------
# کانال‌های تلگرام
# ---------------------------------------------------------------------------
@dataclass
class Channel:
    id: int
    name: str
    chat_id: str                     # @username یا -100xxxxxxxxxx
    alias: str = ""
    enabled: bool = True
    token_key: str = "telegram.bot_token.default"
    created_at: str = ""
    last_test_at: str | None = None
    last_test_ok: bool | None = None
    last_error: str | None = None

    @property
    def display_name(self) -> str:
        return self.alias or self.name


# ---------------------------------------------------------------------------
# صف انتشار و زمان‌بندی
# ---------------------------------------------------------------------------
class PostStatus(str, Enum):
    DRAFT = "draft"
    PENDING = "pending"
    PROCESSING = "processing"
    SENT = "sent"
    FAILED = "failed"
    UNKNOWN = "unknown"          # نتیجه ارسال مبهم — ارسال مجدد خودکار ممنوع
    CANCELLED = "cancelled"


class ContentType(str, Enum):
    TEXT = "text"
    PHOTO = "photo"
    VIDEO = "video"
    AUDIO = "audio"
    DOCUMENT = "document"
    ALBUM = "album"          # sendMediaGroup — از UI تا کلاینت پشتیبانی کامل

    @classmethod
    def media_kinds(cls) -> set[str]:
        """انواعی که فایل رسانه‌ای لازم دارند (برای اعتبارسنجی قبل از زمان‌بندی)."""
        return {cls.PHOTO.value, cls.VIDEO.value, cls.AUDIO.value,
                cls.DOCUMENT.value, cls.ALBUM.value}


@dataclass
class ScheduledPost:
    id: int
    channel_id: int
    content_type: str = ContentType.TEXT.value
    body: str = ""
    media_path: str = ""
    scheduled_at: str = ""           # UTC ISO
    timezone: str = "Asia/Tehran"
    status: str = PostStatus.PENDING.value
    attempts: int = 0
    max_attempts: int = 5
    created_at: str = ""
    updated_at: str = ""
    last_attempt_at: str | None = None
    telegram_message_id: int | None = None
    last_error: str | None = None
    group_uuid: str = ""
    source: str = "manual"           # manual | studio | news
    channel_name: str = ""           # برای نمایش (join)
    send_started_at: str | None = None   # لحظه شروع واقعی درخواست ارسال
    split_long_text: bool = False        # متن بلند رسانه → پیام جداگانه (سیاست صریح)


# ---------------------------------------------------------------------------
# بازار
# ---------------------------------------------------------------------------
class PriceUnit(str, Enum):
    RIAL = "RIAL"
    TOMAN = "TOMAN"
    USDT = "USDT"


@dataclass
class PriceQuote:
    """نقل‌قول قیمت با منبع، واحد و زمان — اجباراً قابل ردیابی."""
    symbol: str
    market: str                      # مثل BTCIRT یا BTCUSDT
    price: float | None
    unit: PriceUnit
    source: str                      # مثل nobitex
    fetched_at: str                  # UTC ISO
    day_change_pct: float | None = None
    day_high: float | None = None
    day_low: float | None = None
    day_open: float | None = None
    best_buy: float | None = None
    best_sell: float | None = None
    volume_src: float | None = None
    volume_dst: float | None = None
    is_closed: bool = False
    stale: bool = False
    estimated: bool = False          # قیمت ریالی محاسبه‌شده از نرخ USDT
    estimate_note: str = ""

    @property
    def rial_price(self) -> float | None:
        """قیمت برحسب ریال؛ فقط اگر واحد ریال باشد (بدون حدس)."""
        return self.price if self.unit == PriceUnit.RIAL else None


@dataclass
class WatchItem:
    symbol: str
    display_name: str = ""
    visible: bool = True
    sort_order: int = 0
    id: int | None = None


# ---------------------------------------------------------------------------
# اخبار
# ---------------------------------------------------------------------------
class NewsStatus(str, Enum):
    NEW = "new"
    REVIEWED = "reviewed"
    APPROVED = "approved"
    REJECTED = "rejected"
    CONVERTED = "converted"


@dataclass
class NewsItem:
    id: int | None
    guid: str
    title: str
    link: str
    source: str
    topic: str = ""
    published_at: str | None = None
    fetched_at: str = ""
    summary: str = ""
    status: str = NewsStatus.NEW.value


# ---------------------------------------------------------------------------
# استودیوی محتوا
# ---------------------------------------------------------------------------
class DraftStatus(str, Enum):
    DRAFT = "draft"
    REVIEW = "review"
    APPROVED = "approved"
    SCHEDULED = "scheduled"
    REJECTED = "rejected"
    PUBLISHED = "published"


@dataclass
class ContentDraft:
    id: int | None
    category: str
    ctype: str
    title: str = ""
    body: str = ""
    hashtags: str = ""
    media_path: str = ""
    status: str = DraftStatus.DRAFT.value
    created_at: str = ""
    updated_at: str = ""
    approved_at: str | None = None
    meta: str = ""                   # JSON: منابع، نکات عدم قطعیت، قیمت‌ها و ...


@dataclass
class GenerationRecord:
    id: int | None = None
    draft_id: int | None = None
    category: str = ""
    ctype: str = ""
    provider: str = ""
    model: str = ""
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    ok: bool = True
    error: str = ""
    created_at: str = ""


# ---------------------------------------------------------------------------
# کتابخانه رسانه
# ---------------------------------------------------------------------------
@dataclass
class MediaAsset:
    id: int | None
    path: str
    filename: str
    kind: str                        # photo | video | audio | document
    size: int
    sha1: str = ""
    added_at: str = ""
    note: str = ""


# ---------------------------------------------------------------------------
# نتیجه عملیات‌های ترکیبی
# ---------------------------------------------------------------------------
@dataclass
class RefreshResult:
    """نتیجه یک چرخه به‌روزرسانی بازار/اخبار — شفاف و قابل نمایش."""
    ok: bool = False
    updated: int = 0
    missing: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    notes: list = field(default_factory=list)   # اطلاعات صریح (مثل شمارش خبر قدیمی حذف‌شده)
    fetched_at: str = ""
    duration_ms: int = 0
