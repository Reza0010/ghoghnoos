"""ذخیره‌سازی امن توکن‌ها و کلیدهای API.

اولویت اول: Windows Credential Manager (از طریق کتابخانه keyring)
جایگزین توسعه‌ای: فایل محلی با دسترسی 0600 (فقط وقتی keyring در دسترس نیست —
با پرچم insecure=True مشخص می‌شود و در رابط کاربری هشدار داده می‌شود.)

توکن‌ها هرگز:
- در فایل JSON معمولی ذخیره نمی‌شوند
- در لاگ، Traceback یا پیام خطا ظاهر نمی‌شوند (core.redact)
- در Git commit نمی‌شوند (.gitignore)
"""
from __future__ import annotations

import base64
import json
import os
import threading
from abc import ABC, abstractmethod
from pathlib import Path

from core.errors import SecretStoreError

SERVICE_NAME = "MinerMediaAI"
SECRETS_WARNING = (
    "کلیدها در فایل محلی ذخیره شده‌اند (حالت توسعه). "
    "روی ویندوز از Windows Credential Manager استفاده می‌شود."
)


class SecretStore(ABC):
    """رابط ذخیره‌سازی رمز."""

    insecure: bool = False

    @abstractmethod
    def set_secret(self, key: str, value: str) -> None: ...

    @abstractmethod
    def get_secret(self, key: str) -> str | None: ...

    @abstractmethod
    def delete_secret(self, key: str) -> None: ...

    @abstractmethod
    def backend_name(self) -> str: ...


class KeyringSecretStore(SecretStore):
    """ذخیره در سرویس کلید سیستم‌عامل — روی ویندوز: Credential Manager."""

    def __init__(self, service: str = SERVICE_NAME):
        import keyring
        try:
            backend = keyring.get_keyring()
            # بک‌اندهایی که واقعاً ذخیره می‌کنند (نه fail/chainer نمایشی)
            name = type(backend).__module__ + "." + type(backend).__name__
            if "fail" in name.lower() or "null" in name.lower():
                raise SecretStoreError(
                    f"بک‌اند keyring کاربردی نیست ({name})",
                    "ذخیره‌سازی امن رمز در این سیستم در دسترس نیست.")
        except Exception as exc:  # noqa: BLE001
            raise SecretStoreError(
                f"keyring init failed: {type(exc).__name__}",
                "راه‌اندازی ذخیره‌سازی امن رمز ناموفق بود.") from exc
        self._keyring = keyring
        self._service = service

    def backend_name(self) -> str:
        return type(self._keyring.get_keyring()).__name__

    def set_secret(self, key: str, value: str) -> None:
        self._keyring.set_password(self._service, key, value)

    def get_secret(self, key: str) -> str | None:
        return self._keyring.get_password(self._service, key)

    def delete_secret(self, key: str) -> None:
        try:
            self._keyring.delete_password(self._service, key)
        except Exception:  # noqa: BLE001 — حذف کلید ناموجود خطا محسوب نمی‌شود
            pass


class FileSecretStore(SecretStore):
    """جایگزین فقط-توسعه‌ای: فایل محلی 0600 با انکودینگ base64.

    توجه صادقانه: این روش «رمزنگاری» نیست؛ فقط از قرارگیری توکن در
    فایل‌های پیکربندی معمولی و Git جلوگیری می‌کند. در رابط کاربری هشدار داده می‌شود.
    """

    insecure = True

    def __init__(self, path: Path):
        self._path = Path(path)
        self._lock = threading.Lock()
        self._data: dict[str, str] = {}
        self._load()

    def backend_name(self) -> str:
        return "FileSecretStore(dev)"

    def _load(self) -> None:
        if self._path.exists():
            try:
                raw = json.loads(self._path.read_text(encoding="utf-8"))
                self._data = {
                    k: base64.b64decode(v.encode()).decode("utf-8")
                    for k, v in raw.get("secrets", {}).items()
                }
            except Exception as exc:  # noqa: BLE001
                raise SecretStoreError(
                    f"secrets file corrupt: {exc}",
                    "فایل رمزهای محلی خراب است.") from exc

    def _save(self) -> None:
        payload = {
            "_warning": "DEV-ONLY fallback store — prefer OS credential vault.",
            "secrets": {
                k: base64.b64encode(v.encode("utf-8")).decode("ascii")
                for k, v in self._data.items()
            },
        }
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=1), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:  # pragma: no cover — ویندوز ACL خودش را دارد
            pass
        os.replace(tmp, self._path)

    def set_secret(self, key: str, value: str) -> None:
        with self._lock:
            self._data[key] = value
            self._save()

    def get_secret(self, key: str) -> str | None:
        with self._lock:
            return self._data.get(key)

    def delete_secret(self, key: str) -> None:
        with self._lock:
            self._data.pop(key, None)
            self._save()


class InMemorySecretStore(SecretStore):
    """فقط برای تست‌های خودکار."""

    def __init__(self):
        self._data: dict[str, str] = {}

    def backend_name(self) -> str:
        return "InMemory(test)"

    def set_secret(self, key: str, value: str) -> None:
        self._data[key] = value

    def get_secret(self, key: str) -> str | None:
        return self._data.get(key)

    def delete_secret(self, key: str) -> None:
        self._data.pop(key, None)


def create_secret_store(data_dir: Path | None = None) -> SecretStore:
    """بهترین روش در دسترس را انتخاب می‌کند (ویندوز → Credential Manager)."""
    try:
        return KeyringSecretStore()
    except SecretStoreError:
        from core.paths import get_data_dir
        return FileSecretStore((data_dir or get_data_dir()) / "secrets.json")
