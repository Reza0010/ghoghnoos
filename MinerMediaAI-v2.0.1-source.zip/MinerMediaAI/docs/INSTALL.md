# راهنمای نصب و اجرا روی ویندوز

## پیش‌نیازها
- ویندوز ۱۰/۱۱ (x64)
- Python 3.11 یا جدیدتر — از [python.org](https://www.python.org/downloads/) نصب کنید و در نصب گزینه **Add python.exe to PATH** را بزنید.

## نصب گام‌به‌گام

1. **باز کردن PowerShell** در پوشه پروژه (راست‌کلیک در فولدر → Open in Terminal).

2. **ساخت محیط مجازی:**
```powershell
python -m venv .venv
.\.venv\Scripts\activate
```

3. **نصب وابستگی‌ها:**
```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

4. **اجرای برنامه:**
```powershell
python app.py
```

> اجرای مجدد در روزهای بعد: فقط `.\.venv\Scripts\activate` و سپس `python app.py`.

## محل ذخیره داده‌ها
همه داده‌های کاربر (دیتابیس، لاگ، رسانه، پشتیبان) در این پوشه است و جدا از کد:

| محتوا | مسیر |
|---|---|
| دیتابیس | `%APPDATA%\MinerMediaAI\minermedia.db` |
| لاگ‌ها | `%APPDATA%\MinerMediaAI\logs\app.log` |
| رسانه‌ها | `%APPDATA%\MinerMediaAI\media\` |
| پشتیبان‌ها | `%APPDATA%\MinerMediaAI\backups\` |
| توکن‌ها | Windows Credential Manager (سرویس: `MinerMediaAI`) |

## اجرای تست‌ها
> **هشدار:** `requirements-dev.txt` فقط pytest نصب می‌کند و برای اجرای برنامه
> کافی نیست؛ اگر فقط همین را نصب کنید، `python app.py` با خطای
> «No module named 'feedparser'» متوقف می‌شود. اول `requirements.txt` را نصب کنید.
```powershell
pip install -r requirements-dev.txt
python -m pytest tests/
# تست زنده API عمومی نوبیتکس (نیازمند اینترنت):
python -m pytest tests/test_live_nobitex.py --live
```

## تغییر دایرکتوری داده (اختیاری — برای توسعه)
```powershell
python app.py --data-dir D:\MinerMediaData
```

## رفع اشکال نصب
| مشکل | راه‌حل |
|---|---|
| `python` شناخته نشد | نصب مجدد Python با گزینه Add to PATH، یا استفاده از `py` به‌جای `python` |
| خطای SSL هنگام pip | اتصال شبکه/پروکسی سازمانی را بررسی کنید؛ `pip install --trusted-host pypi.org ...` |
| خطای `keyring` روی ویندوز | keyring به‌صورت خودکار از Windows Credential Manager استفاده می‌کند؛ در صورت خطا برنامه با هشدار صریح به حالت فایل محلی می‌رود |
| فونت فارسی ناخوانا | فونت‌های وزیرمتن به‌صورت خودکار از `assets/fonts` بارگذاری می‌شوند؛ در نبود آن‌ها Segoe UI/Tahoma استفاده می‌شود |
