# گزارش تست واقعی — MinerMedia AI v2.0.1

> تاریخ اجرا: 2026-10-11 | محیط: Python 3.12.15 / PySide6 6.12.0 / SQLite 3 (WAL) / Linux (Qt offscreen)
> فرمان اجرا: `python -m pytest tests/ -q` و `python -m pytest tests/test_live_nobitex.py --live -q`
> این گزارش فقط از خروجی واقعی تولید شده است — هیچ نتیجه‌ای بدون اجرا ادعا نشده است.

## نتیجه کلی v2.0.1

| دسته | تعداد | نتیجه |
|---|---|---|
| تست‌های خودکار (mock/offscreen) | **۱۲۰** | ✅ 120 passed, 0 failed |
| تست زنده نوبیتکس (`--live`، API واقعی apiv2.nobitex.ir) | **۲** | ✅ پاس (نسبت واحد IRT×10 == ریال تأیید زنده) |
| چک‌لیست پذیرش (۱۵ شرط v2.0.0 + ۷ شرط جدید v2.0.1) | **۲۱** | ✅ 21/21 PASS |
| بوت واقعی app + اسکرین‌شات ۹ صفحه | ۹ PNG | ✅ exit=0، خاموشی تمیز |

خروجی خام آخرین اجرا: `120 passed, 2 skipped in 2.12s` (skip = ۲ تست live بدون فلگ `--live`)

> **بازرستیابی مجدد (2026-10-12):** هر چهار سطر جدول بالا در محیط تازه دوباره
> به‌صورت واقعی اجرا شد — `120 passed, 2 skipped`، تست زنده `2 passed in 6.10s`،
> پذیرش `21/21 PASS`، بوت واقعی با مسیر «خاموشی صادقانه» (market_worker عقب از
> بودجه → هشدار → دیتابیس بسته نشد) و خروج `exit=0`. هیچ عددی تغییر نکرد.

## تست‌های جدید v2.0.1 (به تفکیک مأموریت)

### مأموریت ۱ — خاموش‌شدن امن (`tests/test_shutdown.py` — ۴ تست)
- همه Workerها متوقف → دیتابیس بسته می‌شود (`test_all_stopped_then_db_closes`)
- Worker زنده (درخواست طولانی در جریان) → دیتابیس بسته **نمی‌شود** و همچنان سالم است (`test_worker_alive_means_db_not_closed`)
- سناریوی کلیدی مأموریت: بسته‌شدن DB حین ارسال → بدون کرش، بدون نوشتن روی DB بسته؛ وضعیت on-disk «processing + send_started_at» می‌ماند و بازیابی بعدی آن را صادقانه unknown می‌کند (`test_scheduler_never_touches_closed_db`)
- گزارش خاموشی نام‌دار و صادقانه (`test_shutdown_report_lists_honest_names`)

### مأموریت ۲ — بازیابی صف (`tests/test_scheduler.py` — ۱۴ تست، ۷ مورد جدید)
- claim‌شده بدون شروع ارسال → بازیابی به pending نه unknown (`test_startup_recovery_claimed_without_send_returns_pending`)
- توقف وسط چرخه → فقط پست در-flight مبهم می‌شود، بقیه pending می‌مانند (`test_shutdown_mid_cycle_no_unknown_for_unstarted`)
- 429 سقف max_attempts دارد → failed صادقانه + تاریخچه rate_limited/rate_limited_exhausted (`test_429_exhausts_max_attempts_then_fails`)
- استثنای غیرمنتظره شمارنده تلاش را دوبرابر نمی‌کند (`test_unexpected_exception_does_not_double_count`)
- `send_started_at` دقیقاً قبل از publish ثبت می‌شود (`test_send_started_set_before_publish`)
- تست‌های حفظ‌شده v2.0.0: ارسال موفق+ثبت، آینده ارسال نمی‌شود، retry_after 429، backoff موقت، read-timeout→unknown، 403 دائمی، لغو، دو Worker هم‌زمان ۲۰ پست بدون تداخل، منطقه زمانی تهران، توکن ناموجود.

### مأموریت ۳ — نوبیتکس (`tests/test_market_hardening.py` — ۶ تست جدید)
- خطای فقط نرخ USDT/RLS → دقیقاً ۲ درخواست، صفر fallback (`test_rate_only_error_does_not_trigger_fallback`)
- 429 روی دسته → دقیقاً ۲ درخواست، شکست صادقانه (`test_batch_429_does_not_fire_single_requests`)
- قطع شبکه دسته → دقیقاً ۲ درخواست (`test_batch_network_down_no_extra_requests`)
- 400 دسته → fallback مجاز + یادگیری نماد نامعتبر پایدار (`test_batch_400_learns_invalid_symbol_via_fallback`)
- فهرست ۱۵ ارز → فقط ۱ درخواست دسته + ۱ نرخ (`test_large_watchlist_single_batch_request`)
- قیمت مستقیم vs تخمینی + تازگی هر دو منبع (`test_stale_marking_and_estimated_freshness`)

### مأموریت ۴ — Worker اخبار (`tests/test_news_worker.py` — ۵ تست جدید)
- دریافت فوری اول + فاصله از تنظیمات + توقف تمیز (`test_news_worker_fetches_and_respects_interval`)
- خطای منبع Worker را نمی‌کشد (`test_news_worker_survives_source_errors`)
- توقف صادقانه حین درخواست طولانی: False تا واقعاً تمام نشود (`test_news_worker_stop_is_honest_when_busy`)
- فیلتر منابع فعال/غیرفعال + سازگاری فرمت قدیمی (`test_enabled_sources_filter`, `test_settings_sources_roundtrip_with_flag`)
- خبر قدیمی وارد نمی‌شود ولی شمرده می‌شود؛ بی‌تاریخ با برچسب صادقانه؛ تکراری dedupe (`test_news_service_old_news_and_missing_date`)

### مأموریت ۵ — رسانه (`tests/test_media_publish.py` — ۱۳ تست جدید)
- ماتریس کامل photo/video/audio/document از publish_post تا کلاینت
- آلبوم: JSON مسیرها، کپشن فقط آیتم اول، حداقل ۲ آیتم، split متن بلند آلبوم
- متن بلند + رسانه: بدون split → خطای صریح (بدون برش ساکت!)؛ با split → رسانه بدون کپشن + کل متن پیام جداگانه (هیچ حرفی حذف نمی‌شود)
- اعتبارسنجی قبل از زمان‌بندی: فایل حذف‌شده، نوع نامعتبر (.exe)، حجم ۱۱MB عکس، فایل سالم
- رگرسیون کرش: باز شدن دیالوگ پست جدید (باگ واقعی QCheckBox v2.0.0) + جریان کامل آلبوم در UI

### مأموریت ۶ — UI (`tests/test_ui_smoke.py` — ۴ تست حفظ‌شده)
- پنجره اصلی + ۹ صفحه + RTL، حالت خالی بدون عدد ساختگی، صفحه کانال‌ها، ذخیره تنظیمات
- شاهد بصری: اسکرین‌شات واقعی هر ۹ صفحه (offscreen grab) در `workspace/screenshots/dash_*.png`

## تست زنده (جدا از mock — طبق مأموریت ۷)

| تست | نتیجه | توضیح |
|---|---|---|
| `test_live_stats_unit_consistency` | ✅ پاس | stats ریال واقعی از apiv2.nobitex.ir |
| `test_live_udf_matches_stats_x10` | ✅ پاس | کندل IRT ×10 == ریال (واحد صریح) |

## بوت واقعی و خاموشی (شاهد رفتار v2.0.1)

اجرای `scripts_dev/boot_and_screenshot.py` (app.py واقعی + نقل‌قول واقعی نوبیتکس + Worker اخبار واقعی):
- دریافت خودکار اخبار: **۱۰۵ خبر واقعی** (نوار وضعیت + دیتابیس)
- خاموشی: `scheduler stopped → news worker stopped → market worker stopped`؛
  در اجرای ثبت‌شده market_worker در میانه refresh بود → برنامه **دیتابیس را نبست** و صادقانه هشدار داد:
  `WARNING | shutdown: workers still running after budget: market_worker — database NOT closed explicitly`
  (دقیقاً رفتار خواسته‌شده مأموریت ۱) — خروج: exit=0

## نتیجه چک‌لیست پذیرش (۲۱/۲۱ PASS)

شرایط ۱–۱۵ حفظ‌شده از v2.0.0 + شرط‌های ۱۶–۲۱ (خاموشی امن، بازیابی صف، تفکیک fallback نوبیتکس، Worker اخبار، ماتریس رسانه، تاریخچه تلاش/سقف 429).

## محدودیت‌های تست (شفاف)

- تست‌های UI در offscreen اجرا شده‌اند (بدون نمایشگر واقعی ویندوز) — رفتار روی ویندوز باید طبق `docs/INSTALL.md` توسط کاربر تأیید شود.
- تست واقعی ارسال به کانال تلگرام انجام نشده است (نیازمند توکن واقعی کاربر) — مسیر تست توصیه‌شده در `docs/BOT_TOKEN.md`.
