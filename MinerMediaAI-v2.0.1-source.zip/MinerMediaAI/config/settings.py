"""تنظیمات برنامه — غیرمحرمانه در دیتابیس؛ محرمانه فقط در SecretStore.

پیش‌فرض‌ها ایمن هستند:
- انتشار خودکار خاموش
- خبر بدون تأیید دستی منتشر نمی‌شود
- فاصله به‌روزرسانی بازار حداقل ۳۰ ثانیه
"""
from __future__ import annotations

from config import defaults as cfg
from core.errors import ConfigError
from database.repositories import SettingsRepo


class AppSettings:
    def __init__(self, repo: SettingsRepo):
        self.repo = repo

    # ------------------------------ عمومی ------------------------------
    @property
    def app_name(self) -> str:
        return str(self.repo.get("app_name", cfg.DEFAULT_APP_NAME) or
                   cfg.DEFAULT_APP_NAME)

    @app_name.setter
    def app_name(self, value: str) -> None:
        value = (value or "").strip()
        self.repo.set("app_name", value or cfg.DEFAULT_APP_NAME)

    @property
    def timezone(self) -> str:
        return str(self.repo.get("timezone", cfg.DEFAULT_TIMEZONE))

    @timezone.setter
    def timezone(self, value: str) -> None:
        try:
            from zoneinfo import ZoneInfo
            ZoneInfo(value)
        except Exception as exc:  # noqa: BLE001
            raise ConfigError(f"bad timezone: {value}",
                              "منطقه زمانی نامعتبر است.") from exc
        self.repo.set("timezone", value)

    # ------------------------------ بازار ------------------------------
    @property
    def market_refresh_sec(self) -> int:
        val = int(self.repo.get("market_refresh_sec",
                                cfg.DEFAULT_MARKET_REFRESH_SEC) or 60)
        return max(cfg.MIN_MARKET_REFRESH_SEC, min(val, cfg.MAX_MARKET_REFRESH_SEC))

    @market_refresh_sec.setter
    def market_refresh_sec(self, value: int) -> None:
        val = max(cfg.MIN_MARKET_REFRESH_SEC, min(int(value),
                                                  cfg.MAX_MARKET_REFRESH_SEC))
        self.repo.set("market_refresh_sec", val)

    @property
    def market_display_unit(self) -> str:
        return str(self.repo.get("market_display_unit", "TOMAN"))

    @market_display_unit.setter
    def market_display_unit(self, value: str) -> None:
        if value not in ("RIAL", "TOMAN", "USDT"):
            raise ConfigError(f"bad display unit {value}",
                              "واحد نمایش باید ریال، تومان یا USDT باشد.")
        self.repo.set("market_display_unit", value)

    # ------------------------------ هوش مصنوعی ------------------------------
    @property
    def ai_base_url(self) -> str:
        return str(self.repo.get("ai_base_url", cfg.DEFAULT_AI_BASE_URL))

    @ai_base_url.setter
    def ai_base_url(self, value: str) -> None:
        self.repo.set("ai_base_url", (value or "").strip())

    @property
    def ai_text_model(self) -> str:
        return str(self.repo.get("ai_text_model", cfg.DEFAULT_AI_TEXT_MODEL))

    @ai_text_model.setter
    def ai_text_model(self, value: str) -> None:
        self.repo.set("ai_text_model", (value or "").strip())

    @property
    def ai_image_model(self) -> str:
        return str(self.repo.get("ai_image_model", cfg.DEFAULT_AI_IMAGE_MODEL))

    @ai_image_model.setter
    def ai_image_model(self, value: str) -> None:
        self.repo.set("ai_image_model", (value or "").strip())

    @property
    def ai_temperature(self) -> float:
        try:
            return float(self.repo.get("ai_temperature", cfg.DEFAULT_AI_TEMPERATURE))
        except (TypeError, ValueError):
            return cfg.DEFAULT_AI_TEMPERATURE

    @ai_temperature.setter
    def ai_temperature(self, value: float) -> None:
        self.repo.set("ai_temperature", max(0.0, min(2.0, float(value))))

    # ------------------------------ اخبار ------------------------------
    @property
    def news_require_approval(self) -> bool:
        return bool(self.repo.get("news_require_approval", cfg.NEWS_REQUIRE_APPROVAL))

    @news_require_approval.setter
    def news_require_approval(self, value: bool) -> None:
        self.repo.set("news_require_approval", bool(value))

    @property
    def news_refresh_sec(self) -> int:
        return max(300, int(self.repo.get("news_refresh_sec",
                                          cfg.DEFAULT_NEWS_REFRESH_SEC)))

    @news_refresh_sec.setter
    def news_refresh_sec(self, value: int) -> None:
        self.repo.set("news_refresh_sec", max(300, int(value)))

    @property
    def news_sources(self) -> list:
        return self.repo.get(
            "news_sources", [list(s) for s in cfg.DEFAULT_NEWS_SOURCES])

    @news_sources.setter
    def news_sources(self, value: list) -> None:
        clean = []
        for entry in value or []:
            try:
                name, url = str(entry[0]).strip(), str(entry[1]).strip()
            except (IndexError, TypeError):
                continue
            if not name or not url.startswith(("http://", "https://")):
                continue
            topic = str(entry[2] if len(entry) > 2 else "crypto")
            # پرچم فعال/غیرفعال اختیاری — فرمت ۴تایی جدید؛ سازگار با فرمت ۳تایی قدیمی
            enabled = bool(entry[3]) if len(entry) > 3 else True
            clean.append([name, url, topic, enabled])
        self.repo.set("news_sources", clean)

    @property
    def enabled_news_sources(self) -> list[tuple]:
        """فقط منابع فعال — ورودی Worker اخبار و دریافت دستی."""
        from services.news.service import news_enabled_sources
        return news_enabled_sources(self.news_sources)

    # ------------------------------ انتشار ------------------------------
    @property
    def auto_publish_enabled(self) -> bool:
        """پیش‌فرض: خاموش — محتوای AI بدون تأیید منتشر نمی‌شود."""
        return bool(self.repo.get("auto_publish_enabled", False))

    @auto_publish_enabled.setter
    def auto_publish_enabled(self, value: bool) -> None:
        self.repo.set("auto_publish_enabled", bool(value))

    # ------------------------------ نگهداری ------------------------------
    @property
    def retention_days(self) -> dict:
        val = self.repo.get("retention_days", {}) or {}
        return {
            "logs": int(val.get("logs", cfg.DEFAULT_LOG_RETENTION_DAYS)),
            "samples": int(val.get("samples", cfg.DEFAULT_SAMPLE_RETENTION_DAYS)),
            "news": int(val.get("news", cfg.DEFAULT_NEWS_RETENTION_DAYS)),
        }

    @retention_days.setter
    def retention_days(self, value: dict) -> None:
        self.repo.set("retention_days", value)
