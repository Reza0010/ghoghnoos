"""ثابت‌ها و مقادیر پیش‌فرض ایمن برنامه.

هیچ مقدار محرمانه‌ای در این فایل نگهداری نمی‌شود.
"""
from __future__ import annotations

# ---------- هویت برنامه ----------
DEFAULT_APP_NAME = "MinerMedia AI"
DEFAULT_APP_SUBTITLE = "Smart Mining & Crypto Channel Manager"
APP_VERSION = "2.0.1"

# ---------- منطقه زمانی ----------
DEFAULT_TIMEZONE = "Asia/Tehran"

# ---------- بازار و قیمت ----------
# فاصله پیشنهادی به‌روزرسانی قیمت (ثانیه) — طبق مأموریت: پیش‌فرض ۶۰ ثانیه
DEFAULT_MARKET_REFRESH_SEC = 60
MIN_MARKET_REFRESH_SEC = 30          # جلوگیری از درخواست بی‌رویه
MAX_MARKET_REFRESH_SEC = 3600
# محدودیت رسمی /market/stats نوبیتکس: ۲۰ درخواست در دقیقه → فاصله ایمن ۴ ثانیه بین هر فراخوانی
NOBITEX_STATS_MIN_INTERVAL_SEC = 4.0
# محدودیت رسمی /market/udf/history: ۶۰ درخواست در دقیقه
NOBITEX_UDF_MIN_INTERVAL_SEC = 1.5
NOBITEX_BASE_URL = "https://apiv2.nobitex.ir"
NOBITEX_USER_AGENT = "TraderBot/MinerMediaAI-2.0.1"
NOBITEX_DOCS_URL = "https://apidocs.nobitex.ir/"
# یک داده قیمت قدیمی‌تر از ۳ برابر فاصله به‌روزرسانی «کهنه» محسوب می‌شود
PRICE_STALENESS_FACTOR = 3
# برای قیمت «تخمینی» (ضرب USDT در نرخ USDT/ریال) هر دو داده باید تازه باشند
ESTIMATION_MAX_AGE_FACTOR = 2

# ارزهای اولیه فهرست منتخب (قابل توسعه توسط کاربر).
# توجه: حضور در این فهرست به معنی تأیید معامله‌پذیری همه آن‌ها در نوبیتکس نیست؛
# قیمت فقط برای جفت‌معاملاتی که پاسخ API واقعاً برگرداند نمایش داده می‌شود.
DEFAULT_WATCHLIST = [
    ("BTC", "Bitcoin"),
    ("BCH", "Bitcoin Cash"),
    ("BSV", "Bitcoin SV"),
    ("LTC", "Litecoin"),
    ("KAS", "Kaspa"),
    ("DOGE", "Dogecoin"),
    ("ETC", "Ethereum Classic"),
    ("ETH", "Ethereum"),
    ("USDT", "Tether"),
    ("DGB", "DigiByte"),
]

# ---------- تلگرام ----------
TELEGRAM_API_BASE = "https://api.telegram.org"
# محدودیت‌های رسمی Bot API (برای اعتبارسنجی رسانه)
MAX_PHOTO_MB = 10
MAX_VIDEO_MB = 50
MAX_AUDIO_MB = 50
MAX_DOCUMENT_MB = 50
MAX_TEXT_LEN = 4096
MAX_CAPTION_LEN = 1024
MAX_ALBUM_ITEMS = 10
MEDIA_ALLOWED_EXT = {
    "photo": {".jpg", ".jpeg", ".png", ".webp"},
    "video": {".mp4"},
    "audio": {".mp3", ".ogg", ".m4a"},
    "document": {".jpg", ".jpeg", ".png", ".webp", ".mp4", ".pdf", ".zip", ".mp3", ".ogg", ".m4a", ".txt", ".csv"},
}
DEFAULT_SCHEDULER_POLL_SEC = 5.0
DEFAULT_MAX_ATTEMPTS = 5
RETRY_BASE_DELAY_SEC = 60          # تأخیر افزایشی: 60s, 120s, 240s, …
RETRY_MAX_DELAY_SEC = 1800         # سقف ۳۰ دقیقه

# ---------- تولید محتوا ----------
DEFAULT_AI_BASE_URL = "https://api.openai.com/v1"
DEFAULT_AI_TEXT_MODEL = ""
DEFAULT_AI_IMAGE_MODEL = ""
DEFAULT_AI_TEMPERATURE = 0.7
DEFAULT_AI_MAX_TOKENS = 900

# دسته‌بندی‌های محتوای تخصصی ماینینگ (حداقل موارد مأموریت)
CONTENT_CATEGORIES = [
    ("repair_tutorial", "آموزش تعمیرات ماینر"),
    ("hashboard_debug", "عیب‌یابی هش‌برد"),
    ("controlboard_repair", "تعمیر کنترل‌برد"),
    ("psu_repair", "تعمیر پاور و PSU"),
    ("antminer_errors", "خطاهای رایج Antminer"),
    ("whatsminer_errors", "خطای رایج WhatsMiner"),
    ("mining_industry", "اخبار صنعت ماینینگ"),
    ("bitcoin_network", "اخبار بیت‌کوین و شبکه"),
    ("coin_market", "قیمت و اخبار ارزهای ماینینگ"),
    ("tools_tutorial", "آموزش تجهیزات تعمیرگاهی"),
    ("safety_tips", "نکات ایمنی تعمیرات"),
    ("services_intro", "معرفی خدمات و ابزارهای تعمیراتی"),
]

CONTENT_TYPES = [
    ("short_post", "پست آموزشی کوتاه"),
    ("tutorial", "آموزش تخصصی مرحله‌به‌مرحله"),
    ("news_flash", "خبر فوری"),
    ("news_analysis", "تحلیل خبر"),
    ("part_intro", "معرفی قطعه و کاربرد آن"),
    ("troubleshooting", "نکات عیب‌یابی"),
    ("comparison", "مقایسه فنی"),
    ("image_post", "پست همراه تصویر"),
    ("caption_hashtag", "کپشن و هشتگ"),
    ("series", "مجموعه پست‌های دنباله‌دار"),
]

# ---------- اخبار ----------
DEFAULT_NEWS_REFRESH_SEC = 900   # هر ۱۵ دقیقه
NEWS_REQUIRE_APPROVAL = True     # انتشار خبر تأییدنشده ممنوع (پیش‌فرض ایمن)
# خبرهای قدیمی‌تر از این آستانه در زمان دریافت وارد صف نمی‌شوند (مدیریت صریح
# «خبر قدیمی» — شمارش آن‌ها در نتیجه ثبت می‌شود، نه حذف بی‌صدا)
NEWS_MAX_AGE_DAYS = 30
DEFAULT_NEWS_SOURCES = [
    # (نام، آدرس RSS/Atom، موضوع پیش‌فرض)
    ("Cointelegraph", "https://cointelegraph.com/rss", "crypto"),
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/", "crypto"),
    ("Bitcoin Magazine", "https://bitcoinmagazine.com/feed", "bitcoin"),
    ("Bitcoin.com News", "https://news.bitcoin.com/feed/", "bitcoin_mining"),
    ("Decrypt", "https://decrypt.co/feed", "crypto"),
]
# کلیدواژه‌های موضوعی برای برچسب‌گذاری خودکار (فارسی + انگلیسی)
NEWS_TOPIC_KEYWORDS = {
    "mining": ["mining", "miner", "asic", "hashrate", "استخراج", "ماین", "ماینر", "هاش"],
    "hardware": ["antminer", "whatsminer", "bitmain", "microbt", "hashboard", "control board", "psu",
                 "هش‌برد", "کنترل‌برد", "پاور", "سخت‌افزار"],
    "bitcoin": ["bitcoin", "btc", "بیت‌کوین", "بیت کوین"],
    "energy": ["energy", "electricity", "power cost", "انرژی", "برق", "مصرف برق"],
    "regulation": ["regulation", "ban", "law", "قانون", "ممنوعیت", "مقررات"],
}

# ---------- نگهداری داده ----------
DEFAULT_LOG_RETENTION_DAYS = 30
DEFAULT_SAMPLE_RETENTION_DAYS = 14
DEFAULT_NEWS_RETENTION_DAYS = 60
