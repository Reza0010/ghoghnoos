"""MinerMedia AI — Smart Mining & Crypto Channel Manager.

بازسازی و توسعه‌یافته از TeleAI-AutoPoster v1.0.2
"""
__app_name__ = "MinerMedia AI"
__version__ = "2.0.0"
