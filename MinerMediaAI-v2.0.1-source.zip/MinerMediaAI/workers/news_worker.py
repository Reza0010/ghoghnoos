"""Worker زمان‌بندی‌شده دریافت اخبار — مستقل از UI و از سرویس قیمت.

- فاصله دریافت از تنظیمات (news_refresh_sec) خوانده می‌شود و تغییرش در
  چرخه بعدی اعمال می‌شود (بدون ری‌استارت).
- فهرست منابع فعال در هر چرخه از providers گرفته می‌شود (فعال/غیرفعال کردن
  منبع بلافاصله در چرخه بعدی اثر می‌گذارد).
- خرابی یک منبع هرگز بقیه را متوقف نمی‌کند (در NewsService per-source است).
- دریافت هرگز UI را بلاک نمی‌کند (این Thread جدا است؛ نتیجه با listener).
- خطای متوالی → backoff ملایم (تا ۴ برابر فاصله و سقف ۱ ساعت).
- توقف ایمن: stop_safe قبل از join پرچم را می‌گذارد؛ حلقه بین منابع
  stop را می‌بیند. اگر وسط درخواست شبکه بودیم، join ممکن است timeout شود —
  خروجی False صادقانه است (فرض توقف نمی‌زنیم).
"""
from __future__ import annotations

import threading

from core.logging_setup import get_logger
from core.redact import scrub_text
from services.news.service import NewsService

log = get_logger("minermedia.news_worker")

MIN_NEWS_INTERVAL_SEC = 300.0       # هماهنگ با settings.news_refresh_sec
MAX_ERROR_INTERVAL_SEC = 3600.0


class NewsWorker(threading.Thread):
    MAX_ERROR_FACTOR = 4

    def __init__(self, service: NewsService,
                 interval_provider,        # callable -> int ثانیه
                 sources_provider):        # callable -> list[(name, url, topic[, enabled])]
        super().__init__(name="news-worker", daemon=True)
        self.service = service
        self.interval_provider = interval_provider
        self.sources_provider = sources_provider
        self._stop_flag = threading.Event()
        self._listeners: list = []

    # ----------------------------- کنترل -----------------------------
    def add_listener(self, callback) -> None:
        self._listeners.append(callback)

    def _emit(self, result) -> None:
        for cb in self._listeners:
            try:
                cb(result)
            except Exception:  # noqa: BLE001 — شنونده نباید Worker را بشکند
                pass

    def stop_safe(self, join_timeout: float = 20.0) -> bool:
        """توقف ایمن؛ خروجی: آیا Thread واقعاً متوقف شد؟ (صادقانه)"""
        self._stop_flag.set()
        if self.is_alive():
            self.join(timeout=join_timeout)
        return not self.is_alive()

    # ----------------------------- حلقه -----------------------------
    def run(self) -> None:
        log.info("news worker started")
        error_streak = 0
        self._fetch_once()   # اولین دریافت بلافاصله پس از شروع
        while not self._stop_flag.is_set():
            interval = max(MIN_NEWS_INTERVAL_SEC,
                           float(self.interval_provider() or 900))
            delay = interval
            if error_streak:
                delay = min(interval * (self.MAX_ERROR_FACTOR ** min(error_streak, 2)),
                            MAX_ERROR_INTERVAL_SEC)
            self._stop_flag.wait(delay)
            if self._stop_flag.is_set():
                break
            ok = self._fetch_once()
            error_streak = 0 if ok else error_streak + 1
        log.info("news worker stopped")

    def _fetch_once(self) -> bool:
        """یک چرخه کامل دریافت؛ خروجی: بدون خطا؟"""
        if self.service.repo.db.is_closed:
            log.warning("news fetch skipped: database is closing")
            return False
        try:
            result = self.service.fetch_all(self.sources_provider())
        except Exception as exc:  # noqa: BLE001 — Worker هرگز نمی‌میرد
            log.error("news worker error: %s", scrub_text(str(exc)))
            return False
        self._emit(result)
        if result.errors:
            log.warning("news fetch errors (%d): %s", len(result.errors),
                        scrub_text("; ".join(result.errors)[:400]))
        return not result.errors
