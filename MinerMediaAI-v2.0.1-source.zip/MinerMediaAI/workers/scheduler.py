"""سرویس زمان‌بندی و ارسال — مستقل از UI و از تولید محتوای AI.

اصول رفتاری (طبق مأموریت):
- پردازش آیتم‌های موعدرسیده با «claim اتمی» در SQLite → دو Worker هم‌زمان
  هرگز یک آیتم مشترک را پردازش نمی‌کنند.
- خطای موقت (connect/5xx) → تأخیر افزایشی و بازگشت به صف (تا max_attempts).
- 429 → احترام به retry_after تلگرام.
- خطای دائمی (400/401/403/404) → failed بدون تلاش مجدد.
- نتیجه مبهم (timeout در فاز read پس از اتصال، یا کرش حین پردازش) →
  وضعیت unknown؛ ارسال مجدد خودکار ممنوع؛ تصمیم با کاربر.
- همه وضعیت‌ها پایدار در SQLite → بازیابی پس از بستن برنامه.
- هیچ تضمین «دقیقاً یک‌بار» در خطای شبکه ادعا نمی‌شود.
"""
from __future__ import annotations

import threading
import time

from config import defaults as cfg
from core.errors import (NetworkError, RateLimitError, SecretStoreError,
                         TelegramError)
from core.logging_setup import get_logger
from core.redact import scrub_text
from core.timeutils import parse_iso, utc_iso, utc_now
from database.repositories import ChannelsRepo, PostsRepo
from security.secret_store import SecretStore
from services.telegram.client import TelegramBotClient, publish_post

log = get_logger("minermedia.scheduler")


class SchedulerService(threading.Thread):
    def __init__(self, posts_repo: PostsRepo, channels_repo: ChannelsRepo,
                 secret_store: SecretStore, poll_sec: float = cfg.DEFAULT_SCHEDULER_POLL_SEC,
                 claim_limit: int = 10):
        super().__init__(name="scheduler", daemon=True)
        self.posts = posts_repo
        self.channels = channels_repo
        self.secrets = secret_store
        self.poll_sec = float(poll_sec)
        self.claim_limit = int(claim_limit)
        self._stop_flag = threading.Event()
        self._pause = threading.Event()
        self._listeners: list = []          # callback(event: dict)
        self._client_cache: dict[int, TelegramBotClient] = {}
        self._lock = threading.Lock()

    # ----------------------------- کنترل -----------------------------
    def stop_safe(self, join_timeout: float = 15.0) -> bool:
        """توقف ایمن؛ خروجی: آیا Thread واقعاً متوقف شد؟

        صادقانه: اگر تا پایان join_timeout خاتمه نیابد (مثلاً درخواست شبکهٔ
        طولانی در جریان است)، False برمی‌گردانیم — فرض نمی‌کنیم متوقف شده.
        """
        self._stop_flag.set()
        if self.is_alive():
            self.join(timeout=join_timeout)
        return not self.is_alive()

    def pause(self) -> None:
        self._pause.set()

    def resume(self) -> None:
        self._pause.clear()

    @property
    def paused(self) -> bool:
        return self._pause.is_set()

    def add_listener(self, callback) -> None:
        self._listeners.append(callback)

    def _emit(self, event: dict) -> None:
        for cb in self._listeners:
            try:
                cb(event)
            except Exception:  # noqa: BLE001 — شنونده نباید Worker را بشکند
                pass

    # ----------------------------- حلقه -----------------------------
    def run(self) -> None:
        log.info("scheduler started (poll=%.1fs)", self.poll_sec)
        while not self._stop_flag.is_set():
            if not self._pause.is_set():
                try:
                    self.cycle()
                except Exception as exc:  # noqa: BLE001 — حلقه هرگز نمی‌میرد
                    log.error("scheduler cycle error: %s", scrub_text(str(exc)))
            self._stop_flag.wait(self.poll_sec)
        log.info("scheduler stopped")

    def cycle(self) -> int:
        """یک چرخه claim تک‌تک + پردازش. خروجی: تعداد آیتم‌های پردازش‌شده.

        claim یک‌به‌یک انجام می‌شود تا بین آیتم‌ها بتوانیم stop را ببینیم؛
        در نتیجه هنگام خاموش‌شدن حداکثر یک آیتم در وضعیت processing می‌ماند
        و همان یک مورد هم با send_started_at به‌صورت صادقانه بازیابی می‌شود.
        """
        processed = 0
        for _ in range(max(1, self.claim_limit)):
            if self._stop_flag.is_set() or self.posts.db.is_closed:
                break
            post = self.posts.claim_one(utc_iso())
            if post is None:
                break
            processed += 1
            self._process(post)
        return processed

    # ----------------------------- پردازش -----------------------------
    def _client_for(self, channel_id: int) -> TelegramBotClient:
        with self._lock:
            client = self._client_cache.get(channel_id)
            if client is None:
                channel = self.channels.get(channel_id)
                if channel is None:
                    raise TelegramError(f"channel {channel_id} deleted",
                                        "کانال حذف شده است.", status_code=404)
                token_key = channel.token_key

                def provider(key=token_key):
                    value = self.secrets.get_secret(key)
                    if not value:
                        raise SecretStoreError(
                            f"missing secret: {key}",
                            f"توکن ربات برای «{key}» ثبت نشده است.")
                    return value
                client = TelegramBotClient(provider)
                self._client_cache[channel_id] = client
            return client

    def _process(self, post) -> None:
        """پردازش یک پست claim‌شده — شمارنده تلاش فقط همین‌جا یک بار زیاد می‌شود.

        قبلاً باگ: _process_inner اول کار increment می‌کرد و اگر استثنای
        غیرمنتظره رخ می‌داد، except اینجا دوباره increment می‌کرد (دو شمارش).
        اکنون: increment واحد + ثبت تاریخچه با نتیجهٔ واقعی.
        """
        started = time.monotonic()
        if self.posts.db.is_closed:
            log.warning("post %s skipped: database is closing", post.id)
            return
        attempts = self.posts.increment_attempt(post.id)
        history_id = self.posts.record_attempt_start(post.id, attempts)
        duration = lambda: int((time.monotonic() - started) * 1000)  # noqa: E731
        try:
            outcome, detail = self._process_inner(post, attempts)
            self.posts.record_attempt_end(history_id, outcome, detail, duration())
            return
        except Exception as exc:  # noqa: BLE001 — مدیریت متمرکز زیر
            # مأموریت ۱: اگر دیتابیس حین ارسال بسته شد (خروج برنامه)،
            # هیچ نوشتن وضعیتی ممکن/مجاز نیست؛ صادقانه رد می‌شویم —
            # وضعیت processing روی دیسک می‌ماند و بازیابی بعدی درست تصمیم
            # می‌گیرد (send_started_at ثبت شده → unknown، نه ارسال دوباره).
            if self.posts.db.is_closed:
                log.warning("post %s: database closed during send; "
                            "state write skipped (honest recovery at next start)",
                            post.id)
                return
            self._dispatch_failure(post, exc, attempts, history_id, duration())

    def _dispatch_failure(self, post, exc: Exception, attempts: int,
                          history_id: int | None, duration_ms: int) -> None:
        """مسیریابی خطا به سیاست درست — بدون شمارش دوم، با تاریخچه صادقانه."""
        if isinstance(exc, RateLimitError):
            # 429 → سیاست کنترل‌شده: retry_after + سقف + تاریخچه
            self._on_rate_limited(post, exc, attempts, history_id)
            return
        if isinstance(exc, NetworkError):
            err = scrub_text(exc.technical)
            if exc.phase == "read":
                # نتیجه ارسال مبهم — تلاش مجدد خودکار ممنوع
                self.posts.mark_unknown(post.id, err + " | نتیجه ارسال نامشخص")
                self.posts.record_attempt_end(history_id, "unknown", err, duration_ms)
                self._emit({"post_id": post.id, "status": "unknown", "error": err})
                log.warning("post %s ambiguous outcome (read timeout)", post.id)
                return
            # connect/other → خطای موقت: backoff تا max_attempts
            if attempts >= post.max_attempts:
                self.posts.mark_failed(post.id, err, permanent=True)
                self.posts.record_attempt_end(history_id, "failed", err, duration_ms)
                self._emit({"post_id": post.id, "status": "failed", "error": err})
            else:
                delay = self.posts.backoff_for(post.id)
                self.posts.schedule_retry(post.id, delay, err)
                self.posts.record_attempt_end(history_id, "retry", err, duration_ms)
                self._emit({"post_id": post.id, "status": "pending", "error": err})
            log.warning("post %s transient error (%s): %s", post.id, exc.phase, err)
            return
        if isinstance(exc, TelegramError):
            err = scrub_text(exc.technical)
            self.posts.mark_failed(post.id, err, permanent=True)
            self.posts.record_attempt_end(history_id, "failed_permanent", err, duration_ms)
            self._emit({"post_id": post.id, "status": "failed", "error": err})
            log.error("post %s permanent failure: %s", post.id, err)
            return
        if isinstance(exc, SecretStoreError):
            err = scrub_text(exc.technical)
            self.posts.mark_failed(post.id, err, permanent=True)
            self.posts.record_attempt_end(history_id, "failed_missing_token", err, duration_ms)
            self._emit({"post_id": post.id, "status": "failed", "error": err})
            log.error("post %s missing token: %s", post.id, err)
            return
        # استثنای غیرمنتظره: صادقانه و بدون increment دوم (شمارش در ابتدای پردازش)
        err = scrub_text(str(getattr(exc, "technical", exc)))
        if attempts >= post.max_attempts:
            self.posts.mark_failed(post.id, err, permanent=True)
            self.posts.record_attempt_end(history_id, "error", err, duration_ms)
            self._emit({"post_id": post.id, "status": "failed", "error": err})
        else:
            delay = self.posts.backoff_for(post.id)
            self.posts.schedule_retry(post.id, delay, err)
            self.posts.record_attempt_end(history_id, "error_retry", err, duration_ms)
            self._emit({"post_id": post.id, "status": "pending", "error": err})
        log.error("post %s unexpected error: %s", post.id, err)

    def _process_inner(self, post, attempts: int) -> tuple[str, str]:
        """خروجی: (outcome برای تاریخچه، detail) — وضعیت دیتابیس اینجا نهایی می‌شود."""
        # بررسی صریح توکن قبل از هر اقدام ارسال (fail-fast)
        channel = self.channels.get(post.channel_id)
        if channel is None:
            raise TelegramError(f"channel {post.channel_id} deleted",
                                "کانال حذف شده است.", status_code=404)
        if not self.secrets.get_secret(channel.token_key):
            raise SecretStoreError(
                f"missing secret: {channel.token_key}",
                f"توکن ربات برای «{channel.token_key}» ثبت نشده است.")
        client = self._client_for(post.channel_id)
        chat_id = channel.chat_id
        # ⚠️ مرز حیاتی: از این لحظه نتیجهٔ ارسال می‌تواند مبهم شود.
        self.posts.mark_send_started(post.id)
        message_id = publish_post(client, chat_id, post.content_type,
                                  post.body, post.media_path,
                                  split_long_text=post.split_long_text)
        self.posts.mark_sent(post.id, message_id or None)
        self._emit({"post_id": post.id, "status": "sent",
                    "message_id": message_id})
        log.info("post %s sent (msg_id=%s)", post.id, message_id)
        return "sent", f"msg_id={message_id}"

    def _on_rate_limited(self, post, exc: RateLimitError, attempts: int,
                         history_id: int | None) -> None:
        """سیاست کنترل‌شدهٔ 429: احترام به retry_after + سقف تلاش + تاریخچه.

        قبلاً باگ: 429 هرگز سقف نمی‌خورد و تا ابد حلقه می‌زد؛ و چون
        increment در ابتدای پردازش انجام می‌شد، 429 هم شمارنده را می‌سوزاند —
        اکنون 429 سقف max_attempts دارد و شمارشِ آن در تاریخچه ثبت می‌شود.
        """
        started = time.monotonic()
        delay = float(exc.retry_after or 30) + 1.0
        if attempts >= post.max_attempts:
            err = (f"محدودیت نرخ تلگرام پس از {attempts} تلاش؛ "
                   f"retry_after={int(delay)}s — تلاش مجدد متوقف شد")
            self.posts.mark_failed(post.id, err, permanent=True)
            self.posts.record_attempt_end(
                history_id, "rate_limited_exhausted", err,
                int((time.monotonic() - started) * 1000))
            self._emit({"post_id": post.id, "status": "failed", "error": err})
            log.warning("post %s rate-limited beyond max attempts", post.id)
            return
        note = f"429 محدودیت نرخ؛ تلاش مجدد پس از {int(delay)} ثانیه"
        self.posts.schedule_retry(post.id, delay, note)
        self.posts.record_attempt_end(
            history_id, "rate_limited", note,
            int((time.monotonic() - started) * 1000))
        self._emit({"post_id": post.id, "status": "pending",
                    "error": f"429 retry_after={delay}"})
        log.warning("post %s rate-limited, retry in %.0fs", post.id, delay)
