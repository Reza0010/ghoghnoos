"""Worker پس‌زمینه به‌روزرسانی قیمت‌ها — مستقل از UI.

- UI هرگز شبکه را صدا نمی‌زند؛ این Thread هر refresh_interval یک بار
  MarketDataService.refresh را اجرا و نتیجه را از طریق callback می‌فرستد.
- خطای متوالی → backoff (تا ۱۰ دقیقه)؛ موفقیت → بازگشت به فاصله عادی.
- تغییر فاصله به‌روزرسانی در چرخه بعدی اعمال می‌شود (بدون فریز).
"""
from __future__ import annotations

import threading

from core.logging_setup import get_logger
from core.redact import scrub_text
from services.market_data.service import MarketDataService

log = get_logger("minermedia.market")


class MarketWorker(threading.Thread):
    MAX_ERROR_INTERVAL = 600.0

    def __init__(self, service: MarketDataService,
                 interval_provider,  # callable -> float (ثانیه)
                 symbols_provider):  # callable -> list[str]
        super().__init__(name="market-worker", daemon=True)
        self.service = service
        self.interval_provider = interval_provider
        self.symbols_provider = symbols_provider
        self._stop_flag = threading.Event()
        self._listeners: list = []

    def add_listener(self, callback) -> None:
        self._listeners.append(callback)

    def _emit(self, result) -> None:
        for cb in self._listeners:
            try:
                cb(result)
            except Exception:  # noqa: BLE001
                pass

    def stop_safe(self, join_timeout: float = 10.0) -> None:
        self._stop_flag.set()
        if self.is_alive():
            self.join(timeout=join_timeout)

    def run(self) -> None:
        log.info("market worker started")
        error_streak = 0
        # اولین refresh بلافاصله پس از شروع (نه بعد از یک فاصله کامل)
        self._refresh_once()
        while not self._stop_flag.is_set():
            interval = max(30.0, float(self.interval_provider() or 60))
            delay = interval
            if self.service.consecutive_errors:
                # backoff پس از خطا — هرگز حلقه شبکه‌ای سریع نمی‌زنیم
                error_streak = self.service.consecutive_errors
                delay = min(interval * (2 ** min(error_streak, 4)),
                            self.MAX_ERROR_INTERVAL)
            self._stop_flag.wait(delay)
            if self._stop_flag.is_set():
                break
            self._refresh_once()
        log.info("market worker stopped")

    def _refresh_once(self) -> None:
        try:
            result = self.service.refresh(self.symbols_provider())
            self._emit(result)
            if not result.ok and result.errors:
                log.warning("market refresh errors: %s",
                            scrub_text("; ".join(result.errors)))
        except Exception as exc:  # noqa: BLE001 — Worker هرگز نمی‌میرد
            log.error("market worker error: %s", scrub_text(str(exc)))
