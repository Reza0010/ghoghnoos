"""اجرای واقعی app.py در offscreen + رندر صفحه‌ها به PNG (شاهد بصری)."""
import os
import sys

os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["MINERMEDIA_DATA_DIR"] = "/tmp/mm_real_run"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import faulthandler
import sys as _sys

import app as app_module
from PySide6.QtCore import QTimer

# بعد از 20 ثانیه پشته همه نخ‌ها را چاپ کن (دیباگ تعلیق)
pass  # دیباگ تمام شد


def main():
    from PySide6.QtWidgets import QApplication, QMessageBox
    orig_exec = QApplication.exec

    def fake_exec(self):
        shots = {"i": 0}
        out_dir = "/home/z/my-project/workspace/screenshots"
        os.makedirs(out_dir, exist_ok=True)
        pages = [("overview", "dash_overview"), ("market", "dash_market"),
                 ("queue", "dash_queue"), ("studio", "dash_studio"),
                 ("news", "dash_news"), ("media", "dash_media"),
                 ("reports", "dash_reports"), ("channels", "dash_channels"),
                 ("settings", "dash_settings")]

        def _grab(key_name):
            key, name = key_name
            win = app_module.__dict__.get("_last_window")
            if win is None:
                return
            win.navigate(key)
            QTimer.singleShot(350, lambda: (win.grab().save(f"{out_dir}/{name}.png"),
                                            print("saved:", name)))

        def next_shot():
            idx = shots["i"]
            if idx >= len(pages):
                QApplication.instance().quit()
                return
            _grab(pages[idx])
            shots["i"] = idx + 1
            QTimer.singleShot(2500, next_shot)

        QTimer.singleShot(3000, next_shot)   # شروع صفحه‌ها
        return orig_exec()

    QApplication.exec = fake_exec

    import ui.main_window as mw
    orig_init = mw.MainWindow.__init__

    def patched_init(self, ctx):
        orig_init(self, ctx)
        app_module.__dict__["_last_window"] = self
    mw.MainWindow.__init__ = patched_init

    QMessageBox.question = staticmethod(lambda *a, **kw: QMessageBox.Yes)
    # مسیر صادقانهٔ خاموشی (هشدار «Worker عقب ماند از بودجه») هم در offscreen
    # نباید تعلیق شود — جواب خودکار OK تا بوت آزمایشی همیشه کامل شود.
    QMessageBox.warning = staticmethod(lambda *a, **kw: QMessageBox.Ok)
    QMessageBox.information = staticmethod(lambda *a, **kw: QMessageBox.Ok)
    QMessageBox.critical = staticmethod(lambda *a, **kw: QMessageBox.Ok)

    return app_module.main()


if __name__ == "__main__":
    raise SystemExit(main())
