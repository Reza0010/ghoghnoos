"""خودآزمایی شرایط پذیرش نهایی (بخش ۱۵ مأموریت) — اجرا: python scripts_dev/acceptance_check.py"""
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("MINERMEDIA_DATA_DIR", "/tmp/mm_acceptance")

RESULTS = []


def check(num: int, name: str, fn):
    try:
        ok, detail = fn()
    except Exception as exc:  # noqa: BLE001
        ok, detail = False, f"EXCEPTION: {type(exc).__name__}: {exc}"
    RESULTS.append((num, name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] #{num} {name} — {detail}")


def c1_original_preserved():
    src = ROOT / "original_source" / "Main.py"
    lines = len(src.read_text(encoding="utf-8", errors="ignore").splitlines())
    return src.exists() and lines > 2000, f"original Main.py با {lines} خط حفظ شده"


def c2_import_run():
    r = subprocess.run(
        [sys.executable, "-c", "import app; print('import-ok')"],
        capture_output=True, text=True, cwd=ROOT, timeout=60)
    return r.returncode == 0 and "import-ok" in r.stdout, "app.py بدون خطای Import"


def c3_dashboard_pages():
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    import tempfile
    from database.db import Database
    from database.repositories import (ChannelsRepo, DraftsRepo, LogsRepo,
                                       MarketRepo, MediaRepo, NewsRepo,
                                       PostsRepo, SettingsRepo)
    tmp = Path(tempfile.mkdtemp())
    db = Database(tmp / "a.db"); db.migrate()

    class Ctx:
        pass
    ctx = Ctx()
    from config.settings import AppSettings
    from security.secret_store import InMemorySecretStore
    from services.ai.provider import AIProvider
    from services.ai.studio import ContentStudioService
    from services.market_data.service import MarketDataService
    from services.media.library import MediaLibraryService
    from services.news.service import NewsService
    from services.nobitex.client import NobitexClient
    from workers.market_worker import MarketWorker
    from workers.scheduler import SchedulerService
    ctx.db = db
    ctx.settings = AppSettings(SettingsRepo(db))
    ctx.secret_store = InMemorySecretStore()
    ctx.channels_repo = ChannelsRepo(db)
    ctx.posts_repo = PostsRepo(db)
    ctx.market_repo = MarketRepo(db)
    ctx.market_repo.seed_defaults([("BTC", "Bitcoin")])
    ctx.news_repo = NewsRepo(db)
    ctx.drafts_repo = DraftsRepo(db)
    ctx.logs_repo = LogsRepo(db)
    ctx.market_service = MarketDataService(NobitexClient(), ctx.market_repo)
    ctx.news_service = NewsService(ctx.news_repo)
    ctx.ai_provider = AIProvider("", lambda: "", "")
    ctx.studio = ContentStudioService(ctx.ai_provider, ctx.drafts_repo, ctx.market_service)
    ctx.media_service = MediaLibraryService(MediaRepo(db), tmp / "media")
    ctx.scheduler = SchedulerService(ctx.posts_repo, ctx.channels_repo, ctx.secret_store)
    ctx.market_worker = MarketWorker(ctx.market_service, lambda: 60, lambda: ["BTC"])
    ctx.kick_market_worker = lambda: None
    ctx.rebuild_ai_provider = lambda: None
    from ui.main_window import MainWindow
    from PySide6.QtWidgets import QMessageBox
    QMessageBox.question = staticmethod(lambda *a, **kw: QMessageBox.Yes)
    QMessageBox.information = staticmethod(lambda *a, **kw: QMessageBox.Ok)
    win = MainWindow(ctx)
    ctx.main_window = win
    n = win.stack.count()
    win.close()
    db.close()
    return n == 9, f"{n} صفحه داشبورد عملیاتی"


def c4_watchlist_persist():
    from database.db import Database
    import tempfile
    from database.repositories import MarketRepo
    db = Database(Path(tempfile.mkdtemp()) / "w.db"); db.migrate()
    repo = MarketRepo(db)
    repo.seed_defaults([("BTC", "Bitcoin")])
    repo.add_watch("SOL", "Solana")
    repo.set_visible("SOL", False)
    repo.reorder(["SOL", "BTC"])
    repo2 = MarketRepo(db)
    ok = (not any(w.symbol == "SOL" for w in repo2.list_watch(visible_only=True))
          and [w.symbol for w in repo2.list_watch()][0] == "SOL")
    db.close()
    return ok, "افزودن/حذف/ترتیب/پدیداری ذخیره و بازیابی شد"


def c5_nobitex_endpoint():
    src = (ROOT / "services" / "nobitex" / "client.py").read_text(encoding="utf-8")
    ok = "/market/stats" in src and "/market/udf/history" in src and \
        "apiv2.nobitex.ir" in src
    return ok, "فقط endpointهای مستندشده apidocs.nobitex.ir"


def c6_rial_toman():
    from core.units import rial_to_toman
    return rial_to_toman(10) == 1, "هر ۱۰ ریال = ۱ تومان (تست خودکار هم دارد)"


def c7_stale_missing_labels():
    ov = (ROOT / "ui" / "overview_page.py").read_text(encoding="utf-8")
    mk = (ROOT / "ui" / "market_page.py").read_text(encoding="utf-8")
    ok = "ناموجود" in ov and "کهنه" in mk and "در حال دریافت" in ov
    return ok, "برچسب‌های ناموجود/کهنه/در حال دریافت در UI"


def c8_scheduler_independent():
    sch = (ROOT / "workers" / "scheduler.py").read_text(encoding="utf-8")
    no_ai = "services.ai" not in sch and "ContentStudio" not in sch
    return no_ai and "publish_post" in sch, \
        "زمان‌بند هیچ importی از services.ai ندارد (فقط ارسال)"


def c9_no_blind_resend():
    sch = (ROOT / "workers" / "scheduler.py").read_text(encoding="utf-8")
    return "mark_unknown" in sch and 'phase == "read"' in sch, \
        "نتیجه مبهم → unknown؛ resend فقط با کاربر"


def c10_multichannel():
    from database.db import Database
    import tempfile
    from database.repositories import ChannelsRepo, PostsRepo
    db = Database(Path(tempfile.mkdtemp()) / "m.db"); db.migrate()
    ch = ChannelsRepo(db); posts = PostsRepo(db)
    a = ch.add("A", "@a", ""); b = ch.add("B", "@b", "")
    ids = posts.create_group([
        {"channel_id": a, "content_type": "text", "body": "x", "scheduled_at_utc": "2026-01-01T00:00:00+00:00"},
        {"channel_id": b, "content_type": "text", "body": "x", "scheduled_at_utc": "2026-01-01T00:00:00+00:00"}])
    posts.mark_sent(ids[0], 1)
    st0 = posts.get(ids[0]).status
    st1 = posts.get(ids[1]).status
    db.close()
    return st0 == "sent" and st1 == "pending", "نتیجه هر کانال مستقل ثبت می‌شود"


def c11_secrets_secure():
    ss = (ROOT / "security" / "secret_store.py").read_text(encoding="utf-8")
    return "keyring" in ss and "Credential" in ss, "توکن‌ها در Credential Manager"


def c12_no_ui_freeze():
    w = (ROOT / "workers" / "market_worker.py").read_text(encoding="utf-8")
    t = (ROOT / "workers" / "scheduler.py").read_text(encoding="utf-8")
    s = (ROOT / "ui" / "market_page.py").read_text(encoding="utf-8")
    ok = "threading.Thread" in t and "threading.Thread" in w and "QThread" in s
    return ok, "شبکه فقط در Thread (Scheduler/MarketWorker/QThread)"


def c13_tests_run():
    r = subprocess.run([sys.executable, "-m", "pytest", "tests/"],
                       capture_output=True, text=True, cwd=ROOT, timeout=300)
    both = r.stdout + r.stderr
    import re as _re
    m = _re.search(r"(\d+) passed", both)
    failed = _re.search(r"(\d+) failed", both)
    ok = r.returncode == 0 and m and not failed
    return ok, f"pytest: {m.group(0) if m else 'بدون خروجی'} (exit={r.returncode})"


def c14_docs():
    docs = ["README.md", "docs/INSTALL.md", "docs/BOT_TOKEN.md", "docs/NOBITEX_API.md",
            "docs/AI_SETUP.md", "docs/BACKUP_RESTORE.md", "docs/LIMITATIONS.md",
            "docs/TEST_REPORT.md", "CHANGELOG.md"]
    missing = [d for d in docs if not (ROOT / d).exists()]
    return not missing, f"{len(docs) - len(missing)}/{len(docs)} سند موجود"


def c15_no_exe():
    exes = [p for p in ROOT.rglob("*.exe")]
    return not exes, "هیچ فایل EXE در پروژه وجود ندارد"


# ----------------------- v2.0.1 — پایداری و سخت‌سازی -----------------------
def c16_safe_shutdown():
    sh = (ROOT / "core" / "shutdown.py").read_text(encoding="utf-8")
    mw = (ROOT / "ui" / "main_window.py").read_text(encoding="utf-8")
    db = (ROOT / "database" / "db.py").read_text(encoding="utf-8")
    ok = ("close_database_safely" in sh and "shutdown_background_workers" in sh
          and "shutdown_background_workers" in mw and "is_closed" in db
          and "close_database_safely(self.ctx.db" in mw)
    return ok, "خاموشی: Workerها واقعاً متوقف، DB فقط بعد از آن بسته می‌شود"


def c17_claim_recovery_split():
    pr = (ROOT / "database" / "repositories" / "posts_repo.py").read_text(encoding="utf-8")
    mig = (ROOT / "database" / "migrations" / "002_hardening.sql").read_text(encoding="utf-8")
    ok = ("claim_one" in pr and "mark_send_started" in pr
          and "send_started_at IS NULL" in pr and "send_started_at" in mig)
    return ok, "claim تک‌تک + تفکیک send_started_at در بازیابی (بدون unknown اشتباه)"


def c18_nobitex_fallback_separated():
    svc = (ROOT / "services" / "market_data" / "service.py").read_text(encoding="utf-8")
    ok = "fallback_worthy" in svc and "batch_exc" in svc \
        and 'status_code", None) == 400' in svc
    return ok, "fallback تک‌نمادی فقط برای 400؛ روی 429/شبکه هیچ درخواست اضافه"


def c19_news_worker():
    w = (ROOT / "workers" / "news_worker.py").exists()
    app = (ROOT / "app.py").read_text(encoding="utf-8")
    st = (ROOT / "config" / "settings.py").read_text(encoding="utf-8")
    ok = w and "NewsWorker" in app and "news_refresh_sec" in app \
        and "enabled_news_sources" in st
    return ok, "Worker زمان‌بندی‌شده اخبار با فاصله/منابع فعال از تنظیمات"


def c20_media_matrix():
    qp = (ROOT / "ui" / "queue_page.py").read_text(encoding="utf-8")
    cl = (ROOT / "services" / "telegram" / "client.py").read_text(encoding="utf-8")
    ok = ("QCheckBox" in qp and '"album"' in qp and '"audio"' in qp
          and "validate_media_for_send" in qp and "_publish_album" in cl
          and "split_long_text" in cl)
    return ok, "audio/آلبوم از UI تا کلاینت + اعتبارسنجی قبل از زمان‌بندی"


def c21_attempt_history():
    pr = (ROOT / "database" / "repositories" / "posts_repo.py").read_text(encoding="utf-8")
    sch = (ROOT / "workers" / "scheduler.py").read_text(encoding="utf-8")
    mig = (ROOT / "database" / "migrations" / "002_hardening.sql").read_text(encoding="utf-8")
    ok = ("post_attempts" in pr and "record_attempt_start" in pr
          and "record_attempt_end" in sch and "post_attempts" in mig
          and "rate_limited_exhausted" in sch)
    return ok, "تاریخچه تلاش + سقف 429 (rate_limited_exhausted)"


check(1, "سورس اصلی حفظ شده", c1_original_preserved)
check(2, "اجرای بدون خطای Import", c2_import_run)
check(3, "داشبورد حرفه‌ای و ۹ صفحه عملیاتی", c3_dashboard_pages)
check(4, "فهرست منتخب قابل تغییر و ذخیره", c4_watchlist_persist)
check(5, "قیمت نوبیتکس از endpoint مستندشده", c5_nobitex_endpoint)
check(6, "واحد ریال/تومان صحیح", c6_rial_toman)
check(7, "نمایش صحیح داده ناموجود/کهنه", c7_stale_missing_labels)
check(8, "صف مستقل از تولید AI", c8_scheduler_independent)
check(9, "عدم ارسال کورکورانه مجدد", c9_no_blind_resend)
check(10, "چندکاناله با نتیجه مستقل", c10_multichannel)
check(11, "نگهداری امن کلیدها", c11_secrets_secure)
check(12, "عدم فریز UI در عملیات طولانی", c12_no_ui_freeze)
check(13, "تست‌های اجراشده واقعی", c13_tests_run)
check(14, "مستندات به‌روز", c14_docs)
check(15, "هیچ EXE ساخته نشده", c15_no_exe)
check(16, "خاموش‌شدن امن (مأموریت ۱)", c16_safe_shutdown)
check(17, "بازیابی صحیح صف (مأموریت ۲)", c17_claim_recovery_split)
check(18, "تفکیک خطای نوبیتکس (مأموریت ۳)", c18_nobitex_fallback_separated)
check(19, "Worker اخبار زمان‌بندی‌شده (مأموریت ۴)", c19_news_worker)
check(20, "ماتریس رسانه و اعتبارسنجی (مأموریت ۵)", c20_media_matrix)
check(21, "تاریخچه تلاش و سقف 429 (مأموریت ۲)", c21_attempt_history)

passed = sum(1 for _, _, ok, _ in RESULTS if ok)
print(f"\n=== شرایط پذیرش: {passed}/{len(RESULTS)} ===")
sys.exit(0 if passed == len(RESULTS) else 1)
