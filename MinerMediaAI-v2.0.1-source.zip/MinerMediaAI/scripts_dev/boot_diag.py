"""تشخیص تعلیق خروج: بعد از 45 ثانیه پشتهٔ همهٔ Threadها را چاپ می‌کند و خارج می‌شود."""
import faulthandler
import os
import sys

os.environ["QT_QPA_PLATFORM"] = "offscreen"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 45 ثانیه بعد از شروع، اگر پروسه هنوز زنده بود = تعلیق؛ پشته‌ها را بریز و تمام کن
faulthandler.dump_traceback_later(45, exit=True)

import scripts_dev.boot_and_screenshot as boot

if __name__ == "__main__":
    raise SystemExit(boot.main())
