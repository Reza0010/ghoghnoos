"""تست سرویس اخبار: parse فید محلی، dedupe، قطعی منبع، سیاست تأیید."""
import pytest

from services.news.service import NewsService

SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel>
<title>Test Mining News</title>
<item>
  <title>Bitmain announces new Antminer series</title>
  <link>https://example.com/news/1</link>
  <guid>tag:example.com,2026:news/1</guid>
  <pubDate>Tue, 06 Oct 2026 10:00:00 GMT</pubDate>
  <description>ASIC miners with improved hashrate for bitcoin mining</description>
</item>
<item>
  <title>Bitcoin network difficulty reaches new high</title>
  <link>https://example.com/news/2</link>
  <guid>tag:example.com,2026:news/2</guid>
  <pubDate>Tue, 06 Oct 2026 09:00:00 GMT</pubDate>
  <description>mining difficulty increased; miners monitor electricity energy cost</description>
</item>
</channel></rss>"""


class _Resp:
    def __init__(self, content, status_code=200):
        self.content = content
        self.status_code = status_code


class _Session:
    def __init__(self, responses):
        self.responses = responses
        self.calls = []

    def get(self, url, headers=None, timeout=None):
        self.calls.append(url)
        r = self.responses.get(url) or next(iter(self.responses.values()))
        if isinstance(r, Exception):
            raise r
        return r


def test_fetch_parses_and_dedupes(tmp_path):
    session = _Session({"https://feed.example/rss": _Resp(SAMPLE_FEED.encode())})
    from database.db import Database
    db = Database(tmp_path / "n.db"); db.migrate()
    from database.repositories import NewsRepo
    repo = NewsRepo(db)
    svc = NewsService(repo, session=session)
    result = svc.fetch_all([("TestFeed", "https://feed.example/rss", "mining")])
    assert result.ok and result.updated == 2
    items = repo.list()
    assert len(items) == 2
    # دریافت دوباره: هیچ تکراری اضافه نمی‌شود
    result2 = svc.fetch_all([("TestFeed", "https://feed.example/rss", "mining")])
    assert result2.updated == 0
    assert len(repo.list()) == 2
    # برچسب موضوعی خودکار
    topics = " ".join(i.topic for i in items)
    assert "hardware" in topics or "bitcoin" in topics or "mining" in topics
    db.close()


def test_source_failure_does_not_break_others(tmp_path):
    from database.db import Database
    db = Database(tmp_path / "n2.db"); db.migrate()
    from database.repositories import NewsRepo
    repo = NewsRepo(db)
    import requests as _rq
    session = _Session({
        "https://broken/rss": _rq.exceptions.ConnectionError("down"),
        "https://good/rss": _Resp(SAMPLE_FEED.encode()),
    })
    svc = NewsService(repo, session=session)
    result = svc.fetch_all([("Broken", "https://broken/rss", "x"),
                            ("Good", "https://good/rss", "x")])
    assert result.updated == 2
    assert len(result.errors) == 1 and "Broken" in result.errors[0]
    db.close()


def test_offline_no_fresh_news_invented(tmp_path):
    """نبود وب → هیچ خبر تازه‌ای «تولید» نمی‌شود؛ فقط خطا ثبت می‌شود."""
    from database.db import Database
    db = Database(tmp_path / "n3.db"); db.migrate()
    from database.repositories import NewsRepo
    repo = NewsRepo(db)
    import requests as _rq
    session = _Session({"https://down/rss": _rq.exceptions.ConnectTimeout("x")})
    svc = NewsService(repo, session=session)
    result = svc.fetch_all([("Down", "https://down/rss", "x")])
    assert not result.ok
    assert result.updated == 0
    assert len(repo.list()) == 0
    db.close()


def test_news_workflow_statuses(tmp_path):
    from database.db import Database
    db = Database(tmp_path / "n4.db"); db.migrate()
    from database.repositories import NewsRepo
    repo = NewsRepo(db)
    svc = NewsService(repo, session=_Session({}))
    from models.entities import NewsItem
    item = NewsItem(id=None, guid="g", title="t", link="l", source="s")
    repo.upsert(item)
    stored = repo.list()[0]
    svc.set_status(stored.id, "approved")
    assert repo.get(stored.id).status == "approved"
    with pytest.raises(Exception):
        svc.set_status(stored.id, "bogus")
    db.close()


def test_publishable_policy(tmp_path):
    from models.entities import NewsItem, NewsStatus
    svc = NewsService(None, session=_Session({}))
    new = NewsItem(id=1, guid="g", title="t", link="l", source="s")
    approved = NewsItem(id=2, guid="g", title="t", link="l", source="s",
                        status=NewsStatus.APPROVED.value)
    rejected = NewsItem(id=3, guid="g", title="t", link="l", source="s",
                        status=NewsStatus.REJECTED.value)
    # با الزام تأیید (پیش‌فرض): فقط تأییدشده منتشرشدنی است
    assert svc.publishable(new, True) is False
    assert svc.publishable(approved, True) is True
    assert svc.publishable(rejected, True) is False
    # بدون الزام: ردشده همچنان ممنوع
    assert svc.publishable(new, False) is True
    assert svc.publishable(rejected, False) is False
