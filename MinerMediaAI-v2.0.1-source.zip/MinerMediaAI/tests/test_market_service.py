"""تست سرویس بازار: تفسیر واحد، staleness، تخمین، نمونه‌برداری، عدم داده ساختگی."""
import pytest

from core.timeutils import utc_iso
from services.market_data.service import MarketDataService
from services.nobitex.client import NobitexClient
from tests.conftest import FakeResponse  # noqa: F401
from tests.test_nobitex_client import VALID_STATS  # noqa: F401


import json as _json

# پاسخ جداگانه نرخ USDT/RLS (درخواست دوم — زوج usdt-usdt نامعتبر است)
USDT_RLS = '{"status":"ok","stats":{"usdt-rls":{"latest":"2650900","dayChange":"0.05"}}}'


def make_service(fake_session_cls, interval=60.0):
    # درخواست ۱: دسته ارزها؛ درخواست ۲: نرخ USDT/RLS (جداگانه — زوج usdt-usdt نامعتبر است)
    session = fake_session_cls(get_results=[
        FakeResponse(200, VALID_STATS),
        FakeResponse(200, _json.loads(USDT_RLS))])
    client = NobitexClient(session=session, stats_min_interval=0.0,
                           udf_min_interval=0.0)
    return client, MarketDataService(client, None, interval)


def test_rial_parsing_is_exact(fake_session_cls):
    """rls → ریال (مستند نوبیتکس)؛ مقادیر رشته به عدد صحیح."""
    from database.db import Database
    import tempfile, pathlib
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "m.db"); db.migrate()
    from database.repositories import MarketRepo
    repo = MarketRepo(db)
    repo.seed_defaults([("BTC", "Bitcoin")])
    client, _ = make_service(fake_session_cls)
    svc = MarketDataService(client, repo, 60)
    result = svc.refresh(["BTC"])
    assert result.ok
    q = repo.get_quote("BTC", "BTCIRT")
    assert q is not None
    assert q["currency"] == "RIAL"
    assert q["price"] == 219456369080.0
    assert q["source"] == "nobitex"
    assert q["stale"] == 0
    # جفت دلاری هم جداگانه ذخیره شده
    qu = repo.get_quote("BTC", "BTCUSDT")
    assert qu["currency"] == "USDT"
    assert qu["price"] == 82790.0
    db.close()


def test_display_price_toman_is_rial_divided_by_ten(fake_session_cls):
    """تومان = ریال ÷ ۱۰ — دقیق و بدون حدس."""
    from database.db import Database
    import tempfile, pathlib
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "m.db"); db.migrate()
    from database.repositories import MarketRepo
    repo = MarketRepo(db); repo.seed_defaults([("BTC", "Bitcoin")])
    client, _ = make_service(fake_session_cls)
    svc = MarketDataService(client, repo, 60)
    svc.refresh(["BTC"])
    info = svc.display_price("BTC", "TOMAN")
    assert info["exact"] is True
    assert info["estimated"] is False
    assert abs(info["price"] - 21945636908.0) < 1e-6
    db.close()


def test_missing_symbol_is_not_fabricated(fake_session_cls):
    """ارزی که پاسخ نداده → بدون قیمت؛ هیچ مقدار ساختگی ساخته نمی‌شود."""
    from database.db import Database
    import tempfile, pathlib
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "m.db"); db.migrate()
    from database.repositories import MarketRepo
    repo = MarketRepo(db); repo.seed_defaults([("XYZ", "Ghost")])
    client, _ = make_service(fake_session_cls)
    svc = MarketDataService(client, repo, 60)
    result = svc.refresh(["BTC", "XYZ"])
    assert "XYZIRT" in result.missing
    assert svc.display_price("XYZ", "TOMAN") is None
    db.close()


def test_network_failure_marks_stale_keeps_last_price(fake_session_cls):
    """قطع اتصال: آخرین قیمت معتبر می‌ماند و stale می‌شود."""
    from database.db import Database
    import tempfile, pathlib
    import requests
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "m.db"); db.migrate()
    from database.repositories import MarketRepo
    repo = MarketRepo(db); repo.seed_defaults([("BTC", "Bitcoin")])
    session = fake_session_cls(get_results=[
        FakeResponse(200, VALID_STATS),
        FakeResponse(200, _json.loads(USDT_RLS)),      # refresh اول: موفق
        requests.exceptions.ConnectionError("down"),   # refresh دوم: قطع
        requests.exceptions.ConnectionError("down")])
    client = NobitexClient(session=session, stats_min_interval=0.0)
    svc = MarketDataService(client, repo, 60)
    assert svc.refresh(["BTC"]).ok
    result2 = svc.refresh(["BTC"])
    assert not result2.ok and result2.errors
    q = repo.get_quote("BTC", "BTCIRT")
    assert q["price"] == 219456369080.0   # آخرین قیمت معتبر حفظ شده
    assert q["stale"] == 1
    assert svc.consecutive_errors == 1
    db.close()


def test_estimated_rial_requires_both_fresh(fake_session_cls):
    """تخمین ریالی فقط با جفت USDT + نرخ USDTIRT تازه."""
    from database.db import Database
    import tempfile, pathlib
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "m.db"); db.migrate()
    from database.repositories import MarketRepo
    repo = MarketRepo(db); repo.seed_defaults([("BTC", "Bitcoin")])
    client, _ = make_service(fake_session_cls)
    svc = MarketDataService(client, repo, 60)
    svc.refresh(["BTC"])
    est = svc.estimate_rial("BTC")
    # جفت rls مستقیم داریم؛ تخمین هم باید با همان داده‌های تازه قابل محاسبه باشد
    assert est is not None
    assert abs(est["rial"] - 82790.0 * svc.get_quote("USDT", "USDTIRT").price) < 1e-3
    db.close()


def test_estimation_refuses_stale_rate(fake_session_cls):
    """اگر نرخ USDT/RLS کهنه شود، تخمین ممنوع است."""
    from database.db import Database
    import tempfile, pathlib
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "m.db"); db.migrate()
    from database.repositories import MarketRepo
    repo = MarketRepo(db); repo.seed_defaults([("DOGE", "Dogecoin")])
    client, _ = make_service(fake_session_cls)
    svc = MarketDataService(client, repo, 60)
    # هیچ refresh موفقی نداشته → داده‌ای وجود ندارد → تخمین None
    assert svc.estimate_rial("DOGE") is None
    db.close()


def test_sample_throttle_60s(fake_session_cls):
    """نمونه‌برداری محلی حداکثر هر ~۶۰ ثانیه."""
    from database.db import Database
    import tempfile, pathlib
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "m.db"); db.migrate()
    from database.repositories import MarketRepo
    repo = MarketRepo(db); repo.seed_defaults([("BTC", "Bitcoin")])
    client, _ = make_service(fake_session_cls)
    svc = MarketDataService(client, repo, 60)
    svc.refresh(["BTC"])
    n1 = len(repo.samples("BTC", "BTCIRT", utc_iso()))
    # refresh فوری بعدی نباید نمونه جدید اضافه کند
    session2 = fake_session_cls(get_results=[
        FakeResponse(200, VALID_STATS),
        FakeResponse(200, _json.loads(USDT_RLS))])
    svc.client = NobitexClient(session=session2, stats_min_interval=0.0)
    svc.refresh(["BTC"])
    n2 = len(repo.samples("BTC", "BTCIRT", utc_iso()))
    assert n2 == n1  # بدون نمونه تکراری فوری
    db.close()
