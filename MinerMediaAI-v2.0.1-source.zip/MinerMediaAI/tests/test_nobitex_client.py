"""تست کلاینت نوبیتکس — پاسخ معتبر، خطاها، timeout، JSON نامعتبر، محدودیت نرخ."""
import pytest
import requests

from core.errors import NetworkError, NobitexError, RateLimitError
from core.redact import contains_secret
from services.nobitex.client import NobitexClient
from tests.conftest import FakeResponse

FAKE_TOKEN = "1234567890:AAH1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6"

VALID_STATS = {
    "status": "ok",
    "stats": {
        "btc-rls": {
            "isClosed": False, "bestSell": "219454174520",
            "bestBuy": "218998467820", "volumeSrc": "5.67",
            "volumeDst": "1243967121872.4", "latest": "219456369080",
            "mark": "220258593110", "dayLow": "216350010020",
            "dayHigh": "220466905460", "dayOpen": "219797979200",
            "dayClose": "219456369080", "dayChange": "-0.16",
        },
        "btc-usdt": {"isClosed": False, "latest": "82790", "dayChange": "0.17"},
        "usdt-rls": {"isClosed": False, "latest": "2650900",
                     "dayChange": "0.05"},
    },
    "global": {"binance": {}},
}


def make_client(session, stats_interval=0.0, udf_interval=0.0):
    return NobitexClient(session=session, stats_min_interval=stats_interval,
                         udf_min_interval=udf_interval)


def test_valid_stats_response(fake_session_cls):
    session = fake_session_cls(get_results=[FakeResponse(200, VALID_STATS)])
    client = make_client(session)
    stats = client.market_stats(["btc"], ["rls", "usdt"])
    assert stats["btc-rls"]["latest"] == "219456369080"
    assert stats["btc-usdt"]["dayChange"] == "0.17"
    # هدر User-Agent الزامی طبق ملاحظات عمومی نوبیتکس
    url, params, headers = session.get_calls[0]
    assert headers["User-Agent"].startswith("TraderBot/")
    assert params["srcCurrency"] == "btc"
    assert params["dstCurrency"] == "rls,usdt"


def test_invalid_currency_400(fake_session_cls):
    session = fake_session_cls(get_results=[FakeResponse(
        400, {"status": "failed", "code": "InvalidCurrency", "message": "x"})])
    client = make_client(session)
    with pytest.raises(NobitexError) as exc:
        client.market_stats(["nonexistentxyz"], ["rls"])
    assert exc.value.status_code == 400
    assert exc.value.code == "InvalidCurrency"


def test_timeout_connect_is_transient(fake_session_cls):
    session = fake_session_cls(get_results=[
        requests.exceptions.ConnectTimeout("t")])
    client = make_client(session)
    with pytest.raises(NetworkError) as exc:
        client.market_stats(["btc"], ["rls"])
    assert exc.value.phase == "connect"


def test_invalid_json(fake_session_cls):
    session = fake_session_cls(get_results=[FakeResponse(200, None)])
    client = make_client(session)
    with pytest.raises(NobitexError):
        client.market_stats(["btc"], ["rls"])


def test_429_with_retry_after(fake_session_cls):
    session = fake_session_cls(get_results=[FakeResponse(
        429, {"status": "failed"}, headers={"Retry-After": "7"})])
    client = make_client(session)
    with pytest.raises(RateLimitError) as exc:
        client.market_stats(["btc"], ["rls"])
    assert exc.value.retry_after == 7.0


def test_rate_limiter_enforces_min_interval(fake_session_cls):
    session = fake_session_cls(get_results=[
        FakeResponse(200, VALID_STATS), FakeResponse(200, VALID_STATS)])
    client = make_client(session, stats_interval=0.3)
    import time
    t0 = time.monotonic()
    client.market_stats(["btc"], ["rls"])
    client.market_stats(["btc"], ["rls"])
    elapsed = time.monotonic() - t0
    assert elapsed >= 0.25  # فراخوانی دوم صبر کرده است


def test_udf_valid(fake_session_cls):
    udf = {"s": "ok", "t": [1791703800], "o": [21743063877.0],
           "h": [21848999999.0], "l": [21735896360.0],
           "c": [21945636908.0], "v": [12.5]}
    session = fake_session_cls(get_results=[FakeResponse(200, udf)])
    client = make_client(session)
    out = client.udf_history("BTCIRT", "60", to_ts=1791711000, countback=3)
    assert out["s"] == "ok"
    assert out["c"] == [21945636908.0]
    url, params, _ = session.get_calls[0]
    assert params["symbol"] == "BTCIRT"
    assert params["countback"] == 3


def test_udf_no_data_is_not_error(fake_session_cls):
    session = fake_session_cls(get_results=[FakeResponse(200, {"s": "no_data"})])
    client = make_client(session)
    out = client.udf_history("BTCIRT", "D", to_ts=100)
    assert out["s"] == "no_data"


def test_udf_invalid_resolution_rejected_locally(fake_session_cls):
    session = fake_session_cls()
    client = make_client(session)
    with pytest.raises(NobitexError):
        client.udf_history("BTCIRT", "99", to_ts=100)
    assert session.get_calls == []  # هیچ درخواستی ارسال نشده


def test_udf_error_response(fake_session_cls):
    session = fake_session_cls(get_results=[FakeResponse(
        200, {"s": "error", "errmsg": "Invalid resolution!"})])
    client = make_client(session)
    with pytest.raises(NobitexError):
        client.udf_history("BTCIRT", "D", to_ts=100)


def test_token_like_message_is_scrubbed(fake_session_cls):
    """پیام خطا نباید توکن/کلید احتمالی را فاش کند."""
    session = fake_session_cls(get_results=[FakeResponse(
        500, {"status": "failed", "message": "boom 123456789:AAHxyz1234567890123456789012345678901"})])
    client = make_client(session)
    from core.redact import contains_secret
    with pytest.raises(NobitexError) as exc:
        client.market_stats(["btc"], ["rls"])
    assert not contains_secret(exc.value.technical)
