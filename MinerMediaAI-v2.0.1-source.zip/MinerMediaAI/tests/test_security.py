"""تست امنیت: انتخاب بک‌اند، file store، پاک‌سازی توکن در لاگ."""
import logging
import stat

import pytest

from core.errors import SecretStoreError
from core.redact import contains_secret, scrub, scrub_text
from core.logging_setup import SecretScrubbingFilter
from security.secret_store import (FileSecretStore, InMemorySecretStore,
                                   create_secret_store)

FAKE_TOKEN = "1234567890:AAH1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6"
FAKE_KEY = "sk-proj-abcdef123456ghijklmnop"


def test_scrub_telegram_token():
    text = f"error calling https://api.telegram.org/bot{FAKE_TOKEN}/sendMessage failed"
    out = scrub_text(text)
    assert FAKE_TOKEN not in out
    assert "REDACTED" in out
    assert contains_secret(text) and not contains_secret(out)


def test_scrub_openai_key():
    out = scrub_text(f"auth failed for key {FAKE_KEY}")
    assert FAKE_KEY not in out


def test_scrub_url_param():
    out = scrub_text("http://x/?token=abcdef123456&x=1")
    assert "abcdef123456" not in out


def test_scrub_recursive():
    data = {"a": FAKE_TOKEN, "b": [f"sk-abcdefgh1234567890xx", "پاک"]}
    out = scrub(data)
    assert FAKE_TOKEN not in str(out)
    assert "پاک" in str(out)


def test_logging_filter_scrubs(caplog):
    logger = logging.getLogger("scrub_test")
    logger.addFilter(SecretScrubbingFilter())
    with caplog.at_level(logging.INFO):
        logger.info(f"token={FAKE_TOKEN} leaked?")
    assert FAKE_TOKEN not in caplog.text


def test_file_secret_store_roundtrip(tmp_path):
    store = FileSecretStore(tmp_path / "secrets.json")
    assert store.insecure is True          # هشدار صادقانه
    store.set_secret("ai.api_key", FAKE_KEY)
    store.set_secret("tg", FAKE_TOKEN)
    assert store.get_secret("ai.api_key") == FAKE_KEY
    assert store.get_secret("tg") == FAKE_TOKEN
    store.delete_secret("tg")
    assert store.get_secret("tg") is None
    # مقاوم در برابر بازخوانی
    store2 = FileSecretStore(tmp_path / "secrets.json")
    assert store2.get_secret("ai.api_key") == FAKE_KEY


def test_file_secret_store_permissions(tmp_path):
    import sys
    store = FileSecretStore(tmp_path / "secrets.json")
    store.set_secret("k", "v")
    if not sys.platform.startswith("win"):
        mode = stat.S_IMODE((tmp_path / "secrets.json").stat().st_mode)
        assert mode & 0o077 == 0           # فقط مالک دسترسی دارد


def test_file_store_corrupt_raises(tmp_path):
    p = tmp_path / "secrets.json"
    p.write_text("این JSON نیست", encoding="utf-8")
    with pytest.raises(SecretStoreError):
        FileSecretStore(p)


def test_in_memory_store():
    s = InMemorySecretStore()
    s.set_secret("k", "v")
    assert s.get_secret("k") == "v"
    s.delete_secret("k")
    assert s.get_secret("k") is None


def test_create_store_fallback(tmp_path, monkeypatch):
    """اگر keyring کاربردی نباشد → file store با پرچم insecure."""
    import security.secret_store as ss

    def broken_init(self, *a, **kw):
        raise SecretStoreError("no keyring", "x")
    monkeypatch.setattr(ss.KeyringSecretStore, "__init__", broken_init)
    store = create_secret_store(tmp_path)
    assert isinstance(store, FileSecretStore)
    assert store.insecure is True
