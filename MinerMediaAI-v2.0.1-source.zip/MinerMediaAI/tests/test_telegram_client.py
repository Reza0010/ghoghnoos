"""تست کلاینت تلگرام: مخفی‌سازی توکن، 429، خطای دائمی/موقت، اعتبارسنجی رسانه."""
import pytest

from tests.conftest import FakeResponse
from core.errors import (MediaError, NetworkError, RateLimitError,
                         TelegramError)
from core.redact import contains_secret
from services.telegram.client import TelegramBotClient
from services.telegram.media import validate_media_for_send

FAKE_TOKEN = "1234567890:AAH1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6"


def make_client(session):
    return TelegramBotClient(lambda: FAKE_TOKEN, session=session)


def test_send_message_ok(fake_session_cls):
    session = fake_session_cls(post_results=[FakeResponse(
        200, {"ok": True, "result": {"message_id": 42}})])
    client = make_client(session)
    result = client.send_message("@chan", "سلام")
    assert result["message_id"] == 42
    url, data, _ = session.post_calls[0]
    assert url.endswith("/sendMessage")
    assert data["chat_id"] == "@chan"


def test_token_never_leaks_on_network_error(fake_session_cls):
    """توکن ربات در URL است؛ هر خطای شبکه باید scrub شود."""
    session = fake_session_cls(post_results=[
        __import__("requests").exceptions.ConnectionError(
            f"connection to api.telegram.org failed: bot{FAKE_TOKEN}/sendMessage")])
    client = make_client(session)
    with pytest.raises(NetworkError) as exc:
        client.send_message("@chan", "hi")
    assert not contains_secret(exc.value.technical)


def test_429_parses_retry_after(fake_session_cls):
    session = fake_session_cls(post_results=[FakeResponse(
        429, {"ok": False, "error_code": 429, "description": "Too Many Requests",
              "parameters": {"retry_after": 17}})])
    client = make_client(session)
    with pytest.raises(RateLimitError) as exc:
        client.send_message("@chan", "hi")
    assert exc.value.retry_after == 17.0


def test_403_is_permanent(fake_session_cls):
    session = fake_session_cls(post_results=[FakeResponse(
        403, {"ok": False, "error_code": 403,
              "description": "bot is not a member of the channel chat"})])
    client = make_client(session)
    with pytest.raises(TelegramError) as exc:
        client.send_message("@chan", "hi")
    assert exc.value.status_code == 403


def test_500_is_transient(fake_session_cls):
    session = fake_session_cls(post_results=[FakeResponse(
        500, {"ok": False, "error_code": 500, "description": "internal"})])
    client = make_client(session)
    with pytest.raises(NetworkError):
        client.send_message("@chan", "hi")


def test_read_timeout_is_ambiguous(fake_session_cls):
    """timeout در فاز read → نتیجه مبهم (برای policy ارسال دوباره حیاتی است)."""
    import requests
    session = fake_session_cls(post_results=[requests.exceptions.ReadTimeout("t")])
    client = make_client(session)
    with pytest.raises(NetworkError) as exc:
        client.send_message("@chan", "hi")
    assert exc.value.phase == "read"


def test_empty_text_rejected_locally(fake_session_cls):
    client = make_client(fake_session_cls())
    with pytest.raises(TelegramError):
        client.send_message("@chan", "   ")


def test_text_too_long_rejected(fake_session_cls):
    client = make_client(fake_session_cls())
    with pytest.raises(TelegramError):
        client.send_message("@chan", "x" * 4097)


def test_caption_limit_for_media(fake_session_cls, tmp_path):
    photo = tmp_path / "p.jpg"
    photo.write_bytes(b"\xff\xd8\xff" + b"0" * 100)
    client = make_client(fake_session_cls())
    with pytest.raises(TelegramError):
        client.send_photo("@chan", str(photo), "c" * 1025)


def test_missing_media_file(fake_session_cls):
    client = make_client(fake_session_cls())
    with pytest.raises(MediaError):
        client.send_photo("@chan", "/nonexistent/file.jpg", "cap")


def test_media_validation(tmp_path):
    from config import defaults as cfg
    big = tmp_path / "big.jpg"
    big.write_bytes(b"0" * (cfg.MAX_PHOTO_MB * 1024 * 1024 + 1))
    with pytest.raises(MediaError):
        validate_media_for_send(str(big), "sendPhoto")
    bad_ext = tmp_path / "x.exe"
    bad_ext.write_bytes(b"MZ")
    with pytest.raises(MediaError):
        validate_media_for_send(str(bad_ext), "sendPhoto")
    ok = tmp_path / "ok.png"
    ok.write_bytes(b"0" * 1024)
    assert validate_media_for_send(str(ok), "sendPhoto").exists()


def test_send_photo_ok(fake_session_cls, tmp_path):
    photo = tmp_path / "p.jpg"
    photo.write_bytes(b"\xff\xd8\xff" + b"0" * 100)
    session = fake_session_cls(post_results=[FakeResponse(
        200, {"ok": True, "result": {"message_id": 7}})])
    client = make_client(session)
    res = client.send_photo("@chan", str(photo), "کپشن")
    assert res["message_id"] == 7
    url, data, files = session.post_calls[0]
    assert url.endswith("/sendPhoto")
    assert "photo" in files
