"""تست مهاجرت‌ها و ریپازیتوری‌ها: idempotency، قید یکتایی، claim اتمی، تنظیمات."""
import pytest

from core.errors import ValidationError
from core.timeutils import utc_iso
from database.db import Database


def test_migrations_idempotent(tmp_path):
    db1 = Database(tmp_path / "a.db")
    applied = db1.migrate()
    assert applied == [1, 2]
    assert db1.schema_version() == 2
    assert db1.migrate() == []          # اجرای دوباره چیزی اعمال نمی‌کند
    db1.close()
    # بازگشایی همان فایل: مهاجرت تکرار نمی‌شود
    db2 = Database(tmp_path / "a.db")
    assert db2.migrate() == []
    assert db2.schema_version() == 2
    db2.close()


def test_channels_unique_chat_id(repos):
    repos["channels"].add("اول", "@ch1", "")
    with pytest.raises(ValidationError):
        repos["channels"].add("دوم", "@ch1", "")


def test_channel_add_validation(repos):
    with pytest.raises(ValidationError):
        repos["channels"].add("", "@ch2", "")
    with pytest.raises(ValidationError):
        repos["channels"].add("بدون شناسه", "", "")


def test_claim_due_only_due_posts(repos):
    from datetime import timedelta
    from core.timeutils import utc_now
    posts = repos["posts"]
    cid = repos["channels"].add("ک", "@c1", "")
    due_id = posts.create(cid, "text", "موعدرسیده", utc_iso())
    future_id = posts.create(cid, "text", "آینده",
                             utc_iso(utc_now() + timedelta(days=1)))
    claimed = posts.claim_due(utc_iso())
    ids = [p.id for p in claimed]
    assert due_id in ids and future_id not in ids


def test_claim_atomicity_single_claim(repos):
    posts = repos["posts"]
    cid = repos["channels"].add("ک", "@c2", "")
    pid = posts.create(cid, "text", "یکی", utc_iso())
    first = posts.claim_due(utc_iso())
    second = posts.claim_due(utc_iso())
    assert [p.id for p in first] == [pid]
    assert second == []                  # claimed دوباره claim نمی‌شود


def test_mark_sent_inserts_published(repos):
    posts = repos["posts"]
    cid = repos["channels"].add("ک", "@c3", "")
    pid = posts.create(cid, "text", "سلام", utc_iso())
    posts.mark_sent(pid, 999)
    row = posts.db.query_one("SELECT * FROM published_messages WHERE post_id=?", (pid,))
    assert row["telegram_message_id"] == 999
    assert posts.get(pid).status == "sent"


def test_create_group_multiple_channels(repos):
    posts = repos["posts"]
    c1 = repos["channels"].add("یک", "@g1", "")
    c2 = repos["channels"].add("دو", "@g2", "")
    ids = posts.create_group([
        {"channel_id": c1, "content_type": "text", "body": "x",
         "scheduled_at_utc": utc_iso()},
        {"channel_id": c2, "content_type": "text", "body": "x",
         "scheduled_at_utc": utc_iso()},
    ])
    assert len(ids) == 2
    rows = posts.db.query(
        "SELECT group_uuid FROM scheduled_posts WHERE id IN (?,?)", ids)
    assert rows[0]["group_uuid"] == rows[1]["group_uuid"]


def test_settings_roundtrip(repos):
    st = repos["settings"]
    st.set("market_refresh_sec", 90)
    assert st.get("market_refresh_sec") == 90
    assert st.get("nothing", "پیش‌فرض") == "پیش‌فرض"


def test_watchlist_add_remove_order(repos):
    market = repos["market"]
    assert market.add_watch("sol", "Solana") is True
    assert market.add_watch("SOL") is False       # تکراری
    with pytest.raises(ValidationError):
        market.add_watch("bad symbol!")
    market.set_visible("SOL", False)
    visible = [w.symbol for w in market.list_watch(visible_only=True)]
    assert "SOL" not in visible
    market.reorder(["ETH", "BTC", "SOL"])
    ordered = [w.symbol for w in market.list_watch()]
    assert ordered[:2] == ["ETH", "BTC"]
    market.remove_watch("SOL")
    assert market.add_watch("SOL") is True


def test_news_dedupe(repos):
    news = repos["news"]
    from models.entities import NewsItem
    item = NewsItem(id=None, guid="g1", title="تیتر خبر", link="https://x/1",
                    source="Test", topic="mining")
    assert news.upsert(item) is True
    assert news.upsert(item) is False            # همان guid
    clone = NewsItem(id=None, guid="g2", title="تیتر خبر", link="https://x/1",
                     source="Test")
    assert news.upsert(clone) is False           # همان محتوا → hash تکراری


def test_logs_and_cleanup(repos):
    logs = repos["logs"]
    logs.add("INFO", "TEST", "پیام آزمایشی")
    rows = logs.query(level="INFO")
    assert any("آزمایشی" in r["message"] for r in rows)
    assert logs.cleanup(0) >= 0


def test_transaction_rollback_on_error(db):
    """خطای داخل تراکنش → rollback کامل."""
    from core.errors import DatabaseError
    db.execute("CREATE TABLE IF NOT EXISTS _txtest(id INTEGER)")
    try:
        with db.transaction() as conn:
            conn.execute("INSERT INTO _txtest VALUES (1)")
            raise RuntimeError("boom")
    except DatabaseError:
        pass
    n = db.query_one("SELECT COUNT(*) AS n FROM _txtest")["n"]
    assert n == 0
