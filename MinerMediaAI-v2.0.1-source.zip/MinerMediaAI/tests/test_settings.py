"""تست تنظیمات AppSettings: پیش‌فرض‌های ایمن و clamp ها."""
import pytest

from config import defaults as cfg
from config.settings import AppSettings
from core.errors import ConfigError


@pytest.fixture()
def st(repos):
    return AppSettings(repos["settings"])


def test_defaults_are_safe(st):
    assert st.app_name == cfg.DEFAULT_APP_NAME
    assert st.market_refresh_sec == cfg.DEFAULT_MARKET_REFRESH_SEC == 60
    assert st.auto_publish_enabled is False        # انتشار خودکار خاموش
    assert st.news_require_approval is True        # خبر بدون تأیید ممنوع
    assert st.timezone == cfg.DEFAULT_TIMEZONE


def test_market_interval_clamped(st):
    st.market_refresh_sec = 1          # کمتر از حداقل → clamp
    assert st.market_refresh_sec == cfg.MIN_MARKET_REFRESH_SEC
    st.market_refresh_sec = 99999
    assert st.market_refresh_sec == cfg.MAX_MARKET_REFRESH_SEC


def test_timezone_validation(st):
    st.timezone = "Europe/Berlin"
    assert st.timezone == "Europe/Berlin"
    with pytest.raises(ConfigError):
        st.timezone = "Nowhere/Fake"


def test_display_unit_validation(st):
    st.market_display_unit = "TOMAN"
    with pytest.raises(ConfigError):
        st.market_display_unit = "لیر"


def test_news_sources_sanitized(st):
    st.news_sources = [("X", "https://ok/rss", "crypto"),
                       ("bad", "ftp://not-http", "y"),
                       ("only-name",)]
    assert st.news_sources == [["X", "https://ok/rss", "crypto", True]]


def test_app_name_persisted(st):
    st.app_name = "  ماینرمدیا  "
    assert st.app_name == "ماینرمدیا"
    st.app_name = ""
    assert st.app_name == cfg.DEFAULT_APP_NAME
