"""تست زنده نوبیتکس — فقط با --live اجرا می‌شود (درخواست واقعی، عمومی، حداقلی).

اجرای دستی: pytest tests/test_live_nobitex.py --live
این تست در اجراهای CI/عادی skip می‌شود.
"""
import pytest


@pytest.mark.live
def test_live_market_stats():
    from services.nobitex.client import NobitexClient
    client = NobitexClient()
    stats = client.market_stats(["btc"], ["rls", "usdt"])
    assert stats["btc-rls"]["latest"]
    price_rial = float(stats["btc-rls"]["latest"])
    assert price_rial > 1e6          # قیمت BTC به ریال معقول است
    assert stats["btc-usdt"]["latest"]


@pytest.mark.live
def test_live_udf_unit_ratio():
    """تأیید واحد: کندل IRT (تومان) × ۱۰ ≈ latest ریالی stats."""
    import tempfile
    import pathlib
    from services.nobitex.client import NobitexClient
    from services.market_data.service import MarketDataService
    from database.db import Database
    from database.repositories import MarketRepo
    tmp = pathlib.Path(tempfile.mkdtemp())
    db = Database(tmp / "live.db"); db.migrate()
    repo = MarketRepo(db); repo.seed_defaults([("BTC", "Bitcoin")])
    client = NobitexClient()
    svc = MarketDataService(client, repo, 60)
    result = svc.refresh(["BTC"])
    assert result.ok
    hist = svc.market_history("BTC", "7d")
    assert hist and hist["points"]
    # مقایسه آخرین کندل با قیمت لحظه‌ای
    rial_q = repo.get_quote("BTC", "BTCIRT")
    last_close_toman = hist["points"][-1][1]
    assert abs(last_close_toman * 10 - rial_q["price"]) / rial_q["price"] < 0.05
    db.close()
