"""تست مأموریت ۵ — ماتریس قابلیت رسانه از UI تا کلاینت + سیاست متن بلند."""
import json as _json

import pytest

from config import defaults as cfg
from core.errors import MediaError, TelegramError
from services.telegram.client import publish_post
from services.telegram.media import validate_media_for_send


class FakeTelegramClient:
    """کلاینت ساختگی — ثبت فراخوانی‌ها بدون شبکه."""

    def __init__(self, message_id: int = 100):
        self.calls: list[tuple] = []
        self._mid = message_id

    def send_message(self, chat_id, text, disable_notification=False):
        self.calls.append(("message", chat_id, text))
        return {"message_id": self._mid + len(self.calls)}

    def send_photo(self, chat_id, path, caption=""):
        self.calls.append(("photo", chat_id, path, caption))
        return {"message_id": self._mid + len(self.calls)}

    def send_video(self, chat_id, path, caption=""):
        self.calls.append(("video", chat_id, path, caption))
        return {"message_id": self._mid + len(self.calls)}

    def send_audio(self, chat_id, path, caption=""):
        self.calls.append(("audio", chat_id, path, caption))
        return {"message_id": self._mid + len(self.calls)}

    def send_document(self, chat_id, path, caption=""):
        self.calls.append(("document", chat_id, path, caption))
        return {"message_id": self._mid + len(self.calls)}

    def send_album(self, chat_id, items):
        self.calls.append(("album", chat_id, [dict(i) for i in items]))
        return [{"message_id": self._mid + len(self.calls)}] * len(items)


# ---------------------------------------------------------------------------
# publish_post: ماتریس کامل انواع پشتیبانی‌شده
# ---------------------------------------------------------------------------
def test_publish_matrix_all_single_types(tmp_path):
    """هر نوع رسانه‌ای که UI ارائه می‌دهد باید تا کلاینت برسد."""
    client = FakeTelegramClient()
    files = {}
    for kind, ext in (("photo", ".jpg"), ("video", ".mp4"),
                      ("audio", ".mp3"), ("document", ".pdf")):
        f = tmp_path / f"file{ext}"
        f.write_bytes(b"x" * 1024)
        files[kind] = str(f)
    for kind in ("photo", "video", "audio", "document"):
        mid = publish_post(client, "@ch", kind, "کپشن", files[kind])
        assert mid > 0
    kinds = [c[0] for c in client.calls]
    assert kinds == ["photo", "video", "audio", "document"]


def test_album_json_media_path_with_caption(tmp_path):
    """آلبوم: media_path = JSON؛ کپشن روی آیتم اول (محدودیت واقعی Bot API)."""
    client = FakeTelegramClient()
    f1 = tmp_path / "a.jpg"; f1.write_bytes(b"x")
    f2 = tmp_path / "b.mp4"; f2.write_bytes(b"y")
    media = _json.dumps([{"type": "photo", "path": str(f1)},
                         {"type": "video", "path": str(f2)}])
    mid = publish_post(client, "@ch", "album", "کپشن آلبوم", media)
    assert mid > 0
    kind, chat, items = client.calls[0]
    assert kind == "album"
    assert items[0]["caption"] == "کپشن آلبوم"
    assert "caption" not in items[1]


def test_album_requires_two_items(tmp_path):
    client = FakeTelegramClient()
    f1 = tmp_path / "a.jpg"; f1.write_bytes(b"x")
    media = _json.dumps([{"type": "photo", "path": str(f1)}])
    with pytest.raises(TelegramError):
        publish_post(client, "@ch", "album", "کپشن", media)


def test_long_text_with_media_split_policy(tmp_path):
    """متن بلند + رسانه:
    - بدون split → خطای صریح (نه برش ساکت)
    - با split → رسانه بدون کپشن + کل متن در پیام جداگانه
    """
    client = FakeTelegramClient()
    f = tmp_path / "p.jpg"; f.write_bytes(b"x" * 512)
    long_body = "ک" * (cfg.MAX_CAPTION_LEN + 100)
    with pytest.raises(TelegramError):
        publish_post(client, "@ch", "photo", long_body, str(f),
                     split_long_text=False)
    # هیچ پیامی ارسال نشده باشد
    assert client.calls == []
    mid = publish_post(client, "@ch", "photo", long_body, str(f),
                       split_long_text=True)
    assert mid > 0
    kinds = [c[0] for c in client.calls]
    assert kinds == ["photo", "message"]
    # پیام متنی حاوی «کل» متن است — هیچ حرفی حذف نشده
    assert client.calls[1][2] == long_body
    # رسانه بدون کپشن ارسال شده
    assert client.calls[0][3] == ""


def test_long_text_with_album_split(tmp_path):
    client = FakeTelegramClient()
    f1 = tmp_path / "a.jpg"; f1.write_bytes(b"x")
    f2 = tmp_path / "b.jpg"; f2.write_bytes(b"y")
    media = _json.dumps([{"type": "photo", "path": str(f1)},
                         {"type": "photo", "path": str(f2)}])
    long_body = "م" * (cfg.MAX_CAPTION_LEN + 50)
    publish_post(client, "@ch", "album", long_body, media,
                 split_long_text=True)
    kinds = [c[0] for c in client.calls]
    assert kinds == ["album", "message"]
    assert client.calls[0][2][0].get("caption", "") == ""  # بدون کپشن
    assert client.calls[1][2] == long_body                  # متن کامل جداگانه


def test_unsupported_type_rejected():
    with pytest.raises(TelegramError):
        publish_post(FakeTelegramClient(), "@ch", "sticker", "x", "")


# ---------------------------------------------------------------------------
# اعتبارسنجی قبل از زمان‌بندی
# ---------------------------------------------------------------------------
def test_validation_reports_deleted_file(tmp_path):
    with pytest.raises(MediaError):
        validate_media_for_send(str(tmp_path / "missing.jpg"), "sendPhoto")


def test_validation_reports_invalid_type(tmp_path):
    f = tmp_path / "script.exe"
    f.write_bytes(b"x")
    with pytest.raises(MediaError):
        validate_media_for_send(str(f), "sendPhoto")


def test_validation_reports_oversize(tmp_path, monkeypatch):
    f = tmp_path / "big.jpg"
    f.write_bytes(b"x" * (11 * 1024 * 1024))
    with pytest.raises(MediaError):
        validate_media_for_send(str(f), "sendPhoto")


def test_validation_accepts_valid_photo(tmp_path):
    f = tmp_path / "ok.jpg"
    f.write_bytes(b"x" * 2048)
    path = validate_media_for_send(str(f), "sendPhoto")
    assert path.is_file()


# ---------------------------------------------------------------------------
# UI: دیالوگ پست جدید — باز شدن بدون کرش + اعتبارسنجی قبل از زمان‌بندی
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from ui.theme import apply_theme
    apply_theme(app)
    yield app


def test_new_post_dialog_opens_without_crash(qapp, ui_ctx):
    """باگ واقعی v2.0.0: QCheckBox بدون import → NameError در باز شدن."""
    from ui.queue_page import NewPostDialog
    dlg = NewPostDialog(None, ui_ctx)   # قبلاً همین خط کرش می‌کرد
    assert dlg.type_combo.count() == 6  # text/photo/video/audio/document/album
    assert dlg.split_check is not None


def test_new_post_dialog_rejects_long_caption_without_split(qapp, ui_ctx, tmp_path):
    from ui.queue_page import NewPostDialog
    dlg = NewPostDialog(None, ui_ctx)
    f = tmp_path / "p.jpg"; f.write_bytes(b"x")
    dlg.type_combo.setCurrentIndex(1)   # photo
    dlg.media_edit.setText(str(f))
    dlg.body_edit.setPlainText("ک" * (cfg.MAX_CAPTION_LEN + 10))
    dlg.split_check.setChecked(False)
    with pytest.raises(Exception):
        dlg._validate()


def test_new_post_dialog_album_flow(qapp, ui_ctx, tmp_path):
    """جریان کامل آلبوم از UI: اعتبارسنجی و ساخت JSON مسیرها."""
    from ui.queue_page import NewPostDialog
    dlg = NewPostDialog(None, ui_ctx)
    f1 = tmp_path / "1.jpg"; f1.write_bytes(b"x")
    f2 = tmp_path / "2.png"; f2.write_bytes(b"y")
    dlg.type_combo.setCurrentIndex(5)   # album
    dlg.album_paths = [str(f1), str(f2)]
    dlg.media_edit.setText("2 فایل انتخاب شد")
    dlg.body_edit.setPlainText("کپشن آلبوم")
    ctype, media, split = dlg._validate()
    assert ctype == "album"
    items = _json.loads(media)
    assert len(items) == 2 and items[0]["type"] == "photo"
    assert split is False
