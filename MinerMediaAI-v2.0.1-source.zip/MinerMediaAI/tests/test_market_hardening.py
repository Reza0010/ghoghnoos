"""تست مأموریت ۳ — تفکیک خطای دسته از خطای نرخ USDT/RLS و ممنوعیت درخواست اضافی."""
import json as _json

import pytest

from core.errors import NetworkError, NobitexError, RateLimitError
from database.db import Database
from database.repositories import MarketRepo
from services.market_data.service import MarketDataService
from services.nobitex.client import NobitexClient
from tests.conftest import FakeResponse
from tests.test_nobitex_client import VALID_STATS

USDT_RLS = {"status": "ok", "stats": {"usdt-rls": {"latest": "2650900",
                                                   "dayChange": "0.05"}}}


def make_db(tmp_path):
    db = Database(tmp_path / "m.db")
    db.migrate()
    repo = MarketRepo(db)
    repo.seed_defaults([("BTC", "Bitcoin"), ("ETH", "Ethereum")])
    return db, repo


def test_rate_only_error_does_not_trigger_fallback(fake_session_cls, tmp_path):
    """خطای فقط نرخ USDT/RLS → هیچ درخواست تک‌نمادی اضافه‌ای زده نمی‌شود."""
    db, repo = make_db(tmp_path)
    # درخواست ۱: دسته OK؛ درخواست ۲ (نرخ): 429 — و تمام؛ نه یک درخواست بیشتر
    session = fake_session_cls(get_results=[
        FakeResponse(200, VALID_STATS),
        FakeResponse(429, {"error": "too many"}, headers={"Retry-After": "3"}),
    ])
    client = NobitexClient(session=session, stats_min_interval=0.0,
                           udf_min_interval=0.0)
    svc = MarketDataService(client, repo, 60)
    result = svc.refresh(["BTC", "ETH"])
    assert result.ok is True                      # داده دسته سالم است
    assert result.updated >= 2
    assert any("USDT/RLS" in e for e in result.errors)   # خطای نرخ شفاف ثبت شده
    total_calls = len(session.get_calls)
    # فقط ۲ درخواست: دسته + نرخ — بدون fallback
    assert total_calls == 2, f"درخواست اضافه زده شد: {total_calls}"
    db.close()


def test_batch_429_does_not_fire_single_requests(fake_session_cls, tmp_path):
    """429 روی دسته → نه fallback تک‌نمادی؛ درخواست‌ها: دسته + نرخ = ۲."""
    db, repo = make_db(tmp_path)
    session = fake_session_cls(get_results=[
        FakeResponse(429, {}, headers={"Retry-After": "10"}),
        FakeResponse(200, USDT_RLS),
    ])
    client = NobitexClient(session=session, stats_min_interval=0.0,
                           udf_min_interval=0.0)
    svc = MarketDataService(client, repo, 60)
    result = svc.refresh(["BTC", "ETH"])
    assert result.ok is False                     # هیچ قیمت ارزی نگرفتیم
    assert len(session.get_calls) == 2, "429 نباید درخواست اضافه تولید کند"
    # داده قبلی stale علامت خورده (نه حذف؛ نه قیمت ساختگی)
    q = repo.get_quote("BTC", "BTCIRT")
    assert q is None or q["stale"] in (0, 1)
    db.close()


def test_batch_network_down_no_extra_requests(fake_session_cls, tmp_path):
    """قطع شبکه در دسته → بدون درخواست اضافی؛ شکست صادقانه."""
    db, repo = make_db(tmp_path)
    session = fake_session_cls(get_results=[
        NetworkError("conn refused", phase="connect"),
        FakeResponse(200, USDT_RLS),
    ])
    client = NobitexClient(session=session, stats_min_interval=0.0,
                           udf_min_interval=0.0)
    svc = MarketDataService(client, repo, 60)
    result = svc.refresh(["BTC", "ETH"])
    assert result.ok is False
    assert len(session.get_calls) == 2
    db.close()


def test_batch_400_learns_invalid_symbol_via_fallback(fake_session_cls, tmp_path):
    """400 دسته (نماد نامعتبر) → fallback مجاز است؛ نماد بد یاد گرفته می‌شود."""
    db, repo = make_db(tmp_path)
    ok_stats = {"status": "ok", "stats": {
        "btc-rls": {"latest": "219456369080"}, "btc-usdt": {"latest": "82790"}}}
    session = fake_session_cls(get_results=[
        # دسته با BTC+ETH → 400 (یکی نامعتبر)
        FakeResponse(400, {"code": "InvalidCurrency", "message": "bad symbol"}),
        FakeResponse(200, USDT_RLS),
        # fallback تک‌نمادی: BTC OK
        FakeResponse(200, ok_stats),
        # fallback تک‌نمادی: ETH → 400 (نماد بدون جفت)
        FakeResponse(400, {"code": "InvalidCurrency", "message": "no pair"}),
    ])
    client = NobitexClient(session=session, stats_min_interval=0.0,
                           udf_min_interval=0.0)
    svc = MarketDataService(client, repo, 60)
    result = svc.refresh(["BTC", "ETH"])
    # BTC نجات پیدا کرد → چرخه موفق با خطای جزئی
    assert result.ok is True
    assert repo.get_quote("BTC", "BTCIRT") is not None
    assert "ETH" in svc._invalid_symbols
    # یادگیری پایدار در repo
    assert "ETH" in repo.get_invalid_symbols()
    assert any("ETH" in e for e in result.errors)
    db.close()


def test_large_watchlist_single_batch_request(fake_session_cls, tmp_path):
    """فهرست بزرگ → فقط یک درخواست دسته + یک نرخ (نه N درخواست)."""
    db, repo = make_db(tmp_path)
    syms = [f"C{i}" for i in range(15)]
    repo.seed_defaults([(s, s) for s in syms])
    stats = {"status": "ok", "stats": {}}
    for s in syms:
        stats["stats"][f"{s.lower()}-rls"] = {"latest": "1000"}
    session = fake_session_cls(get_results=[
        FakeResponse(200, stats),
        FakeResponse(200, USDT_RLS),
    ])
    client = NobitexClient(session=session, stats_min_interval=0.0,
                           udf_min_interval=0.0)
    svc = MarketDataService(client, repo, 60)
    result = svc.refresh(syms)
    assert result.ok
    assert len(session.get_calls) == 2
    db.close()


def test_stale_marking_and_estimated_freshness(fake_session_cls, tmp_path):
    """داده کهنه علامت می‌خورد؛ تخمین فقط با تازه‌بودن هر دو منبع."""
    db, repo = make_db(tmp_path)
    session = fake_session_cls(get_results=[
        FakeResponse(200, VALID_STATS),
        FakeResponse(200, USDT_RLS),
    ])
    client = NobitexClient(session=session, stats_min_interval=0.0,
                           udf_min_interval=0.0)
    svc = MarketDataService(client, repo, 60)
    svc.refresh(["BTC"])
    # BTC جفت مستقیم ریالی دارد → قیمت دقیق (نه تخمینی)
    info = svc.display_price("BTC", "RIAL")
    assert info["exact"] is True and info["estimated"] is False
    assert info["unit"] == "RIAL" and info["source"] == "nobitex"
    # تخمین برای نماد بدون جفت ریالی: فقط با تازگی هر دو منبع
    est = svc.estimate_rial("ETH")   # ETH داده‌ای ندارد → None بدون ساختگی
    assert est is None
    db.close()
