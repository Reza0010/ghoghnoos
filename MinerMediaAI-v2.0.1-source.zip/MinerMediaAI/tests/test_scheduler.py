"""تست Scheduler: claim اتمی، ارسال موفق، 429، backoff، unknown، بازیابی، هم‌زمانی."""
import threading
import time

import pytest

from core.timeutils import utc_iso, utc_now
from database.repositories import ChannelsRepo, PostsRepo
from security.secret_store import InMemorySecretStore
from workers.scheduler import SchedulerService


@pytest.fixture()
def setup(repos, secrets):
    channels: ChannelsRepo = repos["channels"]
    posts: PostsRepo = repos["posts"]
    cid = channels.add("کانال تست", "@test_channel", "تست")
    secrets.set_secret("telegram.bot_token.default", "1234567890:AAHtesttoken_testtoken_testtoken12")
    return channels, posts, cid


def make_scheduler(repos, secrets, poll=0.1):
    return SchedulerService(repos["posts"], repos["channels"], secrets,
                            poll_sec=poll, claim_limit=10)


class FakeClientFactory:
    """جایگزین کلاینت تلگرام با رفتار اسکریپت‌شده."""

    def __init__(self, behavior):
        self.behavior = behavior   # callable(post, chat_id) -> message_id یا raise
        self.calls = []

    def __call__(self, posts_repo, channels_repo, secrets):
        svc = make_scheduler_for_fake(posts_repo, channels_repo, secrets, self)
        return svc


def _patch_publish(monkeypatch, behavior):
    """publish_post را با رفتار دلخواه جایگزین می‌کند."""
    import workers.scheduler as sched
    calls = []

    def fake_publish(client, chat_id, content_type, body, media_path="",
                     split_long_text=False):
        calls.append({"chat_id": chat_id, "type": content_type, "body": body})
        return behavior(client, chat_id, content_type, body)

    monkeypatch.setattr(sched, "publish_post", fake_publish)
    return calls


def test_due_post_is_sent_and_recorded(setup, monkeypatch, secrets):
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام دنیا", utc_iso())
    calls = _patch_publish(monkeypatch, lambda c, ch, t, b: 111)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.secrets.set_secret("telegram.bot_token.default", "tok")
    svc.cycle()
    post = posts.get(pid)
    assert post.status == "sent"
    assert post.telegram_message_id == 111
    row = posts.db.query_one("SELECT * FROM published_messages WHERE post_id=?", (pid,))
    assert row is not None and row["telegram_message_id"] == 111
    assert calls and calls[0]["chat_id"] == "@test_channel"


def test_future_post_not_sent(setup, monkeypatch, secrets):
    from datetime import timedelta
    channels, posts, cid = setup
    future = utc_iso(utc_now() + timedelta(hours=2))
    pid = posts.create(cid, "text", "آینده", future)
    _patch_publish(monkeypatch, lambda c, ch, t, b: 1)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()
    assert posts.get(pid).status == "pending"


def test_429_reschedules_with_retry_after(setup, monkeypatch, secrets):
    from core.errors import RateLimitError
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso())

    def raise_429(c, ch, t, b):
        raise RateLimitError("429", retry_after=45)
    _patch_publish(monkeypatch, raise_429)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()
    post = posts.get(pid)
    assert post.status == "pending"
    assert post.attempts == 1
    assert "429" in post.last_error


def test_transient_error_backoff_then_fail(setup, monkeypatch, secrets):
    from core.errors import NetworkError
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso(), max_attempts=2)

    def raise_net(c, ch, t, b):
        raise NetworkError("connect fail", phase="connect")
    _patch_publish(monkeypatch, raise_net)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    # چرخه اول: attempts=1 < max → pending با backoff آینده
    svc.cycle()
    assert posts.get(pid).status == "pending"
    # شبیه‌سازی گذر زمان تأخیر backoff → موعدرسیده می‌شود
    posts.reschedule(pid, utc_iso())
    # چرخه دوم: attempts=2 >= max → failed
    svc.cycle()
    assert posts.get(pid).status == "failed"


def test_read_timeout_becomes_unknown_never_resent(setup, monkeypatch, secrets):
    """نتیجه مبهم → unknown؛ تلاش مجدد خودکار ممنوع."""
    from core.errors import NetworkError
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso(), max_attempts=5)

    def raise_read(c, ch, t, b):
        raise NetworkError("read timeout", phase="read")
    _patch_publish(monkeypatch, raise_read)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()
    assert posts.get(pid).status == "unknown"
    # چرخه‌های بعدی هم آن را دوباره نمی‌فرستند
    svc.cycle(); svc.cycle()
    assert posts.get(pid).status == "unknown"


def test_permanent_403_fails_immediately(setup, monkeypatch, secrets):
    from core.errors import TelegramError
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso())

    def raise_403(c, ch, t, b):
        raise TelegramError("403 forbidden", status_code=403)
    _patch_publish(monkeypatch, raise_403)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()
    post = posts.get(pid)
    assert post.status == "failed"
    assert post.attempts == 1


def test_cancel_pending(setup, secrets):
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso())
    assert posts.cancel(pid) is True
    assert posts.get(pid).status == "cancelled"
    assert posts.cancel(pid) is False  # cancelled دوباره لغو نمی‌شود


def test_startup_recovery_marks_unknown(setup, secrets):
    """ارسال شروع‌شده ولی ناتمام → unknown (نه ارسال دوباره کورکورانه)."""
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso())
    posts.db.execute(
        "UPDATE scheduled_posts SET status='processing', send_started_at=? WHERE id=?",
        (utc_iso(), pid))
    r = posts.recover_at_startup()
    assert r == {"pending": 0, "unknown": 1}
    assert posts.get(pid).status == "unknown"


def test_startup_recovery_claimed_without_send_returns_pending(setup, secrets):
    """مأموریت ۲: claim‌شده ولی ارسال شروع نشده → pending (نه unknown)."""
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso())
    posts.db.execute("UPDATE scheduled_posts SET status='processing' WHERE id=?", (pid,))
    r = posts.recover_at_startup()
    assert r == {"pending": 1, "unknown": 0}
    post = posts.get(pid)
    assert post.status == "pending"
    # و در چرخه بعدی بدون خطر تکرار ارسال می‌شود
    import workers.scheduler as sched


def test_shutdown_mid_cycle_no_unknown_for_unstarted(setup, monkeypatch, secrets):
    """توقف وسط چرخه: پست claim نشده بعدی بماند pending؛ فقط در-flight ممکن است unknown شود."""
    channels, posts, cid = setup
    p1 = posts.create(cid, "text", "اول", utc_iso())
    posts.create(cid, "text", "دوم", utc_iso())
    import workers.scheduler as sched
    calls = []

    def slow_publish(client, chat_id, ctype, body, media_path="", split_long_text=False):
        calls.append(body)
        # شبیه‌سازی stop هنگام پردازش پست اول
        svc_holder["svc"]._stop_flag.set()
        return 100
    svc_holder = {}
    monkeypatch.setattr(sched, "publish_post", slow_publish)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05, claim_limit=10)
    svc_holder["svc"] = svc
    svc.cycle()   # پست اول ارسال شد؛ stop وسط کار → پست دوم claim نمی‌شود
    assert posts.get(p1).status == "sent"
    others = [p for p in posts.list() if p.id != p1]
    assert all(p.status == "pending" for p in others), \
        "پست‌های claim‌نشده باید pending بمانند"


def test_429_exhausts_max_attempts_then_fails(setup, monkeypatch, secrets):
    """مأموریت ۲: 429 سقف تلاش دارد — بی‌پایان نیست."""
    from core.errors import RateLimitError
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso(), max_attempts=2)

    def raise_429(c, ch, t, b, media_path="", split_long_text=False):
        raise RateLimitError("429", retry_after=5)
    monkeypatch.setattr(
        __import__("workers.scheduler", fromlist=["publish_post"]),
        "publish_post", raise_429)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()
    assert posts.get(pid).status == "pending"
    posts.reschedule(pid, utc_iso())
    svc.cycle()   # attempts=2 >= max → failed صادقانه
    post = posts.get(pid)
    assert post.status == "failed"
    assert "retry_after" in (post.last_error or "")  # پیام صادقانه فارسی + جزئیات
    hist = posts.attempt_history(pid)
    assert any(h["outcome"] == "rate_limited" for h in hist)
    assert any(h["outcome"] == "rate_limited_exhausted" for h in hist)


def test_unexpected_exception_does_not_double_count(setup, monkeypatch, secrets):
    """مأموریت ۲: استثنای غیرمنتظره شمارنده را دوبرابر زیاد نمی‌کند."""
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso(), max_attempts=5)

    def boom(c, ch, t, b, media_path="", split_long_text=False):
        raise RuntimeError("unexpected crash in publish")
    monkeypatch.setattr(
        __import__("workers.scheduler", fromlist=["publish_post"]),
        "publish_post", boom)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()
    post = posts.get(pid)
    assert post.attempts == 1, "فقط یک increment در هر چرخه"
    assert post.status == "pending"
    hist = posts.attempt_history(pid)
    assert len(hist) == 1 and hist[0]["outcome"] == "error_retry"


def test_send_started_set_before_publish(setup, monkeypatch, secrets):
    """send_started_at دقیقاً قبل از فراخوانی publish ثبت می‌شود."""
    channels, posts, cid = setup
    pid = posts.create(cid, "text", "سلام", utc_iso())
    seen = {}

    def spy_publish(client, chat_id, ctype, body, media_path="", split_long_text=False):
        seen["started"] = posts.get(pid).send_started_at
        return 7
    monkeypatch.setattr(
        __import__("workers.scheduler", fromlist=["publish_post"]),
        "publish_post", spy_publish)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()
    assert seen["started"] is not None
    assert posts.get(pid).status == "sent"


def test_two_workers_never_claim_same_post(setup, monkeypatch, secrets):
    """دو Worker هم‌زمان: هر آیتم دقیقاً یک‌بار claim می‌شود."""
    channels, posts, cid = setup
    ids = [posts.create(cid, "text", f"پست {i}", utc_iso()) for i in range(20)]
    _patch_publish(monkeypatch, lambda c, ch, t, b: 1)
    svc1 = SchedulerService(posts, channels, secrets, poll_sec=0.05, claim_limit=50)
    svc2 = SchedulerService(posts, channels, secrets, poll_sec=0.05, claim_limit=50)
    results = {}

    def run(svc, name):
        results[name] = svc.cycle()

    t1 = threading.Thread(target=run, args=(svc1, "a"))
    t2 = threading.Thread(target=run, args=(svc2, "b"))
    t1.start(); t2.start(); t1.join(); t2.join()
    sent = posts.db.query_one(
        "SELECT COUNT(*) AS n FROM scheduled_posts WHERE status='sent'")
    assert int(sent["n"]) == 20
    assert results["a"] + results["b"] == 20


def test_timezone_aware_scheduling(setup, monkeypatch, secrets):
    """پست با آفست +03:30 تهران: فقط پس از موعد واقعی پردازش می‌شود."""
    channels, posts, cid = setup
    # ۱ ساعت آینده به وقت تهران = هنوز موعد نرسیده (UTC)
    from core.timeutils import parse_user_datetime
    from datetime import timedelta
    future_local = (utc_now() + timedelta(hours=1))
    fut_iso = utc_iso(future_local)
    pid = posts.create(cid, "text", "تهران", fut_iso, timezone_name="Asia/Tehran")
    _patch_publish(monkeypatch, lambda c, ch, t, b: 1)
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()
    assert posts.get(pid).status == "pending"
    # با عقب‌بردن موعد → پردازش می‌شود
    posts.reschedule(pid, utc_iso())
    svc.cycle()
    assert posts.get(pid).status == "sent"


def test_missing_token_fails_permanently(repos, monkeypatch):
    channels, posts = repos["channels"], repos["posts"]
    cid = channels.add("بدون توکن", "@no_token", "")
    pid = posts.create(cid, "text", "سلام", utc_iso())
    svc = SchedulerService(posts, channels, InMemorySecretStore(), poll_sec=0.05)
    # توکنی ثبت نشده
    calls = {}
    import workers.scheduler as sched

    def fail_publish(client, chat_id, ctype, body, media_path="",
                     split_long_text=False):
        calls["called"] = True
        return 1
    monkeypatch.setattr(sched, "publish_post", fail_publish)
    svc.cycle()
    post = posts.get(pid)
    assert post.status == "failed"
    assert "called" not in calls  # هرگز به publish نرسیده
