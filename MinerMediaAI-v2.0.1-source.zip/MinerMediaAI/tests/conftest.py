"""پیکربندی pytest — مسیر پروژه، دیتابیس موقت و ابزارهای مشترک."""
import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pytest  # noqa: E402


def pytest_addoption(parser):
    parser.addoption("--live", action="store_true", default=False,
                     help="تست‌های زنده API عمومی نوبیتکس اجرا شوند")


def pytest_configure(config):
    config.addinivalue_line(
        "markers", "live: درخواست واقعی به API عمومی نوبیتکس (فقط با --live)")


def pytest_collection_modifyitems(config, items):
    if config.getoption("--live"):
        return
    skip = pytest.mark.skip(reason="بدون --live اجرا نمی‌شود")
    for item in items:
        if "live" in item.keywords:
            item.add_marker(skip)


from database.db import Database  # noqa: E402
from database.repositories import (  # noqa: E402
    ChannelsRepo, DraftsRepo, LogsRepo, MarketRepo, MediaRepo, NewsRepo,
    PostsRepo, SettingsRepo)
from security.secret_store import InMemorySecretStore  # noqa: E402


class Ctx:
    """کانتکست سبک برای تست‌های UI/Worker (مشترک بین ماژول‌های تست)."""
    pass


@pytest.fixture(scope="session")
def qapp():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from ui.theme import apply_theme
    apply_theme(app)
    yield app


@pytest.fixture()
def ui_ctx(tmp_path, qapp):
    """کانتکست کامل UI با دیتابیس موقت — مشترک بین تست‌های UI/رسانه."""
    from config.settings import AppSettings
    from services.ai.provider import AIProvider
    from services.ai.studio import ContentStudioService
    from services.market_data.service import MarketDataService
    from services.media.library import MediaLibraryService
    from services.news.service import NewsService
    from services.nobitex.client import NobitexClient
    from workers.market_worker import MarketWorker
    from workers.scheduler import SchedulerService
    database = Database(tmp_path / "ui.db")
    database.migrate()
    ctx = Ctx()
    ctx.db = database
    ctx.settings = AppSettings(SettingsRepo(database))
    ctx.secret_store = InMemorySecretStore()
    ctx.channels_repo = ChannelsRepo(database)
    ctx.posts_repo = PostsRepo(database)
    ctx.market_repo = MarketRepo(database)
    ctx.market_repo.seed_defaults([("BTC", "Bitcoin")])
    ctx.news_repo = NewsRepo(database)
    ctx.drafts_repo = DraftsRepo(database)
    ctx.logs_repo = LogsRepo(database)
    ctx.market_service = MarketDataService(NobitexClient(), ctx.market_repo)
    ctx.news_service = NewsService(ctx.news_repo)
    ctx.ai_provider = AIProvider("", lambda: "", "")
    ctx.studio = ContentStudioService(ctx.ai_provider, ctx.drafts_repo,
                                      ctx.market_service)
    ctx.media_service = MediaLibraryService(MediaRepo(database), tmp_path / "media")
    ctx.scheduler = SchedulerService(ctx.posts_repo, ctx.channels_repo,
                                     ctx.secret_store)
    ctx.market_worker = MarketWorker(ctx.market_service, lambda: 60, lambda: ["BTC"])
    ctx.kick_market_worker = lambda: None
    ctx.kick_threads = lambda: []
    ctx.rebuild_ai_provider = lambda: None
    yield ctx
    database.close()


@pytest.fixture()
def tmp_data_dir(tmp_path):
    os.environ["MINERMEDIA_DATA_DIR"] = str(tmp_path)
    yield tmp_path


@pytest.fixture()
def db(tmp_path):
    database = Database(tmp_path / "test.db")
    database.migrate()
    yield database
    database.close()


@pytest.fixture()
def repos(db):
    market = MarketRepo(db)
    market.seed_defaults([("BTC", "Bitcoin"), ("ETH", "Ethereum")])
    return {
        "channels": ChannelsRepo(db),
        "posts": PostsRepo(db),
        "market": market,
        "news": NewsRepo(db),
        "drafts": DraftsRepo(db),
        "settings": SettingsRepo(db),
        "logs": LogsRepo(db),
        "media": MediaRepo(db),
    }


@pytest.fixture()
def secrets():
    return InMemorySecretStore()


# ---------------------------------------------------------------------------
# Fake HTTP session برای تست بدون شبکه
# ---------------------------------------------------------------------------
class FakeResponse:
    def __init__(self, status_code=200, json_body=None, text="", headers=None):
        self.status_code = status_code
        self._json = json_body if not isinstance(json_body, bytes) else None
        if isinstance(json_body, bytes):
            self.text = text
            self.content = json_body          # feed RSS خام
        else:
            self.text = text or (str(json_body) if json_body is not None else "")
            self.content = self.text.encode("utf-8")
        self.headers = headers or {}

    def json(self):
        if self._json is None:
            raise ValueError("no json")
        return self._json


class FakeSession:
    """جایگزین requests.Session با اسکریپت پاسخ‌ها."""

    def __init__(self, get_results=None, post_results=None):
        self.get_results = list(get_results or [])
        self.post_results = list(post_results or [])
        self.get_calls: list[tuple[str, dict, dict]] = []
        self.post_calls: list[tuple[str, dict, dict]] = []

    def get(self, url, params=None, headers=None, timeout=None):
        self.get_calls.append((url, params or {}, headers or {}))
        if not self.get_results:
            raise AssertionError("unexpected GET call")
        item = self.get_results.pop(0)
        if isinstance(item, Exception):
            raise item
        return item

    def post(self, url, data=None, json=None, files=None, timeout=None):
        self.post_calls.append((url, data or {}, files or {}))
        if not self.post_results:
            raise AssertionError("unexpected POST call")
        item = self.post_results.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


@pytest.fixture()
def fake_session_cls():
    return FakeSession
