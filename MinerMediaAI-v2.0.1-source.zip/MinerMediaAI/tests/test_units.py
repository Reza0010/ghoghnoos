"""تست تبدیل ریال/تومان و فرمت‌کننده‌ها — قاعده مأموریت: ۱۰ ریال = ۱ تومان."""
import pytest

from core.units import (format_amount, format_compact, format_percent,
                        format_price, rial_to_toman, smart_price_decimals,
                        to_persian_digits, toman_to_rial)


def test_rial_toman_roundtrip():
    assert rial_to_toman(219456369080) == 21945636908.0
    assert toman_to_rial(21945636908.0) == 219456369080.0
    assert toman_to_rial(rial_to_toman(123456789)) == 123456789


def test_rial_toman_exact_division_by_ten():
    """قاعده صریح مأموریت: هر ۱۰ ریال = ۱ تومان."""
    assert rial_to_toman(10) == 1
    assert rial_to_toman(1000) == 100
    assert rial_to_toman(7) == 0.7


def test_format_price_units_explicit():
    assert "ریال" in format_price(219456369080.0, "RIAL")
    assert "تومان" in format_price(21945636908.0, "TOMAN")
    assert "USDT" in format_price(82790.0, "USDT")


def test_format_amount_thousands():
    assert format_amount(1234567) == "1,234,567"
    assert format_amount(None) == "—"


def test_format_percent_sign():
    assert format_percent(0.17).startswith("+")
    assert format_percent(-0.16).startswith("−")
    assert format_percent(None) == "—"


def test_persian_digits():
    assert to_persian_digits("123") == "۱۲۳"


def test_format_compact():
    out = format_compact(2_194_563_690_800, "RIAL")
    assert "تریلیون" in out or "میلیارد" in out
    assert "ریال" in out


def test_smart_decimals():
    assert smart_price_decimals(82790.0, "USDT") == 0
    assert smart_price_decimals(0.42, "USDT") == 2
    assert smart_price_decimals(219456369080.0, "RIAL") == 0
