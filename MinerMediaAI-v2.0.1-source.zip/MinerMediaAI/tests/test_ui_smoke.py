"""تست دود UI در pytest — ساخت پنجره، ۹ صفحه، RTL، داده واقعی DB.

نکته: qapp/ui_ctx اکنون در conftest مشترک هستند (تست‌های رسانه هم استفاده می‌کنند).
"""
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest  # noqa: E402,F401


def test_main_window_pages_and_rtl(qapp, ui_ctx, monkeypatch):
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **kw: QMessageBox.Yes))
    monkeypatch.setattr(QMessageBox, "information",
                        staticmethod(lambda *a, **kw: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "warning",
                        staticmethod(lambda *a, **kw: QMessageBox.Ok))
    from ui.main_window import MainWindow
    win = MainWindow(ui_ctx)
    ui_ctx.main_window = win
    win.show()
    assert win.layoutDirection() == Qt.RightToLeft
    assert win.stack.count() == 9
    for key in ("overview", "channels", "queue", "studio", "market", "news",
                "media", "reports", "settings"):
        win.navigate(key)
    # بدون کانال و بدون داده → صفحه‌ها نباید کرش کنند و مقدار ساختگی ندارند
    overview = win.pages["overview"]
    overview.refresh()
    assert overview.card_channels.value_label.text() == "0"
    win.close()


def test_empty_state_no_fake_numbers(qapp, ui_ctx, monkeypatch):
    """در نبود داده، کارت‌ها «۰» یا «—» نشان می‌دهند؛ نه عدد ساختگی."""
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **kw: QMessageBox.Yes))
    monkeypatch.setattr(QMessageBox, "information",
                        staticmethod(lambda *a, **kw: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "warning",
                        staticmethod(lambda *a, **kw: QMessageBox.Ok))
    from ui.main_window import MainWindow
    win = MainWindow(ui_ctx)
    ui_ctx.main_window = win
    overview = win.pages["overview"]
    overview.refresh()
    assert "ناموجود" in overview.card_market_updated.value_label.text() or \
        overview.card_market_updated.value_label.text() == "—"
    queue = win.pages["queue"]
    queue.refresh()
    assert queue.table.rowCount() == 0
    win.close()


def test_channel_page_add_and_list(qapp, ui_ctx, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **kw: QMessageBox.Yes))
    monkeypatch.setattr(QMessageBox, "information",
                        staticmethod(lambda *a, **kw: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "warning",
                        staticmethod(lambda *a, **kw: QMessageBox.Ok))
    from ui.main_window import MainWindow
    ui_ctx.channels_repo.add("کانال اصلی", "@main_ch", "اصلی")
    win = MainWindow(ui_ctx)
    ui_ctx.main_window = win
    win.navigate("channels")
    page = win.pages["channels"]
    assert page.table.rowCount() == 1
    win.close()


def test_settings_page_saves(qapp, ui_ctx, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "information",
                        staticmethod(lambda *a, **kw: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **kw: QMessageBox.Yes))
    monkeypatch.setattr(QMessageBox, "warning",
                        staticmethod(lambda *a, **kw: QMessageBox.Ok))
    from ui.main_window import MainWindow
    from ui.settings_page import SettingsPage
    win = MainWindow(ui_ctx)
    ui_ctx.main_window = win
    win.navigate("settings")
    page = win.pages["settings"]
    page.interval_spin.setValue(120)
    page._save_market()
    assert ui_ctx.settings.market_refresh_sec == 120
    win.close()
