"""تست مأموریت ۱ — خاموش‌شدن امن: ترتیب توقف، دیتابیس، گارد DB بسته.

سناریوی کلیدی مأموریت: «در زمان درخواست شبکه طولانی، خروج برنامه موجب
دسترسی به دیتابیس بسته‌شده نشود.»
"""
import threading
import time

import pytest

from core.timeutils import utc_iso
from core.shutdown import (close_database_safely, shutdown_background_workers)


class FakeWorker:
    """Worker با پنجرهٔ مشغولی واقعی — توقف فقط پس از پایان کار در جریان.

    busy_for>0 یعنی درخواست شبکه‌ای طولانی در جریان است؛ حتی بعد از stop،
    Thread تا پایان آن پنجره واقعاً کار می‌کند (دقیقاً مثل درخواست تلگرام).
    """

    def __init__(self, busy_for: float = 0.0):
        self._stop_flag = threading.Event()
        self._busy_for = float(busy_for)
        self._busy_until = 0.0
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def _run(self):
        while not (self._stop_flag.is_set()
                   and time.monotonic() >= self._busy_until):
            self._stop_flag.wait(0.02)

    def is_alive(self):
        return self._thread is not None and self._thread.is_alive()

    def stop_safe(self, join_timeout: float = 10.0) -> bool:
        self._busy_until = time.monotonic() + self._busy_for
        self._stop_flag.set()
        if self.is_alive():
            self._thread.join(timeout=join_timeout)
        return not self.is_alive()

    def release(self):
        """تست تمام شد — اجازهٔ خاتمه بده (جلوگیری از Thread سرگردان)."""
        self._busy_until = 0.0
        self._stop_flag.set()


class Ctx:
    pass


def test_all_stopped_then_db_closes(repos):
    db = repos["posts"].db
    ctx = Ctx()
    ctx.scheduler = FakeWorker().start()
    ctx.market_worker = FakeWorker().start()
    ctx.news_worker = FakeWorker().start()
    ctx.settings = type("S", (), {"enabled_news_sources": []})()
    ctx.kick_threads = lambda: []
    report = shutdown_background_workers(ctx)
    assert all(report.values()), report
    assert close_database_safely(db, report) is True
    assert db.is_closed


def test_worker_alive_means_db_not_closed(repos):
    """Worker زنده → دیتابیس بسته نمی‌شود (صادقانه، بدون فرض توقف)."""
    db = repos["posts"].db
    ctx = Ctx()
    ctx.scheduler = FakeWorker(busy_for=100).start()
    ctx.market_worker = FakeWorker().start()
    ctx.news_worker = FakeWorker().start()
    ctx.settings = type("S", (), {"enabled_news_sources": []})()
    ctx.kick_threads = lambda: []
    report = shutdown_background_workers(ctx, scheduler_budget=0.3,
                                         market_budget=0.3, news_budget=0.3)
    assert report["scheduler"] is False          # صادقانه: متوقف نشد
    assert close_database_safely(db, report) is False
    assert not db.is_closed
    # دیتابیس همچنان قابل استفاده است
    repos["posts"].db.query_one("SELECT COUNT(*) AS n FROM scheduled_posts")
    ctx.scheduler.release()                      # پاک‌سازی Thread تست


def test_scheduler_never_touches_closed_db(repos, secrets, monkeypatch):
    """ارسال در جریان + بسته‌شدن DB → گارد جلوی کرش/نوشتن روی DB بسته را می‌گیرد."""
    channels, posts = repos["channels"], repos["posts"]
    cid = channels.add("کانال", "@ch", "")
    pid = posts.create(cid, "text", "سلام", utc_iso())
    import workers.scheduler as sched

    def slow_publish(client, chat_id, ctype, body, media_path="",
                     split_long_text=False):
        # حین درخواست طولانی، برنامه DB را می‌بندد (شبیه‌سازی خروج)
        posts.db.close()
        return 55
    secrets.set_secret("telegram.bot_token.default", "tok")
    monkeypatch.setattr(sched, "publish_post", slow_publish)
    from workers.scheduler import SchedulerService
    svc = SchedulerService(posts, channels, secrets, poll_sec=0.05)
    svc.cycle()   # ← هیچ استثنایی به بیرون نشت نمی‌کند (گارد DB بسته)
    # خواندن از DB بسته ممکن نیست — وضعیت نهایی را از اتصال تازه می‌خوانیم
    from database.db import Database
    db2 = Database(posts.db.db_path)
    db2.migrate()
    row = db2.query_one("SELECT status, send_started_at FROM scheduled_posts WHERE id=?",
                        (pid,))
    assert row["status"] == "processing"      # نه sent نه failed — صادقانه
    assert row["send_started_at"] is not None
    p2 = PostsRepoStrict(db2)
    r = p2.recover_at_startup()
    assert r == {"pending": 0, "unknown": 1}  # نتیجه واقعاً نامشخص → unknown
    db2.close()


def PostsRepoStrict(db):
    from database.repositories import PostsRepo
    return PostsRepo(db)


def test_shutdown_report_lists_honest_names(repos):
    ctx = Ctx()
    ctx.scheduler = FakeWorker().start()
    ctx.market_worker = FakeWorker().start()
    ctx.news_worker = FakeWorker().start()
    ctx.settings = type("S", (), {"enabled_news_sources": ["a", "b"]})()
    ctx.kick_threads = lambda: []
    report = shutdown_background_workers(ctx)
    assert set(report.keys()) == {"scheduler", "market_worker", "news_worker"}
