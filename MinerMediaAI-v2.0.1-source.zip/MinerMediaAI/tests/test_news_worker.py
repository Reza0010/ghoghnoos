"""تست مأموریت ۴ — Worker زمان‌بندی‌شده اخبار و سیاست‌های منابع."""
import time

from config.settings import AppSettings
from services.news.service import NewsService, news_enabled_sources
from workers.news_worker import NewsWorker


def test_enabled_sources_filter():
    srcs = [
        ["A", "https://a/rss", "crypto", True],
        ["B", "https://b/rss", "crypto", False],
        ["C", "https://c/rss", "crypto"],           # بدون پرچم = فعال
        ["bad", "ftp://x", "crypto", True],          # غیر http → نادیده
        ["", "https://d/rss", "crypto", True],       # نام خالی → نادیده
    ]
    enabled = news_enabled_sources(srcs)
    names = [s[0] for s in enabled]
    assert names == ["A", "C"]


def test_settings_sources_roundtrip_with_flag(repos):
    st = AppSettings(repos["settings"])
    st.news_sources = [("A", "https://a/rss", "crypto", True),
                       ("B", "https://b/rss", "crypto", False)]
    assert st.news_sources == [["A", "https://a/rss", "crypto", True],
                               ["B", "https://b/rss", "crypto", False]]
    assert [s[0] for s in st.enabled_news_sources] == ["A"]
    # سازگاری با فرمت قدیمی ۳تایی
    st.news_sources = [("C", "https://c/rss", "crypto")]
    assert st.enabled_news_sources[0][0] == "C"


class FakeNewsService:
    """NewsService ساختگی با کنترل نتیجه — بدون شبکه."""

    def __init__(self, repo, fail_sources: set[str] | None = None):
        self.repo = repo
        self.calls: list[list] = []
        self.fail_sources = fail_sources or set()
        from models.entities import RefreshResult
        self._result_cls = RefreshResult

    def fetch_all(self, sources=None):
        self.calls.append(list(sources or []))
        result = self._result_cls(fetched_at="2026-01-01T00:00:00+00:00")
        errors = [f"منبع «{s[0]}» ناموفق بود." for s in (sources or [])
                  if s[0] in self.fail_sources]
        result.errors = errors
        result.updated = 0 if errors else 3
        result.ok = not errors
        return result


def test_news_worker_fetches_and_respects_interval(repos):
    svc = FakeNewsService(repos["news"])
    srcs = [("A", "https://a/rss", "crypto", True)]
    w = NewsWorker(svc, interval_provider=lambda: 300,
                   sources_provider=lambda: srcs)
    w.start()
    deadline = time.monotonic() + 5
    while len(svc.calls) < 1 and time.monotonic() < deadline:
        time.sleep(0.02)
    assert svc.calls, "دریافت فوری اول انجام نشد"
    assert svc.calls[0] == srcs
    assert w.stop_safe(3.0) is True


def test_news_worker_survives_source_errors(repos):
    """خطای منبع Worker را نمی‌کشد؛ چرخه بعدی ادامه می‌دهد."""
    svc = FakeNewsService(repos["news"], fail_sources={"A"})
    srcs = [("A", "https://a/rss", "crypto", True)]
    w = NewsWorker(svc, interval_provider=lambda: 300,
                   sources_provider=lambda: srcs)
    w.start()
    deadline = time.monotonic() + 5
    while len(svc.calls) < 1 and time.monotonic() < deadline:
        time.sleep(0.02)
    assert w.is_alive()
    w.stop_safe(3.0)
    assert not w.is_alive()


def test_news_worker_stop_is_honest_when_busy(repos):
    """کاربر stop می‌زند وسط درخواست → join تمام نمی‌شود → False صادقانه."""
    svc = FakeNewsService(repos["news"])
    release = threading_event = None
    import threading
    release = threading.Event()

    class SlowService(FakeNewsService):
        def fetch_all(self, sources=None):
            # ثبت فراخوانی قبل از بلاک — شبیه‌سازی درخواست طولانی در جریان
            self.calls.append(list(sources or []))
            release.wait(5)
            result = self._result_cls(fetched_at="2026-01-01T00:00:00+00:00")
            result.ok = True
            return result

    slow = SlowService(repos["news"])
    w = NewsWorker(slow, interval_provider=lambda: 300,
                   sources_provider=lambda: [])
    w.start()
    deadline = time.monotonic() + 5
    while len(slow.calls) < 1 and time.monotonic() < deadline:
        time.sleep(0.02)
    stopped = w.stop_safe(0.3)   # بودجه کوتاه — هنوز درخواست در جریان است
    assert stopped is False
    assert w.is_alive()          # فرض توقف نزده‌ایم
    release.set()
    assert w.stop_safe(5.0) is True   # پس از آزادسازی واقعاً تمام می‌شود


def test_news_service_old_news_and_missing_date(repos, fake_session_cls):
    """خبر قدیمی وارد صف نمی‌شود ولی شمرده می‌شود؛ خبر بی‌تاریخ با برچسب صادقانه می‌ماند."""
    from tests.conftest import FakeResponse
    now_year = 2026
    rss = f"""<?xml version="1.0"?>
    <rss version="2.0"><channel>
      <item><guid>old-1</guid><title>خبر قدیمی</title>
        <link>https://x/old</link>
        <pubDate>Mon, 01 Jan {now_year - 2} 00:00:00 GMT</pubDate></item>
      <item><guid>nodate-1</guid><title>خبر بی‌تاریخ</title>
        <link>https://x/nodate</link></item>
      <item><guid>dup-1</guid><title>خبر تکراری</title>
        <link>https://x/dup</link></item>
      <item><guid>dup-1</guid><title>خبر تکراری (دوباره)</title>
        <link>https://x/dup</link></item>
    </channel></rss>"""
    session = fake_session_cls(get_results=[FakeResponse(200, rss.encode())])
    svc = NewsService(repos["news"], session=session)
    result = svc.fetch_all([("TestSrc", "https://src/rss", "crypto")])
    assert result.ok
    items = repos["news"].list()
    titles = [i.title for i in items]
    assert "خبر قدیمی" not in titles          # قدیمی وارد نشد
    assert "خبر بی‌تاریخ" in titles            # بی‌تاریخ حذف نشد
    assert len(titles) == 2                    # تکراری فقط یک‌بار
    assert any("قدیمی" in n for n in result.notes)  # شمارش شفاف
