"""ابزارهای زمان — همه‌چیز UTC است؛ نمایش در منطقه زمانی کاربر."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

UTC = timezone.utc


def utc_now() -> datetime:
    return datetime.now(UTC)


def utc_iso(dt: datetime | None = None) -> str:
    """ISO-8601 با آفست صریح (مثال: 2026-10-11T06:30:00+00:00)."""
    dt = dt or utc_now()
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC).isoformat()


def parse_iso(value: str) -> datetime:
    """ISO-8601 را به datetime آگاه می‌کند (naive را UTC فرض می‌کند)."""
    value = (value or "").strip()
    if not value:
        raise ValueError("رشته زمان خالی است")
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt


def to_local(dt_utc: datetime, tz_name: str) -> datetime:
    return dt_utc.astimezone(ZoneInfo(tz_name))


def parse_user_datetime(date_str: str, time_str: str, tz_name: str) -> datetime:
    """تاریخ/ساعت ورودی کاربر در منطقه زمانی او را به UTC تبدیل می‌کند."""
    dt = datetime.strptime(f"{date_str.strip()} {time_str.strip()}", "%Y-%m-%d %H:%M")
    return dt.replace(tzinfo=ZoneInfo(tz_name)).astimezone(UTC)


def format_local(dt_utc: datetime | str, tz_name: str, with_seconds: bool = False) -> str:
    """نمایش خوانا در منطقه زمانی کاربر."""
    dt = parse_iso(dt_utc) if isinstance(dt_utc, str) else dt_utc
    fmt = "%Y-%m-%d %H:%M:%S" if with_seconds else "%Y-%m-%d %H:%M"
    return to_local(dt, tz_name).strftime(fmt)


def relative_age(dt_utc: datetime | str, now: datetime | None = None) -> timedelta:
    dt = parse_iso(dt_utc) if isinstance(dt_utc, str) else dt_utc
    return (now or utc_now()) - dt


def monotonic() -> float:
    """ساعت تک‌نوتیک برای اندازه‌گیری فاصله زمانی (برای rate-limiter)."""
    import time
    return time.monotonic()


def backoff_delay(attempt: int, base: int, cap: int) -> float:
    """تأخیر افزایشی: base × 2^(attempt-1) با سقف cap."""
    if attempt <= 1:
        return float(base)
    return float(min(cap, base * (2 ** (attempt - 1))))
