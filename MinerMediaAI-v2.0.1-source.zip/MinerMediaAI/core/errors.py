"""سلسله‌مراتب خطاهای برنامه.

هر خطا دو پیام دارد:
- technical: برای لاگ (فقط پس از scrub توکن‌ها)
- user_message: متن فارسی قابل نمایش به کاربر
"""
from __future__ import annotations


class MinerMediaError(Exception):
    """خطای پایه برنامه."""

    user_message = "خطای نامشخص رخ داد."

    def __init__(self, technical: str = "", user_message: str | None = None):
        self.technical = technical or self.__class__.__name__
        if user_message:
            self.user_message = user_message
        super().__init__(self.technical)

    def __str__(self) -> str:  # pragma: no cover - نمایشی
        return self.technical


class ConfigError(MinerMediaError):
    user_message = "تنظیمات برنامه نامعتبر است."


class SecretStoreError(MinerMediaError):
    user_message = "ذخیره‌سازی امن رمزها در دسترس نیست."


class DatabaseError(MinerMediaError):
    user_message = "خطای پایگاه داده."


class ValidationError(MinerMediaError):
    user_message = "ورودی نامعتبر است."


class MediaError(ValidationError):
    user_message = "فایل رسانه‌ای نامعتبر است."


# ---------------------------------------------------------------------------
# خطاهای شبکه و API
# ---------------------------------------------------------------------------
class NetworkError(MinerMediaError):
    """خطای شبکه‌ای موقت (timeout، قطع اتصال، خطای 5xx سرور).

    phase مشخص می‌کند خطا در چه مرحله‌ای رخ داده:
    - "connect": اتصال برقرار نشد → درخواست به مقصد نرسیده → تلاش مجدد امن‌تر است
    - "read": اتصال برقرار شد ولی پاسخ دریافت نشد → نتیجه مبهم است
    """

    def __init__(self, technical: str = "", user_message: str | None = None,
                 phase: str = "other", retry_after: float | None = None):
        super().__init__(technical, user_message)
        self.phase = phase
        self.retry_after = retry_after


class RateLimitError(MinerMediaError):
    """خطای 429 — شامل retry_after (ثانیه) در صورت ارسال توسط سرویس."""

    def __init__(self, technical: str = "", user_message: str | None = None,
                 retry_after: float | None = None):
        super().__init__(technical, user_message)
        self.retry_after = retry_after


class APIError(MinerMediaError):
    """خطای منطقی از سمت API (خطای دائمی — تلاش مجدد بی‌فایده است)."""

    def __init__(self, technical: str = "", user_message: str | None = None,
                 status_code: int | None = None, code: str | None = None):
        super().__init__(technical, user_message)
        self.status_code = status_code
        self.code = code


class TelegramError(APIError):
    user_message = "خطای تلگرام."


class NobitexError(APIError):
    user_message = "خطای سرویس نوبیتکس."


class AIError(APIError):
    user_message = "خطای سرویس هوش مصنوعی."


class UnknownOutcomeError(MinerMediaError):
    """نتیجه درخواست ارسال مبهم است (مثلاً timeout پس از ارسال).

    در این حالت هیچ‌گاه به‌صورت خودکار دوباره ارسال نمی‌شود.
    """

    user_message = "نتیجه عملیات مبهم است؛ ارسال مجدد خودکار انجام نمی‌شود."
