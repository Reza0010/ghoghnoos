"""راه‌اندازی لاگ‌گیری برنامه با پاک‌سازی خودکار اطلاعات حساس."""
from __future__ import annotations

import logging
import logging.handlers
import sys

from .redact import scrub_text


class SecretScrubbingFilter(logging.Filter):
    """هر رکورد لاگ را قبل از نوشتن از توکن/کلید پاک می‌کند."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = scrub_text(str(record.msg))
            if record.args:
                record.args = tuple(
                    scrub_text(str(a)) if isinstance(a, str) else a
                    for a in record.args
                )
        except Exception:  # noqa: BLE001 — لاگ هرگز نباید برنامه را بشکند
            pass
        return True


def setup_logging(level: int = logging.INFO, console: bool = True) -> logging.Logger:
    logger = logging.getLogger("minermedia")
    if logger.handlers:  # جلوگیری از دوباره‌سازی
        return logger
    logger.setLevel(level)

    from .paths import get_log_dir
    handler = logging.handlers.RotatingFileHandler(
        get_log_dir() / "app.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"))
    handler.addFilter(SecretScrubbingFilter())
    logger.addHandler(handler)

    if console:
        ch = logging.StreamHandler(sys.stderr)
        ch.setFormatter(logging.Formatter("%(levelname)-7s | %(message)s"))
        ch.addFilter(SecretScrubbingFilter())
        logger.addHandler(ch)

    logger.propagate = False
    return logger


def get_logger(name: str = "minermedia") -> logging.Logger:
    return logging.getLogger(name)
