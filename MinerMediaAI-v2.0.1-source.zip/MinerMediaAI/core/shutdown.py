"""هماهنگ‌کننده خاموشی — ترتیب واقعی توقف Threadها و تصمیم صادقانه درباره دیتابیس.

قاعده طلایی (مأموریت ۱):
- دیتابیس تا وقتی Workerهای استفاده‌کننده از آن واقعاً متوقف نشده‌اند بسته
  نمی‌شود؛ اگر توقف کامل نشد، بستن دیتابیس را «رد» می‌کنیم و صادقانه لاگ
  می‌کنیم — هرگز فرض نمی‌کنیم Thread به‌خاطر اتمام timeout متوقف شده است.
- بودجهٔ هر Worker از timeoutهای واقعی شبکه‌اش مشتق می‌شود (نه عدد دلخواه):
  * scheduler: تلگرام connect 8s + read 60s + حاشیه → 75s
  * market worker: نوبیتکس connect 6s + read 15s + گیت نرخ 4s + حاشیه → 30s
  * news worker: هر منبع تا 15s؛ یک گذر کامل با N منبع → 15×N+10s (سقف 100)
  * threadهای kick لحظه‌ای بازار: نوبیتکس 6+15+4 → 30s
- Workerهای QThread صفحات (نمودار/دریافت اخبار/خلاصه‌سازی) هم منتظر می‌مانیم.
"""
from __future__ import annotations

import time

from core.logging_setup import get_logger
from core.redact import scrub_text

log = get_logger("minermedia.shutdown")

SCHEDULER_BUDGET_SEC = 75.0      # telegram (8, 60) + margin
MARKET_BUDGET_SEC = 30.0         # nobitex (6, 15) + stats gate 4s + margin
NEWS_PER_SOURCE_SEC = 15.0       # NewsService timeout per source
NEWS_BUDGET_CAP_SEC = 100.0
KICK_BUDGET_SEC = 30.0
QTHREAD_WAIT_MS = 25000          # نمودار/اخبار صفحه‌ها — هم‌مرتبه با بودجه شبکه

WORKER_ATTRS = ("_hist_worker", "_worker", "_summarize_worker")


def _news_budget(sources_count: int) -> float:
    return min(NEWS_PER_SOURCE_SEC * max(1, sources_count) + 10.0,
               NEWS_BUDGET_CAP_SEC)


def stop_joinable(thread, join_timeout: float) -> bool:
    """join ساده با بودجه؛ خروجی: واقعاً تمام شد؟"""
    if thread is None or not thread.is_alive():
        return True
    thread.join(timeout=join_timeout)
    return not thread.is_alive()


def shutdown_background_workers(
        ctx,
        scheduler_budget: float | None = None,
        market_budget: float | None = None,
        news_budget: float | None = None,
        kick_budget: float | None = None) -> dict[str, bool]:
    """توقف همه Workerهای پس‌زمینه به ترتیب درست. خروجی: {name: stopped?}.

    ترتیب: اول پرچم توقف همه (تا موازی شروع به تمام‌شدن کنند)، بعد join
    با بودجهٔ هرکدام. اگر مجموع بودجه‌ها طولانی شد، از سهم باقی‌ماندهٔ
    deadline مشترک استفاده می‌شود — اما هیچ‌وقت «فرض توقف» نمی‌زنیم.
    """
    report: dict[str, bool] = {}

    # ---------- فاز ۱: پرچم توقف ----------
    scheduler = getattr(ctx, "scheduler", None)
    market = getattr(ctx, "market_worker", None)
    news = getattr(ctx, "news_worker", None)
    for w in (scheduler, market, news):
        if w is not None and w.is_alive():
            try:
                w._stop_flag.set()  # noqa: SLF001 — همان قرارداد داخلی stop_safe
            except AttributeError:
                pass

    # ---------- فاز ۲: join با بودجهٔ واقعی ----------
    if news_budget is None:
        try:
            news_src_count = len(ctx.settings.enabled_news_sources)
        except Exception:  # noqa: BLE001
            news_src_count = 5
        news_budget = _news_budget(news_src_count)
    scheduler_budget = SCHEDULER_BUDGET_SEC if scheduler_budget is None else scheduler_budget
    market_budget = MARKET_BUDGET_SEC if market_budget is None else market_budget
    kick_budget = KICK_BUDGET_SEC if kick_budget is None else kick_budget

    if scheduler is not None and scheduler.is_alive():
        try:
            report["scheduler"] = scheduler.stop_safe(scheduler_budget)
        except Exception as exc:  # noqa: BLE001
            report["scheduler"] = not scheduler.is_alive()
            log.error("scheduler stop error: %s", scrub_text(str(exc)))
    else:
        report["scheduler"] = True

    if market is not None and market.is_alive():
        try:
            report["market_worker"] = market.stop_safe(market_budget)
        except Exception as exc:  # noqa: BLE001
            report["market_worker"] = not market.is_alive()
            log.error("market worker stop error: %s", scrub_text(str(exc)))
    else:
        report["market_worker"] = True

    if news is not None and news.is_alive():
        try:
            report["news_worker"] = news.stop_safe(news_budget)
        except Exception as exc:  # noqa: BLE001
            report["news_worker"] = not news.is_alive()
            log.error("news worker stop error: %s", scrub_text(str(exc)))
    else:
        report["news_worker"] = True

    # threadهای kick لحظه‌ای (فاقد stop_flag — فقط join)
    kick_threads = []
    try:
        kick_threads = list(ctx.kick_threads())
    except Exception:  # noqa: BLE001
        pass
    alive_kick = [t for t in kick_threads if t is not None and t.is_alive()]
    for i, t in enumerate(alive_kick):
        report[f"market_kick_{i}"] = stop_joinable(t, kick_budget)

    # ---------- فاز ۳: QThreadهای صفحات ----------
    for w in _collect_page_qthreads(ctx):
        try:
            w.wait(QTHREAD_WAIT_MS)
            report[f"qthread_{w.__class__.__name__}_{id(w) % 1000}"] = \
                not w.isRunning()
        except Exception:  # noqa: BLE001
            report[f"qthread_{id(w) % 1000}"] = False

    return report


def _collect_page_qthreads(ctx) -> list:
    out: list = []
    window = getattr(ctx, "main_window", None)
    pages = getattr(window, "pages", {}) if window is not None else {}
    for page in pages.values():
        for attr in WORKER_ATTRS:
            w = getattr(page, attr, None)
            if w is not None and getattr(w, "isRunning", lambda: False)():
                out.append(w)
    return out


def all_workers_stopped(report: dict[str, bool]) -> bool:
    return bool(report) and all(report.values())


def close_database_safely(db, report: dict[str, bool]) -> bool:
    """دیتابیس فقط وقتی بسته می‌شود که هیچ Worker زنده‌ای باقی نمانده باشد.

    اگر توقف کامل نشده بود → بستن را رد می‌کنیم (True برنمی‌گردانیم)؛
    خروج از برنامه اتصال‌ها را در سطح OS می‌بندد و SQLite در حالت WAL
    در برابر این خروج سالم است — اما «بستن روی Worker زنده» که خطای
    «closed database» حین نوشتن می‌سازد، ممنوع است.
    """
    if all_workers_stopped(report):
        try:
            db.close()
            log.info("database closed cleanly after all workers stopped")
            return True
        except Exception as exc:  # noqa: BLE001
            log.error("db close error: %s", scrub_text(str(exc)))
            return False
    still = [k for k, v in report.items() if not v]
    log.warning("shutdown: workers still running after budget: %s — "
                "database NOT closed explicitly (process exit will release it)",
                ", ".join(still))
    return False


def wait_for_deadline(deadline: float) -> float:
    """کمکی برای تست‌ها — ثانیهٔ باقی‌مانده تا deadline (منفی = گذشته)."""
    return deadline - time.monotonic()
