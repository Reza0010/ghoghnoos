"""مسیرهای داده برنامه — جداسازی کامل داده کاربر از کد.

- ویندوز: %APPDATA%\\MinerMediaAI
- لینوکس/مک: ~/.local/share/MinerMediaAI
- برای تست/توسعه: متغیر محیطی MINERMEDIA_DATA_DIR
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

DATA_DIR_ENV = "MINERMEDIA_DATA_DIR"
DB_FILENAME = "minermedia.db"
SECRETS_FILENAME = "secrets.json"
LOG_DIRNAME = "logs"
MEDIA_DIRNAME = "media"
BACKUP_DIRNAME = "backups"


def get_data_dir() -> Path:
    """دایرکتوری داده کاربر را برمی‌گرداند و در صورت نیاز می‌سازد."""
    env = os.environ.get(DATA_DIR_ENV, "").strip()
    if env:
        base = Path(env)
    elif sys.platform.startswith("win"):
        appdata = os.environ.get("APPDATA", "")
        base = Path(appdata) / "MinerMediaAI" if appdata else Path.home() / "MinerMediaAI"
    else:
        xdg = os.environ.get("XDG_DATA_HOME", "")
        base = (Path(xdg) if xdg else Path.home() / ".local" / "share") / "MinerMediaAI"
    base.mkdir(parents=True, exist_ok=True)
    return base


def get_log_dir() -> Path:
    p = get_data_dir() / LOG_DIRNAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def get_media_dir() -> Path:
    p = get_data_dir() / MEDIA_DIRNAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def get_backup_dir() -> Path:
    p = get_data_dir() / BACKUP_DIRNAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def get_db_path() -> Path:
    return get_data_dir() / DB_FILENAME
