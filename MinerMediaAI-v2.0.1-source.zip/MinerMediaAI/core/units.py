"""فرمت‌کننده ارز و تبدیل ریال/تومان.

قاعده مأموریت: هر ۱۰ ریال = ۱ تومان. واحد هر مقدار باید صریح باشد و
هیچ‌گاه از «ظاهر عدد» حدس واحد زده نمی‌شود.

منابع واحد:
- /market/stats با dstCurrency=rls → مقادیر برحسب «ریال» (طبق مستندات رسمی نوبیتکس)
- /market/udf/history برای نماد <SYM>IRT → مقادیر برحسب «تومان»
  (تأیید تجربی: close کندل IRT × ۱۰ == latest ریالی stats)
"""
from __future__ import annotations

RIAL_PER_TOMAN = 10

_FA_DIGITS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def rial_to_toman(rial: float) -> float:
    return float(rial) / RIAL_PER_TOMAN


def toman_to_rial(toman: float) -> float:
    return float(toman) * RIAL_PER_TOMAN


def to_persian_digits(text: str) -> str:
    return str(text).translate(_FA_DIGITS)


def format_amount(value: float | int | None, decimals: int = 0,
                  persian_digits: bool = False) -> str:
    """عدد با جداکننده هزارگان (مثل 219,456,369,080)."""
    if value is None:
        return "—"
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "—"
    if abs(v - round(v)) < 1e-12:
        s = f"{int(round(v)):,}"
    else:
        s = f"{v:,.{decimals}f}"
    return to_persian_digits(s) if persian_digits else s


def format_price(value: float | None, unit: str, decimals: int | None = None,
                 persian_digits: bool = False) -> str:
    """قیمت با واحد صریح: «ریال»، «تومان»، «دلار/USDT»."""
    if value is None:
        return "ناموجود"
    if unit == "RIAL":
        return f"{format_amount(value, decimals or 0, persian_digits)} ریال"
    if unit == "TOMAN":
        return f"{format_amount(value, decimals or 0, persian_digits)} تومان"
    if unit in ("USDT", "USD"):
        d = 2 if decimals is None else decimals
        return f"{format_amount(value, d, persian_digits)} USDT"
    return f"{format_amount(value, decimals or 2, persian_digits)} {unit}"


def format_percent(p: float | None, persian_digits: bool = False) -> str:
    """درصد تغییر ۲۴ ساعته: +0.17٪ / -0.16٪."""
    if p is None:
        return "—"
    sign = "+" if p >= 0 else "−"   # منفی واقعی U+2212 برای خوانایی
    s = f"{sign}{abs(p):.2f}٪"
    return to_persian_digits(s) if persian_digits else s


def format_compact(value: float | None, unit: str, persian_digits: bool = False) -> str:
    """نمایش فشرده خوانا: میلیارد/میلیون/هزار."""
    if value is None:
        return "ناموجود"
    v = abs(float(value))
    sign = "−" if float(value) < 0 else ""
    units = [
        (1_000_000_000_000, "تریلیون"),
        (1_000_000_000, "میلیارد"),
        (1_000_000, "میلیون"),
        (1_000, "هزار"),
    ]
    out = None
    for factor, label in units:
        if v >= factor:
            out = f"{sign}{v / factor:,.2f} {label}"
            break
    if out is None:
        out = f"{sign}{v:,.0f}"
    if unit == "RIAL":
        out += " ریال"
    elif unit == "TOMAN":
        out += " تومان"
    elif unit in ("USDT", "USD"):
        out += " USDT"
    return to_persian_digits(out) if persian_digits else out


def smart_price_decimals(value: float, unit: str) -> int:
    """تعداد اعشار مناسب بر اساس بزرگی عدد و واحد."""
    v = abs(float(value or 0))
    if unit in ("USDT", "USD"):
        return 0 if v >= 1000 else (2 if v >= 0.01 else 6)
    return 0 if v >= 100 else 6
