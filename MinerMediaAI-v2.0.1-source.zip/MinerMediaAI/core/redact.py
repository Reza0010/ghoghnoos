"""پاک‌سازی اطلاعات حساس از رشته‌ها و ساختارها قبل از لاگ/نمایش.

از نشت توکن ربات تلگرام و کلیدهای API در لاگ، Traceback و پیام خطا جلوگیری می‌کند.
"""
from __future__ import annotations

import re

# توکن ربات تلگرام: <bot_id>:<35+ کاراکتر>
# بدون \b ابتدایی: توکن در URL به‌صورت «bot<TOKEN>» چسبیده است
_TELEGRAM_TOKEN = re.compile(r"\d{6,12}:[A-Za-z0-9_-]{30,}")
# کلیدهای OpenAI/OpenRouter
_OPENAI_KEY = re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{16,}\b", re.IGNORECASE)
# توکن Authorization: Bearer
_BEARER = re.compile(r"(?i)\b(bearer\s+)[A-Za-z0-9._-]{8,}")
# پارامترهای توکن در URL
_URL_TOKEN = re.compile(r"(?i)([?&](?:token|key|api_key|apikey|access_token)=)[^&\s]+")

_REPLACEMENT = "«REDACTED»"


def scrub_text(text: str) -> str:
    """تمام الگوهای حساس را در یک رشته پاک می‌کند."""
    if not text:
        return text
    out = _TELEGRAM_TOKEN.sub(_REPLACEMENT, text)
    out = _OPENAI_KEY.sub(_REPLACEMENT, out)
    out = _BEARER.sub(r"\1" + _REPLACEMENT, out)
    out = _URL_TOKEN.sub(r"\1" + _REPLACEMENT, out)
    return out


def scrub(value) -> object:
    """به‌صورت بازگشتی رشته‌های داخل dict/list را پاک می‌کند."""
    if isinstance(value, str):
        return scrub_text(value)
    if isinstance(value, dict):
        return {k: scrub(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        t = type(value)
        return t(scrub(v) for v in value)
    return value


def contains_secret(text: str) -> bool:
    """بررسی می‌کند آیا متن حاوی الگوی توکن/کلید است (برای تست‌ها)."""
    return bool(
        _TELEGRAM_TOKEN.search(text)
        or _OPENAI_KEY.search(text)
        or _URL_TOKEN.search(text)
    )
