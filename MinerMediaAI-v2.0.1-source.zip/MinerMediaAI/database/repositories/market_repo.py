"""ریپازیتوری بازار: فهرست منتخب، قیمت‌ها، نمونه‌های محلی برای نمودار.

قواعد حیاتی:
- هر رکورد قیمت دارای symbol + market + currency + source + fetched_at است.
- currency همیشه صریح است (RIAL/TOMAN/USDT) — تبدیل واحد فقط در core.units.
"""
from __future__ import annotations

from core.timeutils import utc_iso, utc_now
from database.db import Database
from models.entities import WatchItem


class MarketRepo:
    def __init__(self, db: Database):
        self.db = db

    # --------------------------- فهرست منتخب ---------------------------
    def seed_defaults(self, items: list[tuple[str, str]]) -> None:
        """فقط اگر فهرست خالی باشد ارزهای پیش‌فرض را وارد می‌کند."""
        row = self.db.query_one("SELECT COUNT(*) AS n FROM market_watchlist")
        if row and int(row["n"]) > 0:
            return
        for i, (sym, name) in enumerate(items):
            self.db.execute(
                "INSERT OR IGNORE INTO market_watchlist(symbol, display_name, "
                "visible, sort_order, added_at) VALUES (?,?,1,?,?)",
                (sym.upper(), name, i, utc_iso()))

    def list_watch(self, visible_only: bool = False) -> list[WatchItem]:
        sql = "SELECT * FROM market_watchlist"
        if visible_only:
            sql += " WHERE visible = 1"
        sql += " ORDER BY sort_order, id"
        return [WatchItem(id=int(r["id"]), symbol=r["symbol"],
                          display_name=r["display_name"],
                          visible=bool(r["visible"]), sort_order=int(r["sort_order"]))
                for r in self.db.query(sql)]

    def add_watch(self, symbol: str, display_name: str = "") -> bool:
        symbol = symbol.strip().upper()
        if not symbol or not symbol.isalnum() or len(symbol) > 12:
            from core.errors import ValidationError
            raise ValidationError(f"bad symbol: {symbol}",
                                  "نماد ارز نامعتبر است (فقط حروف/عدد).")
        exists = self.db.query_one(
            "SELECT id FROM market_watchlist WHERE symbol=?", (symbol,))
        if exists:
            return False
        row = self.db.query_one("SELECT COALESCE(MAX(sort_order),0)+1 AS nx "
                                "FROM market_watchlist")
        self.db.execute(
            "INSERT INTO market_watchlist(symbol, display_name, visible, sort_order, "
            "added_at) VALUES (?,?,1,?,?)",
            (symbol, display_name or symbol, int(row["nx"]), utc_iso()))
        return True

    def remove_watch(self, symbol: str) -> None:
        self.db.execute("DELETE FROM market_watchlist WHERE symbol=?",
                        (symbol.strip().upper(),))

    def set_visible(self, symbol: str, visible: bool) -> None:
        self.db.execute("UPDATE market_watchlist SET visible=? WHERE symbol=?",
                        (int(visible), symbol.strip().upper()))

    def reorder(self, ordered_symbols: list[str]) -> None:
        with self.db.transaction() as conn:
            for i, sym in enumerate(ordered_symbols):
                conn.execute("UPDATE market_watchlist SET sort_order=? WHERE symbol=?",
                             (i, sym.upper()))

    # --------------------------- نمادهای بدون جفت ---------------------------
    def get_invalid_symbols(self) -> list[str]:
        """نمادهایی که نوبیتکس برایشان جفت معاملاتی ندارد (مانا در تنظیمات)."""
        row = self.db.query_one(
            "SELECT value FROM app_settings WHERE key='market_invalid_symbols'")
        if not row:
            return []
        try:
            import json
            return [str(s) for s in json.loads(row["value"])]
        except (ValueError, TypeError):
            return []

    def set_invalid_symbols(self, symbols: list[str]) -> None:
        import json
        self.db.execute(
            "INSERT INTO app_settings(key, value) VALUES ('market_invalid_symbols', ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (json.dumps(sorted(set(symbols))),))

    # ----------------------------- قیمت‌ها -----------------------------
    def upsert_quote(self, symbol: str, market: str, price: float | None,
                     currency: str, source: str, fetched_at: str,
                     day_change: float | None, day_high: float | None,
                     day_low: float | None, day_open: float | None,
                     best_buy: float | None, best_sell: float | None,
                     volume_src: float | None, volume_dst: float | None,
                     is_closed: bool, stale: bool) -> None:
        self.db.execute(
            "INSERT INTO market_prices(symbol, market, price, currency, source, "
            "fetched_at, day_change, day_high, day_low, day_open, best_buy, best_sell, "
            "volume_src, volume_dst, is_closed, stale) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(symbol, market) DO UPDATE SET "
            "price=excluded.price, currency=excluded.currency, source=excluded.source, "
            "fetched_at=excluded.fetched_at, day_change=excluded.day_change, "
            "day_high=excluded.day_high, day_low=excluded.day_low, "
            "day_open=excluded.day_open, best_buy=excluded.best_buy, "
            "best_sell=excluded.best_sell, volume_src=excluded.volume_src, "
            "volume_dst=excluded.volume_dst, is_closed=excluded.is_closed, "
            "stale=excluded.stale",
            (symbol, market, price, currency, source, fetched_at, day_change,
             day_high, day_low, day_open, best_buy, best_sell, volume_src,
             volume_dst, int(is_closed), int(stale)))

    def mark_stale(self, symbol: str, market: str) -> None:
        self.db.execute(
            "UPDATE market_prices SET stale=1 WHERE symbol=? AND market=?",
            (symbol, market))

    def get_quote(self, symbol: str, market: str) -> dict | None:
        row = self.db.query_one(
            "SELECT * FROM market_prices WHERE symbol=? AND market=?",
            (symbol, market))
        return dict(row) if row else None

    def add_sample(self, symbol: str, market: str, price: float,
                   currency: str, sampled_at: str | None = None) -> None:
        self.db.execute(
            "INSERT INTO price_samples(symbol, market, price, currency, sampled_at) "
            "VALUES (?,?,?,?,?)",
            (symbol, market, price, currency, sampled_at or utc_iso()))

    def last_sample_at(self, symbol: str, market: str) -> str | None:
        row = self.db.query_one(
            "SELECT sampled_at FROM price_samples WHERE symbol=? AND market=? "
            "ORDER BY sampled_at DESC LIMIT 1", (symbol, market))
        return row["sampled_at"] if row else None

    def samples(self, symbol: str, market: str, since_utc_iso: str) -> list[dict]:
        rows = self.db.query(
            "SELECT price, currency, sampled_at FROM price_samples "
            "WHERE symbol=? AND market=? AND sampled_at >= ? ORDER BY sampled_at",
            (symbol, market, since_utc_iso))
        return [dict(r) for r in rows]

    def cleanup_samples(self, days: int) -> int:
        from datetime import timedelta
        cutoff = utc_iso(utc_now() - timedelta(days=days))
        cur = self.db.execute("DELETE FROM price_samples WHERE sampled_at < ?",
                              (cutoff,))
        return cur.rowcount or 0
