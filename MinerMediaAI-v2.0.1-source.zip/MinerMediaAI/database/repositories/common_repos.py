"""ریپازیتوری اخبار، پیش‌نویس‌ها، تاریخچه تولید، تنظیمات، لاگ و رسانه."""
from __future__ import annotations

import hashlib
import json

from core.timeutils import utc_iso
from database.db import Database
from models.entities import ContentDraft, MediaAsset, NewsItem


class NewsRepo:
    def __init__(self, db: Database):
        self.db = db

    @staticmethod
    def dedupe_hash(title: str, link: str) -> str:
        norm = " ".join((title or "").lower().split()) + "|" + (link or "").strip()
        return hashlib.sha1(norm.encode("utf-8")).hexdigest()

    def upsert(self, item: NewsItem) -> bool:
        """True اگر جدید بود و اضافه شد؛ False اگر تکراری بود."""
        h = self.dedupe_hash(item.title, item.link)
        dup = self.db.query_one(
            "SELECT id FROM news_items WHERE guid=? OR dedupe_hash=?",
            (item.guid, h))
        if dup:
            return False
        try:
            self.db.execute(
                "INSERT INTO news_items(guid, title, link, source, topic, "
                "published_at, fetched_at, summary, status, dedupe_hash) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                (item.guid, item.title, item.link, item.source, item.topic,
                 item.published_at, item.fetched_at or utc_iso(), item.summary,
                 item.status, h))
            return True
        except Exception:  # noqa: BLE001 — رکورد تکراری هم‌زمان
            return False

    def list(self, status: str | None = None, topic: str | None = None,
             q: str | None = None, limit: int = 100) -> list[NewsItem]:
        sql = "SELECT * FROM news_items WHERE 1=1"
        params: list = []
        if status:
            sql += " AND status = ?"
            params.append(status)
        if topic:
            sql += " AND topic = ?"
            params.append(topic)
        if q:
            sql += " AND (title LIKE ? OR summary LIKE ?)"
            params.extend([f"%{q}%", f"%{q}%"])
        sql += " ORDER BY COALESCE(published_at, fetched_at) DESC LIMIT ?"
        params.append(limit)
        return [self._from_row(r) for r in self.db.query(sql, params)]

    def set_status(self, item_id: int, status: str) -> None:
        self.db.execute("UPDATE news_items SET status=? WHERE id=?", (status, item_id))

    def get(self, item_id: int) -> NewsItem | None:
        row = self.db.query_one("SELECT * FROM news_items WHERE id=?", (item_id,))
        return self._from_row(row) if row else None

    def counts_by_status(self) -> dict[str, int]:
        rows = self.db.query(
            "SELECT status, COUNT(*) AS n FROM news_items GROUP BY status")
        return {r["status"]: int(r["n"]) for r in rows}

    def cleanup(self, days: int) -> int:
        from core.timeutils import parse_iso, utc_now
        from datetime import timedelta
        cutoff = utc_iso(utc_now() - timedelta(days=days))
        cur = self.db.execute("DELETE FROM news_items WHERE fetched_at < ?", (cutoff,))
        return cur.rowcount or 0

    @staticmethod
    def _from_row(r) -> NewsItem:
        return NewsItem(id=int(r["id"]), guid=r["guid"], title=r["title"],
                        link=r["link"], source=r["source"], topic=r["topic"],
                        published_at=r["published_at"], fetched_at=r["fetched_at"],
                        summary=r["summary"], status=r["status"])


class DraftsRepo:
    def __init__(self, db: Database):
        self.db = db

    def create(self, draft: ContentDraft) -> int:
        now = utc_iso()
        cur = self.db.execute(
            "INSERT INTO content_drafts(category, ctype, title, body, hashtags, "
            "media_path, status, created_at, updated_at, meta) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (draft.category, draft.ctype, draft.title, draft.body, draft.hashtags,
             draft.media_path, draft.status, now, now, draft.meta))
        return int(cur.lastrowid)

    def get(self, draft_id: int) -> ContentDraft | None:
        row = self.db.query_one("SELECT * FROM content_drafts WHERE id=?", (draft_id,))
        return self._from_row(row) if row else None

    def list(self, status: str | None = None, category: str | None = None,
             limit: int = 100) -> list[ContentDraft]:
        sql = "SELECT * FROM content_drafts WHERE 1=1"
        params: list = []
        if status:
            sql += " AND status = ?"
            params.append(status)
        if category:
            sql += " AND category = ?"
            params.append(category)
        sql += " ORDER BY updated_at DESC LIMIT ?"
        params.append(limit)
        return [self._from_row(r) for r in self.db.query(sql, params)]

    def update(self, draft_id: int, **fields) -> None:
        allowed = {"title", "body", "hashtags", "media_path", "status", "meta"}
        sets, params = [], []
        for k, v in fields.items():
            if k in allowed:
                sets.append(f"{k}=?")
                params.append(v)
        if not sets:
            return
        sets.append("updated_at=?")
        params.append(utc_iso())
        params.append(draft_id)
        self.db.execute(f"UPDATE content_drafts SET {', '.join(sets)} WHERE id=?",
                        params)

    def set_status(self, draft_id: int, status: str) -> None:
        approved = utc_iso() if status == "approved" else None
        if approved:
            self.db.execute(
                "UPDATE content_drafts SET status=?, approved_at=?, updated_at=? "
                "WHERE id=?", (status, approved, utc_iso(), draft_id))
        else:
            self.db.execute(
                "UPDATE content_drafts SET status=?, updated_at=? WHERE id=?",
                (status, utc_iso(), draft_id))

    def delete(self, draft_id: int) -> None:
        self.db.execute("DELETE FROM content_drafts WHERE id=?", (draft_id,))

    # ------------------------ تاریخچه تولید ------------------------
    def add_generation(self, draft_id: int | None, category: str, ctype: str,
                       provider: str, model: str, prompt_tokens: int | None,
                       completion_tokens: int | None, ok: bool,
                       error: str = "") -> None:
        self.db.execute(
            "INSERT INTO generation_history(draft_id, category, ctype, provider, "
            "model, prompt_tokens, completion_tokens, ok, error, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (draft_id, category, ctype, provider, model, prompt_tokens,
             completion_tokens, int(ok), error[:500], utc_iso()))

    def generation_stats(self) -> dict:
        row = self.db.query_one(
            "SELECT COUNT(*) AS total, "
            "COALESCE(SUM(CASE WHEN ok=1 THEN 1 ELSE 0 END),0) AS ok, "
            "COALESCE(SUM(prompt_tokens),0) AS pt, "
            "COALESCE(SUM(completion_tokens),0) AS ct "
            "FROM generation_history")
        return dict(row) if row else {}

    @staticmethod
    def _from_row(r) -> ContentDraft:
        return ContentDraft(
            id=int(r["id"]), category=r["category"], ctype=r["ctype"],
            title=r["title"], body=r["body"], hashtags=r["hashtags"],
            media_path=r["media_path"], status=r["status"],
            created_at=r["created_at"], updated_at=r["updated_at"],
            approved_at=r["approved_at"], meta=r["meta"] or "")


class SettingsRepo:
    """ذخیره تنظیمات غیرمحرمانه در app_settings (مقدار JSON)."""

    def __init__(self, db: Database):
        self.db = db

    def get(self, key: str, default=None):
        row = self.db.query_one("SELECT value FROM app_settings WHERE key=?", (key,))
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except (ValueError, TypeError):
            return default

    def set(self, key: str, value) -> None:
        self.db.execute(
            "INSERT INTO app_settings(key, value) VALUES (?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value, ensure_ascii=False)))

    def all_settings(self) -> dict:
        rows = self.db.query("SELECT key, value FROM app_settings")
        out = {}
        for r in rows:
            try:
                out[r["key"]] = json.loads(r["value"])
            except (ValueError, TypeError):
                out[r["key"]] = r["value"]
        return out

    def delete(self, key: str) -> None:
        self.db.execute("DELETE FROM app_settings WHERE key=?", (key,))


class LogsRepo:
    def __init__(self, db: Database):
        self.db = db

    def add(self, level: str, category: str, message: str) -> None:
        self.db.execute(
            "INSERT INTO operation_logs(ts, level, category, message) "
            "VALUES (?,?,?,?)", (utc_iso(), level, category, message[:1000]))

    def query(self, level: str | None = None, category: str | None = None,
              limit: int = 200) -> list[dict]:
        sql = "SELECT * FROM operation_logs WHERE 1=1"
        params: list = []
        if level:
            sql += " AND level=?"
            params.append(level)
        if category:
            sql += " AND category=?"
            params.append(category)
        sql += " ORDER BY ts DESC LIMIT ?"
        params.append(limit)
        return [dict(r) for r in self.db.query(sql, params)]

    def cleanup(self, days: int) -> int:
        from core.timeutils import parse_iso, utc_now
        from datetime import timedelta
        cutoff = utc_iso(utc_now() - timedelta(days=days))
        cur = self.db.execute("DELETE FROM operation_logs WHERE ts < ?", (cutoff,))
        return cur.rowcount or 0


class MediaRepo:
    def __init__(self, db: Database):
        self.db = db

    def upsert(self, asset: MediaAsset) -> int | None:
        row = self.db.query_one("SELECT id FROM media_assets WHERE path=?",
                                (asset.path,))
        if row:
            return int(row["id"])
        cur = self.db.execute(
            "INSERT INTO media_assets(path, filename, kind, size, sha1, added_at, "
            "note) VALUES (?,?,?,?,?,?,?)",
            (asset.path, asset.filename, asset.kind, asset.size, asset.sha1,
             utc_iso(), asset.note))
        return int(cur.lastrowid)

    def list(self) -> list[MediaAsset]:
        rows = self.db.query("SELECT * FROM media_assets ORDER BY added_at DESC")
        return [MediaAsset(id=int(r["id"]), path=r["path"], filename=r["filename"],
                           kind=r["kind"], size=int(r["size"]), sha1=r["sha1"],
                           added_at=r["added_at"], note=r["note"]) for r in rows]

    def get(self, asset_id: int) -> MediaAsset | None:
        row = self.db.query_one("SELECT * FROM media_assets WHERE id=?", (asset_id,))
        if not row:
            return None
        return MediaAsset(id=int(row["id"]), path=row["path"],
                          filename=row["filename"], kind=row["kind"],
                          size=int(row["size"]), sha1=row["sha1"],
                          added_at=row["added_at"], note=row["note"])

    def delete(self, asset_id: int) -> str | None:
        row = self.db.query_one("SELECT path FROM media_assets WHERE id=?", (asset_id,))
        if not row:
            return None
        self.db.execute("DELETE FROM media_assets WHERE id=?", (asset_id,))
        return row["path"]
