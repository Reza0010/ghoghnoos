"""ریپازیتوری کانال‌های تلگرام."""
from __future__ import annotations

from core.timeutils import utc_iso
from database.db import Database
from models.entities import Channel


class ChannelsRepo:
    def __init__(self, db: Database):
        self.db = db

    def add(self, name: str, chat_id: str, alias: str = "",
            token_key: str = "telegram.bot_token.default",
            enabled: bool = True) -> int:
        chat_id = chat_id.strip()
        if not name.strip():
            from core.errors import ValidationError
            raise ValidationError("نام کانال خالی است.", "نام کانال را وارد کنید.")
        if not chat_id:
            from core.errors import ValidationError
            raise ValidationError("شناسه کانال خالی است.",
                                  "شناسه کانال (@username یا -100…) را وارد کنید.")
        dup = self.db.query_one("SELECT id FROM channels WHERE chat_id = ?", (chat_id,))
        if dup:
            from core.errors import ValidationError
            raise ValidationError(
                f"channel exists: {chat_id}", "این کانال قبلاً اضافه شده است.")
        cur = self.db.execute(
            "INSERT INTO channels(name, chat_id, alias, enabled, token_key, created_at) "
            "VALUES (?,?,?,?,?,?)",
            (name.strip(), chat_id, alias.strip(), int(enabled), token_key, utc_iso()))
        return int(cur.lastrowid)

    def get(self, channel_id: int) -> Channel | None:
        row = self.db.query_one("SELECT * FROM channels WHERE id = ?", (channel_id,))
        return self._from_row(row) if row else None

    def get_by_chat_id(self, chat_id: str) -> Channel | None:
        row = self.db.query_one("SELECT * FROM channels WHERE chat_id = ?", (chat_id,))
        return self._from_row(row) if row else None

    def list(self, include_disabled: bool = True) -> list[Channel]:
        sql = "SELECT * FROM channels"
        if not include_disabled:
            sql += " WHERE enabled = 1"
        sql += " ORDER BY id"
        return [self._from_row(r) for r in self.db.query(sql)]

    def update(self, channel_id: int, **fields) -> None:
        allowed = {"name", "alias", "enabled", "token_key", "chat_id"}
        sets, params = [], []
        for key, value in fields.items():
            if key not in allowed:
                continue
            if key == "enabled":
                value = int(bool(value))
            sets.append(f"{key} = ?")
            params.append(value)
        if not sets:
            return
        params.append(channel_id)
        self.db.execute(f"UPDATE channels SET {', '.join(sets)} WHERE id = ?", params)

    def delete(self, channel_id: int) -> None:
        self.db.execute("DELETE FROM channels WHERE id = ?", (channel_id,))

    def set_test_result(self, channel_id: int, ok: bool, error: str | None) -> None:
        self.db.execute(
            "UPDATE channels SET last_test_at = ?, last_test_ok = ?, last_error = ? "
            "WHERE id = ?", (utc_iso(), int(ok), error, channel_id))

    @staticmethod
    def _from_row(r) -> Channel:
        return Channel(
            id=int(r["id"]), name=r["name"], chat_id=r["chat_id"],
            alias=r["alias"] or "", enabled=bool(r["enabled"]),
            token_key=r["token_key"], created_at=r["created_at"],
            last_test_at=r["last_test_at"],
            last_test_ok=None if r["last_test_ok"] is None else bool(r["last_test_ok"]),
            last_error=r["last_error"])
