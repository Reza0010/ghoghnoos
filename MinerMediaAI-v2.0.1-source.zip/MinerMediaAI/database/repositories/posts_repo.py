"""ریپازیتوری صف انتشار — با claim اتمی برای Workerهای هم‌زمان."""
from __future__ import annotations

import uuid

from config import defaults as config_defaults
from core.timeutils import backoff_delay, utc_iso, utc_now
from database.db import Database
from models.entities import ScheduledPost

RETRY_BASE = getattr(config_defaults, "RETRY_BASE_DELAY_SEC", 60)
RETRY_CAP = getattr(config_defaults, "RETRY_MAX_DELAY_SEC", 1800)


class PostsRepo:
    def __init__(self, db: Database):
        self.db = db

    # ----------------------------- ایجاد -----------------------------
    def create(self, channel_id: int, content_type: str, body: str,
               scheduled_at_utc: str, media_path: str = "",
               timezone_name: str = "Asia/Tehran", max_attempts: int = 5,
               source: str = "manual", group_uuid: str = "",
               status: str = "pending", split_long_text: bool = False) -> int:
        now = utc_iso()
        cur = self.db.execute(
            "INSERT INTO scheduled_posts(group_uuid, channel_id, content_type, body, "
            "media_path, scheduled_at, timezone, status, max_attempts, created_at, "
            "updated_at, source, split_long_text) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (group_uuid or uuid.uuid4().hex, channel_id, content_type, body,
             media_path, scheduled_at_utc, timezone_name, status, max_attempts,
             now, now, source, int(bool(split_long_text))))
        return int(cur.lastrowid)

    def create_group(self, posts: list[dict]) -> list[int]:
        """ایجاد چند پست (چندکاناله) در یک تراکنش — هر کانال رکورد مستقل."""
        gu = uuid.uuid4().hex
        ids = []
        with self.db.transaction() as conn:
            for p in posts:
                now = utc_iso()
                cur = conn.execute(
                    "INSERT INTO scheduled_posts(group_uuid, channel_id, content_type, "
                    "body, media_path, scheduled_at, timezone, status, max_attempts, "
                    "created_at, updated_at, source, split_long_text) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (gu, p["channel_id"], p.get("content_type", "text"),
                     p.get("body", ""), p.get("media_path", ""),
                     p["scheduled_at_utc"], p.get("timezone_name", "Asia/Tehran"),
                     p.get("status", "pending"), p.get("max_attempts", 5),
                     now, now, p.get("source", "manual"),
                     int(bool(p.get("split_long_text", False)))))
                ids.append(int(cur.lastrowid))
        return ids

    # ----------------------------- خواندن -----------------------------
    def get(self, post_id: int) -> ScheduledPost | None:
        row = self.db.query_one(
            "SELECT p.*, c.name AS channel_name, c.chat_id AS chat_id "
            "FROM scheduled_posts p LEFT JOIN channels c ON c.id = p.channel_id "
            "WHERE p.id = ?", (post_id,))
        return self._from_row(row) if row else None

    def list(self, status: str | None = None, channel_id: int | None = None,
             limit: int = 200) -> list[ScheduledPost]:
        sql = ("SELECT p.*, c.name AS channel_name FROM scheduled_posts p "
               "LEFT JOIN channels c ON c.id = p.channel_id WHERE 1=1")
        params: list = []
        if status:
            sql += " AND p.status = ?"
            params.append(status)
        if channel_id:
            sql += " AND p.channel_id = ?"
            params.append(channel_id)
        sql += " ORDER BY p.scheduled_at ASC LIMIT ?"
        params.append(limit)
        return [self._from_row(r) for r in self.db.query(sql, params)]

    def counts_by_status(self) -> dict[str, int]:
        rows = self.db.query(
            "SELECT status, COUNT(*) AS n FROM scheduled_posts GROUP BY status")
        return {r["status"]: int(r["n"]) for r in rows}

    # ------------------------- claim اتمی صف -------------------------
    def claim_due(self, now_utc_iso: str, limit: int = 10) -> list[ScheduledPost]:
        """پست‌های موعدرسیده pending را به‌صورت اتمی به processing می‌برد.

        claim_token تضمین می‌کند دو Worker هم‌زمان یک آیتم را نگیرند
        (UPDATE مشروط داخل BEGIN IMMEDIATE).
        """
        token = uuid.uuid4().hex
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE scheduled_posts SET status = 'processing', updated_at = ?, "
                "claim_token = ? WHERE id IN (SELECT id FROM scheduled_posts "
                "WHERE status = 'pending' AND scheduled_at <= ? "
                "ORDER BY scheduled_at ASC LIMIT ?)",
                (utc_iso(), token, now_utc_iso, limit))
            rows = conn.execute(
                "SELECT p.*, c.name AS channel_name FROM scheduled_posts p "
                "LEFT JOIN channels c ON c.id = p.channel_id "
                "WHERE p.claim_token = ?", (token,)).fetchall()
            conn.execute(
                "UPDATE scheduled_posts SET claim_token = '' WHERE claim_token = ?",
                (token,))
        return [self._from_row(r) for r in rows]

    def claim_one(self, now_utc_iso: str) -> ScheduledPost | None:
        """فقط یک پست موعدرسیده را claim می‌کند (اتمی).

        چرا تک‌تک؟ اگر برنامه هنگام خاموش‌شدن وسط یک دسته رها شود،
        آیتم‌های claim‌شدهٔ پردازش‌نشده در 'processing' می‌مانند و در بازیابی
        بعدی به‌اشتباه unknown می‌شوند. با claim تک‌تک + بررسی stop بین هر claim،
        حداکثر «یک» آیتم در لحظهٔ خاموشی در processing است و برای همان یک،
        ستون send_started_at تکلیف را مشخص می‌کند.
        """
        token = uuid.uuid4().hex
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE scheduled_posts SET status = 'processing', updated_at = ?, "
                "claim_token = ? WHERE id = (SELECT id FROM scheduled_posts "
                "WHERE status = 'pending' AND scheduled_at <= ? "
                "ORDER BY scheduled_at ASC LIMIT 1)",
                (utc_iso(), token, now_utc_iso))
            row = conn.execute(
                "SELECT p.*, c.name AS channel_name FROM scheduled_posts p "
                "LEFT JOIN channels c ON c.id = p.channel_id "
                "WHERE p.claim_token = ?", (token,)).fetchone()
            conn.execute(
                "UPDATE scheduled_posts SET claim_token = '' WHERE claim_token = ?",
                (token,))
        return self._from_row(row) if row else None

    def mark_send_started(self, post_id: int) -> None:
        """ثبت لحظه شروع واقعی درخواست ارسال — قبل از اولین بایت شبکه.

        این ستون مرز «claim شده ولی ارسال شروع نشده» (بازیابی → pending)
        با «ارسال در جریان بود» (بازیابی → unknown) است.
        """
        self.db.execute(
            "UPDATE scheduled_posts SET send_started_at = ?, updated_at = ? "
            "WHERE id = ? AND send_started_at IS NULL",
            (utc_iso(), utc_iso(), post_id))

    # ----------------------------- وضعیت‌ها -----------------------------
    def mark_sent(self, post_id: int, telegram_message_id: int | None) -> None:
        now = utc_iso()
        self.db.execute(
            "UPDATE scheduled_posts SET status='sent', telegram_message_id=?, "
            "last_error=NULL, updated_at=? WHERE id=?",
            (telegram_message_id, now, post_id))
        self.db.execute(
            "INSERT INTO published_messages(post_id, channel_id, chat_id, "
            "telegram_message_id, content_type, text_snippet, sent_at) "
            "SELECT id, channel_id, (SELECT chat_id FROM channels WHERE id=channel_id), "
            "?, content_type, substr(body,1,120), ? FROM scheduled_posts WHERE id=?",
            (telegram_message_id, now, post_id))

    def mark_failed(self, post_id: int, error: str, permanent: bool) -> None:
        self.db.execute(
            "UPDATE scheduled_posts SET status='failed', last_error=?, updated_at=? "
            "WHERE id=?", (error[:900], utc_iso(), post_id))

    def mark_unknown(self, post_id: int, error: str) -> None:
        """نتیجه مبهم — هرگز به‌صورت خودکار تکرار نمی‌شود."""
        self.db.execute(
            "UPDATE scheduled_posts SET status='unknown', last_error=?, updated_at=? "
            "WHERE id=?", (error[:900], utc_iso(), post_id))

    def schedule_retry(self, post_id: int, delay_sec: float, error: str) -> None:
        """بازگشت به صف با تأخیر (429: retry_after تلگرام؛ خطای موقت: backoff)."""
        from datetime import timedelta
        nxt = utc_now() + timedelta(seconds=max(0.0, float(delay_sec)))
        self.db.execute(
            "UPDATE scheduled_posts SET status='pending', scheduled_at=?, last_error=?, "
            "updated_at=? WHERE id=?",
            (utc_iso(nxt), error[:900], utc_iso(), post_id))

    def increment_attempt(self, post_id: int) -> int:
        self.db.execute(
            "UPDATE scheduled_posts SET attempts = attempts + 1, last_attempt_at = ?, "
            "updated_at = ? WHERE id=?", (utc_iso(), utc_iso(), post_id))
        row = self.db.query_one("SELECT attempts, max_attempts FROM scheduled_posts "
                                "WHERE id=?", (post_id,))
        return int(row["attempts"]) if row else 0

    # ------------------------ تاریخچه تلاش ------------------------
    def record_attempt_start(self, post_id: int, attempt_no: int) -> int | None:
        """ثبت شروع یک تلاش در تاریخچه؛ خروجی: شناسه رکورد (برای بستن آن)."""
        try:
            cur = self.db.execute(
                "INSERT INTO post_attempts(post_id, attempt_no, started_at, outcome) "
                "VALUES (?,?,?,'processing')", (post_id, attempt_no, utc_iso()))
            return int(cur.lastrowid) if cur.lastrowid else None
        except Exception:  # noqa: BLE001 — تاریخچه هرگز ارسال را نمی‌شکند
            return None

    def record_attempt_end(self, history_id: int | None, outcome: str,
                           detail: str = "", duration_ms: int | None = None) -> None:
        if not history_id:
            return
        try:
            self.db.execute(
                "UPDATE post_attempts SET outcome=?, detail=?, finished_at=?, "
                "duration_ms=? WHERE id=?",
                (outcome[:40], detail[:900], utc_iso(), duration_ms, history_id))
        except Exception:  # noqa: BLE001
            pass

    def attempt_history(self, post_id: int, limit: int = 20) -> list[dict]:
        rows = self.db.query(
            "SELECT attempt_no, started_at, finished_at, outcome, detail, "
            "duration_ms FROM post_attempts WHERE post_id=? "
            "ORDER BY attempt_no DESC, id DESC LIMIT ?", (post_id, limit))
        return [dict(r) for r in rows]

    def backoff_for(self, post_id: int) -> float:
        row = self.db.query_one("SELECT attempts FROM scheduled_posts WHERE id=?",
                                (post_id,))
        return backoff_delay(int(row["attempts"] or 1), RETRY_BASE, RETRY_CAP)

    def set_status(self, post_id: int, status: str, note: str | None = None) -> None:
        self.db.execute(
            "UPDATE scheduled_posts SET status=?, last_error=COALESCE(?, last_error), "
            "updated_at=? WHERE id=?", (status, note, utc_iso(), post_id))

    def reschedule(self, post_id: int, scheduled_at_utc: str) -> None:
        self.db.execute(
            "UPDATE scheduled_posts SET scheduled_at=?, status='pending', updated_at=? "
            "WHERE id=?", (scheduled_at_utc, utc_iso(), post_id))

    def cancel(self, post_id: int) -> bool:
        row = self.db.query_one("SELECT status FROM scheduled_posts WHERE id=?",
                                (post_id,))
        if not row or row["status"] not in ("pending", "draft", "failed", "unknown"):
            return False
        self.set_status(post_id, "cancelled")
        return True

    def delete(self, post_id: int) -> None:
        self.db.execute("DELETE FROM scheduled_posts WHERE id=?", (post_id,))

    def recover_at_startup(self) -> dict[str, int]:
        """بازیابی صادقانه پس از بستن ناگهانی — دو حالت متمایز:

        - processing بدون send_started_at → هرگز ارسال شروع نشده → pending
          (در چرخه بعدی ارسال می‌شود؛ بدون خطر تکرار)
        - processing با send_started_at → درخواست ارسال در جریان بود و
          نتیجه‌اش نامشخص است → unknown (ارسال مجدد خودکار ممنوع)

        خروجی: {"pending": n, "unknown": m} — شمارش واقعی هر مسیر.
        """
        cur_pending = self.db.execute(
            "UPDATE scheduled_posts SET status='pending', updated_at=? "
            "WHERE status='processing' AND send_started_at IS NULL",
            (utc_iso(),))
        n_pending = cur_pending.rowcount or 0
        cur_unknown = self.db.execute(
            "UPDATE scheduled_posts SET status='unknown', last_error=?, updated_at=? "
            "WHERE status='processing' AND send_started_at IS NOT NULL",
            ("برنامه حین ارسال بسته شد؛ نتیجهٔ درخواست در جریان نامشخص است.",
             utc_iso()))
        n_unknown = cur_unknown.rowcount or 0
        return {"pending": n_pending, "unknown": n_unknown}

    # ----------------------------- آمار -----------------------------
    def published_today_count(self, channel_id: int | None = None) -> int:
        day_start = utc_now().replace(hour=0, minute=0, second=0, microsecond=0)
        sql = "SELECT COUNT(*) AS n FROM published_messages WHERE sent_at >= ?"
        params: list = [utc_iso(day_start)]
        if channel_id:
            sql += " AND channel_id = ?"
            params.append(channel_id)
        row = self.db.query_one(sql, params)
        return int(row["n"] or 0)

    def published_per_day(self, days: int = 14) -> list[tuple[str, int]]:
        from datetime import timedelta
        start = utc_now() - timedelta(days=days)
        rows = self.db.query(
            "SELECT substr(sent_at,1,10) AS day, COUNT(*) AS n "
            "FROM published_messages WHERE sent_at >= ? GROUP BY day ORDER BY day",
            (utc_iso(start),))
        return [(r["day"], int(r["n"])) for r in rows]

    def recent_errors(self, limit: int = 10) -> list[dict]:
        rows = self.db.query(
            "SELECT id, channel_id, status, last_error AS err, updated_at AS ts "
            "FROM scheduled_posts WHERE last_error IS NOT NULL AND last_error <> '' "
            "ORDER BY updated_at DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]

    @staticmethod
    def _from_row(r) -> ScheduledPost:
        return ScheduledPost(
            id=int(r["id"]), channel_id=int(r["channel_id"]),
            content_type=r["content_type"], body=r["body"] or "",
            media_path=r["media_path"] or "", scheduled_at=r["scheduled_at"],
            timezone=r["timezone"] or "Asia/Tehran", status=r["status"],
            attempts=int(r["attempts"]), max_attempts=int(r["max_attempts"]),
            created_at=r["created_at"], updated_at=r["updated_at"],
            last_attempt_at=r["last_attempt_at"],
            telegram_message_id=r["telegram_message_id"],
            last_error=r["last_error"], group_uuid=r["group_uuid"] or "",
            source=r["source"] or "manual", channel_name=r["channel_name"] or "",
            send_started_at=r["send_started_at"] if "send_started_at" in r.keys() else None,
            split_long_text=bool(r["split_long_text"]) if "split_long_text" in r.keys() else False)
