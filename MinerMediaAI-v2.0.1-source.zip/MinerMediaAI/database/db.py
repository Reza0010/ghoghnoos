"""موتور پایگاه داده SQLite — اتصال واحد، تراکنش، مهاجرت نسخه‌بندی‌شده.

اصول:
- همه دسترسی‌های دیتابیس از طریق همین ماژول/ریپازیتوری‌ها (نه از UI)
- WAL برای هم‌زمانی خواندن/نوشتن بین Workerها و UI
- claim اتمی صف با BEGIN IMMEDIATE
- مهاجرت‌ها idempotent و نسخه‌بندی‌شده‌اند
"""
from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

from core.errors import DatabaseError
from core.logging_setup import get_logger

log = get_logger("minermedia.db")

MIGRATIONS_DIR = Path(__file__).parent / "migrations"


class Database:
    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        self._lock = threading.RLock()
        self._closed = False
        try:
            self._conn = sqlite3.connect(
                self.db_path, check_same_thread=False, timeout=15.0)
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA busy_timeout=15000")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        except sqlite3.Error as exc:
            raise DatabaseError(f"connect failed: {exc}",
                                "باز کردن پایگاه داده ناموفق بود.") from exc

    @property
    def is_closed(self) -> bool:
        """True یعنی اتصال بسته شده — Workerها قبل از نوشتن باید این را ببینند."""
        return self._closed

    # ----------------------------- زیرساخت -----------------------------
    def _guard_open(self) -> None:
        if self._closed:
            raise DatabaseError(
                "database is closed (application shutting down)",
                "پایگاه داده بسته شده است (برنامه در حال خاموش شدن است).")

    @contextmanager
    def transaction(self):
        """تراکنش اتمی: BEGIN IMMEDIATE تا COMMIT/ROLLBACK."""
        with self._lock:
            self._guard_open()
            try:
                self._conn.execute("BEGIN IMMEDIATE")
                yield self._conn
                self._conn.commit()
            except Exception as exc:
                try:
                    self._conn.rollback()
                except sqlite3.Error:
                    pass
                if isinstance(exc, DatabaseError):
                    raise
                raise DatabaseError(f"transaction failed: {exc}",
                                    "عملیات پایگاه داده ناموفق بود.") from exc

    def execute(self, sql: str, params: tuple | list = ()) -> sqlite3.Cursor:
        with self._lock:
            self._guard_open()
            try:
                cur = self._conn.execute(sql, params)
                self._conn.commit()
                return cur
            except sqlite3.Error as exc:
                raise DatabaseError(f"execute failed: {exc} | sql={sql[:120]}",
                                    "اجرای دستور پایگاه داده ناموفق بود.") from exc

    def query(self, sql: str, params: tuple | list = ()) -> list[sqlite3.Row]:
        with self._lock:
            self._guard_open()
            try:
                return self._conn.execute(sql, params).fetchall()
            except sqlite3.Error as exc:
                raise DatabaseError(f"query failed: {exc} | sql={sql[:120]}",
                                    "خواندن از پایگاه داده ناموفق بود.") from exc

    def query_one(self, sql: str, params: tuple | list = ()) -> sqlite3.Row | None:
        rows = self.query(sql, params)
        return rows[0] if rows else None

    # ----------------------------- مهاجرت‌ها -----------------------------
    def migrate(self) -> list[int]:
        """مهاجرت‌های اعمال‌نشده را به ترتیب اجرا می‌کند؛ خروجی: نسخه‌های اعمال‌شده."""
        applied: list[int] = []
        with self._lock:
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS schema_migrations ("
                "version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)")
            self._conn.commit()
            done = {r["version"] for r in
                    self._conn.execute("SELECT version FROM schema_migrations")}
            files = sorted(MIGRATIONS_DIR.glob("*.sql"))
            for path in files:
                version = int(path.stem.split("_")[0])
                if version in done:
                    continue
                sql = path.read_text(encoding="utf-8")
                try:
                    self._conn.executescript(sql)
                    self._conn.execute(
                        "INSERT INTO schema_migrations(version, applied_at) "
                        "VALUES (?, datetime('now'))", (version,))
                    self._conn.commit()
                    applied.append(version)
                    log.info("migration %s applied", version)
                except sqlite3.Error as exc:
                    self._conn.rollback()
                    raise DatabaseError(
                        f"migration {version} failed: {exc}",
                        "اجرای مهاجرت پایگاه داده ناموفق بود.") from exc
        return applied

    def schema_version(self) -> int:
        row = self.query_one(
            "SELECT MAX(version) AS v FROM schema_migrations")
        return int(row["v"] or 0) if row else 0

    def close(self) -> None:
        """بستن اتصال — idempotent؛ فقط بعد از توقف واقعی Workerها صدا زده شود.

        نکتهٔ صادقانه: این متد وضعیت اتصال را می‌بندد؛ اگر Worker زنده‌ای بعداً
        بنویسد، DatabaseError با پیام شفاف می‌گیرد (نه کرش خام sqlite).
        به همین دلیل ترتیب خاموشی در ui/main_window تضمین می‌کند اول Workerها
        واقعاً بایستند، بعد این متد فراخوانی شود.
        """
        with self._lock:
            if self._closed:
                return
            self._closed = True
            try:
                self._conn.close()
            except sqlite3.Error:
                pass
