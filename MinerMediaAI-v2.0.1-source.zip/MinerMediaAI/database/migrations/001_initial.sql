-- مهاجرت 001: طرح اولیه پایگاه داده MinerMedia AI
-- همه زمان‌ها به‌صورت ISO-8601 UTC با آفست صریح ذخیره می‌شوند.

CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    chat_id TEXT NOT NULL UNIQUE,
    alias TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 1,
    token_key TEXT NOT NULL DEFAULT 'telegram.bot_token.default',
    created_at TEXT NOT NULL,
    last_test_at TEXT,
    last_test_ok INTEGER,
    last_error TEXT
);

CREATE TABLE IF NOT EXISTS scheduled_posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_uuid TEXT NOT NULL DEFAULT '',
    channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    content_type TEXT NOT NULL DEFAULT 'text',
    body TEXT NOT NULL DEFAULT '',
    media_path TEXT NOT NULL DEFAULT '',
    scheduled_at TEXT NOT NULL,
    timezone TEXT NOT NULL DEFAULT 'Asia/Tehran',
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('draft','pending','processing','sent','failed','unknown','cancelled')),
    attempts INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 5,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    last_attempt_at TEXT,
    telegram_message_id INTEGER,
    last_error TEXT,
    source TEXT NOT NULL DEFAULT 'manual',
    claim_token TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_posts_status_sched ON scheduled_posts(status, scheduled_at);
CREATE INDEX IF NOT EXISTS idx_posts_channel ON scheduled_posts(channel_id);
CREATE INDEX IF NOT EXISTS idx_posts_group ON scheduled_posts(group_uuid);

CREATE TABLE IF NOT EXISTS published_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER REFERENCES scheduled_posts(id) ON DELETE SET NULL,
    channel_id INTEGER NOT NULL,
    chat_id TEXT NOT NULL,
    telegram_message_id INTEGER,
    content_type TEXT NOT NULL DEFAULT 'text',
    text_snippet TEXT NOT NULL DEFAULT '',
    sent_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_published_channel_time ON published_messages(channel_id, sent_at);

CREATE TABLE IF NOT EXISTS market_watchlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL DEFAULT '',
    visible INTEGER NOT NULL DEFAULT 1,
    sort_order INTEGER NOT NULL DEFAULT 0,
    added_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS market_prices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    market TEXT NOT NULL,
    price REAL,
    currency TEXT NOT NULL,
    source TEXT NOT NULL,
    fetched_at TEXT NOT NULL,
    day_change REAL,
    day_high REAL,
    day_low REAL,
    day_open REAL,
    best_buy REAL,
    best_sell REAL,
    volume_src REAL,
    volume_dst REAL,
    is_closed INTEGER NOT NULL DEFAULT 0,
    stale INTEGER NOT NULL DEFAULT 0,
    UNIQUE(symbol, market)
);
CREATE INDEX IF NOT EXISTS idx_prices_symbol ON market_prices(symbol, market);

CREATE TABLE IF NOT EXISTS price_samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    market TEXT NOT NULL,
    price REAL NOT NULL,
    currency TEXT NOT NULL,
    sampled_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_samples_symbol_time ON price_samples(symbol, market, sampled_at);

CREATE TABLE IF NOT EXISTS news_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guid TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    link TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT '',
    topic TEXT NOT NULL DEFAULT '',
    published_at TEXT,
    fetched_at TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'new'
        CHECK (status IN ('new','reviewed','approved','rejected','converted')),
    dedupe_hash TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_news_status_time ON news_items(status, published_at);

CREATE TABLE IF NOT EXISTS content_drafts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    ctype TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    body TEXT NOT NULL DEFAULT '',
    hashtags TEXT NOT NULL DEFAULT '',
    media_path TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft','review','approved','scheduled','rejected','published')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    approved_at TEXT,
    meta TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS generation_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    draft_id INTEGER REFERENCES content_drafts(id) ON DELETE SET NULL,
    category TEXT NOT NULL DEFAULT '',
    ctype TEXT NOT NULL DEFAULT '',
    provider TEXT NOT NULL DEFAULT '',
    model TEXT NOT NULL DEFAULT '',
    prompt_tokens INTEGER,
    completion_tokens INTEGER,
    ok INTEGER NOT NULL DEFAULT 1,
    error TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS operation_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    level TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'GENERAL',
    message TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_logs_ts ON operation_logs(ts DESC);

CREATE TABLE IF NOT EXISTS media_assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT NOT NULL UNIQUE,
    filename TEXT NOT NULL,
    kind TEXT NOT NULL,
    size INTEGER NOT NULL DEFAULT 0,
    sha1 TEXT NOT NULL DEFAULT '',
    added_at TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT ''
);
