-- مهاجرت 002: سخت‌سازی پایداری (v2.0.1)
-- 1) send_started_at: تفکیک «claim شده ولی ارسال شروع نشده» از «ارسال در جریان بود»
--    - processing + send_started_at IS NULL  → بازیابی: pending (ارسالی در کار نبود)
--    - processing + send_started_at NOT NULL → بازیابی: unknown (نتیجه واقعاً نامشخص)
-- 2) split_long_text: سیاست صریح متن بلند همراه رسانه (ارسال متن کامل به‌صورت
--    پیام جداگانه) — هیچ متنی بی‌صدا حذف نمی‌شود.
-- 3) post_attempts: تاریخچه تلاش‌های هر پست (429، خطای موقت، خطای دائمی، ارسال موفق...)

ALTER TABLE scheduled_posts ADD COLUMN send_started_at TEXT;
ALTER TABLE scheduled_posts ADD COLUMN split_long_text INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS post_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL REFERENCES scheduled_posts(id) ON DELETE CASCADE,
    attempt_no INTEGER NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    outcome TEXT NOT NULL DEFAULT '',
    detail TEXT NOT NULL DEFAULT '',
    duration_ms INTEGER
);
CREATE INDEX IF NOT EXISTS idx_attempts_post ON post_attempts(post_id, attempt_no);
